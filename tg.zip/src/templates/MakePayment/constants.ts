import { ReactComponent as AlipayIcon } from '@src/assets/svg/make-payment-alipay.svg';
import { ReactComponent as GooglePayIcon } from '@src/assets/svg/make-payment-google-pay.svg';
import { ReactComponent as CCIcon } from '@src/assets/svg/make-payment-cc.svg';
import { ReactComponent as ApplePayIcon } from '@src/assets/svg/make-payment-apple.svg';
import { ReactComponent as PaypalIcon } from '@src/assets/svg/make-payment-paypal.svg';
import { PaymentMethod } from '@src/lib/payment/braintree';
import { SubmitFailureErrorCodes } from '@src/lib/payment/postMessage';
import { CommonErrorContentResponse } from '@src/lib/api/types';

export type PaymentMethods = PaymentMethod | '';
export type OfflinePaymentFailureErrorCodes =
  | SubmitFailureErrorCodes
  | 'DUPLICATE_PAYMENT_ERROR'
  | 'DEFAULT'
  | 'EXPIRED_LINK'
  | 'INVALID_LINK'
  | 'DETAILS_NOT_FOUND'
  | 'PAGE_ERROR'
  | '';
export type OfflinePaymentError = {
  [errorCodes in OfflinePaymentFailureErrorCodes]?: CommonErrorContentResponse;
};
export type ErrorObj = {
  [paymentType in PaymentMethods | 'DEFAULT']: OfflinePaymentError;
};
export enum PaymentJourneySlug {
  PREPAID_ACTIVATION = 'PrepaidActivation',
  POSTPAID_PAYMENT = 'PostpaidPayment',
  POSTPAID_PRE_PAYMENT = 'PostpaidPrePayment',
}
export type PaymentMethodConfig = {
  title: string;
  subTitle?: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
  component: PaymentMethods;
  infoText: string;
};
const PAYMENTERRORS: OfflinePaymentError = {
  CUSTOMER_ERROR: {
    alertTitle: 'We’re unable to process your payment',
    alertText: 'Please check your details before trying again or use a different card.',
    primaryCtaLabel: 'Try again',
  },
  VFE_3DS_LIABILITY_NOT_SHIFTED: {
    alertTitle: 'We’re unable to process your payment',
    alertText: 'Please check your details and try again or use a different payment method.',
    primaryCtaLabel: 'Try again',
  },
  VODAFONE_ERROR: {
    alertTitle: 'Something didn’t go as planned',
    alertText: 'Unfortunately, we’re experiencing a technical issue.',
    primaryCtaLabel: 'Try again',
  },
  HIGH_RISK_ERROR: {
    alertTitle: 'We’re unable to accept this card',
    alertText: 'We can’t process your request using this card. Please use a different card.',
    primaryCtaLabel: 'Try again',
  },
  DUPLICATE_PAYMENT_ERROR: {
    alertTitle: 'Your payment has been processed',
    alertText: 'Please check your email for a Vodafone order confirmation.',
    primaryCtaLabel: 'Try again',
  },
  DEFAULT: {
    alertTitle: 'Payment failed',
    alertText: 'We’re unable to process your payment. Please try again.',
    primaryCtaLabel: 'Try again',
  },
};
export const MakePaymentPageData = {
  seoTitle: 'Make a Payment | Vodafone Australia',
  metaTag:
    '&lt;title&gt;Make a Payment | Vodafone Australia&lt;/title&gt;&lt;meta name="title" content="Make a Payment | Vodafone Australia"/&gt;&lt;meta name="robots" content="noindex, nofollow"/&gt;',
  reviewAndPayTitle: 'Review & Pay',
  prepaidRechargeText: 'You are recharging mobile:',
  youPayText: 'You pay',
  choosePaymentTitle: 'How would you like to pay?',
  paymentMethodConfig: [
    { title: 'Credit or debit card', icon: CCIcon, component: 'CREDITCARD', infoText: '' },
    {
      title: 'PayPal',
      subTitle: 'Pay now or Pay in 4',
      icon: PaypalIcon,
      component: 'PAYPAL',
      infoText:
        'After agreeing to the terms and clicking &lt;b&gt;Pay with PayPal&lt;/b&gt; below, you will be redirected to PayPal where you&apos;ll have the option to pay everything now or use Pay in 4 to complete your payment.',
    },
    {
      title: 'Apple Pay',
      icon: ApplePayIcon,
      component: 'APPLEPAY',
      infoText:
        'After agreeing to the terms and clicking &lt;b&gt;Pay with Apple Pay&lt;/b&gt; below, confirm your payment in the Apple Pay pop-up.',
    },
    {
      title: 'Google Pay',
      icon: GooglePayIcon,
      component: 'GOOGLEPAY',
      infoText:
        'After agreeing to the terms and clicking &lt;b&gt;Pay with Google Pay&lt;/b&gt; below, confirm your payment in the Google Pay pop-up.',
    },
    {
      title: 'Alipay',
      icon: AlipayIcon,
      component: 'ALIPAY',
      infoText:
        'After agreeing to the terms and clicking &lt;b&gt;Pay with Alipay&lt;/b&gt; below, confirm your payment in the Alipay app.',
    },
  ] as PaymentMethodConfig[],
  termsAndConditionHeroMsg: 'Lastly, agree to the terms and make your payment.',
  termsAndConditionConsentMsg:
    'I authorise Vodafone to charge my nominated payment method and have read and agree to the &lt;a href=&quot;https://www.vodafone.com.au/about/legal/standard-form-of-agreement&quot; target=&quot;_blank&quot;&gt;Terms and conditions&lt;/a&gt; and &lt;a href=&quot;https://www.vodafone.com.au/about/legal/privacy&quot; target=&quot;_blank&quot;&gt;Privacy policy&lt;/a&gt;.',
  securityText: 'Your payment is safe and secure.',
  reviewAndPayConfig: {
    [PaymentJourneySlug.PREPAID_ACTIVATION]: { title: 'Prepaid Plan', subText: '', paymentType: 'one-off cost' },
    [PaymentJourneySlug.POSTPAID_PAYMENT]: {
      title: 'Make a payment',
      subText: 'Vodafone account number:',
      paymentType: 'one-off payment',
    },
    [PaymentJourneySlug.POSTPAID_PRE_PAYMENT]: {
      title: 'Make a prepayment',
      subText: 'Your order number:',
      paymentType: 'one-off prepayment',
    },
  },
  paymentInProgress: {
    processingPaymentTitle: 'Processing payment',
    processingPaymentSubTitle: 'Please don’t leave this page',
  },
  paymentErrors: {
    ALIPAY: {
      ...PAYMENTERRORS,
      ALIPAY_UNAVAILABLE_ERROR: {
        alertTitle: 'Something didn’t go as planned',
        alertText: 'Alipay is currently unavailable. Please try again or use a different payment method.',
        primaryCtaLabel: 'Try again',
      },
      ALIPAY_DUPLICATE_SUBMIT_PAYMENT_ERROR: {
        alertTitle: 'Payment already in progress',
        alertText: 'It looks like you’ve already attempted to make a payment. Please check your Alipay account.',
        primaryCtaLabel: 'Try again',
      },
      ALIPAY_PAYMENT_CANCELLED: {
        alertTitle: 'Something didn’t go as planned',
        alertText: 'Please try again or use a different payment method.',
        primaryCtaLabel: 'Try again',
      },
    },
    APPLEPAY: { ...PAYMENTERRORS },
    CREDITCARD: { ...PAYMENTERRORS },
    GOOGLEPAY: { ...PAYMENTERRORS },
    PAYPAL: { ...PAYMENTERRORS },
    DEFAULT: {
      EXPIRED_LINK: {
        alertTitle: 'Expired link',
        alertText:
          'This payment link has expired. To request another link, please ask customer care or give us a call on 1300 650 410.',
      },
      INVALID_LINK: {
        alertTitle: 'Invalid link',
        alertText:
          'This payment link is no longer valid as you’ve already made your payment. If you need help, please call us on 1300 650 410.',
        primaryCtaLabel: 'Try again',
      },
      DETAILS_NOT_FOUND: {
        alertTitle: 'Something didn’t go as planned',
        alertText:
          'Unfortunately, we’re unable to display your payment details. If you need help, please call us on 1300 650 410.',
        primaryCtaLabel: 'Try again',
      },
      PAGE_ERROR: {
        alertTitle: 'Something didn’t go as planned',
        alertText:
          'Unfortunately due to a technical issue, this page is currently unavailable. Please refresh this page or try again.',
        primaryCtaLabel: 'Try again',
      },
      DEFAULT: {
        alertTitle: 'Something didn’t go as planned',
        alertText:
          'Unfortunately due to a technical issue, this page is currently unavailable. Please refresh this page or try again.',
        primaryCtaLabel: 'Try again',
      },
    },
  } as ErrorObj,
  mandatoryFieldSelectionErrorMsg:
    'There are mandatory fields which have not been completed. Please complete all empty fields.',
};
