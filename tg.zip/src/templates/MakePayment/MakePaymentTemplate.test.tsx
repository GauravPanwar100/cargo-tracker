import React from 'react';
import { render } from 'test-utils';
import MakePaymentTemplate, { MakePaymentTemplateProps } from '@src/templates/MakePayment/MakePaymentTemplate';
import { Flag } from '@src/lib/context/feature-flags';

jest.mock('@src/lib/context/feature-flags', () => ({
  __esModule: true,
  useFeatureFlag: () => ({ data: false }),
  useRedirectFeatureFlag: jest.fn(),
  Flag: {
    DISABLE_MAKE_PAYMENT_JOURNEY_BUSINESS: '',
    DISABLE_MAKE_PAYMENT_JOURNEY_OPERATIONAL: '',
  },
}));

const defaultProps: MakePaymentTemplateProps = {
  redirectFlag: {
    businessRedirect: Flag.DISABLE_MAKE_PAYMENT_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_MAKE_PAYMENT_JOURNEY_OPERATIONAL,
  },
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<MakePaymentTemplate {...props} />);
  return { utils, props };
};

describe('MakePaymentTemplate', () => {
  it.each([
    { elementId: 'make-payment-reviewAndPayTitle' },
    { elementId: 'ReviewAndPayContainer' },
    { elementId: 'make-payment-choosePaymentTitle' },
    { elementId: 'make-payment-payment-methods-section' },
    { elementId: 'make-payment-tAndCHero' },
    { elementId: 'make-payment-tAndC-consent' },
  ] as const)('should render make payment template components', ({ elementId }) => {
    const { utils } = setup();
    expect(utils.getByTestId(elementId)).toBeDefined();
  });
});
