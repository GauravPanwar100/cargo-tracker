import styled from 'styled-components';
import { MixinProperty, marginBottomMixin, marginTopMixin, media } from '@src/lib/util/mixins';

export const MainContainer = styled.div`
  ${media.m`
    max-width: 1180px;
    background-color: ${(p) => p.theme.colors.lightGrey};
    width: auto;
    margin: auto;
    padding: 48px 0 60px;
  `}
`;

interface ContainerWrapperProps {
  marginBottom?: MixinProperty;
}

export const ContainerWrapper = styled.div<ContainerWrapperProps>`
  margin: 0 auto;
  ${media.m`
    display: block;
    max-width: 600px;
  `}
  ${(p) => marginBottomMixin(p.marginBottom)};
`;

interface FlexContainerProps {
  marginBottom?: MixinProperty<string>;
  marginTop?: MixinProperty<string>;
}

export const FlexContainer = styled.div<FlexContainerProps>`
  ${(p) => marginBottomMixin(p.marginBottom)}
  ${(p) => marginTopMixin(p.marginTop)}
  display: flex;
  &.verticalAlign {
    align-items: center;
  }
  &.spaceBetween {
    justify-content: space-between;
  }
  &.directionColumn {
    flex-direction: column;
    margin-left: 10px;
  }
  &.buttonContainer {
    width: 100%;
    ${media.m`
      width: 260px;
      width: auto;
      justify-content: right;
      margin-left: auto;
      margin-right: 0px;
    `}
    & div {
      ${media.m`
        margin-right: 0px;
        margin-left: auto;
        width: auto;
      `}
    }
  }
`;

export const Card = styled.div`
  border-radius: ${(p) => p.theme.sizes.borderRadius}px;
  box-shadow: ${(p) => p.theme.boxShadows.brand};
  overflow: hidden;
`;

export const PaymentProcessContainer = styled.div`
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background-color: ${(p) => p.theme.colors.aluminium};
`;

export const RelativeContainer = styled.div`
  position: relative;
  &.buttonContainer {
    width: 100%;
  }
`;

export const AlipayButtonStyle = `
  width: 100%;
  border: 1px solid grey;
  border-radius: 6px;
`;

export const PaymentFailureContainer = styled.div`
  min-height: 80vh;
  background-color: ${(p) => p.theme.colors.aluminium};
`;

export const SpinnerContainer = styled.div`
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
`;

interface IframeButtonContainerProps {
  showButton: boolean;
}
export const IframeButtonContainer = styled.div<IframeButtonContainerProps>`
  display: none;
  ${(p) => p.showButton && 'display: block;'}
`;

interface DividerWrapProps {
  marginBottom: MixinProperty<string>;
  marginTop: MixinProperty<string>;
}

export const DividerWrap = styled.div<DividerWrapProps>`
  ${(p) => marginBottomMixin(p.marginBottom)}
  ${(p) => marginTopMixin(p.marginTop)}
`;
