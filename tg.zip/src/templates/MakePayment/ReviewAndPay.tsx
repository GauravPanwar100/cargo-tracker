import IconWrapper from '@src/components/core/IconWrapper';
import Section from '@src/components/core/Section';
import { Card, DividerWrap, FlexContainer } from '@src/templates/MakePayment/MakePaymentTemplate.styles';
import React from 'react';
import { ReactComponent as PrepaidSimIcon } from '@src/assets/svg/make-payment-prepaid-sim-icon.svg';
import { ReactComponent as PrepaidSimSmallIcon } from '@src/assets/svg/make-payment-prepaid-sim-icon-small.svg';
import Text from '@src/components/core/Text';
import Divider from '@src/components/core/Divider';
import { MakePaymentPageData, PaymentJourneySlug } from '@src/templates/MakePayment/constants';
import { lightTheme } from '@src/lib/theme';

export interface ReviewAndPayProps {
  isSmallDevice: boolean;
  journeyType: PaymentJourneySlug;
  orderId: string;
}

const ReviewAndPay: React.FC<ReviewAndPayProps> = ({ isSmallDevice, journeyType, orderId }) => {
  const { youPayText, reviewAndPayConfig } = MakePaymentPageData;
  const paymentPageData = reviewAndPayConfig[journeyType];
  const isPrepaidActivationJourney = journeyType === PaymentJourneySlug.PREPAID_ACTIVATION;
  return (
    <Card data-testid="ReviewAndPayContainer">
      <Section
        spacingTop={{ xs: 'xxs', m: 'xs' }}
        spacingLeft={{ xs: '16px', m: '20px' }}
        spacingBottom={{ xs: 'xs', m: 'xs' }}
        spacingRight={{ xs: '16px', m: '20px' }}
        backgroundColorValue={lightTheme.variants.backgroundColor}
      >
        <FlexContainer>
          <FlexContainer className="verticalAlign">
            {isPrepaidActivationJourney && (
              <IconWrapper
                marginRight={{ xs: '12px', m: '20px' }}
                height={{ xs: '37px', m: '76px' }}
                svg={isSmallDevice ? PrepaidSimSmallIcon : PrepaidSimIcon}
                width={{ xs: '37px', m: '76px' }}
              />
            )}
          </FlexContainer>
          <div>
            <Text
              fontSize={{ xs: 'base', m: 'baseLarge' }}
              lineHeight={{ xs: 'base', m: 'heading5' }}
              fontFamily={{ xs: 'bold' }}
              data-testid="review-and-pay-plan-title"
            >
              {paymentPageData.title}
            </Text>
            <Text
              fontSize={
                isPrepaidActivationJourney
                  ? { xs: 'baseSmall', m: 'heading4' }
                  : { xs: 'heading6Mobile', m: 'heading4Tablet' }
              }
              lineHeight={
                isPrepaidActivationJourney
                  ? { xs: 'footnote', m: 'heading5Tablet' }
                  : { xs: 'base', m: 'heading5Tablet' }
              }
              fontFamily={isPrepaidActivationJourney ? { xs: 'regular', m: 'light' } : { xs: 'light', m: 'light' }}
              marginTop={{ xs: '8px' }}
              data-testid="review-and-pay-plan-subTitle"
            >
              {isPrepaidActivationJourney ? orderId : `${paymentPageData.subText} ${orderId}`}
            </Text>
          </div>
        </FlexContainer>
        <DividerWrap marginTop={{ xs: '24px', m: '28px' }} marginBottom={{ xs: '12px', m: '8px' }}>
          <Divider />
        </DividerWrap>
        <FlexContainer className="spaceBetween">
          <div>
            <Text
              fontSize={{ xs: 'base', m: 'baseLarge' }}
              lineHeight={{ xs: 'base', m: 'heading5Tablet' }}
              fontFamily={{ xs: 'regular' }}
              data-testid="review-and-pay-you-pay-title"
            >
              {youPayText}
            </Text>
          </div>
          <div>
            <Text
              fontSize={{ xs: 'heading4Mobile', m: 'heading4' }}
              lineHeight={{ xs: 'heading5Mobile', m: 'heading5Tablet' }}
              fontFamily={{ xs: 'bold' }}
              data-testid="review-and-pay-amount"
              textAlign="right"
            >
              $40.00
            </Text>
            <Text
              fontSize={{ xs: 'baseSmall', m: 'baseLarge' }}
              lineHeight={{ xs: 'footnoteMobile', m: 'priceSmall' }}
              fontFamily={{ xs: 'regular' }}
              data-testid="review-and-pay-payment-type"
            >
              {paymentPageData.paymentType}
            </Text>
          </div>
        </FlexContainer>
      </Section>
    </Card>
  );
};

export default ReviewAndPay;
