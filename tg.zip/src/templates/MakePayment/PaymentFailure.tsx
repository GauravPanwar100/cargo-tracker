import CommonError from '@src/components/vfe/CommonError/CommonError';
import { PaymentFailureContainer } from '@src/templates/MakePayment/MakePaymentTemplate.styles';
import {
  MakePaymentPageData,
  OfflinePaymentFailureErrorCodes,
  PaymentMethods,
} from '@src/templates/MakePayment/constants';
import React from 'react';

export interface PaymentFailureProps {
  activePaymentComponent?: PaymentMethods;
  errorCode: OfflinePaymentFailureErrorCodes;
}

const PaymentFailure: React.FC<PaymentFailureProps> = ({ activePaymentComponent, errorCode }) => {
  const { paymentErrors } = MakePaymentPageData;
  const alertContent = () => {
    if (activePaymentComponent && errorCode) {
      return paymentErrors[activePaymentComponent][errorCode] ?? paymentErrors[activePaymentComponent].DEFAULT;
    }
    return paymentErrors.DEFAULT[errorCode] ?? paymentErrors.DEFAULT.DEFAULT;
  };
  return (
    <PaymentFailureContainer>
      <CommonError errorContent={alertContent()} reloadPageOnCTAClick={true} />
    </PaymentFailureContainer>
  );
};

export default PaymentFailure;
