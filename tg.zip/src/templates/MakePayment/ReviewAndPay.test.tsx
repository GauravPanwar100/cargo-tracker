import React from 'react';
import { render } from 'test-utils';
import ReviewAndPay, { ReviewAndPayProps } from '@src/templates/MakePayment/ReviewAndPay';
import { MakePaymentPageData, PaymentJourneySlug } from '@src/templates/MakePayment/constants';

const defaultProps: ReviewAndPayProps = {
  isSmallDevice: true,
  journeyType: PaymentJourneySlug.PREPAID_ACTIVATION,
  orderId: '1036675',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<ReviewAndPay {...props} />);
  return { utils, props };
};

describe('ReviewAndPay component', () => {
  it('renders ReviewAndPay component - PREPAID_ACTIVATION', () => {
    const { utils } = setup();
    expect(utils.getByRole('presentation')).toBeInTheDocument();
    expect(utils.getByTestId('ReviewAndPayContainer')).toBeDefined();
  });
  it.each([
    { journeyType: PaymentJourneySlug.PREPAID_ACTIVATION },
    { journeyType: PaymentJourneySlug.POSTPAID_PAYMENT },
    { journeyType: PaymentJourneySlug.POSTPAID_PRE_PAYMENT },
  ] as const)('should render make payment template components', ({ journeyType }) => {
    const paymentPageData = MakePaymentPageData.reviewAndPayConfig[journeyType];
    const { utils } = setup({ journeyType });

    expect(utils.getByTestId('review-and-pay-plan-title').innerHTML).toContain(paymentPageData.title);
    expect(utils.getByTestId('review-and-pay-payment-type').innerHTML).toContain(paymentPageData.paymentType);
  });
});
