import React from 'react';

export interface PaymentSuccessProps {}

const PaymentSuccess: React.FC<PaymentSuccessProps> = () => {
  return <div>Payment Success</div>;
};

export default PaymentSuccess;
