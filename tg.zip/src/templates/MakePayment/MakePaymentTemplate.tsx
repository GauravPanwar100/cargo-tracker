import SeoHead from '@src/components/vfe/SeoHead';
import { RedirectFlag, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { MaintenancePage } from '@src/lib/util/error';
import React, { ChangeEvent, useEffect, useRef, useState } from 'react';
import Text from '@src/components/core/Text';
import {
  AlipayButtonStyle,
  ContainerWrapper,
  DividerWrap,
  FlexContainer,
  MainContainer,
  RelativeContainer,
} from '@src/templates/MakePayment/MakePaymentTemplate.styles';
import Section from '@src/components/core/Section';
import Divider from '@src/components/core/Divider';
import {
  MakePaymentPageData,
  OfflinePaymentFailureErrorCodes,
  PaymentJourneySlug,
  PaymentMethodConfig,
  PaymentMethods,
} from '@src/templates/MakePayment/constants';
import { breakpoints, midTheme } from '@src/lib/theme';
import IconWrapper from '@src/components/core/IconWrapper';
import Checkbox from '@src/components/core/Checkbox';
import Radio from '@src/components/core/Radio/Radio';
import CCPay from '@src/templates/MakePayment/PaymentMethods/CCPay';
import APM from '@src/templates/MakePayment/PaymentMethods/APM';
import ReviewAndPay from '@src/templates/MakePayment/ReviewAndPay';
import useWindowSize from '@src/lib/hooks/use-window-size';
import { ThemeProvider } from 'styled-components';
import CCButton from '@src/templates/MakePayment/PaymentButtons/CCButton';
import { AccountType } from '@src/lib/api/types';
import PaymentInProgress from '@src/templates/MakePayment/PaymentInProgress';
import { ReceivedMessageType, SendMessageType } from '@src/lib/payment/postMessage';
import { TestIframeProps } from '@src/templates/Payment/TestIframe';
import PaymentFailure from '@src/templates/MakePayment/PaymentFailure';
import PaymentSuccess from '@src/templates/MakePayment/PaymentSuccess';
import { scrollElementIntoView } from '@src/lib/util/dom';
import APMButton from '@src/templates/MakePayment/PaymentButtons/APMButton';
import IframeRenderError from '@src/templates/MakePayment/PaymentMethods/IframeRenderError';
import RichText from '@src/components/core/RichText';
import Alert from '@src/components/core/Alert';
import DefaultButton from '@src/templates/MakePayment/PaymentButtons/DefaultButton';

export interface MakePaymentTemplateProps {
  redirectFlag: RedirectFlag;
}

const MakePaymentTemplate: React.FC<MakePaymentTemplateProps> = ({ redirectFlag }) => {
  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });
  const {
    seoTitle,
    metaTag,
    reviewAndPayTitle,
    prepaidRechargeText,
    choosePaymentTitle,
    paymentMethodConfig,
    termsAndConditionConsentMsg,
    termsAndConditionHeroMsg,
    mandatoryFieldSelectionErrorMsg,
  } = MakePaymentPageData;
  const paymentContainerRef = useRef<HTMLDivElement>(null);
  const alertContentRef = useRef<HTMLDivElement>(null);
  const [activePaymentComponent, setActivePaymentComponent] = useState<PaymentMethods>('');
  const [paymentMethodOptions, setPaymentMethodOptions] = useState<PaymentMethodConfig[]>([]);
  const [tncAcceptance, setTncAcceptance] = useState(false);
  const [isPaymentInProgress, setIsPaymentInProgress] = useState<boolean>(false);
  const [paymentFailureCode, setPaymentFailureCode] = useState<OfflinePaymentFailureErrorCodes>('');
  const [iframeRenderErrorCode, setIframeRenderErrorCode] = useState<OfflinePaymentFailureErrorCodes>('');
  const [showPaymentSuccess, setShowPaymentSuccess] = useState<boolean>(false);
  const [showAPMButtonLoader, setShowAPMButtonLoader] = useState<boolean>(true);
  const [isCCPaymentLoading, setIsCCPaymentLoading] = useState<boolean>(true);
  const [alertContent, setAlertContent] = useState<string>('');
  const { width } = useWindowSize();
  const isSmallDevice = (width && width < breakpoints.m) as boolean;
  // Need the get the below value from Get Order API
  const paymentDetails: TestIframeProps = {
    accounttype: AccountType.PREPAY,
    PAYMENT_METHOD: 'CREDITCARD',
    FLOW_TYPE: 'CHARGE',
    ORDER_ID: 'VDFO-12345',
    'X-SESSION_ID': 'abcdef1234567890',
    AMOUNT: '50.00',
    HMAC: '32f64855738384b3f409d0d976cc18ceb0d6032638973195ac41d0745efb9b4d',
  };
  const customerDetails: Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload'] = {
    email: 'test.approve@vodafone.com.au',
    phone: '0425567782',
    firstName: 'Test',
    lastName: 'User',
  };
  const scrollToPaymentMethods = () => {
    scrollElementIntoView(paymentContainerRef.current);
  };
  const scrollToPageAlert = () => {
    scrollElementIntoView(alertContentRef.current);
  };
  const defaultButtonClickHandler = () => {
    setAlertContent(mandatoryFieldSelectionErrorMsg);
    scrollToPageAlert();
  };
  useEffect(() => {
    setPaymentMethodOptions(
      paymentMethodConfig.filter((paymentItem) => {
        return !(
          paymentItem.component === 'APPLEPAY' &&
          !window.ApplePaySession &&
          // @ts-ignore
          !window.ApplePaySession?.canMakePayments()
        );
      }),
    );
  }, [paymentMethodConfig]);
  useEffect(() => {
    const handler = (event: MessageEvent<SendMessageType>) => {
      const eventData = event?.data;
      if (eventData && eventData.source === 'vfe') {
        switch (eventData.type) {
          case 'VFE_IFRAME_READY':
            if (eventData.iframe === 'CC') setIsCCPaymentLoading(false);
            else if (
              eventData.iframe === 'PAYPAL' ||
              eventData.iframe === 'APPLE_PAY' ||
              eventData.iframe === 'GOOGLE_PAY' ||
              eventData.iframe === 'ALIPAY'
            ) {
              setTimeout(() => {
                const iframeContentWindow = document?.querySelector('iframe')?.contentWindow;
                iframeContentWindow?.postMessage({
                  source: 'omniscript',
                  type: 'CUSTOMER_DETAILS',
                  payload: customerDetails,
                });
                if (eventData.iframe === 'ALIPAY')
                  iframeContentWindow?.document
                    .getElementById('alipay-button')
                    ?.setAttribute('style', AlipayButtonStyle);
              }, 500);
              if (eventData.iframe !== 'PAYPAL') setShowAPMButtonLoader(false);
            }
            break;
          case 'PAYMENT_CLIENT_READY':
            setShowAPMButtonLoader(false);
            break;
          case 'CC_REQUEST_INITIATED':
            setIsPaymentInProgress(true);
            window.scrollTo(0, 0);
            break;
          case 'SUBMIT_INITIATED':
            setIsPaymentInProgress(true);
            window.scrollTo(0, 0);
            break;
          case '3DS_CARD_VERIFIED':
            setIsPaymentInProgress(true);
            window.scrollTo(0, 0);
            break;
          case '3DS_MODAL_RENDERED':
            scrollToPaymentMethods();
            setIsPaymentInProgress(false);
            break;
          case 'SUBMIT_SUCCESS':
            setIsPaymentInProgress(false);
            setShowPaymentSuccess(true);
            break;
          case 'SUBMIT_FAILURE':
            if (eventData.code !== 'CUSTOMER_ERROR') {
              // We are skipping the CUSTOMER_ERROR to show the inline error messages in CC Form
              setIsPaymentInProgress(false);
              setPaymentFailureCode(eventData.code);
            }
            break;
          case 'VFE_IFRAME_FAILED':
            setIsPaymentInProgress(false);
            setIframeRenderErrorCode('VODAFONE_ERROR');
            scrollToPaymentMethods();
            break;
          default:
        }
      }
    };

    window.addEventListener('message', handler);

    // clean up
    return () => window.removeEventListener('message', handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const getPaymentComponent = (paymentItem: PaymentMethodConfig) => {
    switch (paymentItem.component) {
      case 'CREDITCARD':
        return <CCPay paymentDetails={paymentDetails} isLoading={isCCPaymentLoading} />;
      case 'PAYPAL':
      case 'APPLEPAY':
      case 'GOOGLEPAY':
      case 'ALIPAY':
        return <APM infoText={paymentItem.infoText} />;
      default:
        return <></>;
    }
  };
  const getPaymentButton = () => {
    switch (activePaymentComponent) {
      case 'CREDITCARD':
        return <CCButton customerDetails={customerDetails} isLoading={isCCPaymentLoading} />;
      case 'PAYPAL':
      case 'APPLEPAY':
      case 'GOOGLEPAY':
      case 'ALIPAY':
        return <APMButton showAPMButtonLoader={showAPMButtonLoader} paymentMethod={activePaymentComponent} />;
      default:
        return <DefaultButton clickHandler={defaultButtonClickHandler} />;
    }
  };
  const onPaymentMethodChange = (event: ChangeEvent<HTMLInputElement>) => {
    const paymentType = event.target.value as PaymentMethods;
    setActivePaymentComponent(paymentType);
    setIframeRenderErrorCode('');
    setAlertContent('');
    if (paymentType === 'CREDITCARD') {
      setIsCCPaymentLoading(true);
    } else {
      setShowAPMButtonLoader(true);
    }
  };
  const handleTncChange = () => {
    setTncAcceptance(!tncAcceptance);
    setAlertContent('');
  };
  // Need to update the value based on the API response
  const isPrepaidActivationJourney = true;

  if (paymentFailureCode) {
    return <PaymentFailure activePaymentComponent={activePaymentComponent} errorCode={paymentFailureCode} />;
  }
  if (showPaymentSuccess) {
    return <PaymentSuccess />;
  }
  return (
    <ThemeProvider theme={midTheme}>
      <SeoHead title={seoTitle} aemMetaTags={metaTag} structuredData={[]} />
      <Section spacingTop={{ xs: 'xxs', m: 'l' }} spacingBottom={{ xs: 'l', m: 'l' }}>
        <RelativeContainer>
          {isPaymentInProgress && <PaymentInProgress isSmallDevice={isSmallDevice} />}
          <MainContainer>
            <ContainerWrapper>
              <Text
                fontSize={{ xs: 'heading1Mobile', m: 'heading1Tablet' }}
                lineHeight={{ xs: 'heading1Mobile', m: 'heading1Tablet' }}
                fontFamily={{ xs: 'light', m: 'light' }}
                marginBottom={{ xs: '32px', m: '48px' }}
                data-testid="make-payment-reviewAndPayTitle"
              >
                {reviewAndPayTitle}
              </Text>
              <Section
                spacingTop="none"
                spacingBottom="none"
                spacingLeft="none"
                spacingRight="none"
                ref={alertContentRef}
              >
                {alertContent && (
                  <Alert variant="error" marginBottom={{ xs: '32px' }}>
                    {alertContent}
                  </Alert>
                )}
              </Section>
              {isPrepaidActivationJourney && (
                <Text
                  fontSize={{ xs: 'base', m: 'baseLarge' }}
                  lineHeight={{ xs: 'base', m: 'baseLarge' }}
                  marginBottom={{ xs: '36px', m: '56px' }}
                >
                  {prepaidRechargeText} **** *** 123
                </Text>
              )}
              <ReviewAndPay
                isSmallDevice={isSmallDevice}
                journeyType={PaymentJourneySlug.PREPAID_ACTIVATION}
                orderId="$40 Pay and Go Starter Pack"
              />
              <DividerWrap marginTop={{ xs: '24px', m: '36px' }} marginBottom={{ xs: '32px', m: '36px' }}>
                <Divider />
              </DividerWrap>
              <Text
                fontSize={{ xs: 'heading4Tablet', m: 'heading2Tablet' }}
                lineHeight={{ xs: 'heading4Tablet', m: 'heading2Tablet' }}
                fontFamily={{ xs: 'light' }}
                data-testid="make-payment-choosePaymentTitle"
                marginBottom={{ xs: '36px', m: '24px' }}
              >
                {choosePaymentTitle}
              </Text>
              <Section
                ref={paymentContainerRef}
                spacingTop="none"
                spacingBottom="none"
                backgroundColorValue={
                  isSmallDevice ? midTheme.variants.backgroundColor : midTheme.variants.tableHeaderBackgroundColor
                }
                spacingRight="0px"
                spacingLeft="0px"
                data-testid="make-payment-payment-methods-section"
              >
                {paymentMethodOptions.map((paymentItem) => {
                  return (
                    <React.Fragment key={paymentItem.title}>
                      <FlexContainer className="verticalAlign" marginTop={{ xs: '16px' }} marginBottom={{ xs: '16px' }}>
                        <Radio
                          height="20px"
                          width="20px"
                          id={paymentItem.component}
                          value={paymentItem.component}
                          name={paymentItem.component}
                          onChange={onPaymentMethodChange}
                          checked={activePaymentComponent === paymentItem.component}
                        />
                        <FlexContainer className="directionColumn">
                          <Text fontSize={{ xs: 'base' }} lineHeight={{ xs: 'base' }}>
                            {paymentItem.title}
                          </Text>
                          {paymentItem.subTitle && (
                            <Text fontSize={{ xs: 'baseXSmall' }} lineHeight={{ xs: 'base' }}>
                              {paymentItem.subTitle}
                            </Text>
                          )}
                        </FlexContainer>

                        <IconWrapper
                          marginLeft={{ xs: 'auto' }}
                          height={{ xs: '25px' }}
                          svg={paymentItem.icon}
                          width={{ xs: '40px' }}
                        />
                      </FlexContainer>
                      {paymentItem.component === activePaymentComponent &&
                        (iframeRenderErrorCode ? (
                          <IframeRenderError errorAlertCode={iframeRenderErrorCode} />
                        ) : (
                          <Section
                            spacingBottom="none"
                            spacingTop="none"
                            spacingRight="none"
                            spacingLeft="none"
                            backgroundColorValue={midTheme.variants.tableCellBackgroundColor}
                          >
                            {paymentItem.component && getPaymentComponent(paymentItem)}
                          </Section>
                        ))}
                    </React.Fragment>
                  );
                })}
              </Section>
              <DividerWrap marginTop={{ xs: '32px', m: '48px' }} marginBottom={{ xs: '32px', m: '48px' }}>
                <Divider />
              </DividerWrap>
              <Text
                fontSize={{ xs: 'base', m: 'baseLarge' }}
                lineHeight={{ xs: 'base', m: 'baseLarge' }}
                fontFamily={{ xs: 'regular' }}
                data-testid="make-payment-tAndCHero"
              >
                {termsAndConditionHeroMsg}
              </Text>
              <FlexContainer marginTop={{ xs: '16px', m: '24px' }} marginBottom={{ xs: '36px', m: '36px' }}>
                <Checkbox
                  data-testid="make-payment-tnc-checkbox"
                  name="make-payment-tnc-checkbox"
                  wrapperMarginBottom={{ s: '0' }}
                  checked={tncAcceptance}
                  onChange={handleTncChange}
                />
                <Text
                  fontSize={{ xs: 'baseSmall' }}
                  lineHeight={{ xs: 'footnote' }}
                  fontFamily={{ xs: 'regular' }}
                  data-testid="make-payment-tAndC-consent"
                >
                  <RichText>{termsAndConditionConsentMsg}</RichText>
                </Text>
              </FlexContainer>
              <FlexContainer className="buttonContainer" data-testid="make-payment-cta-container">
                {tncAcceptance ? getPaymentButton() : <DefaultButton clickHandler={defaultButtonClickHandler} />}
              </FlexContainer>
            </ContainerWrapper>
          </MainContainer>
        </RelativeContainer>
      </Section>
    </ThemeProvider>
  );
};

export default MakePaymentTemplate;
