import Section from '@src/components/core/Section';
import { MakePaymentPageData } from '@src/templates/MakePayment/constants';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import Text from '@src/components/core/Text';
import React from 'react';
import { PaymentProcessContainer } from '@src/templates/MakePayment/MakePaymentTemplate.styles';
import { ThemeProvider } from 'styled-components';
import { midTheme } from '@src/lib/theme';

export interface PaymentInProgressProps {
  isSmallDevice: boolean;
}

const PaymentInProgress: React.FC<PaymentInProgressProps> = ({ isSmallDevice }) => {
  const { paymentInProgress } = MakePaymentPageData;
  return (
    <ThemeProvider theme={midTheme}>
      <PaymentProcessContainer>
        <Section spacingTop={{ xs: 's', m: 'xxl' }} spacingBottom={{ xs: 's', m: 'xxl' }}>
          <Text
            fontSize={{ xs: 'heading3Mobile', m: 'heading2Tablet' }}
            lineHeight={{ xs: 'heading3Mobile', m: 'heading2Tablet' }}
            fontFamily={{ xs: 'light', m: 'light' }}
            marginBottom={{ xs: '32px', m: '60px' }}
            data-testid="make-payment-in-progress-title"
            textAlign="center"
          >
            {paymentInProgress.processingPaymentTitle}
          </Text>
          <SpinnerSection
            width={isSmallDevice ? '48px' : '92px'}
            height={isSmallDevice ? '48px' : '92px'}
            spacingBottom="none"
            spacingTop="none"
          />
          <Text
            fontSize={{ xs: 'base', m: 'heading6Tablet' }}
            lineHeight={{ xs: 'base', m: 'heading6Mobile' }}
            fontFamily={{ xs: 'regular', m: 'regular' }}
            marginTop={{ xs: '28px', m: '56px' }}
            data-testid="make-payment-in-progress-subtitle"
            textAlign="center"
          >
            {paymentInProgress.processingPaymentSubTitle}
          </Text>
        </Section>
      </PaymentProcessContainer>
    </ThemeProvider>
  );
};

export default PaymentInProgress;
