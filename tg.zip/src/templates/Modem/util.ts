interface ConfigItem {
  value: string;
}

/** Temp hardcoded ALT text */
export const esimEnabledDeviceAltText = 'eSIM-enabled device';
export const fiveGAltText = '5G approved device';

/**
 * Searches through a list of configs -- [color, color, color] or [capacity, capacity] -- and checks
 * to see if that config was specified in a query param. If not, find and return the defaultValue
 * for that config
 */
export function findConfigValue<T extends ConfigItem>(
  configs: T[],
  queryValue: string,
  defaultValue: string,
): T | undefined {
  let config: T | undefined;
  if (queryValue) {
    config = configs.find((c) => c.value === queryValue);
  }

  return config || configs.find((c) => c.value === defaultValue);
}
