import { ReceivedMessageType, SendMessageType, usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import AliPayPayment, { AliPayPaymentProps } from '@src/templates/Payment/AliPayPayment';
import * as braintree from 'braintree-web';
import { render } from '@src/test-utils';
import { act, fireEvent, waitFor } from '@testing-library/react';
import React from 'react';
import { AccountType } from '@src/lib/api/types';
import { mocked } from 'ts-jest/utils';
import { getPaymentIframeHashParams } from '@src/lib/payment/params';
import type { LocalPayment } from 'braintree-web/modules/local-payment';

// Mock the Iframe fucntions for postMessage and getting the hash parameters
jest.mock('@src/lib/payment/params');
jest.mock('@src/lib/payment/postMessage');
const mockGetPaymentIframeHashParams = mocked(getPaymentIframeHashParams, true);
const mockUsePaymentIframePostMessage = mocked(usePaymentIframePostMessage, true);

const mockCreateTransaction = jest.fn().mockReturnValue(Promise.resolve('success'));
jest.mock('@src/lib/api', () => ({
  _esModule: true,
  getApiClient: () => ({
    createTransaction: mockCreateTransaction,
  }),
}));

const mockStartPayment = jest.fn(() => Promise.resolve('Payment started'));
const mockLocalPaymentClient = jest.fn(() => Promise.resolve('client'));
jest.mock('braintree-web', () => ({
  _esModule: true,
  localPayment: {
    create: () => mockLocalPaymentClient(),
    startPayment: () => mockStartPayment(),
  },
}));

const customerDetailsPayload: Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload'] = {
  email: 'test@example.org',
  phone: '61491570110',
  firstName: 'Test',
  lastName: 'User',
};

const defaultProps: AliPayPaymentProps = {
  localPaymentInstance: braintree.localPayment as LocalPayment,
  deviceData: JSON.stringify({ correlation_id: 'abcdef1234567890' }),
};

describe('Alipay Button', () => {
  let postMessage: jest.Mock<void, [data: SendMessageType]>;
  let simulateMessage: (data: ReceivedMessageType) => void;

  beforeEach(() => {
    postMessage = jest.fn();
    mockUsePaymentIframePostMessage.mockReturnValue(postMessage);

    simulateMessage = (data) =>
      act(() =>
        mockUsePaymentIframePostMessage.mock.calls.forEach((call) => {
          return call[0]?.(data);
        }),
      );
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should render the Alipay button', async () => {
    mockGetPaymentIframeHashParams.mockReturnValue({
      accounttype: AccountType.PREPAY,
      origin,
      PAYMENT_METHOD: 'ALIPAY',
      FLOW_TYPE: 'CHARGE',
      ORDER_ID: 'VDFO-12345',
      'X-SESSION_ID': '',
      AMOUNT: '0',
      HMAC: 'abc123',
    });
    const utils = render(<AliPayPayment {...defaultProps} />);
    simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
    await waitFor(() => expect(utils.getByTestId('alipay-button')).toBeInTheDocument());
  });

  it('should start Alipay payment flow and trigger charge transaction', async () => {
    const utils = render(<AliPayPayment {...defaultProps} />);
    simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
    await act(async () => {
      const button = utils.getByTestId('alipay-button');
      fireEvent.click(button);
    });
    expect(mockStartPayment).toHaveBeenCalled();
    expect(mockCreateTransaction).toHaveBeenCalled();
  });
});
