import ApplePayButton from '@src/templates/Payment/ApplePayButton';
import { act, render } from '@src/test-utils';
import { ApplePay } from 'braintree-web';
import React from 'react';
import { mocked } from 'ts-jest/utils';
import { ReceivedMessageType, SendMessageType, usePaymentIframePostMessage } from '@src/lib/payment/postMessage';

const mockCreateTransaction = jest.fn().mockReturnValue(Promise.resolve('success'));

jest.mock('@src/lib/payment/postMessage');

jest.mock('@src/lib/api', () => ({
  __esModule: true,
  getApiClient: () => ({
    createTransaction: mockCreateTransaction,
  }),
}));

const mockUsePaymentIframePostMessage = mocked(usePaymentIframePostMessage, true);

const mockCompletePayment = jest.fn();

// Create mock apple pay class that safari provides on window
class mockApplePaySession {
  validatemerchant: (obj?: { validationUrl: string }) => void;

  merchantValidation: (merchantSession?: unknown) => void;

  paymentauthorized: (obj?: { payment: { token: string } }) => void;

  completePayment: jest.Mock<void>;

  constructor() {
    this.validatemerchant = () => {};
    this.merchantValidation = () => {};
    this.paymentauthorized = () => {};
    this.completePayment = mockCompletePayment;
  }

  set onvalidatemerchant(fn: (obj?: { validationUrl: string }) => void) {
    this.validatemerchant = fn;
  }

  set completeMerchantValidation(fn: (merchantSession: unknown) => void) {
    this.merchantValidation = fn;
  }

  set onpaymentauthorized(fn: (obj?: { payment: { token: string } }) => void) {
    this.paymentauthorized = fn;
  }

  begin() {
    this.validatemerchant({ validationUrl: 'url-123' });
    this.merchantValidation({});
    this.paymentauthorized({ payment: { token: 'token-123' } });
  }
}

window.ApplePaySession = mockApplePaySession as unknown as ApplePaySession;

const mockApplePayInstance = {
  createPaymentRequest: jest.fn(),
  performValidation: jest.fn().mockResolvedValue('success'),
  tokenize: jest.fn(),
} as unknown as ApplePay;

const setup = (extraProps = {}) => {
  const props = { applePayInstance: mockApplePayInstance, ...extraProps };
  const utils = render(<ApplePayButton {...props} />);

  return { utils, props };
};

describe('ApplePayButton', () => {
  let postMessage: jest.Mock<void, [data: SendMessageType]>;
  let simulateMessage: (data: ReceivedMessageType) => void;

  beforeEach(() => {
    mockCompletePayment.mockClear();
    postMessage = jest.fn();
    mockUsePaymentIframePostMessage.mockReturnValue(postMessage);
    simulateMessage = (data) =>
      act(() => mockUsePaymentIframePostMessage.mock.calls.forEach((call) => call[0]?.(data)));
  });

  it('should render apple pay button', () => {
    const { utils } = setup();
    simulateMessage({
      source: 'omniscript',
      type: 'CUSTOMER_DETAILS',
      payload: {
        email: 'test@example.org',
        phone: '61491570110',
        firstName: 'User',
        lastName: 'User',
      },
    });

    expect(utils.getByTestId('apple-pay-button')).toBeDefined();
  });

  it('should create apple pay session and set attributes', () => {
    const { utils } = setup();
    simulateMessage({
      source: 'omniscript',
      type: 'CUSTOMER_DETAILS',
      payload: {
        email: 'test@example.org',
        phone: '61491570110',
        firstName: 'User',
        lastName: 'User',
      },
    });

    const button = utils.getByTestId('apple-pay-button');

    button.click();

    expect(mockApplePayInstance.createPaymentRequest).toBeCalledTimes(1);
    expect(mockApplePayInstance.performValidation).toBeCalledTimes(1);
    expect(mockApplePayInstance.tokenize).toBeCalledTimes(1);
  });

  it('should create transaction', () => {
    const { utils } = setup();
    simulateMessage({
      source: 'omniscript',
      type: 'CUSTOMER_DETAILS',
      payload: {
        email: 'test@example.org',
        phone: '61491570110',
        firstName: 'User',
        lastName: 'User',
      },
    });

    const button = utils.getByTestId('apple-pay-button');

    button.click();

    expect(mockCreateTransaction).toBeCalledTimes(1);
  });

  it('should handle submit request post message', () => {
    setup();
    simulateMessage({
      source: 'omniscript',
      type: 'CUSTOMER_DETAILS',
      payload: {
        email: 'test@example.org',
        phone: '61491570110',
        firstName: 'User',
        lastName: 'User',
      },
    });

    simulateMessage({ source: 'omniscript', type: 'SUBMIT_REQUEST' });

    expect(mockApplePayInstance.createPaymentRequest).toBeCalled();
    expect(mockApplePayInstance.performValidation).toBeCalled();
    expect(mockApplePayInstance.tokenize).toBeCalled();
  });
});
