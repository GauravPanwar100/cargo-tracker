/* eslint-disable no-console */
import React from 'react';
import Logger from '@src/lib/logger/logger';
import { AliPayButton, AliPayButtonContainer, AliPayButtonWrapper } from '@src/templates/Payment/AliPayPayment.styles';
import AliPayButtonSVG from '@src/assets/svg/alipay-button.svg';
import { LocalPaymentTypes } from 'braintree-web';
import { getApiClient } from '@src/lib/api';
import { ReceivedMessageType, usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import { getPaymentIframeHashParams } from '@src/lib/payment/params';
import { APMTransactionResult } from '@src/lib/api/types';
import type { LocalPayment, LocalPaymentTokenizePayload } from 'braintree-web/modules/local-payment';

export interface AliPayPaymentProps {
  localPaymentInstance: LocalPayment;
  deviceData: braintree.DataCollector['deviceData'] | undefined;
}

const AliPayPayment = ({ deviceData, localPaymentInstance }: AliPayPaymentProps) => {
  const ApiClient = getApiClient();
  const alipayButton = document.getElementById('alipay-button');
  const [details, setDetails] = React.useState<Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload']>();
  const { AMOUNT } = getPaymentIframeHashParams();

  const postMessage = usePaymentIframePostMessage((data) => {
    switch (data.type) {
      case 'CUSTOMER_DETAILS':
        setDetails(data.payload);
        break;

      default:
      // do nothing
    }
  });

  const createLocalPaymentClickListener = React.useCallback(
    (type: LocalPaymentTypes) => {
      return (event: Event) => {
        event.preventDefault();
        console.log(`${window.location.hostname}/checkout`);

        if (details) {
          const { email, phone } = details;
          let transactionPaymentId: string;
          localPaymentInstance
            .startPayment({
              paymentType: type,
              amount: AMOUNT,
              fallback: {
                url: `${window.location.hostname}`, // Redirect to home page
                buttonText: 'Return to Vodafone Australia',
              },
              currencyCode: 'AUD',
              givenName: details.firstName, // Only needed for FE
              surname: details.lastName, // Only needed for FE
              address: {
                countryCode: 'C2',
              },
              onPaymentStart: (data: { paymentId: string }, start: () => void) => {
                // NOTE: It is critical here to store data.paymentId on your server
                //       so it can be mapped to a webhook sent by Braintree once the
                //       buyer completes their payment. See Start the payment
                //       section for details.
                // Fusion sends this to PSM for logPayment. PSM persists for later use with Webhooks if needed

                // Process Webhooks call heppens here. Check if result is INITIATED.
                transactionPaymentId = data.paymentId;
                ApiClient.submitAPMPayment({
                  deviceData: deviceData!,
                  paymentId: transactionPaymentId,
                  params: getPaymentIframeHashParams(),
                  msisdn: details.phone,
                })
                  .then(() => {
                    // Call start to initiate the popup if submitAPMpayment calls resolves successfully
                    return start();
                  })
                  .catch((error) => {
                    // @ts-ignore
                    localPaymentInstance.closeWindow();
                    Logger.error('AliPay payment details submission failed', { error, ucode: 'rIjcBYF' });
                    postMessage({
                      source: 'vfe',
                      type: 'SUBMIT_FAILURE',
                      code: (error.response?.data?.errors && error.response?.data?.errors[0]?.code) ?? 'VODAFONE_ERROR', // Tries to post error code provided by API response. Defaults to VODAFONE_ERROR if not found
                    });
                    throw new Error('AliPay payment details submission failed');
                  });
              },
            })
            .then((payload: LocalPaymentTokenizePayload) => {
              postMessage({
                source: 'vfe',
                type: 'SUBMIT_INITIATED',
              });
              return ApiClient.createTransaction({
                payload,
                details: { email, phone },
                deviceData: deviceData!,
                params: getPaymentIframeHashParams(),
                paymentType: 'ALIPAY',
                paymentId: transactionPaymentId,
              });
            })
            .then((payload: APMTransactionResult) => {
              postMessage({
                source: 'vfe',
                type: 'SUBMIT_SUCCESS',
                payload,
              });
            })
            .catch((error) => {
              if (error.code === 'LOCAL_PAYMENT_CANCELED' || error.code === 'LOCAL_PAYMENT_WINDOW_CLOSED') {
                Logger.error('AliPay payment was cancelled', { error, ucode: 'c86bc8d' });
                postMessage({
                  source: 'vfe',
                  type: 'SUBMIT_FAILURE',
                  code: 'ALIPAY_PAYMENT_CANCELLED',
                });
              } else {
                Logger.error('AliPay payment submission failed', { error, ucode: 'e845a95' });
                postMessage({
                  source: 'vfe',
                  type: 'SUBMIT_FAILURE',
                  code: (error.response?.data?.errors && error.response?.data?.errors[0]?.code) ?? 'VODAFONE_ERROR', // Tries to post error code provided by API response. Defaults to VODAFONE_ERROR if not found
                });
              }
            });
        }
      };
    },
    [AMOUNT, ApiClient, details, deviceData, localPaymentInstance, postMessage],
  );

  alipayButton?.addEventListener('click', createLocalPaymentClickListener('ALIPAY' as LocalPaymentTypes));

  return (
    <AliPayButtonWrapper>
      <AliPayButtonContainer id="alipay-button" data-testid="alipay-button">
        {details && (
          <AliPayButton>
            <img alt="AlipayImg" src={AliPayButtonSVG} />
          </AliPayButton>
        )}
      </AliPayButtonContainer>
    </AliPayButtonWrapper>
  );
};

export default AliPayPayment;
