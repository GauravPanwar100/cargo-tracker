import React, { useCallback } from 'react';
import Logger from '@src/lib/logger/logger';
import { PayPalCheckout, PayPalCheckoutCreatePaymentOptions, PayPalTokenizePayload } from 'braintree-web';
import { Currency, PaypalButtonLabel, isBraintreeError, merchantDisplayName } from '@src/lib/payment/braintree';
import { getPaymentIframeHashParams } from '@src/lib/payment/params';
import { ReceivedMessageType, usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import { PayPalPaymentContainer } from '@src/templates/Payment/PayPalPayment.styles';
import { getApiClient } from '@src/lib/api';
import { APMTransactionResult } from '@src/lib/api/types';
import useWindowSize from '@src/lib/hooks/use-window-size';
import { breakpoints } from '@src/lib/theme';

export interface PayPalPaymentProps {
  deviceData: braintree.DataCollector['deviceData'] | undefined;
  paypalCheckout: PayPalCheckout | undefined;
  customerDetails: Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload'];
  clientMetadataId?: string;
}

const PayPalPayment = ({ deviceData, paypalCheckout, customerDetails, clientMetadataId }: PayPalPaymentProps) => {
  const ApiClient = getApiClient();
  const { width } = useWindowSize();
  const postMessage = usePaymentIframePostMessage();
  const { email, phone } = customerDetails;

  const createButton = useCallback(
    (paypalCheckoutInstance) => {
      const { AMOUNT: amount, FLOW_TYPE } = getPaymentIframeHashParams();
      const isVaultFlow = FLOW_TYPE === 'VAULT';
      const isCheckoutFlow = FLOW_TYPE === 'CHARGE';

      const shippingOptions: Pick<
        PayPalCheckoutCreatePaymentOptions,
        'enableShippingAddress' | 'shippingAddressEditable' | 'shippingAddressOverride'
      > = {
        enableShippingAddress: false,
        shippingAddressEditable: false,
      };
      const createPaymentOptions: PayPalCheckoutCreatePaymentOptions = {
        flow: (isVaultFlow ? 'vault' : 'checkout') as paypal.FlowType,
        // @ts-ignore
        riskCorrelationId: isCheckoutFlow ? clientMetadataId : undefined,
        amount,
        currency: Currency.AUD,
        intent: (isVaultFlow ? 'authorize' : 'capture') as paypal.Intent,
        // TODO: again `commit` is missing in DefinitelyTyped, will raise PR for it
        // @ts-ignore
        commit: isCheckoutFlow ? true : undefined,
        billingAgreementDescription: isVaultFlow ? 'Check and confirm your payment details below.' : undefined,
        displayName: merchantDisplayName,
        ...shippingOptions,
      };

      const createPaymentFunction = () => {
        return paypalCheckoutInstance.createPayment(createPaymentOptions);
      };

      if (customerDetails) {
        window.paypal
          .Buttons({
            fundingSource: 'paypal',
            // TODO: again `style` is missing in DefinitelyTyped, will raise PR for it
            // @ts-ignore
            style: {
              color: 'blue',
              shape: 'rect',
              label: isCheckoutFlow ? PaypalButtonLabel.PAY : PaypalButtonLabel.PAYPAL,
              height: width! > breakpoints.m ? 50 : 44,
            },
            createOrder: isCheckoutFlow ? createPaymentFunction : undefined,
            createBillingAgreement: isVaultFlow ? createPaymentFunction : undefined,
            onApprove(data) {
              return paypalCheckoutInstance
                .tokenizePayment(data)
                .then((payload: PayPalTokenizePayload) => {
                  postMessage({
                    source: 'vfe',
                    type: 'SUBMIT_INITIATED',
                  });
                  return ApiClient.createTransaction({
                    payload,
                    details: { email, phone },
                    deviceData: deviceData!,
                    params: getPaymentIframeHashParams(),
                    paymentType: 'PAYPAL',
                  });
                })
                .then((payload: APMTransactionResult) => {
                  postMessage({
                    source: 'vfe',
                    type: 'SUBMIT_SUCCESS',
                    payload,
                  });
                })
                .catch((error: unknown) => {
                  Logger.error('PayPal payment submission failed', { error, ucode: '233b0db' });

                  if (isBraintreeError(error)) {
                    postMessage({ source: 'vfe', type: 'SUBMIT_FAILURE', code: 'VODAFONE_ERROR' });
                    return;
                  }

                  postMessage({ source: 'vfe', type: 'SUBMIT_FAILURE', code: 'VODAFONE_ERROR' });
                });
            },
            onCancel() {
              // TODO: Error handling will be handled in separate card to be raised.
            },
            onError(error) {
              // Logs all other Paypal errors
              Logger.error('Paypal payment error', { error, ucode: '68dccc7' });
              postMessage({ source: 'vfe', type: 'SUBMIT_FAILURE', code: 'VODAFONE_ERROR' });
            },
          })
          .render('#paypal-button');
      }
    },
    [ApiClient, clientMetadataId, customerDetails, deviceData, email, phone, postMessage, width],
  );

  React.useEffect(() => {
    if (!paypalCheckout) return;

    const isCheckoutFlow = getPaymentIframeHashParams().FLOW_TYPE === 'CHARGE';

    paypalCheckout
      .loadPayPalSDK({
        currency: Currency.AUD,
        vault: getPaymentIframeHashParams().FLOW_TYPE === 'VAULT',
        intent: isCheckoutFlow ? 'capture' : undefined,
        commit: isCheckoutFlow,
      })
      .then((paypalCheckoutInstance) => {
        postMessage({
          source: 'vfe',
          type: 'PAYMENT_CLIENT_READY',
          iframe: 'PAYPAL',
        });
        return createButton(paypalCheckoutInstance);
      })
      .catch((error) => {
        Logger.error('PayPal checkout component error', { error, ucode: '949e449' });
        postMessage({
          source: 'vfe',
          type: 'VFE_IFRAME_FAILED',
        });
      });
  }, [createButton, paypalCheckout, postMessage]);

  return <PayPalPaymentContainer data-testid="paypal-button" id="paypal-button" />;
};

export default PayPalPayment;
