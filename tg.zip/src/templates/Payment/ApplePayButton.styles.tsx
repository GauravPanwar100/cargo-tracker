import { media } from '@src/lib/util/mixins';
import styled from 'styled-components';

export const ButtonContainer = styled.div`
  ${media.l`
    display: flex;
    justify-content: center;
    align-items: center;
  `}
`;

export const PayButton = styled.button`
  display: inline-block;
  -webkit-appearance: -apple-pay-button;
  -apple-pay-button-type: buy; /* Use any supported button type. */
  -apple-pay-button-style: black;
  width: 100%;
  height: 44px;
  border-radius: 6px;

    ${media.l`
      width: 160px;
      height: 50px;
  `}
  }
`;
