import * as braintree from 'braintree-web';
import React from 'react';
import { AccountType } from '@src/lib/api/types';
import { act, fireEvent, render } from '@src/test-utils';
import { ReceivedMessageType, SendMessageType, usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import PayPalPayment, { PayPalPaymentProps } from '@src/templates/Payment/PayPalPayment';
import { waitFor } from '@testing-library/react';
import { mocked } from 'ts-jest/utils';
import { getPaymentIframeHashParams } from '@src/lib/payment/params';

jest.mock('@src/lib/payment/postMessage');
jest.mock('@src/lib/payment/params');

const mockUsePaymentIframePostMessage = mocked(usePaymentIframePostMessage, true);
const mockGetPaymentIframeHashParams = mocked(getPaymentIframeHashParams, true);

const mockPayPalClient = jest.fn(() => Promise.resolve('client'));
const mockPayPalCheckout = jest.fn(() =>
  Promise.resolve({
    createPayment: jest.fn(() => Promise.resolve('payment')),
    tokenizePayment: jest.fn(() => {
      return Promise.resolve({ nonce: 'thisIsAPaymentNonce' });
    }),
  }),
);

jest.mock('braintree-web', () => ({
  _esModule: true,
  paypalCheckout: {
    create: () => mockPayPalClient(),
    loadPayPalSDK: () => mockPayPalCheckout(),
  },
}));

const mockCreateTransaction = jest.fn().mockReturnValue(Promise.resolve('success'));
jest.mock('@src/lib/api', () => ({
  __esModule: true,
  getApiClient: () => ({
    createTransaction: mockCreateTransaction,
  }),
}));

const customerDetailsPayload: Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload'] = {
  email: 'test@example.org',
  phone: '61491570110',
  firstName: 'User',
  lastName: 'User',
};

const defaultProps: PayPalPaymentProps = {
  deviceData: JSON.stringify({ correlation_id: 'abcdef1234567890' }),
  paypalCheckout: braintree.paypalCheckout,
  customerDetails: customerDetailsPayload,
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<PayPalPayment {...props} />);
  return { utils, props };
};

describe('PayPalButton', () => {
  let postMessage: jest.Mock<void, [data: SendMessageType]>;
  let simulateMessage: (data: ReceivedMessageType) => void;

  const paypalTestInputs = [
    {
      params: {
        accounttype: AccountType.PREPAY,
        origin,
        PAYMENT_METHOD: 'PAYPAL',
        FLOW_TYPE: 'CHARGE',
        ORDER_ID: 'VDFO-12345',
        'X-SESSION_ID': '',
        AMOUNT: '0',
        HMAC: 'abc123',
      },
    },
    {
      params: {
        accounttype: AccountType.POSTPAY,
        origin,
        PAYMENT_METHOD: 'PAYPAL',
        FLOW_TYPE: 'VAULT',
        ORDER_ID: 'VDFO-12345',
        'X-SESSION_ID': '',
        AMOUNT: '0',
        HMAC: 'abc123',
      },
    },
  ] as const;

  beforeEach(() => {
    postMessage = jest.fn();
    mockUsePaymentIframePostMessage.mockReturnValue(postMessage);

    simulateMessage = (data) =>
      act(() =>
        mockUsePaymentIframePostMessage.mock.calls.forEach((call) => {
          return call[0]?.(data);
        }),
      );

    window.paypal = {
      Buttons: ({ createOrder, createBillingAgreement, onApprove }) => {
        return {
          render: (id) => {
            const button = document.createElement('button');
            button.innerHTML = 'Pay with paypal';
            button.onclick = () => {
              if ((!createOrder && !createBillingAgreement) || !onApprove) return;
              if (createOrder) createOrder();
              if (createBillingAgreement) createBillingAgreement();
              onApprove(
                {
                  payerId: 'payerId',
                  paymentId: 'paymentId',
                },
                {},
              );
            };
            const paypalContainer = document.querySelector(id);
            paypalContainer!.appendChild(button);
          },
        };
      },
    } as Partial<typeof window.paypal> as typeof window.paypal;
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it.each(paypalTestInputs)(
    'should render the PayPal button for account type $params.accounttype',
    async ({ params }) => {
      mockGetPaymentIframeHashParams.mockReturnValue(params);
      const { utils } = setup();
      simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
      await waitFor(() => expect(utils.getByText('Pay with paypal')).toBeInTheDocument());
    },
  );

  it.each(paypalTestInputs)(
    'should tokenise when payment button is clicked for account type $params.accounttype, call create transaction and send SUBMIT_SUCCESS',
    async ({ params }) => {
      mockGetPaymentIframeHashParams.mockReturnValue(params);
      const { utils } = setup();
      simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
      await waitFor(() => expect(utils.getByText('Pay with paypal')).toBeInTheDocument());

      await act(async () => {
        const pp = utils.getByText('Pay with paypal');
        fireEvent.click(pp);
      });

      expect(mockCreateTransaction).toHaveBeenCalled();
      expect(postMessage).toHaveBeenCalledWith({
        source: 'vfe',
        type: 'SUBMIT_SUCCESS',
        payload: 'success',
      });
    },
  );

  it.each(paypalTestInputs)(
    'should send SUBMIT_FAILURE for account type $params.accounttype when create transaction failed',
    async ({ params }) => {
      mockCreateTransaction.mockRejectedValue(
        Object.assign(new Error('Bad Request'), {
          response: {
            status: 400,
            data: {
              error: { code: 'HIGH_RISK_ERROR' },
            },
          },
        }),
      );
      mockGetPaymentIframeHashParams.mockReturnValue(params);
      const { utils } = setup();
      simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
      await waitFor(() => expect(utils.getByText('Pay with paypal')).toBeInTheDocument());

      await act(async () => {
        const pp = utils.getByText('Pay with paypal');
        fireEvent.click(pp);
      });

      expect(postMessage).toHaveBeenCalledWith({
        source: 'vfe',
        type: 'SUBMIT_FAILURE',
        code: 'VODAFONE_ERROR',
      });
    },
  );
});
