import braintree from 'braintree-web';
import type { HostedFieldEventType, HostedFieldsEventTypeMap } from 'braintree-web/modules/hosted-fields';
import { when } from 'jest-when';
import { startCase } from 'lodash';
import React from 'react';
import { AccountType, CreateTransactionRequest, CustomerContactDetails } from '@src/lib/api/types';
import {
  HostedFieldsErrorCode,
  HostedFieldsFieldData,
  HostedFieldsState,
  KnownCardType,
  ThreeDSecureEventType,
} from '@src/lib/payment/braintree';
import { RenderResult, act, render, waitForEventLoopToDrain } from '@src/test-utils';

const mockCardTransaction: jest.MockedFunction<
  ReturnType<typeof import('@src/lib/api')['getApiClient']>['createTransaction']
> = jest.fn();
jest.mock('@src/lib/api', () => ({
  getApiClient: () => ({
    createTransaction: mockCardTransaction,
  }),
}));

const mockGetPaymentIframeHashParams: jest.Mock<PaymentIframeHashParams, []> = jest.fn();
jest.mock('@src/lib/payment/params', () => ({
  __esModule: true,
  getPaymentIframeHashParams: mockGetPaymentIframeHashParams,
}));

const mockUsePaymentIframePostMessage: jest.Mock<
  (data: SendMessageType) => void,
  [((data: ReceivedMessageType) => void)?]
> = jest.fn();
jest.mock('@src/lib/payment/postMessage', () => ({
  __esModule: true,
  usePaymentIframePostMessage: mockUsePaymentIframePostMessage,
}));

import { PaymentIframeHashParams } from '@src/lib/payment/params';
import { ReceivedMessageType, SendMessageType } from '@src/lib/payment/postMessage';
import CardPayment from '@src/templates/Payment/CardPayment';
import { Awaited } from '@src/lib/types';
import BraintreeError from 'braintree-web/lib/braintree-error';

const deviceData = JSON.stringify({ correlation_id: 'abcdef1234567890' });

const makeFieldData = (): HostedFieldsFieldData => ({
  container: document.createElement('div'),
  isEmpty: true,
  isFocused: false,
  isPotentiallyValid: true,
  isValid: false,
});

const defaultState: HostedFieldsState = {
  cards: Object.values(KnownCardType).map((type) => ({
    code: {
      // eslint-disable-next-line no-nested-ternary
      name: type === KnownCardType.AMERICAN_EXPRESS ? 'CID' : type === KnownCardType.MASTERCARD ? 'CVC' : 'CVV',
      size: type === KnownCardType.AMERICAN_EXPRESS ? 4 : 3,
    },
    niceType: startCase(type),
    type,
  })),
  fields: {
    cardholderName: makeFieldData(),
    number: makeFieldData(),
    expirationDate: makeFieldData(),
    cvv: makeFieldData(),
  } as Pick<
    HostedFieldsState['fields'],
    'cardholderName' | 'number' | 'expirationDate' | 'cvv'
  > as HostedFieldsState['fields'],
};

const defaultFields = [
  { id: 'cc-name', label: 'Name on card' },
  { id: 'cc-number', label: 'Card number' },
  { id: 'cc-exp', label: 'Expiry date' },
  { id: 'cc-csc', label: 'Security code' },
] as const;

const validState: HostedFieldsState = {
  ...defaultState,
  cards: defaultState.cards.filter((card) => card.type === KnownCardType.VISA),
  fields: {
    ...defaultState.fields,
    cardholderName: { ...defaultState.fields.cardholderName, isEmpty: false, isValid: true },
    number: { ...defaultState.fields.number, isEmpty: false, isValid: true },
    expirationDate: { ...defaultState.fields.expirationDate, isEmpty: false, isValid: true },
    cvv: { ...defaultState.fields.cvv, isEmpty: false, isValid: true },
  },
};

const tokenizePayload: braintree.HostedFieldsTokenizePayload = {
  description: 'ending in 11',
  details: {
    bin: '411111',
    cardType: KnownCardType.VISA,
    cardholderName: 'Test Cardholder',
    expirationMonth: '12',
    expirationYear: '2021',
    lastFour: '1111',
    lastTwo: '11',
  },
  nonce: 'nonce__abc123_def456',
  type: '',
};

const threeDSVerifyPayload: braintree.ThreeDSecureVerifyPayload = {
  nonce: 'nonce__abc123_def456_3ds_uplifted',
  type: 'CCA',
  details: {
    cardType: tokenizePayload.details.cardType,
    lastTwo: tokenizePayload.details.lastTwo,
  },
  description: tokenizePayload.description,
  binData: {
    commercial: 'Unknown',
    countryOfIssuance: 'AU',
    debit: 'Unknown',
    durbinRegulated: 'Unknown',
    healthcare: 'Unknown',
    issuingBank: 'ANZ',
    payroll: 'Unknown',
    prepaid: 'Unknown',
    productId: 'product__abc123',
  },
  liabilityShiftPossible: true,
  liabilityShifted: true,
  threeDSecureInfo: {
    liabilityShiftPossible: true,
    liabilityShifted: true,
    cavv: 'cavv',
    xid: 'xid',
    dsTransactionId: 'dsTransactionId',
    threeDSecureVersion: '2',
    eciFlag: 'Y',
    threeDSecureAuthenticationId: '3DS__auth_id',
  },
};

const customerDetailsPayload: Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload'] = {
  email: 'test@example.org',
  phone: '61491570110',
  firstName: 'User',
  lastName: 'User',
};
const { email, phone } = customerDetailsPayload;
const customerContactDetails: CustomerContactDetails = { email, phone };

describe('Payment CardPayment Template', () => {
  let postMessage: jest.Mock<void, [data: SendMessageType]>;
  let simulateMessage: (data: ReceivedMessageType) => void;
  let hostedFields: jest.Mocked<braintree.HostedFields>;
  let threeDSecure: jest.Mocked<braintree.ThreeDSecure>;
  let result: RenderResult;
  let getHandlers: <EventType extends HostedFieldEventType>(
    type: EventType,
  ) => ReadonlyArray<(payload: HostedFieldsEventTypeMap[EventType]) => void>;
  let trigger: <EventType extends HostedFieldEventType>(
    type: EventType,
    payload: HostedFieldsEventTypeMap[EventType],
  ) => void;
  beforeEach(() => {
    mockGetPaymentIframeHashParams.mockReturnValue({
      accounttype: AccountType.POSTPAY,
      origin,
      PAYMENT_METHOD: 'CREDITCARD',
      FLOW_TYPE: 'VAULT',
      ORDER_ID: '',
      'X-SESSION_ID': '',
      AMOUNT: '0',
      HMAC: 'abc123',
    });
    postMessage = jest.fn();
    mockUsePaymentIframePostMessage.mockReturnValue(postMessage);
    simulateMessage = (data) =>
      act(() => mockUsePaymentIframePostMessage.mock.calls.forEach((call) => call[0]?.(data)));
    hostedFields = {
      focus: jest.fn(),
      getState: jest.fn(),
      on: jest.fn(),
      off: jest.fn(),
      tokenize: jest.fn(),
    } as Partial<typeof hostedFields> as typeof hostedFields;
    hostedFields.getState.mockReturnValue(defaultState);
    // @ts-ignore
    hostedFields.tokenize.mockRejectedValue(new Error('not stubbed'));
    getHandlers = (type) => hostedFields.on.mock.calls.filter((call) => call[0] === type).map((call) => call[1]);
    trigger = (type, payload) => act(() => getHandlers(type).forEach((handler) => handler(payload)));
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('Hosted Fields', () => {
    beforeEach(() => {
      result = render(<CardPayment deviceData={deviceData} hostedFields={hostedFields} />);
    });

    it('should render the HostedFields', () => {
      expect(result.getByTestId('cc-fields')).toBeInTheDocument();

      defaultFields.forEach(({ id, label }) => {
        expect(result.getByText(label)).toBeInTheDocument();
        expect(result.container.querySelector(`#${id}`)).toBeInTheDocument();
      });
    });

    it.each([
      { field: 'cardholderName', message: 'do nothing' },
      { field: 'number', moveTo: 'expirationDate', message: 'move focus to expirationDate' },
      { field: 'expirationDate', moveTo: 'cvv', message: 'move focus to cvv' },
      { field: 'cvv', message: 'do nothing' },
    ] as const)('should listen to $field becoming valid and $message', ({ field, moveTo }) => {
      hostedFields.getState.mockReturnValue(validState);
      trigger('validityChange', { ...validState, emittedBy: field });

      if (moveTo) {
        expect(hostedFields.focus).toHaveBeenCalledWith(moveTo);
      } else {
        expect(hostedFields.focus).not.toHaveBeenCalled();
      }
    });

    it('should listen to card type changes (AMEX)', () => {
      const amexState: HostedFieldsState = {
        ...defaultState,
        cards: defaultState.cards.filter((card) => card.type === KnownCardType.AMERICAN_EXPRESS),
        fields: {
          ...defaultState.fields,
          number: {
            ...defaultState.fields.number,
            isEmpty: false,
            isFocused: true,
          },
        },
      };
      hostedFields.getState.mockReturnValue(amexState);
      trigger('cardTypeChange', { ...amexState, emittedBy: 'number' });

      expect(result.getByTestId('cc-fields')).toHaveClass('card-type-american-express');
      expect(result.getByText('The 4 digits on the front of your card.')).toBeInTheDocument();
    });

    it('should listen to card type changes (VISA)', () => {
      const visaState: HostedFieldsState = {
        ...defaultState,
        cards: defaultState.cards.filter((card) => card.type === KnownCardType.VISA),
        fields: {
          ...defaultState.fields,
          number: {
            ...defaultState.fields.number,
            isEmpty: false,
            isFocused: true,
          },
        },
      };
      hostedFields.getState.mockReturnValue(visaState);
      trigger('cardTypeChange', { ...visaState, emittedBy: 'number' });

      expect(result.getByTestId('cc-fields')).toHaveClass('card-type-visa');
      expect(result.getByText('The 3 digits on the back of your card.')).toBeInTheDocument();
    });

    it('should listen to focus changes and updated touched state', () => {
      const focusedState: HostedFieldsState = {
        ...defaultState,
        fields: {
          ...defaultState.fields,
          number: {
            ...defaultState.fields.number,
            isEmpty: false,
            isFocused: true,
          },
        },
      };
      hostedFields.getState.mockReturnValue(focusedState);
      trigger('focus', { ...focusedState, emittedBy: 'number' });

      expect(result.getByTestId('cc-number').dataset).toMatchObject({
        empty: 'false',
        touched: 'true',
        valid: 'false',
      });
    });

    it('should mark all fields as touched and send SUBMIT_REQUEST for inputSubmitRequest', () => {
      defaultFields.forEach(({ id }) => {
        expect(result.getByTestId(id).dataset).toMatchObject({
          touched: 'false',
        });
      });

      trigger('inputSubmitRequest', { ...defaultState, emittedBy: 'cardholderName' });

      defaultFields.forEach(({ id }) => {
        expect(result.getByTestId(id).dataset).toMatchObject({
          touched: 'true',
        });
      });
      expect(postMessage).toHaveBeenCalledWith({ source: 'vfe', type: 'SUBMIT_REQUEST' });
    });

    it('should mark all fields as touched on SUBMIT_REQUEST', () => {
      defaultFields.forEach(({ id }) => {
        expect(result.getByTestId(id).dataset).toMatchObject({
          touched: 'false',
        });
      });

      simulateMessage({ source: 'omniscript', type: 'SUBMIT_REQUEST' });

      defaultFields.forEach(({ id }) => {
        expect(result.getByTestId(id).dataset).toMatchObject({
          touched: 'true',
        });
      });
    });

    it.each([
      {
        code: 'CUSTOMER_ERROR',
        reason: 'unsupported card type',
        setup() {
          const unsupportedState: HostedFieldsState = {
            ...defaultState,
            cards: defaultState.cards.filter((card) => card.type === KnownCardType.ELO),
            fields: {
              ...defaultState.fields,
              cardholderName: { ...defaultState.fields.cardholderName, isEmpty: false, isValid: true },
              number: { ...defaultState.fields.number, isEmpty: false, isValid: true },
              expirationDate: { ...defaultState.fields.expirationDate, isEmpty: false, isValid: true },
              cvv: { ...defaultState.fields.cvv, isEmpty: false, isValid: true },
            },
          };
          hostedFields.getState.mockReturnValue(unsupportedState);

          trigger('validityChange', { ...unsupportedState, emittedBy: 'cvv' });
        },
      },
      ...[
        HostedFieldsErrorCode.HOSTED_FIELDS_FIELDS_EMPTY,
        HostedFieldsErrorCode.HOSTED_FIELDS_FIELDS_INVALID,
        HostedFieldsErrorCode.HOSTED_FIELDS_TOKENIZATION_CVV_VERIFICATION_FAILED,
      ].map((braintreeErrorCode) => ({
        code: 'CUSTOMER_ERROR',
        reason: braintreeErrorCode,
        setup() {
          hostedFields.tokenize.mockRejectedValue(
            // @ts-ignore
            new BraintreeError({
              code: braintreeErrorCode,
              message: 'error',
              type: BraintreeError.types.CUSTOMER,
            }),
          );
        },
      })),
      ...[
        HostedFieldsErrorCode.HOSTED_FIELDS_FAILED_TOKENIZATION,
        HostedFieldsErrorCode.HOSTED_FIELDS_TOKENIZATION_NETWORK_ERROR,
        HostedFieldsErrorCode.HOSTED_FIELDS_TOKENIZATION_FAIL_ON_DUPLICATE,
      ].map((braintreeErrorCode) => ({
        code: 'VODAFONE_ERROR',
        reason: braintreeErrorCode,
        setup() {
          hostedFields.tokenize.mockRejectedValue(
            // @ts-ignore
            new BraintreeError({
              code: braintreeErrorCode,
              message: 'error',
              type: BraintreeError.types.INTERNAL,
            }),
          );
        },
      })),
      {
        code: 'HIGH_RISK_ERROR',
        reason: 'HIGH_RISK_ERROR from createTransaction API',
        setup() {
          hostedFields.getState.mockReturnValue(validState);
          const params = {
            accounttype: AccountType.POSTPAY,
            origin,
            PAYMENT_METHOD: 'CREDITCARD',
            FLOW_TYPE: 'VAULT',
            ORDER_ID: 'VDFO-12345',
            'X-SESSION_ID': '',
            AMOUNT: '0',
            HMAC: 'abc123',
          } as const;
          mockGetPaymentIframeHashParams.mockReturnValue(params);
          // @ts-ignore
          hostedFields.tokenize.mockResolvedValue(tokenizePayload);
          mockCardTransaction.mockRejectedValue(
            Object.assign(new Error('Bad Request'), {
              response: {
                status: 400,
                data: {
                  error: { code: 'HIGH_RISK_ERROR' },
                },
              },
            }),
          );

          simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
          trigger('validityChange', { ...validState, emittedBy: 'cvv' });
        },
      },
    ])('should send SUBMIT_FAILURE with $code for $reason', async ({ code, setup }) => {
      setup();

      simulateMessage({ source: 'omniscript', type: 'SUBMIT_REQUEST' });

      await act(waitForEventLoopToDrain);

      expect(postMessage).toHaveBeenCalledWith({
        source: 'vfe',
        type: 'SUBMIT_FAILURE',
        code,
      });
    });

    it.each([
      {
        params: {
          accounttype: AccountType.POSTPAY,
          origin,
          PAYMENT_METHOD: 'CREDITCARD',
          FLOW_TYPE: 'VAULT',
          ORDER_ID: 'VDFO-12345',
          'X-SESSION_ID': '',
          AMOUNT: '0',
          HMAC: 'abc123',
        },
        vault: true,
      },
      {
        params: {
          accounttype: AccountType.PREPAY,
          origin,
          PAYMENT_METHOD: 'CREDITCARD',
          FLOW_TYPE: 'CHARGE',
          ORDER_ID: 'VDFO-12345',
          'X-SESSION_ID': '',
          AMOUNT: '0',
          HMAC: 'abc123',
        },
        vault: false,
      },
    ] as const)('should tokenize and call API with FLOW_TYPE=$params.FLOW_TYPE', async ({ params, vault }) => {
      hostedFields.getState.mockReturnValue(validState);
      mockGetPaymentIframeHashParams.mockReturnValue(params);
      when(hostedFields.tokenize)
        // @ts-ignore
        .calledWith({ vault })
        // @ts-ignore
        .mockResolvedValue(tokenizePayload);
      const paymentResponse: Awaited<ReturnType<typeof mockCardTransaction>> = {
        response: JSON.stringify({
          order_id: params.ORDER_ID,
          credit_card: {
            amount: 25,
            currency: 'AUD',
            expiry: '05/21',
            first_six_digits: '512345',
            last_four_digits: '2346',
            name: 'TESTC',
            token: '5123452111852346',
            type: 'MASTERCARD',
          },
          receipt_number: '900477',
          response: {
            business_identifier: '61902127684',
            description: 'OK',
            reason_code: 'FUS_OK',
          },
        }),
        hmac: 'abcdef1234567890',
      };
      when(mockCardTransaction)
        .calledWith({
          payload: tokenizePayload,
          details: customerContactDetails,
          deviceData,
          params,
          paymentType: 'CREDITCARD',
        })
        .mockResolvedValue(paymentResponse);

      simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
      trigger('validityChange', { ...validState, emittedBy: 'cvv' });
      simulateMessage({ source: 'omniscript', type: 'SUBMIT_REQUEST' });

      await act(waitForEventLoopToDrain);

      expect(postMessage).toHaveBeenCalledWith({
        source: 'vfe',
        type: 'SUBMIT_SUCCESS',
        payload: paymentResponse,
      });
    });
  });

  describe('3D Secure', () => {
    const threeDSTestInputs = [
      {
        params: {
          accounttype: AccountType.POSTPAY,
          origin,
          PAYMENT_METHOD: 'CREDITCARD',
          FLOW_TYPE: 'VAULT',
          ORDER_ID: 'VDFO-12345',
          'X-SESSION_ID': '',
          AMOUNT: '0',
          HMAC: 'abc123',
        },
        vault: true,
      },
      {
        params: {
          accounttype: AccountType.PREPAY,
          origin,
          PAYMENT_METHOD: 'CREDITCARD',
          FLOW_TYPE: 'CHARGE',
          ORDER_ID: 'VDFO-12345',
          'X-SESSION_ID': '',
          AMOUNT: '0',
          HMAC: 'abc123',
        },
        vault: false,
      },
    ] as const;
    let trigger3DSEvent: <EventType extends ThreeDSecureEventType>(type: EventType) => void;
    beforeEach(() => {
      threeDSecure = {
        verifyCard: jest.fn(),
        on: jest.fn(),
        off: jest.fn(),
      } as Partial<typeof threeDSecure> as typeof threeDSecure;
      trigger3DSEvent = (type) =>
        act(() =>
          threeDSecure.on.mock.calls
            .filter((call) => call[0] === type)
            .map((call) => call[1])
            .forEach((handler) => handler()),
        );
      result = render(<CardPayment deviceData={deviceData} hostedFields={hostedFields} threeDSecure={threeDSecure} />);
      hostedFields.getState.mockReturnValue(validState);
    });

    it.each(threeDSTestInputs)(
      'should call 3DS verify card with nonce for FLOW_TYPE=$params.FLOW_TYPE',
      async ({ params, vault }) => {
        mockGetPaymentIframeHashParams.mockReturnValue(params);
        when(hostedFields.tokenize)
          // @ts-ignore
          .calledWith({ vault })
          // @ts-ignore
          .mockResolvedValue(tokenizePayload);

        simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
        trigger('validityChange', { ...validState, emittedBy: 'cvv' });
        simulateMessage({ source: 'omniscript', type: 'SUBMIT_REQUEST' });

        await act(waitForEventLoopToDrain);

        expect(threeDSecure.verifyCard).toHaveBeenCalledWith({
          amount: +params.AMOUNT,
          nonce: tokenizePayload.nonce,
          bin: tokenizePayload.details.bin,
          email: customerDetailsPayload.email,
          billingAddress: {
            phoneNumber: customerDetailsPayload.phone,
          },
        });
      },
    );

    it.each(threeDSTestInputs)(
      'should call 3DS verify card and call API with FLOW_TYPE=$params.FLOW_TYPE when liability is shifted',
      async ({ params, vault }) => {
        mockGetPaymentIframeHashParams.mockReturnValue(params);
        when(hostedFields.tokenize)
          // @ts-ignore
          .calledWith({ vault })
          // @ts-ignore
          .mockResolvedValue(tokenizePayload);
        when(threeDSecure.verifyCard)
          // @ts-ignore
          .calledWith({
            amount: +params.AMOUNT,
            nonce: tokenizePayload.nonce,
            bin: tokenizePayload.details.bin,
            email: customerDetailsPayload.email,
            billingAddress: {
              phoneNumber: customerDetailsPayload.phone,
            },
          })
          // @ts-ignore
          .mockResolvedValue(threeDSVerifyPayload);
        const paymentResponse: Awaited<ReturnType<typeof mockCardTransaction>> = {
          response: JSON.stringify({
            order_id: params.ORDER_ID,
            credit_card: {
              amount: 25,
              currency: 'AUD',
              expiry: '05/21',
              first_six_digits: '512345',
              last_four_digits: '2346',
              name: 'TESTC',
              token: '5123452111852346',
              type: 'MASTERCARD',
            },
            receipt_number: '900477',
            response: {
              business_identifier: '61902127684',
              description: 'OK',
              reason_code: 'FUS_OK',
            },
          }),
          hmac: 'abcdef1234567890',
        };
        const threeDSCardTransactionRequest: CreateTransactionRequest = {
          payload: threeDSVerifyPayload,
          details: customerContactDetails,
          deviceData,
          params,
          paymentType: 'CREDITCARD',
        };
        when(mockCardTransaction)
          // @ts-ignore
          .calledWith(threeDSCardTransactionRequest)
          // @ts-ignore
          .mockResolvedValue(paymentResponse);

        simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
        trigger('validityChange', { ...validState, emittedBy: 'cvv' });
        simulateMessage({ source: 'omniscript', type: 'SUBMIT_REQUEST' });

        await act(waitForEventLoopToDrain);

        expect(postMessage).toHaveBeenCalledWith({
          source: 'vfe',
          type: '3DS_CARD_VERIFIED',
        });
        expect(mockCardTransaction).toHaveBeenCalledWith(threeDSCardTransactionRequest);
        expect(postMessage).toHaveBeenCalledWith({
          source: 'vfe',
          type: 'SUBMIT_SUCCESS',
          payload: paymentResponse,
        });
      },
    );

    it.each(threeDSTestInputs)(
      'should not call API for FLOW_TYPE=$params.FLOW_TYPE when customer failed 3DS authentication and send SUBMIT_FAILURE',
      async ({ params, vault }) => {
        mockGetPaymentIframeHashParams.mockReturnValue(params);
        when(hostedFields.tokenize)
          // @ts-ignore
          .calledWith({ vault })
          // @ts-ignore
          .mockResolvedValue(tokenizePayload);
        when(threeDSecure.verifyCard)
          // @ts-ignore
          .calledWith({
            amount: +params.AMOUNT,
            nonce: tokenizePayload.nonce,
            bin: tokenizePayload.details.bin,
            email: customerDetailsPayload.email,
            billingAddress: {
              phoneNumber: customerDetailsPayload.phone,
            },
          })
          // @ts-ignore
          .mockResolvedValue({
            ...threeDSVerifyPayload,
            threeDSecureInfo: {
              ...threeDSVerifyPayload.threeDSecureInfo,
              liabilityShiftPossible: true,
              liabilityShifted: false,
            },
          } as braintree.ThreeDSecureVerifyPayload);

        simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
        trigger('validityChange', { ...validState, emittedBy: 'cvv' });
        simulateMessage({ source: 'omniscript', type: 'SUBMIT_REQUEST' });

        await act(waitForEventLoopToDrain);

        expect(postMessage).not.toHaveBeenCalledWith({
          source: 'vfe',
          type: '3DS_CARD_VERIFIED',
        });
        expect(mockCardTransaction).not.toHaveBeenCalled();
        expect(postMessage).toHaveBeenCalledWith({
          source: 'vfe',
          type: 'SUBMIT_FAILURE',
          code: 'VFE_3DS_LIABILITY_NOT_SHIFTED',
        });
      },
    );

    it.each(threeDSTestInputs)(
      'should not call API for FLOW_TYPE=$params.FLOW_TYPE when the card was ineligible for 3DS and send SUBMIT_FAILURE',
      async ({ params, vault }) => {
        mockGetPaymentIframeHashParams.mockReturnValue(params);
        when(hostedFields.tokenize)
          // @ts-ignore
          .calledWith({ vault })
          // @ts-ignore
          .mockResolvedValue(tokenizePayload);
        const threeDSIneligiblePayload = {
          ...threeDSVerifyPayload,
          threeDSecureInfo: {
            ...threeDSVerifyPayload.threeDSecureInfo,
            liabilityShifted: false,
            liabilityShiftPossible: false,
          },
        };
        when(threeDSecure.verifyCard)
          // @ts-ignore
          .calledWith({
            amount: +params.AMOUNT,
            nonce: tokenizePayload.nonce,
            bin: tokenizePayload.details.bin,
            email: customerDetailsPayload.email,
            billingAddress: {
              phoneNumber: customerDetailsPayload.phone,
            },
          })
          // @ts-ignore
          .mockResolvedValue(threeDSIneligiblePayload);

        simulateMessage({ source: 'omniscript', type: 'CUSTOMER_DETAILS', payload: customerDetailsPayload });
        trigger('validityChange', { ...validState, emittedBy: 'cvv' });
        simulateMessage({ source: 'omniscript', type: 'SUBMIT_REQUEST' });

        await act(waitForEventLoopToDrain);

        expect(postMessage).not.toHaveBeenCalledWith({
          source: 'vfe',
          type: '3DS_CARD_VERIFIED',
        });
        expect(mockCardTransaction).not.toHaveBeenCalled();
        expect(postMessage).toHaveBeenCalledWith({
          source: 'vfe',
          type: 'SUBMIT_FAILURE',
          code: 'VFE_3DS_LIABILITY_NOT_SHIFTED',
        });
      },
    );

    it('should post message when 3DS modal is rendered', () => {
      trigger3DSEvent('authentication-modal-render');
      expect(postMessage).toHaveBeenCalledWith({
        source: 'vfe',
        type: '3DS_MODAL_RENDERED',
      });
    });
  });
});
