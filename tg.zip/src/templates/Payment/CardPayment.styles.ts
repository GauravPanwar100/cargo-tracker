import styled from 'styled-components';
import { CC_EXP_MAX_WIDTH } from '@src/components/payment/CardField/CardExpiryDateField';
import { fontLineHeightSize } from '@src/lib/util/mixins';

export const FieldsGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  grid-template-areas:
    'cc-name'
    'cc-number'
    'cc-exp'
    'cc-csc'
    'msg';
  gap: 16px;
  padding: 16px 10px;

  // iframe width, not actual page width
  @media only screen and (min-width: 480px) {
    grid-template-columns: ${CC_EXP_MAX_WIDTH}px 1fr;
    grid-template-areas:
      'cc-name cc-name'
      'cc-number cc-number'
      'cc-exp cc-csc'
      'msg msg';
    gap: 24px;
    padding: 20px;
  }
`;

export const SecurityMessageContainer = styled.div`
  grid-area: msg;
  display: grid;
  gap: 8px;
  grid-template-columns: max-content 1fr;
  align-items: end;

  p {
    margin: 0;
    ${fontLineHeightSize('footnote')}
  }
`;
