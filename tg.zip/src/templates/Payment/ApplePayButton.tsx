import React, { useCallback } from 'react';
import braintree, { ApplePay } from 'braintree-web';
import Logger from '@src/lib/logger/logger';
import { getPaymentIframeHashParams } from '@src/lib/payment/params';
import { ReceivedMessageType, usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import { ButtonContainer, PayButton } from '@src/templates/Payment/ApplePayButton.styles';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import { getApiClient } from '@src/lib/api';
import { isTransactionError } from '@src/lib/payment/braintree';

interface ApplePayButtonProps {
  deviceData?: braintree.DataCollector['deviceData'];
  applePayInstance: ApplePay;
}

const ApplePayButton = ({ deviceData, applePayInstance }: ApplePayButtonProps) => {
  const [details, setDetails] = React.useState<Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload']>();

  const postMessage = usePaymentIframePostMessage((data) => {
    switch (data.type) {
      case 'CUSTOMER_DETAILS':
        setDetails(data.payload);
        break;

      case 'SUBMIT_REQUEST':
        requestPaymentHandler();
        break;

      default:
      // do nothing
    }
  });

  const requestPaymentHandler = useCallback(() => {
    if (!applePayInstance) {
      return;
    }
    const paymentRequest = applePayInstance.createPaymentRequest({
      total: {
        label: 'Vodafone',
        amount: getPaymentIframeHashParams().AMOUNT,
      },

      requiredBillingContactFields: ['postalAddress'],
    });

    let applePaySession: ApplePaySession | undefined;
    try {
      // Ignore types here as there is an issue with the type that does not allow for the constructor to be used
      // We are pasing in paymentRequest created above and the value 3, which indicates the version of the apple pay session API to use - we are currently using version 3
      // @ts-ignore
      applePaySession = new window.ApplePaySession(3, paymentRequest) as ApplePaySession | undefined;
    } catch (error) {
      return;
    }

    if (!applePaySession) {
      Logger.error('apple pay session could not be created');
      postMessage({ source: 'vfe', type: 'VFE_IFRAME_FAILED' });
      return;
    }

    applePaySession.onvalidatemerchant = async ({ validationURL }) => {
      try {
        const merchantSession = await applePayInstance.performValidation({
          validationURL,
          displayName: 'Vodafone Australia',
        });
        applePaySession!.completeMerchantValidation(merchantSession);
      } catch (error) {
        Logger.error('Error occured validating apple pay session', { error, ucode: '35b59e1' });
        postMessage({ source: 'vfe', type: 'SUBMIT_FAILURE', code: 'VODAFONE_ERROR' });
      }
    };

    applePaySession.onpaymentauthorized = async ({ payment: { token } }) => {
      try {
        postMessage({
          source: 'vfe',
          type: 'SUBMIT_INITIATED',
        });
        const payload = await applePayInstance.tokenize({ token });
        const transactionResponse = await getApiClient().createTransaction({
          payload,
          details: { email: details!.email, phone: details!.phone },
          deviceData: deviceData!,
          params: getPaymentIframeHashParams(),
          paymentType: 'APPLEPAY',
        });
        applePaySession!.completePayment(ApplePaySession.STATUS_SUCCESS);
        postMessage({
          source: 'vfe',
          type: 'SUBMIT_SUCCESS',
          payload: transactionResponse,
        });
      } catch (error) {
        Logger.error('Apple pay submission failed', { error, ucode: 'f4b72b3' });
        applePaySession!.completePayment(ApplePaySession.STATUS_FAILURE);
        postMessage({
          source: 'vfe',
          type: 'SUBMIT_FAILURE',
          code: isTransactionError(error) ? error.response.data.error.code : 'VODAFONE_ERROR',
        });
      }
    };

    applePaySession.begin();
  }, [applePayInstance, details, deviceData, postMessage]);

  return (
    <>
      {!details ? (
        <SpinnerSection />
      ) : (
        <ButtonContainer>
          <PayButton data-testid="apple-pay-button" type="button" onClick={requestPaymentHandler} />
        </ButtonContainer>
      )}
    </>
  );
};

export default ApplePayButton;
