import React, { useState } from 'react';
import GooglePayButton from '@src/components/payment/GooglePayButton';
import { ReceivedMessageType, usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import { noop } from 'lodash';
import { getPaymentIframeHashParams } from '@src/lib/payment/params';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import Logger from '@src/lib/logger/logger';

export interface GooglePayPaymentProps {
  googleMerchantId: string | undefined;
  deviceData: braintree.DataCollector['deviceData'] | undefined;
  googlePayInstance: braintree.GooglePayment | undefined;
}

export const GOOGLE_PAYMENTS_CLIENT_ENV = {
  TEST: 'TEST,',
  PROD: 'PROD',
} as const;

const GooglePayPayment = ({ googleMerchantId, deviceData, googlePayInstance }: GooglePayPaymentProps) => {
  const [googlePaymentsClient, setGooglePaymentsClient] = useState<google.payments.api.PaymentsClient>();
  const [googlePayDataRequest, setGooglePayDataRequest] = React.useState<google.payments.api.PaymentDataRequest>();
  const [isReadyToPay, setIsReadyToPay] = React.useState<boolean>();
  const [customerDetails, setCustomerDetails] =
    React.useState<Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload']>();

  const postMessage = usePaymentIframePostMessage((data) => {
    switch (data.type) {
      case 'CUSTOMER_DETAILS':
        setCustomerDetails(data.payload);
        break;
      default:
        noop();
    }
  });

  React.useEffect(() => {
    const stage = process.env.NEXT_PUBLIC_STAGE || '';
    const paymentsClientEnv = stage === 'prod' || stage === 'prprod' ? 'PRODUCTION' : 'TEST';

    setGooglePaymentsClient(
      new window.google.payments.api.PaymentsClient({
        environment: paymentsClientEnv,
        merchantInfo: {
          merchantId: googleMerchantId!,
          merchantName: '',
        },
      }),
    );
  }, [googleMerchantId]);

  React.useEffect(() => {
    if (!googlePayInstance) return;

    const { AMOUNT } = getPaymentIframeHashParams();

    async function getAllowedPaymentMethods() {
      const paymentDataRequest = await googlePayInstance?.createPaymentDataRequest({
        emailRequired: true, // Use this to get email in paymentData from google
        merchantInfo: {
          merchantId: googleMerchantId!,
        },
        transactionInfo: {
          currencyCode: 'AUD',
          totalPriceStatus: 'FINAL',
          totalPrice: AMOUNT,
        },
      });
      setGooglePayDataRequest(paymentDataRequest);
    }

    getAllowedPaymentMethods();
  }, [googleMerchantId, googlePayInstance]);

  React.useEffect(() => {
    if (!googlePaymentsClient || !googlePayDataRequest) return;

    googlePaymentsClient
      .isReadyToPay({
        apiVersion: 2,
        apiVersionMinor: 0,
        allowedPaymentMethods: googlePayDataRequest?.allowedPaymentMethods,
        existingPaymentMethodRequired: false,
      })
      .then((isReadyToPayResponse) => {
        setIsReadyToPay(isReadyToPayResponse.result);
        postMessage({
          source: 'vfe',
          type: 'VFE_IFRAME_READY',
          iframe: 'GOOGLE_PAY',
        });
      })
      .catch((error) => {
        Logger.error('GooglePay isReadyToPay error ', { error, ucode: 'a40be77' });
        postMessage({
          source: 'vfe',
          type: 'VFE_IFRAME_FAILED',
        });
      });
  }, [googlePayDataRequest, googlePayDataRequest?.allowedPaymentMethods, googlePaymentsClient, postMessage]);

  return (
    <>
      {!isReadyToPay || !customerDetails ? (
        <SpinnerSection />
      ) : (
        <GooglePayButton
          customerDetails={customerDetails}
          deviceData={deviceData}
          googlePayInstance={googlePayInstance}
          googlePayDataRequest={googlePayDataRequest}
          googlePaymentsClient={googlePaymentsClient}
        />
      )}
    </>
  );
};

export default GooglePayPayment;
