import styled from 'styled-components';

export const AliPayButtonContainer = styled.button``;

export const AliPayButton = styled.div`
  margin-right: 5px;
  margin-top: 2px;
  img {
    height: 32px;
    width: 65px;
  }
`;

export const AliPayButtonWrapper = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
`;
