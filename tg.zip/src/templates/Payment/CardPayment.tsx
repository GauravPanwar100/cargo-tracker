import { ElementType, Entries } from '@kablamo/kerosene';
import { HostedFields, ThreeDSecure } from 'braintree-web';
import BraintreeError from 'braintree-web/lib/braintree-error';
import cx from 'classnames';
import { noop } from 'lodash';
import React from 'react';
import { ReactComponent as SecurityMidSvg } from '@src/assets/svg/security-mid.svg';
import IconWrapper from '@src/components/core/IconWrapper';
import CardNameField from '@src/components/payment/CardField/CardNameField';
import CardNumberField from '@src/components/payment/CardField/CardNumberField';
import CardExpiryDateField from '@src/components/payment/CardField/CardExpiryDateField';
import CardSecurityCodeField from '@src/components/payment/CardField/CardSecurityCodeField';
import { getApiClient } from '@src/lib/api';
import Logger from '@src/lib/logger/logger';
import {
  CardType,
  HostedFieldsErrorCode,
  HostedFieldsState,
  NextFunction,
  ThreeDSecureErrorCode,
  isBraintreeError,
} from '@src/lib/payment/braintree';
import { SUPPORTED_CARD_TYPES } from '@src/lib/payment/cards';
import { getPaymentIframeHashParams } from '@src/lib/payment/params';
import { ReceivedMessageType, usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import { FieldsGrid, SecurityMessageContainer } from '@src/templates/Payment/CardPayment.styles';
import { CreateTransactionRequest } from '@src/lib/api/types';
import { shouldCreateCardTransaction } from '@src/lib/payment/3ds';
import { trackGtagEvent } from '@src/lib/tracking';

interface CardPaymentProps {
  deviceData: braintree.DataCollector['deviceData'] | undefined;
  hostedFields: HostedFields | undefined;
  threeDSecure?: ThreeDSecure;
}

const UPDATE_EVENTS = ['blur', 'focus', 'empty', 'notEmpty', 'cardTypeChange', 'validityChange'] as const;
const MOVE_FOCUS_ON_VALID: Partial<
  Record<braintree.HostedFieldsEvent['emittedBy'], Parameters<braintree.HostedFields['focus']>[0]>
> = {
  number: 'expirationDate',
  expirationDate: 'cvv',
};

type HostedFieldKeys = Exclude<
  keyof braintree.HostedFieldFieldOptions,
  'postalCode' | 'expirationMonth' | 'expirationYear'
>;

const CardPayment = ({ deviceData, hostedFields, threeDSecure }: CardPaymentProps) => {
  const ApiClient = getApiClient();
  const [card, setCard] = React.useState<ElementType<braintree.HostedFieldsEvent['cards']>>();
  const cardType: CardType | undefined = card?.type;
  const isSupportedCardType = SUPPORTED_CARD_TYPES.some((c) => c.type === cardType);
  const isUnsupportedCardType = !!cardType && !isSupportedCardType;
  const [fields, setFields] = React.useState<HostedFieldsState['fields']>();

  // Keep track of which fields have been 'touched' so that we don't trigger errors until after
  const [touched, setTouched] = React.useState<{
    [key in HostedFieldKeys]: boolean;
  }>({
    cardholderName: false,
    number: false,
    expirationDate: false,
    cvv: false,
  });

  const [eventsTracked, setEventsTracked] = React.useState<{
    [key in HostedFieldKeys]: { blank: boolean; invalid: boolean; isNotSupported?: boolean };
  }>({
    cardholderName: { blank: false, invalid: false },
    number: { blank: false, invalid: false, isNotSupported: false },
    expirationDate: { blank: false, invalid: false },
    cvv: { blank: false, invalid: false },
  });

  const touchAll = React.useCallback(
    () =>
      setTouched(
        (previous) =>
          Object.fromEntries(
            (Object.keys(previous) as ReadonlyArray<keyof typeof previous>).map((key) => [key, true] as const),
          ) as typeof previous,
      ),
    [],
  );

  const [details, setDetails] = React.useState<Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload']>();

  const postMessage = usePaymentIframePostMessage((data) => {
    switch (data.type) {
      case 'CUSTOMER_DETAILS':
        setDetails(data.payload);
        break;

      case 'SUBMIT_REQUEST':
        touchAll();

        if (isIncomplete() || isUnsupportedCardType) {
          postMessage({ source: 'vfe', type: 'SUBMIT_FAILURE', code: 'CUSTOMER_ERROR' });
          return;
        }
        postMessage({ source: 'vfe', type: 'CC_REQUEST_INITIATED' });
        hostedFields!
          .tokenize({ vault: getPaymentIframeHashParams().FLOW_TYPE === 'VAULT' })
          .then((payload) => {
            const createTransactionRequest: Omit<CreateTransactionRequest, 'payload'> = {
              details: { email: details!.email, phone: details!.phone },
              deviceData: deviceData!,
              params: getPaymentIframeHashParams(),
              paymentType: 'CREDITCARD',
            };
            return (
              threeDSecure
                ?.verifyCard({
                  amount: +getPaymentIframeHashParams().AMOUNT,
                  nonce: payload.nonce,
                  bin: payload.details.bin,
                  email: details?.email,
                  billingAddress: { phoneNumber: details?.phone },
                })
                .then((threeDSVerifyPayload) => {
                  if (
                    shouldCreateCardTransaction(
                      threeDSVerifyPayload.threeDSecureInfo.liabilityShifted,
                      threeDSVerifyPayload.threeDSecureInfo.liabilityShiftPossible,
                    )
                  ) {
                    postMessage({ source: 'vfe', type: '3DS_CARD_VERIFIED' });
                    return ApiClient.createTransaction({
                      payload: threeDSVerifyPayload,
                      ...createTransactionRequest,
                    });
                  }
                  throw new BraintreeError({
                    type: BraintreeError.types.CUSTOMER,
                    code: ThreeDSecureErrorCode.VFE_3DS_LIABILITY_NOT_SHIFTED,
                    message: '3DS verify card result liability is not shifted',
                  });
                }) ??
              ApiClient.createTransaction({
                payload,
                ...createTransactionRequest,
              })
            );
          })
          .then((payload) => {
            postMessage({
              source: 'vfe',
              type: 'SUBMIT_SUCCESS',
              payload,
            });
          })
          .catch((error) => {
            Logger.error('Payment submission failed', { error, ucode: '2d0abb0' });

            if (isBraintreeError(error)) {
              switch (error.code) {
                case HostedFieldsErrorCode.HOSTED_FIELDS_FIELDS_EMPTY:
                case HostedFieldsErrorCode.HOSTED_FIELDS_FIELDS_INVALID:
                case HostedFieldsErrorCode.HOSTED_FIELDS_TOKENIZATION_CVV_VERIFICATION_FAILED:
                  postMessage({ source: 'vfe', type: 'SUBMIT_FAILURE', code: 'CUSTOMER_ERROR' });
                  return;

                case ThreeDSecureErrorCode.VFE_3DS_LIABILITY_NOT_SHIFTED:
                  postMessage({
                    source: 'vfe',
                    type: 'SUBMIT_FAILURE',
                    code: 'VFE_3DS_LIABILITY_NOT_SHIFTED',
                  });
                  return;

                case HostedFieldsErrorCode.HOSTED_FIELDS_FAILED_TOKENIZATION:
                case HostedFieldsErrorCode.HOSTED_FIELDS_TOKENIZATION_NETWORK_ERROR:
                case HostedFieldsErrorCode.HOSTED_FIELDS_TOKENIZATION_FAIL_ON_DUPLICATE:
                default:
                  postMessage({ source: 'vfe', type: 'SUBMIT_FAILURE', code: 'VODAFONE_ERROR' });
                  return;
              }
            }

            postMessage({
              source: 'vfe',
              type: 'SUBMIT_FAILURE',
              // Try to use the error.code provided by the API error response, and if not present
              // default to `'VODAFONE_ERROR'`
              // e.g. `{ error: { code: 'HIGH_RISK_ERROR' } }`
              code: error.response?.data?.error?.code ?? 'VODAFONE_ERROR',
            });
          });
        break;

      default:
      // do nothing
    }
  });

  const isIncomplete = React.useCallback(() => {
    if (fields) {
      return (Object.keys(fields) as HostedFieldKeys[]).some((key) => fields[key].isEmpty || !fields[key].isValid);
    }
    return false;
  }, [fields]);

  React.useEffect(() => {
    if (!hostedFields) return noop;

    const onValidityChange = (e: braintree.HostedFieldsEvent) => {
      const moveTo = MOVE_FOCUS_ON_VALID[e.emittedBy];
      if (!moveTo || !e.fields[e.emittedBy].isValid) return;

      hostedFields.focus(moveTo);
    };

    const onInputSubmitRequest = () => {
      touchAll();
      postMessage({ source: 'vfe', type: 'SUBMIT_REQUEST' });
    };

    const update = () => {
      const state = hostedFields.getState();

      // NOTE: `cards` contains 0 or more potentially matching card types. Only if there is only exactly one can we be
      // sure about the card type.
      // e.g. an empty card number field would potentially match all card types, or one starting with 0 would match none
      setCard(state.cards.length === 1 ? state.cards[0] : undefined);
      setFields(state.fields);
      setTouched(
        (previous) =>
          Object.fromEntries(
            (Object.entries(previous) as Entries<typeof previous>[]).map(
              ([key, existing]) => [key, existing || state.fields[key].isFocused] as const,
            ),
          ) as typeof previous,
      );
    };

    hostedFields.on('validityChange', onValidityChange);
    hostedFields.on('inputSubmitRequest', onInputSubmitRequest);
    UPDATE_EVENTS.forEach((name) => hostedFields.on(name, update));
    update();

    const onLookupComplete = (_data: unknown, next: NextFunction) => {
      next!();
    };
    const onThreeDSModalRender = () => {
      postMessage({ source: 'vfe', type: '3DS_MODAL_RENDERED' });
    };
    const onAuthIframeAvailable = (event: { element: HTMLElement }, next: NextFunction) => {
      // an html element that contains the iframe
      const { element } = event;
      const AUTH_IFRAME_HEIGHT = 727;
      (element.children[0] as HTMLElement).style.setProperty('height', `${AUTH_IFRAME_HEIGHT}px`, 'important');
      window.parent.document
        .querySelector('iframe')
        ?.style.setProperty('height', `${AUTH_IFRAME_HEIGHT}px`, 'important');
      // hide hosted fields form
      document.querySelector<HTMLElement>('[role="form"]')?.style.setProperty('display', 'none');
      // put it on your page
      document.body.appendChild(element);
      // let the sdk know the element has been added to the page
      next!();
    };
    threeDSecure?.on('lookup-complete', onLookupComplete);
    threeDSecure?.on('authentication-modal-render', onThreeDSModalRender);
    // set up iframe listener
    threeDSecure?.on('authentication-iframe-available', onAuthIframeAvailable);

    return () => {
      hostedFields.off('validityChange', onValidityChange);
      hostedFields.off('inputSubmitRequest', onInputSubmitRequest);
      UPDATE_EVENTS.forEach((name) => hostedFields.off(name, update));
      threeDSecure?.off('lookup-complete', onLookupComplete);
      threeDSecure?.off('authentication-modal-render', onThreeDSModalRender);
      threeDSecure?.off('authentication-iframe-available', onAuthIframeAvailable);
    };
  }, [hostedFields, postMessage, threeDSecure, touchAll]);

  // Effect for event tracking
  React.useEffect(() => {
    if (fields) {
      (Object.keys(fields) as HostedFieldKeys[]).forEach((field) => {
        const { isFocused, isEmpty, isValid } = fields[field];
        const isTouched = touched[field];

        const accountTypeLabel = getPaymentIframeHashParams().accounttype.toLocaleLowerCase();

        const fieldLabelMap: { [key in HostedFieldKeys]: string } = {
          cardholderName: 'card name',
          cvv: 'security code',
          number: 'card number',
          expirationDate: 'expiry date',
        };

        const fieldReadyForEvent = !isFocused && isTouched;

        // track blank fields
        const blankEventTracked = eventsTracked[field].blank;
        if (fieldReadyForEvent && isEmpty && !blankEventTracked) {
          trackGtagEvent('validation', {
            event_label: `${accountTypeLabel} | blank ${fieldLabelMap[field]}`,
            event_category: 'error',
          });

          setEventsTracked((previous) => ({
            ...previous,
            [field]: { ...previous[field], blank: true },
          }));
        }

        const invalidEventTracked = eventsTracked[field].invalid;
        if (fieldReadyForEvent && !isEmpty && !isValid && !invalidEventTracked) {
          trackGtagEvent('validation', {
            event_label: `${accountTypeLabel} | invalid ${fieldLabelMap[field]}`,
            event_category: 'error',
          });

          setEventsTracked((previous) => ({
            ...previous,
            [field]: { ...previous[field], invalid: true },
          }));
        }

        const isNotSupportedEventTracked = !!eventsTracked[field].isNotSupported;
        if (fieldReadyForEvent && isValid && isUnsupportedCardType && !isNotSupportedEventTracked) {
          trackGtagEvent('validation', {
            event_label: `${accountTypeLabel} | not accepted card type`,
            event_category: 'error',
          });

          setEventsTracked((previous) => ({
            ...previous,
            [field]: { ...previous[field], isNotSupported: true },
          }));
        }
      });
    }
  }, [eventsTracked, fields, isUnsupportedCardType, touched]);

  return (
    <FieldsGrid
      className={cx(
        'cc-fields',
        isSupportedCardType && 'supported-card-type',
        isUnsupportedCardType && 'unsupported-card-type',
        cardType && `card-type-${cardType}`,
      )}
      data-testid="cc-fields"
    >
      <CardNameField
        isEmpty={fields?.cardholderName.isEmpty ?? true}
        isFocused={fields?.cardholderName.isFocused ?? false}
        isTouched={touched.cardholderName}
        isValid={fields?.cardholderName.isValid ?? false}
      />
      <CardNumberField
        card={card}
        hostedFields={hostedFields}
        isEmpty={fields?.number.isEmpty ?? true}
        isFocused={fields?.number.isFocused ?? false}
        isTouched={touched.number}
        isValid={(fields?.number.isValid ?? false) && isSupportedCardType}
        isUnsupportedCardType={isUnsupportedCardType}
      />
      <CardExpiryDateField
        isEmpty={fields?.expirationDate.isEmpty ?? true}
        isFocused={fields?.expirationDate.isFocused ?? false}
        isTouched={touched.expirationDate}
        isValid={fields?.expirationDate.isValid ?? false}
      />
      <CardSecurityCodeField
        card={card}
        isEmpty={fields?.cvv.isEmpty ?? true}
        isFocused={fields?.cvv.isFocused ?? false}
        isTouched={touched.cvv}
        isValid={fields?.cvv.isValid ?? false}
      />
      <SecurityMessageContainer>
        <IconWrapper height="24px" width="24px" svg={SecurityMidSvg} />
        <p>Your payment is safe and secure.</p>
      </SecurityMessageContainer>
    </FieldsGrid>
  );
};

export default CardPayment;
