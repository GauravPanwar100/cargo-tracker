import React from 'react';
import { CommonPaymentIframeHashParams, getPaymentIframePath } from '@src/lib/payment/params';
import { PaymentMethodFlows } from '@src/lib/payment/braintree';

export type TestIframeProps = Partial<Omit<CommonPaymentIframeHashParams, 'origin'>> &
  Pick<CommonPaymentIframeHashParams, 'accounttype'> &
  PaymentMethodFlows;

const TestIframe = (params: TestIframeProps) => {
  const [origin, setOrigin] = React.useState('');

  React.useEffect(() => {
    setOrigin(window.origin);
  }, []);

  React.useEffect(() => {
    const onMessage = (e: MessageEvent<unknown>) => {
      if (e.origin !== window.origin) return;

      // eslint-disable-next-line no-console
      console.log('Received message:', e.data);
    };

    window.addEventListener('message', onMessage);

    return () => {
      window.removeEventListener('message', onMessage);
    };
  }, []);

  return (
    <>
      {origin && (
        <iframe
          title="Payment"
          // eslint-disable-next-line react/destructuring-assignment
          src={`/iframe/${getPaymentIframePath(params.PAYMENT_METHOD)}#${new URLSearchParams([
            ['origin', origin],
            ...Object.entries(params),
          ])}`}
          style={{ border: 0, height: 100, width: '100%' }}
        />
      )}
    </>
  );
};

export default TestIframe;
