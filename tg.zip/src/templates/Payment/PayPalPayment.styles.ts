import styled from 'styled-components';

export const PayPalPaymentContainer = styled.div`
  width: 100%;

  @media only screen and (min-width: 750px) {
    width: 750px;
    margin: auto;
  }
`;
