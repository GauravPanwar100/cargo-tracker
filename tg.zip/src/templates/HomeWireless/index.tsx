export { default } from './HomeWireless';
