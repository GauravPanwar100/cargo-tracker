import compact from 'lodash/compact';
import kebabCase from 'lodash/kebabCase';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ThemeProvider } from 'styled-components';
import Divider from '@src/components/core/Divider';
import { Grid, GridCol } from '@src/components/core/Grid';
import Nudge from '@src/components/vfe/Nudge';
import Section from '@src/components/core/Section';
import AddressChecker from '@src/components/vfe/AddressChecker';
import QuickLink from '@src/components/core/QuickLink';
import {
  AddToBasketParams,
  AddressCheckerResponse,
  Basket,
  BasketRequestItem,
  CartItemType,
  CartProductSubType,
  CartProductType,
  CatalogCode,
  HomeInternetModemItem,
  HomeInternetPlanCardCtaParam,
  HomeWirelessPageResponse,
  HomeWirelessPlansResponse,
  ModemChildBasketRequestItem,
  OptimizeContentKey,
  PlanEndpoint,
  PromoSubtype,
} from '@src/lib/api/types';
import { getApiClient } from '@src/lib/api';
import { useStickyCart } from '@src/lib/context/sticky-cart';
import { useBasketState } from '@src/lib/context/basket';
import { LocalStorageClient, SessionStorageClient } from '@src/lib/storage';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import { AddressDetails, ProductItem } from '@src/lib/storage/types';
import { lightTheme, midTheme } from '@src/lib/theme';
import TitleSection from '@src/templates/common/TitleSection';
import FaqTermsAndConditionsSection from '@src/templates/common/FaqTermsAndConditionsSection';
import AuthenticatedBackButton from '@src/components/vfe/AuthenticatedBackButton';
import { useRouter } from 'next/router';
import { decoratePathWithQueries, stripQueryFromPath } from '@src/lib/util/url';
import { formatBundleForTracking, trackEvent, useTrackPage } from '@src/lib/tracking';
import {
  addToBasketAndNavigateToCartPage,
  getRafUpdateRequestParams,
  isFhwPlanBasketItem,
  setRafItemUpdated,
} from '@src/lib/util/cart';
import { safeRouterPush } from '@src/lib/util/router';
import { scrollElementIntoViewThenFocusInput } from '@src/lib/util/dom';
import { Flag, RedirectFlag, useFeatureFlagValue, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { MaintenancePage } from '@src/lib/util/error';
import { useCustomerData } from '@src/lib/context/customer-data';
import { QueryKey } from '@src/lib/util/query';
import useBnsOffer from '@src/lib/hooks/use-bns-offer';
import { BnsOfferProvider } from '@src/lib/context/bns-offer-data';
import HomeWirelessStepSection from '@src/templates/Nbn/NbnStepSection';
import { getHomeInternetModemPriceInfo, useFhwDetailsFn } from '@src/lib/util/home-internet';
import { usePlanIconUrl } from '@src/lib/context/header-data';
import { usePreviouslyViewedContent, usePromotionalCampaignsContent } from '@src/lib/context/global-content';
import { storePreviouslyViewedProduct } from '@src/lib/util/previously-viewed';
import InlineBanner from '@src/components/core/InlineBanner';
import UspSection from '@src/components/vfe/UspSection';
import { isUpgradesRoute } from '@src/lib/util/journey';
import ExperienceFragment from '@src/components/vfe/ExperienceFragment';
import { JourneyStepCompletionParams } from '@src/components/core/Journey/JourneyStep/JourneyStep';
import { ModemPriceInfoProvider } from '@src/lib/context/modem-price-info';
import { PayIn4ContentProvider } from '@src/lib/context/pay-in-four-content-provider';
import { storeOptimizeContent } from '@src/lib/util/promotional-campaigns';
import HomeWirelessPlansSection from './HomeWirelessPlansSection';
import { HomeInternetDataMap, HomeInternetType, previouslyViewedNames } from './HomeWireless.constants';

export interface HomeWirelessTemplateProps {
  addressFields: AddressCheckerResponse;
  fhwPlansResponse: HomeWirelessPlansResponse;
  pageData: HomeWirelessPageResponse;
  redirectFlag: RedirectFlag;
  internetType: HomeInternetType;
  promoAvailabilityPlanEndPoint: PlanEndpoint;
  extraOffer?: string;
}

const HomeWirelessTemplate: React.FC<HomeWirelessTemplateProps> = ({
  addressFields,
  fhwPlansResponse,
  pageData,
  redirectFlag,
  internetType,
  promoAvailabilityPlanEndPoint,
  extraOffer,
}) => {
  const { asPath, query } = useRouter();
  const path = stripQueryFromPath(asPath);
  const isUpgradeJourney = isUpgradesRoute(path);
  const bnsOffer = useBnsOffer();
  const promoCampaignsContent = usePromotionalCampaignsContent();

  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });

  const isStuckCartEnabled = useFeatureFlagValue(Flag.DISABLE_STUCK_CART);

  const [addToBasketState, addToBasket, addToBasketDispatch] = useImperativeData<AddToBasketParams, Basket>(
    getApiClient().addToBasket,
  );

  const { plans, inlineBanners, experienceFragments } = fhwPlansResponse.planListing;
  const topBannerData = inlineBanners?.find((banner) => banner.bannerId === 'top-banner');
  const bottomBannerData = inlineBanners?.find((banner) => banner.bannerId === 'bottom-banner');

  const step1Ref = useRef<HTMLDivElement>(null);
  const step1InputRef = useRef<HTMLInputElement>(null);
  const [addressDetails, setAddressDetails] = useState<AddressDetails | null>(null);
  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [isFhwEligible, setFhwEligible] = useState<boolean | null>(null);

  const { fhwModemsContent: modem, quickLinks } = pageData;

  const { customerBundleAndSaveCount } = useCustomerData();

  const { continueJourney, catalogCode } = HomeInternetDataMap[internetType];
  const storeFhwDetails = useFhwDetailsFn(setAddressDetails, setFhwEligible, continueJourney, path);

  const [{ stickyCart }, stickyCartDispatch] = useStickyCart();

  const { getBasketState } = useBasketState();

  const onStickyCartCtaClick = useCallback(async () => {
    if (!stickyCart || !addressDetails) return;

    const plan = stickyCart.find(isFhwPlanBasketItem); // Update to FHW plan item

    if (!plan) return;

    trackEvent({
      pageEventAttributeOne: 'continue-to-cart',
      pageEventType: 'button',
      pageEventValue: 'click',
    });
    // Merge the Sticky Cart contents with the contents of any existing Local Storage basket
    // This will also calculate and apply a unique package ID for these new NBN items
    const response = await addToBasket({
      items: stickyCart,
      additionalBnsCount: customerBundleAndSaveCount,
      raf: getRafUpdateRequestParams(stickyCart, getBasketState.data),
    });

    if (!response) return;

    LocalStorageClient.setHomeWirelessContext(response.basketId, addressDetails, internetType);

    // If raf has been applied to the item thats just being added, notify the cart page to show the RAF MSO Alert
    if (response.raf) {
      const { appliedCatalogCode, isValid } = response.raf;
      if (appliedCatalogCode && getBasketState.data?.raf?.appliedCatalogCode && isValid) {
        setRafItemUpdated(appliedCatalogCode, getBasketState.data.raf.appliedCatalogCode);
      }
    }
    safeRouterPush(decoratePathWithQueries('/cart', [QueryKey.NUDGE_REFERRER]));
  }, [stickyCart, addressDetails, addToBasket, customerBundleAndSaveCount, getBasketState.data, internetType]);

  // Keep our Sticky Cart CTA up to date as it is memoised with useCallback
  useEffect(() => {
    stickyCartDispatch({
      type: 'SET_ON_CTA_CLICK',
      payload: {
        ctaLabel: 'Continue to cart',
        onCtaClick: onStickyCartCtaClick,
      },
    });
  }, [stickyCartDispatch, onStickyCartCtaClick]);

  // Any time either of the requests is loading, clear the error state of related requests and
  // disable the Sticky Cart CTA
  useEffect(() => {
    const { isLoading } = addToBasketState;
    stickyCartDispatch({
      type: 'SET_IS_CTA_DISABLED',
      payload: isLoading,
    });

    if (!addToBasketState.isLoading && isLoading) {
      addToBasketDispatch({
        type: 'CLEAR_ERROR',
      });
    }
  }, [addToBasketDispatch, addToBasketState, addToBasketState.isLoading, stickyCartDispatch]);

  // Apply the Sticky Cart error state if our apply package ID and add to cart call breaks
  // This is the call that happens when you click the Sticky Cart CTA
  useEffect(() => {
    const isError = !!addToBasketState.error;
    stickyCartDispatch({
      type: 'SET_IS_ERROR',
      payload: isError,
    });
  }, [addToBasketState.error, stickyCartDispatch]);

  useEffect(() => {
    // Clear previous plan selection when inelligible address is entered
    if (!isFhwEligible && selectedPlanId) {
      setSelectedPlanId('');
      stickyCartDispatch({ type: 'RESET_STICKY_CART' });
    }
  }, [isFhwEligible, selectedPlanId, stickyCartDispatch]);

  const goToNextStep = useCallback(
    async (params?: JourneyStepCompletionParams) => {
      if (!params) return Promise.resolve(false);
      const { items } = params;

      const addToBasketResponse = await addToBasketAndNavigateToCartPage(
        items,
        customerBundleAndSaveCount,
        extraOffer,
        getBasketState.data,
      );
      // Add address to local storage when add to basket is successful
      if (addToBasketResponse && addressDetails) {
        LocalStorageClient.setHomeWirelessContext(undefined, addressDetails, internetType);
      }
      return Promise.resolve(addToBasketResponse);
    },
    [customerBundleAndSaveCount, getBasketState.data, extraOffer, addressDetails, internetType],
  );

  const onCardCtaClick = useCallback(
    async ({ plan, withModem, ctaLabel, discountedCost = null }: HomeInternetPlanCardCtaParam) => {
      // Scroll up to step one for the user to interact with it
      if (!addressDetails) {
        scrollElementIntoViewThenFocusInput(step1Ref.current, step1InputRef.current);
        return;
      }

      // FHW will have a single modem as part of product construct
      const modemContent: HomeInternetModemItem = modem.modemPlans[0];

      const childProduct: ModemChildBasketRequestItem | undefined =
        modem && withModem
          ? {
              catalogCode: CatalogCode.NBN_MODEMS,
              itemType: CartItemType.MODEM,
              packageId: '',
              priceInfo: {
                recurringCharge: fhwPlansResponse?.modemPriceInfo?.recurringCharge,
                adjustedMRCAmount: fhwPlansResponse?.modemPriceInfo?.loyaltyMRCAmount,
              },
              productCode: modemContent.productId as string,
              productConfig: {
                contractTerm: fhwPlansResponse.modemPriceInfo.contractTerm,
              },
              productName: modemContent.productDisplayName,
              productType: CartProductType.DEVICE,
              productSubType: CartProductSubType.NBN_MODEM,
              relatedContent: {
                modemName: modemContent.productDisplayName,
              },
            }
          : undefined;
      const basketItems: BasketRequestItem[] = [
        {
          catalogCode,
          productCode: plan.planId,
          childProducts: compact([childProduct]),
          itemType: CartItemType.PLAN,
          packageId: '',
          priceInfo: {
            recurringCharge: plan.recurringCharge,
            oneTimeCharge: plan.oneTimeCharge,
            adjustedMRCAmount: discountedCost ?? plan.discountedRecurringCharge,
          },
          productConfig: {
            contractTerm: String(plan.contractTerm),
          },
          productName: plan.planName,
          productType: CartProductType.PLAN_FIXED,
        },
      ];

      setSelectedPlanId(plan.planId);
      stickyCartDispatch({
        type: 'SET_STICKY_CART',
        payload: {
          items: basketItems,
        },
      });

      if (withModem) {
        stickyCartDispatch({
          type: 'SET_ITEM_TYPES',
          payload: [CartItemType.PLAN, CartItemType.MODEM],
        });
      } else {
        stickyCartDispatch({
          type: 'SET_ITEM_TYPES',
          payload: [CartItemType.PLAN],
        });
      }

      if (isStuckCartEnabled) {
        await goToNextStep({ items: basketItems });
      }

      trackEvent({
        pageEventType: 'button',
        pageEventValue: 'click',
        pageEventAttributeOne: kebabCase(ctaLabel),
        stickyCart: [formatBundleForTracking(basketItems)],
      });
    },
    [
      addressDetails,
      modem,
      fhwPlansResponse.modemPriceInfo?.recurringCharge,
      fhwPlansResponse.modemPriceInfo?.loyaltyMRCAmount,
      fhwPlansResponse.modemPriceInfo.contractTerm,
      catalogCode,
      stickyCartDispatch,
      isStuckCartEnabled,
      goToNextStep,
    ],
  );

  const [onCtaClickState, onCtaClick] = useImperativeData(onCardCtaClick);

  useTrackPage({
    pageTitle: pageData.fhwTitleContent.seoTitle || '',
    path,
    nudgeReferrer: (query[QueryKey.NUDGE_REFERRER] || '').toString(),
  });

  const imageUrl = usePlanIconUrl();
  const previouslyViewedContent = usePreviouslyViewedContent();

  useEffect(() => {
    const productName = previouslyViewedNames[internetType];

    if (productName) {
      const fallback: ProductItem = {
        productName,
        productImg: { imageUrl, altText: productName },
        productUrl: window.location.href,
        id: catalogCode,
      };
      storePreviouslyViewedProduct(catalogCode, fallback, previouslyViewedContent);
    }
  }, [catalogCode, imageUrl, internetType, previouslyViewedContent]);

  useEffect(() => {
    const productName = previouslyViewedNames[internetType];

    if (productName) {
      LocalStorageClient.trackViewedProduct({
        productName,
        productUrl: window.location.href,
        productImg: {
          altText: productName,
          imageUrl,
        },
        id: catalogCode,
      });
    }
  }, [catalogCode, imageUrl, internetType]);

  useEffect(() => {
    if (addressDetails) {
      // call 4G/5G promo vailability API call once address validated
      getApiClient()
        .fetchPromoAvailability({
          subType: PromoSubtype.OnlineBTL,
          planEndpoint: promoAvailabilityPlanEndPoint,
        })
        .then((promoAvailability) => {
          if (promoCampaignsContent) {
            const status = JSON.parse(SessionStorageClient.getInternetSessionContent() || '');
            const fhw5GCoverage = !!status.continue5gFhwJourney;
            const fhw5GPromoAvailability = fhw5GCoverage;
            const is4G = internetType === HomeInternetType.FHW_4G;
            const isUpsell5GPromo = is4G && fhw5GPromoAvailability;
            const availability = isUpsell5GPromo ? fhw5GPromoAvailability : promoAvailability.availability;
            storeOptimizeContent({
              catalogCode:
                internetType === HomeInternetType.FHW_4G ? CatalogCode.FHW_4G_PLANS : CatalogCode.FHW_5G_PLANS,
              promoCampaignsContent,
              promoAvailability: availability,
              optimizeContentKey: OptimizeContentKey.PLAN_ONLINE_OFFER,
            });
          }
        });
    }
  }, [addressDetails, promoAvailabilityPlanEndPoint, promoCampaignsContent, internetType]);

  const modemPriceInfo = getHomeInternetModemPriceInfo(fhwPlansResponse);

  return (
    <ModemPriceInfoProvider modemPriceInfo={modemPriceInfo}>
      <PayIn4ContentProvider
        payIn4Content={{
          showPayIn4PromoContent: fhwPlansResponse.planListing.showPayIn4PromoContent,
          payIn4PromoContentThreshold: fhwPlansResponse.planListing.payIn4PromoContentThreshold,
        }}
      >
        <main>
          <Nudge variant="fhw" />
          {experienceFragments && !!experienceFragments.length && <ExperienceFragment {...experienceFragments[0]} />}
          <div id="banner-5g-ab-testing">{topBannerData && <InlineBanner bannerData={topBannerData} />}</div>
          <TitleSection pageHeaderData={pageData.fhwTitleContent} />
          <AuthenticatedBackButton />
          <UspSection
            {...fhwPlansResponse.planListing}
            isUpgradeJourney={isUpgradeJourney}
            iconSizeVariant={fhwPlansResponse.planListing.iconTilesVariant || 'biggie'}
            backgroundColor={fhwPlansResponse.planListing.iconTilesBgColor || lightTheme.variants.backgroundColor}
          />
          <ThemeProvider theme={midTheme}>
            <Section ref={step1Ref} spacingTop={{ xs: 's', m: 'xxl' }}>
              <Grid rowGap={{ xs: '16px', m: '24px' }}>
                <GridCol gridColSpan={{ xs: 12, m: 8 }} gridColStart={{ xs: 1, m: 3 }}>
                  <HomeWirelessStepSection step={pageData.fhwStepsContent.steps[0]} />
                </GridCol>
                <GridCol gridColSpan={{ xs: 12, m: 6 }} gridColStart={{ xs: 1, m: 4 }}>
                  <div id="banner-5g-addressChecker">
                    <AddressChecker
                      addressFields={addressFields}
                      id="addressChecker"
                      storeHomeInternetDetails={storeFhwDetails}
                      step1InputRef={step1InputRef}
                      internetType={internetType}
                      pathName={path}
                    />
                  </div>
                </GridCol>
              </Grid>
            </Section>
            <Section spacingBottom={null} spacingTop={null}>
              <Grid>
                <GridCol>
                  <Divider />
                </GridCol>
              </Grid>
            </Section>
            <Section spacingTop={{ xs: 's', m: 'xxl' }} spacingBottom={{ xs: 's', m: 'm' }}>
              <Grid>
                <GridCol gridColSpan={{ xs: 12, m: 8 }} gridColStart={{ xs: 1, m: 3 }}>
                  <HomeWirelessStepSection step={pageData.fhwStepsContent.steps[1]} />
                </GridCol>
              </Grid>
            </Section>
          </ThemeProvider>
          <BnsOfferProvider offers={bnsOffer}>
            <ModemPriceInfoProvider modemPriceInfo={fhwPlansResponse.modemPriceInfo}>
              <HomeWirelessPlansSection
                addToBasketState={addToBasketState}
                needsAddressCheck={!addressDetails}
                needsAddressCtaLabel={addressFields.addressCoverage.cta}
                onCardCtaClick={onCtaClick}
                planListing={plans}
                selectedPlanId={selectedPlanId}
                pageTitle={pageData.fhwTitleContent.seoTitle}
                pagePath={path}
                isFhwEligible={!!isFhwEligible}
                internetType={internetType}
                onCtaClickState={onCtaClickState}
              />
            </ModemPriceInfoProvider>
          </BnsOfferProvider>
          {bottomBannerData && <InlineBanner bannerData={bottomBannerData} />}
          <ThemeProvider theme={midTheme}>
            {quickLinks?.quickLinks?.length && (
              <>
                <Section>
                  <Grid>
                    {quickLinks.quickLinks.map((item) => (
                      <GridCol gridColSpan={{ xs: 12, m: 6 }} key={`quicklink_${item.title}`}>
                        <QuickLink
                          key={item.title}
                          description={item.description}
                          href={item.targetUrl}
                          icon={item.iconUrl}
                          title={item.title}
                        />
                      </GridCol>
                    ))}
                  </Grid>
                </Section>
              </>
            )}
            <FaqTermsAndConditionsSection faqs={pageData.fhwFaqContent} termsAndConditions={pageData.fhwTncsContent} />
          </ThemeProvider>
        </main>
      </PayIn4ContentProvider>
    </ModemPriceInfoProvider>
  );
};

export default HomeWirelessTemplate;
