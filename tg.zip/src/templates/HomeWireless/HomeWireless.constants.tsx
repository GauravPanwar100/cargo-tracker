import { Address } from '@src/components/vfe/AddressChecker/AddressChecker.interfaces';
import { CatalogCode } from '@src/lib/api/types';
import { getInstallationAddress } from '@src/lib/util/cart';

export enum ContinueJourney {
  FHW_4G = 'continue4gFhwJourney',
  FHW_5G = 'continue5gFhwJourney',
  NBN = 'continueNbnJourney',
}

export enum HomeInternetType {
  FHW_4G = 'FHW_4G',
  FHW_5G = 'FHW_5G',
  NBN = 'NBN',
  // Need to check if there will be new internet type for Samsung plan network check
}

export enum LocalStorageItemKey {
  FHW_4G = 'HOME_WIRELESS_4G_DETAILS',
  FHW_5G = 'HOME_WIRELESS_5G_DETAILS',
  NBN = 'NBN_DETAILS',
}

export const HomeInternetDataMap = {
  [HomeInternetType.FHW_4G]: {
    continueJourney: ContinueJourney.FHW_4G,
    catalogCode: CatalogCode.FHW_4G_PLANS,
    localStorageItemKey: LocalStorageItemKey.FHW_4G,
    getAddressFn: (): Address => {
      return getInstallationAddress(HomeInternetType.FHW_4G);
    },
  },
  [HomeInternetType.FHW_5G]: {
    continueJourney: ContinueJourney.FHW_5G,
    catalogCode: CatalogCode.FHW_5G_PLANS,
    localStorageItemKey: LocalStorageItemKey.FHW_5G,
    getAddressFn: (): Address => {
      return getInstallationAddress(HomeInternetType.FHW_5G);
    },
  },
  [HomeInternetType.NBN]: {
    continueJourney: ContinueJourney.NBN,
    catalogCode: CatalogCode.NBN_PLANS,
    localStorageItemKey: LocalStorageItemKey.NBN,
    getAddressFn: (): Address => {
      return getInstallationAddress(HomeInternetType.NBN);
    },
  },
};

export const previouslyViewedNames: { [key: string]: string } = {
  [HomeInternetType.FHW_4G]: '4G Home Wireless Broadband plans',
  [HomeInternetType.FHW_5G]: '5G Home Internet plans',
};
