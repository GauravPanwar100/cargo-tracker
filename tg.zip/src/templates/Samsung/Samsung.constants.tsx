export const PATRNER_COOKIE_NAME = 'partnerTransactionDetails';
export const CART_SPLITTER_MESSAGE_SAMSUNG =
  'Offer available for new or additional plans only. You cannot change your current plan.';
export const SAMSUNG = 'samsung';
export const MOBILE_COVERAGE_NO_SUGGESTION_LINK = 'https://www.vodafone.com.au/network/coverage-checker';
