export const nbnPlans = 'nbn&trade; plans';
