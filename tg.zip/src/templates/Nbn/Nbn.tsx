/* eslint-disable no-console */
import kebabCase from 'lodash/kebabCase';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ThemeProvider } from 'styled-components';
import Divider from '@src/components/core/Divider';
import { Grid, GridCol } from '@src/components/core/Grid';
import Nudge from '@src/components/vfe/Nudge';
import InlineBanner from '@src/components/core/InlineBanner';
import Section from '@src/components/core/Section';
import AddressChecker from '@src/components/vfe/AddressChecker';
import {
  AddressStatus,
  AddressStatusWithServiceQualification,
  PickedMatchedAddress,
} from '@src/components/vfe/AddressChecker/AddressChecker.interfaces';
import {
  AddToBasketParams,
  AddressCheckerResponse,
  Basket,
  CartItemType,
  CatalogCode,
  NbnPageResponse,
  NbnPlan,
  NbnPlansResponse,
  OptimizeContentKey,
  PlanEndpoint,
  PromoSubtype,
} from '@src/lib/api/types';
import { getApiClient } from '@src/lib/api';
import { useStickyCart } from '@src/lib/context/sticky-cart';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import { LocalStorageClient, SessionStorageClient } from '@src/lib/storage';
import { NbnDetails } from '@src/lib/storage/types';
import { lightGreyTheme, midTheme } from '@src/lib/theme';
import TitleSection from '@src/templates/common/TitleSection';
import FaqTermsConditionsSection from '@src/templates/common/FaqTermsAndConditionsSection';
import AuthenticatedBackButton from '@src/components/vfe/AuthenticatedBackButton';
import { useRouter } from 'next/router';
import { decoratePathWithQueries, stripQueryFromPath } from '@src/lib/util/url';
import { formatBundleForTracking, trackEvent, useTrackPage } from '@src/lib/tracking';
import { getRafUpdateRequestParams, isNbnPlanBasketItem, setRafItemUpdated } from '@src/lib/util/cart';
import { safeRouterPush } from '@src/lib/util/router';
import { scrollElementIntoView, scrollElementIntoViewThenFocusInput } from '@src/lib/util/dom';
import {
  Flag,
  RedirectFlag,
  useFeatureFlag,
  useFeatureFlagValue,
  useRedirectFeatureFlag,
} from '@src/lib/context/feature-flags';
import { MaintenancePage } from '@src/lib/util/error';
import { useCustomerData } from '@src/lib/context/customer-data';
import { QueryKey } from '@src/lib/util/query';
import {
  HighSpeedPlanTiers,
  convertStreetType,
  extractHighSpeedEligibility,
} from '@src/components/vfe/AddressChecker/utils';
import useBnsOffer from '@src/lib/hooks/use-bns-offer';
import { BnsOfferProvider } from '@src/lib/context/bns-offer-data';
import { isHighSpeedPlan } from '@src/components/vfe/PlanSelectorCard/utils';
import useQueryLogin from '@src/lib/hooks/use-query-login';
import UspSection from '@src/components/vfe/UspSection';
import { isUpgradesRoute } from '@src/lib/util/journey';
import ExperienceFragment from '@src/components/vfe/ExperienceFragment';
import { ConsolidatedNbnPlan, consolidateNbnPlans, constructNbnStickyCartItem } from '@src/lib/util/nbn';
import ActionArea from '@src/templates/Nbn/NbnStepSection/ActionArea';
import NbnPlanSectionUplift from '@src/templates/Nbn/NbnPlansSection/NbnPlanSectionUplift';
import NbnModemSection from '@src/templates/Nbn/NbnModemSection';
import StuckCart from '@src/components/vfe/StuckCart';
import StickyCart from '@src/components/vfe/StickyCart';
import { getHomeInternetModemPriceInfo } from '@src/lib/util/home-internet';
import { ModemPriceInfoProvider } from '@src/lib/context/modem-price-info';
import { useModalContent } from '@src/lib/context/modal';
import { PayIn4ContentProvider } from '@src/lib/context/pay-in-four-content-provider';
import { usePromotionalCampaignsContent } from '@src/lib/context/global-content';
import { storeOptimizeContent } from '@src/lib/util/promotional-campaigns';
import { useBasketState } from '@src/lib/context/basket';
import NbnInformationSection from './NbnInformationSection';
import NbnPlansSection from './NbnPlansSection';
import NbnStepSection from './NbnStepSection';
import { HomeInternetType } from '../HomeWireless/HomeWireless.constants';

export interface NbnTemplateProps {
  addressFields: AddressCheckerResponse;
  nbnPlansResponse: NbnPlansResponse;
  pageData: NbnPageResponse;
  redirectFlag: RedirectFlag;
}

const NbnTemplate: React.FC<NbnTemplateProps> = ({ addressFields, nbnPlansResponse, pageData, redirectFlag }) => {
  useQueryLogin();
  const { asPath, query } = useRouter();
  const path = stripQueryFromPath(asPath);
  const isUpgradeJourney = isUpgradesRoute(path);
  const bnsOffer = useBnsOffer();
  const promoCampaignsContent = usePromotionalCampaignsContent();

  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });

  const [addToBasketState, addToBasket, addToBasketDispatch] = useImperativeData<AddToBasketParams, Basket>(
    getApiClient().addToBasket,
  );

  // Default show standard NBN plans e.g. <=100 mpbs
  const allPlans = nbnPlansResponse.planListing.plans;

  const standardPlans = allPlans.filter(
    (plan) => !Number.isNaN(Number(plan.connectionSpeed)) && Number(plan.connectionSpeed) <= 100,
  );

  // check feature flag to see if nbn high speed plans are disabled
  // if is disabled, display only standard plans, otherwise display all available plans
  const disableNbnHighSpeedPlans = useFeatureFlag(Flag.DISABLE_NBN_HIGH_SPEED_PLANS);
  const plans = disableNbnHighSpeedPlans.data ? standardPlans : allPlans;
  const isStuckCartDisabled = useFeatureFlag(Flag.DISABLE_STUCK_CART)?.data;
  const nbnUpliftDisabled = useFeatureFlagValue(Flag.DISABLE_NBN_PLANLISTING_UPLIFT);
  // const { data: is5GOfferJourneyDisabled } = useFeatureFlag(Flag.DISABLE_5G_ONLINE_OFFER);

  const step1Ref = useRef<HTMLDivElement>(null);
  const step1InputRef = useRef<HTMLInputElement>(null);

  const step2Ref = useRef<HTMLDivElement>(null);
  const step3Ref = useRef<HTMLDivElement>(null);

  const stuckCartRef = useRef<HTMLDivElement>(null);

  const [nbnDetails, setNbnDetails] = useState<NbnDetails | null>(null);
  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [eligibleSpeedTiers, setEligibleSpeed] = useState<HighSpeedPlanTiers[]>([]);
  // There is only one choice of modem -- so only one of the modem items is a physical modem.
  // Get the modem item with a product ID as this is the actual modem
  const modem = pageData.nbnModemsContent.modemPlans.find((modemItem) => !!modemItem.productId);

  // Get nbn generic mincost modal trigger Label from modals API
  const { triggerLabel } = useModalContent().find((modal) => modal.id === 'mincostgeneric') || {};

  const { customerBundleAndSaveCount } = useCustomerData();

  // Get inlineBanner content
  const { inlineBanners, experienceFragments } = nbnPlansResponse.planListing;
  const topBannerData = inlineBanners?.find((banner) => banner.bannerId === 'top-banner');
  const bottomBannerData = inlineBanners?.find((banner) => banner.bannerId === 'bottom-banner');

  const storeNbnDetails = useCallback(
    (pickedMatchedAddress: PickedMatchedAddress | null, nbnStatus: AddressStatus | null) => {
      if (pickedMatchedAddress) {
        // set valid address details in session to use on reload
        SessionStorageClient.setValidAddressDetailsInSession(pickedMatchedAddress);
      }
      if (nbnStatus) {
        // set valid internet details in session to use on reload
        SessionStorageClient.setValidInternetDetailsInSession(nbnStatus);
        setEligibleSpeed(extractHighSpeedEligibility(nbnStatus));
      }
      if (!pickedMatchedAddress || !nbnStatus || !nbnStatus.continueNbnJourney) {
        setNbnDetails(null);
      } else {
        const installation =
          addressFields &&
          addressFields.coverageStatus.installation.find((item) => item.serviceClasses.indexOf(nbnStatus.status) > -1);

        const address = {
          correlationId: pickedMatchedAddress.correlationId,
          matchedAddress: {
            nbnLocationId: pickedMatchedAddress.matchedAddress.nbnLocationId,
            geocode: pickedMatchedAddress.matchedAddress.geocode,
            address: {
              ...pickedMatchedAddress.matchedAddress.address,
              streetType:
                convertStreetType(pickedMatchedAddress.matchedAddress.address.streetType) ||
                pickedMatchedAddress.matchedAddress.address.streetType,
              complexStreetType: convertStreetType(pickedMatchedAddress.matchedAddress.address.complexStreetType),
            },
          },
        };

        const nbnStatusWithServiceQual = nbnStatus as AddressStatusWithServiceQualification;
        const serviceQualification = {
          locationId: nbnStatusWithServiceQual.serviceQualification.locationId,
          correlationId: nbnStatusWithServiceQual.serviceQualification.correlationId,
          serviceabilityClass: nbnStatusWithServiceQual.serviceQualification.serviceabilityClass,
          serviceQualificationItem: nbnStatusWithServiceQual.serviceQualification?.serviceQualificationItem,
        };
        setNbnDetails({
          address,
          serviceQualification,
          siteQualificationAuthorisationDate: nbnStatus.siteQualificationAuthorisationDate,
          siteQualificationAppointmentRequired: installation!.type !== 'self' ? 'Yes' : 'No',
        });
      }
      // set current route in session if valid address search to reuse on page redirection data retrival
      SessionStorageClient.setRouteNameInSession(path);
    },
    [addressFields, path],
  );

  const [{ stickyCart }, stickyCartDispatch] = useStickyCart();

  // If Online Offer feature toggle set to off (false)
  const extraOffer = query[QueryKey.EXTRA] ? query[QueryKey.EXTRA]?.toString() : '';

  const { getBasketState } = useBasketState();

  const onStickyCartCtaClick = useCallback(async () => {
    if (!stickyCart || !nbnDetails) return;

    const plan = stickyCart.find(isNbnPlanBasketItem);

    if (!plan) return;

    trackEvent({
      pageEventAttributeOne: 'continue-to-cart',
      pageEventType: 'button',
      pageEventValue: 'click',
    });

    // Merge the Sticky Cart contents with the contents of any existing Local Storage basket

    const response = await addToBasket({
      items: stickyCart,
      additionalBnsCount: customerBundleAndSaveCount,
      extraOffer,
      raf: getRafUpdateRequestParams(stickyCart, getBasketState.data),
    });

    if (!response) return;

    LocalStorageClient.setNbnContext(response.basketId, nbnDetails);

    // If raf has been applied to the item thats just being added, notify the cart page to show the RAF MSO Alert
    if (response.raf) {
      const { appliedCatalogCode, isValid } = response.raf;
      if (appliedCatalogCode && getBasketState.data?.raf?.appliedCatalogCode && isValid) {
        setRafItemUpdated(appliedCatalogCode, getBasketState.data.raf.appliedCatalogCode);
      }
    }

    safeRouterPush(decoratePathWithQueries('/cart', [QueryKey.NUDGE_REFERRER]));
  }, [stickyCart, nbnDetails, addToBasket, customerBundleAndSaveCount, extraOffer, getBasketState.data]);

  // Keep our Sticky Cart CTA up to date as it is memoised with useCallback
  useEffect(() => {
    stickyCartDispatch({
      type: 'SET_ON_CTA_CLICK',
      payload: {
        ctaLabel: 'Continue to cart',
        onCtaClick: onStickyCartCtaClick,
      },
    });
  }, [stickyCartDispatch, onStickyCartCtaClick]);

  // Any time either of the requests is loading, clear the error state of related requests and
  // disable the Sticky Cart CTA
  useEffect(() => {
    const { isLoading } = addToBasketState;
    stickyCartDispatch({
      type: 'SET_IS_CTA_DISABLED',
      payload: isLoading,
    });

    if (!addToBasketState.isLoading && isLoading) {
      addToBasketDispatch({
        type: 'CLEAR_ERROR',
      });
    }
  }, [addToBasketDispatch, addToBasketState, addToBasketState.isLoading, stickyCartDispatch]);

  // Apply the Sticky Cart error state if our apply package ID and add to cart call breaks
  // This is the call that happens when you click the Sticky Cart CTA
  useEffect(() => {
    const isError = !!addToBasketState.error;
    stickyCartDispatch({
      type: 'SET_IS_ERROR',
      payload: isError,
    });
  }, [addToBasketState.error, stickyCartDispatch]);

  // If customer selects a new address and the eligible high speed tiers changes:
  // check if previously selected plan is a high speed plan and if customer is still eligible
  // If not - clear selected plan id and reset the sticky cart
  useEffect(() => {
    const selectedPlan = nbnPlansResponse.planListing.plans.find((plan) => plan.planId === selectedPlanId);
    if (
      selectedPlan &&
      isHighSpeedPlan(selectedPlan) &&
      !eligibleSpeedTiers.includes(selectedPlan?.connectionSpeed as HighSpeedPlanTiers)
    ) {
      setSelectedPlanId('');
      setSelectedModem(undefined);
      setSelectedSpeedTier('');
      setSelectedPlan(undefined);
      stickyCartDispatch({ type: 'RESET_STICKY_CART' });
    }
  }, [eligibleSpeedTiers, nbnPlansResponse.planListing.plans, selectedPlanId, stickyCartDispatch]);

  const onCardCtaClick = useCallback(
    async (
      plan: NbnPlan | ConsolidatedNbnPlan,
      discountedCost: number | null = null,
      withModem?: boolean,
      ctaLabel?: string,
    ) => {
      // Scroll up to step one for the user to interact with it
      if (!nbnDetails) {
        scrollElementIntoViewThenFocusInput(step1Ref.current, step1InputRef.current);
        return;
      }
      const basketItems = constructNbnStickyCartItem(
        plan,
        !!withModem,
        discountedCost,
        nbnPlansResponse?.modemPriceInfo,
        (plan as NbnPlan).planId,
        modem,
      );

      // Scroll down to stuck cart for the user to interact with it
      if (!isStuckCartDisabled) {
        scrollElementIntoView(stuckCartRef.current);
      }

      setSelectedPlanId((plan as NbnPlan).planId);
      stickyCartDispatch({
        type: 'SET_STICKY_CART',
        payload: {
          items: basketItems,
        },
      });

      if (withModem) {
        stickyCartDispatch({
          type: 'SET_ITEM_TYPES',
          payload: [CartItemType.PLAN, CartItemType.MODEM],
        });
      } else {
        stickyCartDispatch({
          type: 'SET_ITEM_TYPES',
          payload: [CartItemType.PLAN],
        });
      }

      trackEvent({
        pageEventType: 'button',
        pageEventValue: 'click',
        pageEventAttributeOne: kebabCase(ctaLabel),
        stickyCart: [formatBundleForTracking(basketItems)],
      });
    },
    [nbnDetails, nbnPlansResponse?.modemPriceInfo, modem, isStuckCartDisabled, stickyCartDispatch],
  );

  useTrackPage({
    pageTitle: pageData.nbnTitleContent.seoTitle || '',
    path,
    nudgeReferrer: (query[QueryKey.NUDGE_REFERRER] || '').toString(),
  });

  const [selectedSpeedTier, setSelectedSpeedTier] = useState<string>();
  const [selectedPlan, setSelectedPlan] = useState<ConsolidatedNbnPlan>();
  const [selectedModemType, setSelectedModem] = useState<'byo' | 'modem'>();
  const [bnsCost, setBnsCost] = useState<number | null>(null);

  const consolidatedPlans = useMemo(() => consolidateNbnPlans(plans), [plans]);
  const planSelectedHasModem = selectedPlan?.modemPlan?.planId === selectedPlanId;

  const onPlanSelected = (plan: ConsolidatedNbnPlan, discountedCost: number | null) => {
    if (!nbnDetails) {
      scrollElementIntoViewThenFocusInput(step1Ref.current, step1InputRef.current);
      return;
    }

    if (!selectedModemType) {
      scrollElementIntoViewThenFocusInput(step3Ref.current, null);
    }

    if (selectedModemType) {
      setSelectedPlanId(plan[selectedModemType === 'modem' ? 'modemPlan' : 'byoPlan']!.planId);
    }

    setSelectedSpeedTier(plan.connectionSpeed);
    setSelectedPlan(plan);
    setBnsCost(discountedCost);
  };

  const onModemTypeSelected = (planWithModem: boolean) => {
    const plan = consolidatedPlans.find((p) => p.connectionSpeed === selectedSpeedTier) as ConsolidatedNbnPlan;
    const { planId } = plan[planWithModem ? 'modemPlan' : 'byoPlan']!;
    setSelectedPlanId(planId);
    setSelectedModem(planWithModem ? 'modem' : 'byo');
  };

  useEffect(() => {
    if (selectedPlanId && selectedModemType && selectedPlan) {
      const { planId } = selectedPlan[selectedModemType === 'modem' ? 'modemPlan' : 'byoPlan']!;
      const basketItems = constructNbnStickyCartItem(
        selectedPlan,
        planSelectedHasModem,
        bnsCost,
        nbnPlansResponse.modemPriceInfo,
        planId,
        modem,
      );

      stickyCartDispatch({
        type: 'SET_STICKY_CART',
        payload: {
          items: basketItems,
        },
      });

      const payload = [CartItemType.PLAN];
      if (planSelectedHasModem) payload.push(CartItemType.MODEM);

      stickyCartDispatch({
        type: 'SET_ITEM_TYPES',
        payload,
      });
    }
  }, [
    modem,
    nbnPlansResponse.modemPriceInfo,
    planSelectedHasModem,
    selectedModemType,
    selectedPlan,
    selectedPlanId,
    stickyCartDispatch,
    bnsCost,
  ]);

  useEffect(() => {
    if (nbnDetails) {
      // call nbn promo vailability API call once address validated
      getApiClient()
        .fetchPromoAvailability({
          subType: PromoSubtype.OnlineBTL,
          planEndpoint: PlanEndpoint.NBN,
        })
        .then((promoAvailability) => {
          if (promoCampaignsContent) {
            const nbnPromoAvailability = promoAvailability.availability;
            const nbnStatus = JSON.parse(SessionStorageClient.getInternetSessionContent() || '');
            const fhw5GCoverage = !!nbnStatus.continue5gFhwJourney;
            const fhw5GPromoAvailability = fhw5GCoverage;
            const isUpsell5GPromo = fhw5GPromoAvailability;
            const availability = isUpsell5GPromo ? fhw5GPromoAvailability : nbnPromoAvailability;
            storeOptimizeContent({
              catalogCode: CatalogCode.NBN_PLANS,
              promoCampaignsContent,
              promoAvailability: availability,
              optimizeContentKey: OptimizeContentKey.PLAN_ONLINE_OFFER,
            });
          }
        });
    }
  }, [nbnDetails, promoCampaignsContent]);

  const modemPriceInfo = getHomeInternetModemPriceInfo(nbnPlansResponse);

  return (
    <main>
      <ModemPriceInfoProvider modemPriceInfo={modemPriceInfo}>
        <PayIn4ContentProvider
          payIn4Content={{
            showPayIn4PromoContent: nbnPlansResponse.planListing.showPayIn4PromoContent,
            payIn4PromoContentThreshold: nbnPlansResponse.planListing.payIn4PromoContentThreshold,
          }}
        >
          <Nudge variant="nbn" />
          {experienceFragments && !!experienceFragments.length && <ExperienceFragment {...experienceFragments[0]} />}
          {topBannerData && <InlineBanner bannerData={topBannerData} />}
          <TitleSection pageHeaderData={pageData.nbnTitleContent} />
          <AuthenticatedBackButton />
          <UspSection
            {...nbnPlansResponse.planListing}
            iconSizeVariant={nbnPlansResponse.planListing.iconTilesVariant || 'biggie'}
            backgroundColor={nbnPlansResponse.planListing.iconTilesBgColor || lightGreyTheme.variants.backgroundColor}
            isUpgradeJourney={isUpgradeJourney}
          />
          <ThemeProvider theme={midTheme}>
            <Section
              ref={step1Ref}
              spacingTop={{ xs: 's', m: 'xxl' }}
              spacingBottom={!nbnUpliftDisabled ? { xs: 's' } : undefined}
            >
              <Grid rowGap={{ xs: '16px', m: '24px' }}>
                <GridCol gridColSpan={{ xs: 12, m: 8 }} gridColStart={{ xs: 1, m: 3 }}>
                  <NbnStepSection
                    step={pageData.nbnStepsContent.steps[0]}
                    showUpdatedView={!nbnUpliftDisabled}
                    spacingBottom={{ xs: 's' }}
                  />
                </GridCol>
                <GridCol gridColSpan={{ xs: 12, m: 6 }} gridColStart={{ xs: 1, m: 4 }}>
                  <AddressChecker
                    addressFields={addressFields}
                    id="addressChecker"
                    storeHomeInternetDetails={storeNbnDetails}
                    step1InputRef={step1InputRef}
                    internetType={HomeInternetType.NBN}
                    pathName={path}
                  />
                </GridCol>
              </Grid>
            </Section>
            <Section spacingBottom={null} spacingTop={null}>
              <Grid>
                <GridCol>
                  <Divider />
                </GridCol>
              </Grid>
            </Section>
            <Section
              ref={step2Ref}
              spacingTop={{ xs: 's', m: 'xxl' }}
              spacingBottom={!nbnUpliftDisabled ? 'none' : { xs: 's' }}
            >
              <Grid>
                <GridCol gridColSpan={{ xs: 12, m: 8 }} gridColStart={{ xs: 1, m: 3 }}>
                  <NbnStepSection step={pageData.nbnStepsContent.steps[1]} showUpdatedView={!nbnUpliftDisabled} />
                </GridCol>
              </Grid>
            </Section>
          </ThemeProvider>
          <BnsOfferProvider offers={bnsOffer}>
            {nbnUpliftDisabled ? (
              <NbnPlansSection
                addToBasketState={addToBasketState}
                modems={pageData.nbnModemsContent}
                needsAddressCheck={!nbnDetails}
                needsAddressCtaLabel={addressFields.addressCoverage.cta}
                onCardCtaClick={onCardCtaClick}
                planListing={plans}
                selectedPlanId={selectedPlanId}
                pageTitle={pageData.nbnTitleContent.seoTitle}
                pagePath={path}
                eligibleHighSpeedTiers={eligibleSpeedTiers}
                minCostModalTriggerLabel={triggerLabel || ''}
                hideOnPlanCardCIS={nbnPlansResponse.planListing.hideOnPlanCardCIS}
                hideOnPlanCardKFS={nbnPlansResponse.planListing.hideOnPlanCardKFS}
              />
            ) : (
              <NbnPlanSectionUplift
                addToBasketState={addToBasketState}
                modemContent={pageData.nbnModemsContent}
                needsAddressCheck={!nbnDetails}
                needsAddressCtaLabel={addressFields.addressCoverage.cta}
                onCardCtaClick={onPlanSelected}
                planListing={consolidatedPlans}
                selectedPlanId={selectedPlanId}
                pageTitle={pageData.nbnTitleContent.seoTitle}
                pagePath={path}
                eligibleHighSpeedTiers={eligibleSpeedTiers}
                selectedSpeedTier={selectedSpeedTier || ''}
                minCostModalTriggerLabel={triggerLabel || ''}
                hideOnPlanCardCIS={nbnPlansResponse.planListing.hideOnPlanCardCIS}
                hideOnPlanCardKFS={nbnPlansResponse.planListing.hideOnPlanCardKFS}
              />
            )}
          </BnsOfferProvider>
          {!nbnUpliftDisabled && (
            <>
              <Section
                spacingTop="none"
                spacingBottom="none"
                ref={step3Ref}
                backgroundColor={false}
                backgroundColorValue={midTheme.variants.backgroundColor}
              >
                <Grid marginBottom={{ xs: '32px', m: '60px' }}>
                  <GridCol>
                    <Divider />
                  </GridCol>
                </Grid>
                <Grid>
                  <GridCol gridColSpan={{ xs: 12, m: 8 }} gridColStart={{ xs: 1, m: 3 }}>
                    {!!pageData.nbnStepsContent.steps[2] && (
                      <NbnStepSection
                        step={pageData.nbnStepsContent.steps[2]}
                        renderCta={!selectedSpeedTier}
                        onCtaClick={() => scrollElementIntoViewThenFocusInput(step2Ref.current, null)}
                        showUpdatedView={!nbnUpliftDisabled}
                        spacingBottom={{ xs: 'm', m: 'xxl' }}
                      >
                        {selectedSpeedTier && (
                          <ActionArea
                            requireModem={selectedPlanId ? planSelectedHasModem : undefined}
                            onCtaClick={onModemTypeSelected}
                            modemContent={pageData.nbnModemsContent.modemPlans}
                          />
                        )}
                      </NbnStepSection>
                    )}
                  </GridCol>
                </Grid>
                {selectedModemType && (
                  <NbnModemSection
                    modem={
                      pageData.nbnModemsContent.modemPlans.find((plan) =>
                        selectedModemType === 'modem' ? plan.productId : !plan.productId,
                      )!
                    }
                  />
                )}
              </Section>
            </>
          )}

          {!isStuckCartDisabled && (
            <div ref={stuckCartRef}>
              <StuckCart />
            </div>
          )}
          {bottomBannerData && <InlineBanner bannerData={bottomBannerData} />}
          <ThemeProvider theme={nbnUpliftDisabled ? midTheme : lightGreyTheme}>
            <NbnInformationSection content={pageData.nbnInfoContent} />
            <FaqTermsConditionsSection faqs={pageData.nbnFaqContent} termsAndConditions={pageData.nbnTncsContent} />
          </ThemeProvider>
          {isStuckCartDisabled && <StickyCart />}
        </PayIn4ContentProvider>
      </ModemPriceInfoProvider>
    </main>
  );
};

export default NbnTemplate;
