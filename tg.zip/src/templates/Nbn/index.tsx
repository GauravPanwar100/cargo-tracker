export { default } from './Nbn';
