import React from 'react';
import { ThemeProvider } from 'styled-components';
import { sleep } from '@src/common/js/sleep';
import { Grid, GridCol } from '@src/components/core/Grid';
import HeroImageTitle from '@src/components/core/HeroImageTitle';
import QuickLink from '@src/components/core/QuickLink';
import Section from '@src/components/core/Section';
import Text from '@src/components/core/Text';
import BundleSaveCard from '@src/components/vfe/BundleSaveCard';
import { AdditionalServicePageHeaderContent, AdditionalServicesPageResponse, QuickLinkItem } from '@src/lib/api/types';
import { useAuthentication } from '@src/lib/context/authentication';
import { RedirectFlag, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { useSetModal } from '@src/lib/context/modal';
import useWindowSize from '@src/lib/hooks/use-window-size';
import { breakpoints, midTheme } from '@src/lib/theme';
import { createOutboundLinkTracker, trackEvent } from '@src/lib/tracking';
import { MaintenancePage } from '@src/lib/util/error';
import { withAuthRequiredSeo } from '@src/lib/util/with-auth-required';
import FaqTermsAndConditionsSection from '@src/templates/common/FaqTermsAndConditionsSection';
import TwoWaySmsAlertBox from '@src/components/vfe/TwoWaySmsAlertBox';
import { useCustomerData } from '@src/lib/context/customer-data';

interface AdditionalServicesTemplateProps {
  pageData: AdditionalServicesPageResponse;
  redirectFlag: RedirectFlag;
}

// These trackers are defined here once so that their identity remains consistent when re-rendering
const PHONE_AND_PLAN_OUTBOUND_TRACKER = createOutboundLinkTracker({
  pageEventAttributeOne: 'phone-and-plan',
  pageEventType: 'link',
  pageEventValue: 'add-phone-and-plan',
});
const SIM_ONLY_OUTBOUND_TRACKER = createOutboundLinkTracker({
  pageEventAttributeOne: 'sim-only-phone-plans',
  pageEventType: 'link',
  pageEventValue: 'add-simo',
});
const NBN_OUTBOUND_TRACKER = createOutboundLinkTracker({
  pageEventAttributeOne: 'nbn-plans',
  pageEventType: 'link',
  pageEventValue: 'add-nbn',
});
const TABLETS_OUTBOUND_TRACKER = createOutboundLinkTracker({
  pageEventAttributeOne: 'tablet-with-plans',
  pageEventType: 'link',
  pageEventValue: 'add-tablet-and-plan',
});
const TABLET_SIMO_OUTBOUND_TRACKER = createOutboundLinkTracker({
  pageEventAttributeOne: 'sim-only-tablet-plans',
  pageEventType: 'link',
  pageEventValue: 'add-tablet-simo',
});
const MBB_OUTBOUND_TRACKER = createOutboundLinkTracker({
  pageEventAttributeOne: 'modem-with-plans',
  pageEventType: 'link',
  pageEventValue: 'add-mbb',
});
const MBB_SIMO_OUTBOUND_TRACKER = createOutboundLinkTracker({
  pageEventAttributeOne: 'sim-only-mobile-broadband-plans',
  pageEventType: 'link',
  pageEventValue: 'add-mbb-simo',
});

/**
 * Returns an `onClick` handler that will track the QuickLink click if required, according to the `pathname` of the link
 *
 * Unfortunately we have to rely only on the pathname of the quicklink in order to determine tracking information. This
 * is not ideal as links may link to non-VFE domains, but there is no other way with absolute links coming from AEM that
 * may not match the domain that they're deployed on. It is also brittle to URL changes.
 * @param quickLink
 */
const createQuickLinkTracker = (quickLink: QuickLinkItem): React.MouseEventHandler<HTMLAnchorElement> | undefined => {
  // As we only care about `pathname`, the `base` URL here doesn't really matter
  const { pathname } = new URL(quickLink.targetUrl, 'https://shop.vodafone.com.au');
  switch (pathname) {
    case '/mobile/mobile-phones':
      return PHONE_AND_PLAN_OUTBOUND_TRACKER;
    case '/mobile/sim-only-phone-plans':
      return SIM_ONLY_OUTBOUND_TRACKER;
    case '/home-internet/nbn':
      return NBN_OUTBOUND_TRACKER;
    case '/mobile/tablets':
      return TABLETS_OUTBOUND_TRACKER;
    case '/mobile/sim-only-tablet-plans':
      return TABLET_SIMO_OUTBOUND_TRACKER;
    case '/mobile-broadband/plans':
      return MBB_OUTBOUND_TRACKER;
    case '/mobile-broadband/sim-only-plans':
      return MBB_SIMO_OUTBOUND_TRACKER;
    default:
      return undefined;
  }
};

const AdditionalServicesPageTemplate: React.FC<AdditionalServicesTemplateProps> = ({ pageData, redirectFlag }) => {
  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });

  const { header, quickLinks, bundle } = pageData;

  const setGlobalModal = useSetModal();
  const { width } = useWindowSize();
  const { logout } = useAuthentication();
  const [isTwoWaySmsAlertBoxOpen, setTwoWaySmsAlertBox] = React.useState(true);

  const {
    customerDetails: [customerDetailsState],
  } = useCustomerData();

  const { twoWaySmsIconUrl, twoWaySmsInvalidMessage, twoWaySmsMessage } = header;

  const serviceLinks = quickLinks.quickLinks.map((quickLinkItem, qlIndex) => {
    const quickLink = quickLinkItem.modalId ? (
      <QuickLink
        href="#"
        onClick={(e) => {
          e.preventDefault();
          setGlobalModal({
            id: quickLinkItem.modalId,
            isOpen: true,
            onClose: () => setGlobalModal(''),
            cancelCtaAction: () => setGlobalModal(''),
            // Prepaid plans may only be checked out as a New acquisition, so we need to log the user out
            confirmCtaAction:
              quickLinkItem.modalId === 'additionalservicesprepaid'
                ? () => {
                    const trackingComplete = new Promise(() => {
                      // TODO: Figure out if Adobe Launch Data Layer actually has a way to add a callback for when tracking is complete,
                      // and resolve the Promise accordingly. With Google Analytics, this is simple with a field called `hitCallback`.
                      // For now, this Promise will never resolve, and the `sleep(250)` will resolve first.
                      trackEvent({
                        pageEventAttributeOne: 'prepaid-plans',
                        pageEventType: 'link',
                        pageEventValue: 'add-prepaid',
                      });
                    });
                    // Try to wait for the tracking to complete, but only wait for a maxium of 250ms
                    Promise.race([sleep(250), trackingComplete]).then(() =>
                      logout({
                        // The link is hardcoded here as AEM links _could_ change in future and break this functionality,
                        // as any `returnTo` path needs to be whitelisted in AEM in advance
                        returnTo: `${window.location.origin}/prepaid/plans`,
                      }),
                    );
                  }
                : quickLinkItem.targetUrl,
          });
        }}
        icon={quickLinkItem.iconUrl}
        title={quickLinkItem.title}
      />
    ) : (
      <QuickLink
        href={quickLinkItem.targetUrl}
        icon={quickLinkItem.iconUrl}
        title={quickLinkItem.title}
        onClick={createQuickLinkTracker(quickLinkItem)}
      />
    );

    return (
      // eslint-disable-next-line react/no-array-index-key
      <GridCol key={qlIndex} gridColSpan={{ xs: 12, m: 6 }}>
        {quickLink}
      </GridCol>
    );
  });

  return (
    <main>
      {isTwoWaySmsAlertBoxOpen && (
        <TwoWaySmsAlertBox
          primaryContact={customerDetailsState.data?.primaryMobilePhone}
          message={twoWaySmsMessage}
          invalidMessage={twoWaySmsInvalidMessage}
          icon={twoWaySmsIconUrl}
          onClose={() => setTwoWaySmsAlertBox(false)}
        />
      )}
      <HeroImageTitle
        altText=""
        height={{ xs: '128px', m: '320px' }}
        title={header.title}
        subtitle={header.subTitle}
        imageUrl={matchBannerWithWindowSize(header, width || breakpoints.l)}
        theme={header.theme}
      />
      <ThemeProvider theme={midTheme}>
        <Section spacingTop={{ xs: 's', m: 'xxl' }}>
          <Grid>
            <GridCol>
              <BundleSaveCard content={bundle} defaultIsOpen={true} />
            </GridCol>
          </Grid>
        </Section>
        <Section data-testid="another-service-quick-links" spacingTop={null}>
          <Grid>
            <GridCol>
              <Text as="h2" marginBottom={{ xs: '20px', m: '32px' }} textAlign="center">
                {quickLinks.sectionTitle}
              </Text>
            </GridCol>
            {serviceLinks}
          </Grid>
        </Section>
        <FaqTermsAndConditionsSection
          spacingTop={null}
          faqs={pageData.faqs}
          termsAndConditions={pageData.termsAndConditions}
        />
      </ThemeProvider>
    </main>
  );
};

function matchBannerWithWindowSize(header: AdditionalServicePageHeaderContent, width: number) {
  if (width >= breakpoints.l) return header.imageUrl;
  if (breakpoints.s < width && width < breakpoints.l) return header.imageTablet;
  if (width <= breakpoints.s) return header.imageMobile;
  return header.imageUrl;
}

export default withAuthRequiredSeo(AdditionalServicesPageTemplate);
