import { DeviceBandColor, DeviceColor, WatchDeviceDetails } from '@src/lib/api/types';

interface ConfigItem {
  value: string;
}

/** Temp hardcoded ALT text */
export const esimEnabledWatchAltText = 'eSIM-enabled Watch';
export const fiveGAltText = '5G approved Watch';
export const fourGAltText = '4G approved Watch';

/**
 * Searches through a list of configs -- [color, color, color] or [capacity, capacity] -- and checks
 * to see if that config was specified in a query param. If not, find and return the defaultValue
 * for that config
 */
export function findConfigValue<T extends ConfigItem>(
  configs: T[],
  queryValue: string,
  defaultValue: string,
): T | undefined {
  let config: T | undefined;
  if (queryValue) {
    config = configs.find((c) => c.value === queryValue);
  }

  return config || configs.find((c) => c.value === defaultValue);
}

export function callSamsung() {
  window.location.href = 'tel:1300300404';
}

export const getSmartWatchPreviouslyViewedProductImage = (
  deviceDetails: WatchDeviceDetails,
  color: DeviceColor | undefined,
  bandColor: DeviceBandColor | undefined,
  bandName: string | undefined,
): string => {
  return (
    deviceDetails.colors.find(
      (col) => col.value === color?.value && col.bandName === bandName && col.bandColor === bandColor?.value,
    )?.images[0]?.imageUrl ||
    deviceDetails.colors[0]?.images[0]?.imageUrl ||
    ''
  );
};
