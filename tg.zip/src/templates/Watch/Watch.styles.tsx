import styled, { css } from 'styled-components';
import { fontLineHeightSize, maxMedia, media } from '@src/lib/util/mixins';
import Button from '@src/components/core/Button/Button';

export const Form = styled.form`
  margin-bottom: 32px;
`;

export const Container = styled.div`
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  grid-template-areas:
    'title'
    'badge'
    'image'
    'content';
  row-gap: 8px;
  ${media.m`
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
    grid-template-areas:  
      "image title"
      "image badge"
      "image content"
    ;
  `}
`;

export const Content = styled.div`
  grid-area: content;
`;

export const Title = styled.div`
  grid-area: title;
`;

export const ImageContainer = styled.div`
  grid-area: image;
  width: 100%;

  ${media.m`
    margin: 0 auto;
    padding-left: ${(p) => p.theme.sizes.modulePaddingSmall}px;
    padding-right: ${(p) => p.theme.sizes.modulePaddingSmall}px;
  `}
`;

interface RepaymentContainerProps {
  disabled: boolean;
}
export const RepaymentContainer = styled.div<RepaymentContainerProps>`
  opacity: 1;
  transition: opacity ${(p) => p.theme.durations.transition} ease-out;

  ${(p) =>
    p.disabled &&
    css`
      opacity: 0.5;
    `}
`;

export const MinimumCost = styled.div`
  margin-top: 12px;
  white-space: pre-wrap;
  ${fontLineHeightSize('footnote')};
`;

export const MinCostModalLink = styled(MinimumCost)`
  display: inline-block;
  text-decoration: underline;
  &:hover {
    cursor: pointer;
  }
`;

export const BadgeContainer = styled.div`
  grid-area: badge;
  ${media.xs`
    height:  '50px';
  `};
  margin-bottom: '20px';
  ${media.s`
    height: 50px;    
  `}
`;

export const FourGBadge = styled.div`
  float: left;
  margin-right: 5px;
  margin-top: 2px;
  margin-bottom: 10px;
  img {
    height: 45px;
    width: 45px;
  }
`;

export const ESimBadge = styled.div`
  float: left;
  margin-right: 5px;
  margin-bottom: 10px;
  img {
    height: 55px;
    width: 55px;
  }
`;

export const Link = styled.a`
  color: #333;
`;

export const CompareLink = styled.div`
  margin: 32px 0 32px;
  font-size: 18px;
  color: #333;

  ${maxMedia.s`
    margin: 24px 0 32px 0;
    font-size: 16px;
    text-align: center;
  `}
`;
/* Smart Watches Styles */
export const FeatureSubTitle = styled.div`
  grid-area: title;
  font-size: 20px;
  color: #333;
  line-height: 22px;
`;

export const SAMSUNGCTAButton = styled(Button)`
  ${media.l`
    font-size: 17px;
  `}
`;
