import { NextPage } from 'next';
import { useRouter } from 'next/router';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { isEmpty, kebabCase, uniqBy } from 'lodash';
import BackButton from '@src/components/core/BackButton';
import SeoHead from '@src/components/vfe/SeoHead';
import {
  CartItemType,
  CartProductType,
  CatalogCode,
  CompareField,
  DeviceBandColor,
  DeviceBandName,
  DeviceCaseSize,
  DeviceColor,
  DeviceConfigPricingEntry,
  DeviceStockStatus,
  ProductManufacturer,
  ProductSubType,
  Promotion,
  SmartWatchPageResponse,
  TradeInJsonResponse,
  WearableDeviceBasketRequestItem,
} from '@src/lib/api/types';
import { QueryKey } from '@src/lib/util/query';
import { decoratePathWithQueries, stripQueryFromPath } from '@src/lib/util/url';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import Text from '@src/components/core/Text';
import Sticky from '@src/components/core/Sticky';
import DeviceCarousel from '@src/components/vfe/DeviceCarousel';
import useQueryLogin from '@src/lib/hooks/use-query-login';
import { trackEvent, useImperativeTrackPage } from '@src/lib/tracking';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import { getApiClient } from '@src/lib/api';
import ExpressDeliveryCard from '@src/components/vfe/ExpressDeliveryCard';
import SpecialOffersCard from '@src/components/vfe/SpecialOffersCard';
import RichText from '@src/components/core/RichText';
import AnimatedAlert from '@src/components/core/Alert/AnimatedAlert';
import ColorPicker from '@src/components/core/ColorPicker';
import { StickyCartHistory, useCommitStickyCartToHistoryOnMount, useStickyCart } from '@src/lib/context/sticky-cart';
import { calculateMinCost, isWearableDeviceBasketItem } from '@src/lib/util/cart';
import Button from '@src/components/core/Button';
import Price from '@src/components/core/Price';
import { OptionButton, OptionButtonGroup } from '@src/components/core/OptionButtonGroup';
import DeviceInformationSection from '@src/templates/Device/DeviceInformationSection';
import useQuerySync from '@src/lib/hooks/use-query-sync';
import { NudgeVariant } from '@src/components/vfe/Nudge/Nudge';
import { Flag, RedirectFlag, useFeatureFlag, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { GoToNextStepHandler } from '@src/components/core/Journey/JourneyStep/JourneyStep';
import TermsAndConditions from '@src/components/vfe/TermsAndConditions';
import { LocalStorageClient } from '@src/lib/storage';
import DeviceStatusAlert from '@src/templates/Device/DeviceStatusAlert';
import FrequencyBandCard from '@src/components/vfe/FrequencyBandCard';
import { MaintenancePage } from '@src/lib/util/error';
import { formatCurrency } from '@src/lib/util/number-formatter';
import { getTradeAndSaveData } from '@src/templates/Device/util';
import TradeInCard from '@src/components/vfe/TradeInCard/TradeInCard';
import ExperienceFragment from '@src/components/vfe/ExperienceFragment';
import { getFragmentHtml } from '@src/lib/util/getFragmentHtml';
import { callSamsung, findConfigValue, getSmartWatchPreviouslyViewedProductImage } from './util';
import {
  CompareLink,
  Container,
  Content,
  FeatureSubTitle,
  Form,
  ImageContainer,
  Link,
  MinimumCost,
  RepaymentContainer,
  SAMSUNGCTAButton,
  Title,
} from './Watch.styles';

interface WatchTemplateProps {
  pageData: SmartWatchPageResponse;
  backAs?: string;
  backHref?: string;
  backOnClick?: React.MouseEventHandler;
  catalogCode: CatalogCode;
  ctaLabel: string;
  disableCartInteraction?: boolean;
  goToNextStep: GoToNextStepHandler;
  nudgeVariant?: NudgeVariant;
  redirectFlag: RedirectFlag;
  step: number;
}
interface WatchConfigFormValues {
  caseSize: string | undefined;
  color: DeviceColor | undefined;
  contractTerm: string | undefined;
  bandName: string | undefined;
  bandColor: DeviceBandColor | undefined;
  bandSize: string | undefined;
}
interface DeviceProductConfig {
  caseSize: string;
  color: string;
  contractTerm: string;
  imageUrl: string;
  bandSize: string;
  bandColour: string;
  bandName: string;
}
const defaultSmartWatchConfig: WatchConfigFormValues = {
  caseSize: undefined,
  color: undefined,
  bandName: undefined,
  contractTerm: undefined,
  bandColor: undefined,
  bandSize: undefined,
};

interface GetSavedConfigParams {
  history: StickyCartHistory[];
  pageData: SmartWatchPageResponse;
  step: number;
}
const getSavedConfig = ({ history, pageData, step }: GetSavedConfigParams): WatchConfigFormValues | undefined => {
  const historyForStep = history[step];
  if (!historyForStep || !historyForStep.configured) {
    return undefined;
  }
  const savedConfiguration = historyForStep.configured;
  const wearable = savedConfiguration.find(isWearableDeviceBasketItem);
  if (!wearable) {
    return undefined;
  }

  return {
    caseSize: wearable.productConfig.caseSize,
    color: pageData.deviceDetails.colors.find((c) => c.value === wearable.productConfig.color),
    contractTerm: wearable.productConfig.contractTerm,
    bandName: wearable.productConfig.bandName,
    bandColor: pageData.deviceDetails.bandColors.find((c) => c.value === wearable.productConfig.bandColor),
    bandSize: wearable.productConfig.bandSize,
  };
};
const CATALOG_CODE_TO_PRODUCT_SUBTYPE_MAPPING: { [C in CatalogCode]?: ProductSubType } = {
  [CatalogCode.POSTPAID_WEARABLES]: ProductSubType.WEARABLES,
} as const;
const WatchTemplate: NextPage<WatchTemplateProps> = ({
  backAs,
  backHref,
  backOnClick,
  pageData,
  step,
  ctaLabel,
  catalogCode,
  disableCartInteraction,
  redirectFlag,
  goToNextStep,
}) => {
  useQueryLogin();
  const trackPage = useImperativeTrackPage();
  const router = useRouter();
  const { asPath, query } = router;
  const path = stripQueryFromPath(asPath);
  const disableTradeAndSave = !!useFeatureFlag(Flag.TRADE_IN_DEVICE).data; // Trade-in toggle flag, control the old trade-in view
  const tradeInToggle = !!useFeatureFlag(Flag.DISABLE_NEW_TRADE_IN_DEVICE).data; // new trade-in toggle and will remove after fully functional of new trade-in view
  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });

  const [{ history, stickyCart }, stickyCartDispatch] = useStickyCart();
  useCommitStickyCartToHistoryOnMount({ step, stickyCart });
  const { deviceDetails, deviceStockStatus, deviceConfig, labels, experienceFragments } = pageData;
  const isAnnouncementPhase = deviceDetails.announcementPhase;
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [stockStatus, getStockStatus] = useImperativeData(getApiClient().fetchDeviceStockStatus);
  const [currentDeviceStockStatus, setCurrentDeviceStockStatus] = useState<DeviceStockStatus>(deviceStockStatus);
  const [savedConfig] = useState(getSavedConfig({ history, pageData, step }));
  const deviceSku = useRef<string | undefined>(deviceDetails.deviceSku);
  const [postcode, setPostcode] = useState<string>('');
  const [showAlert, setShowAlert] = useState<boolean>(false);
  const [inputError, setInputError] = useState<string | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [promotions, setPromotions] = useState<Promotion[]>(pageData.promotions ?? []);
  const announcementAlertData = pageData.alerts.find((a) => a.alertId === 'Announcement');
  const hasInitialisedConfig = useRef<boolean>(!!savedConfig);
  const [recurringCharge, setRecurringCharge] = useState(pageData.deviceDetails.recurringCharge);
  const { handleSubmit, formState } = useForm<WatchConfigFormValues>({
    defaultValues: savedConfig ?? { ...defaultSmartWatchConfig },
  });
  const [ctaDisabled, setCtaDisabled] = useState(
    [DeviceStockStatus.NON_ORDERABLE, DeviceStockStatus.UNAVAILABLE].includes(currentDeviceStockStatus) ||
      stockStatus.isLoading ||
      deviceDetails.hideStockMessaging,
  );
  // state manage for trade-in data
  const [tradeInDeviceBrandData, setTradeInDeviceBrand] = useState<string[]>([]);
  const [tradeInDeviceData, setTradeInDeviceData] = useState<TradeInJsonResponse[]>([]);

  const numberSyncContent = pageData.alerts.find((a) => a.alertId === 'watch-only-number-sync'); // static number sync content
  const isLoading = formState.isSubmitting || formState.isSubmitted || stockStatus.isLoading;
  const { customStockAlertID } = pageData.deviceDetails;
  const tradeInPromotions: Promotion[] = promotions.filter((item) => item.tradeInAndSave);

  // [SHOP-7531]: Calculating the minimum total cost based on the live configuration of the item
  const configuredStickyCart = history[step]?.configured ?? [];
  const wearable = configuredStickyCart.find(isWearableDeviceBasketItem);
  const liveDiscount = wearable?.priceInfo?.discount ?? 0;
  const liveOriginalRecurringCharge: number | undefined = wearable?.priceInfo.originalRecurringCharge;
  const liveContractTerm: string | undefined = wearable?.productConfig.contractTerm;
  const liveMinimumCost: number | undefined =
    liveOriginalRecurringCharge && liveContractTerm
      ? calculateMinCost({ recurringCharge: liveOriginalRecurringCharge, contractTerm: liveContractTerm }) -
        liveDiscount
      : 0;

  const initialCaseColorSelection = findConfigValue(
    deviceDetails.colors,
    query[QueryKey.DEVICE_COLOR] as string,
    Object.keys(deviceConfig).includes(deviceDetails.defaultColor)
      ? deviceDetails.defaultColor
      : Object.keys(deviceConfig)[0],
  );
  const initialCaseSizeSelection = findConfigValue(
    deviceDetails.caseSizes,
    query[QueryKey.DEVICE_CASE_SIZE] as string,
    Object.keys(deviceConfig[initialCaseColorSelection?.value || '']).includes(deviceDetails.defaultCaseSize)
      ? deviceDetails.defaultCaseSize
      : Object.keys(deviceConfig[initialCaseColorSelection?.value || ''])[0],
  );
  const [caseColor, setCaseColor] = useState(initialCaseColorSelection);
  const [caseSize, setCaseSize] = useState(initialCaseSizeSelection?.value);

  const showBandArea: boolean = caseColor
    ? Object.keys(deviceConfig[caseColor?.value][caseSize ?? '']).length > 1
    : true;

  const initialBandNameSelection = findConfigValue(
    deviceDetails.bandNames,
    showBandArea ? (query[QueryKey.DEVICE_BAND_NAME] as string) : '',
    Object.keys(deviceConfig[initialCaseColorSelection?.value || ''][initialCaseSizeSelection?.value || '']).includes(
      deviceDetails.defaultBandName,
    )
      ? deviceDetails.defaultBandName
      : Object.keys(deviceConfig[initialCaseColorSelection?.value || ''][initialCaseSizeSelection?.value || ''])[0],
  );

  const initialBandColorSelection = findConfigValue(
    deviceDetails.bandColors,
    showBandArea ? (query[QueryKey.DEVICE_BAND_COLOR] as string) : '',
    Object.keys(
      deviceConfig[initialCaseColorSelection?.value || ''][initialCaseSizeSelection?.value || ''][
        initialBandNameSelection?.value || ''
      ],
    ).includes(deviceDetails.defaultBandColor)
      ? deviceDetails.defaultBandColor
      : Object.keys(
          deviceConfig[initialCaseColorSelection?.value || ''][initialCaseSizeSelection?.value || ''][
            initialBandNameSelection?.value || ''
          ],
        )[0],
  );

  const initialBandSizeSelection = findConfigValue(
    deviceDetails.bandSizes,
    showBandArea ? (query[QueryKey.DEVICE_BAND_SIZE] as string) : '',
    Object.keys(
      deviceConfig[initialCaseColorSelection?.value || ''][initialCaseSizeSelection?.value || ''][
        initialBandNameSelection?.value || ''
      ][initialBandColorSelection?.value || ''],
    ).includes(deviceDetails.defaultBandSize)
      ? deviceDetails.defaultBandSize
      : Object.keys(
          deviceConfig[initialCaseColorSelection?.value || ''][initialCaseSizeSelection?.value || ''][
            initialBandNameSelection?.value || ''
          ][initialBandColorSelection?.value || ''],
        )[0],
  );

  const initialContractTermSelection = findConfigValue(
    deviceDetails.contractTerm,
    query[QueryKey.DEVICE_CONTRACT_TERM] as string,
    deviceDetails.defaultContractTerm,
  );
  const [bandName, setBandName] = useState(initialBandNameSelection?.value);
  const [bandColor, setBandColor] = useState(initialBandColorSelection);
  const [bandSize, setBandSize] = useState(initialBandSizeSelection?.value);
  const [contractTerm, setContractTerm] = useState(initialContractTermSelection?.value);

  const fragmentHtml = getFragmentHtml(experienceFragments);

  // update device details on formstate change
  const updateDeviceBasketItem = useCallback(
    async (config: DeviceProductConfig) => {
      const matrixConfig = deviceConfig[config.color]?.[config.caseSize]?.[config.bandName]?.[config.bandColour]?.[
        config.bandSize
      ]?.find(
        (entry) =>
          entry.ContractTerm.toLowerCase() === `${config.contractTerm} Months`.toLowerCase() &&
          entry.OrderType === 'Connect',
      );
      if (!matrixConfig) return;

      if (deviceSku.current !== matrixConfig.SKU) {
        deviceSku.current = matrixConfig.SKU;
        getStockStatus({ deviceSku: matrixConfig.SKU });
      }

      const device: WearableDeviceBasketRequestItem = {
        catalogCode,
        childProducts: [],
        itemType: CartItemType.SMARTWATCH,
        matrixRowKey: matrixConfig.MatrixRowKey,
        packageId: '',
        priceInfo: {
          recurringCharge: matrixConfig.FinalMRC ?? matrixConfig.MRC,
          originalRecurringCharge: matrixConfig.MRC,
          discount: matrixConfig.Discount ?? 0,
        },
        productCode: deviceDetails.id,
        productConfig: {
          color: config.color,
          contractTerm: config.contractTerm,
          deviceSku: matrixConfig.SKU,
          orderType: 'Connect',
          imageUrl: config.imageUrl,
          caseSize: config.caseSize,
          bandColor: config.bandColour,
          bandName: config.bandName,
          bandSize: config.bandSize,
        },
        productName: matrixConfig.ProductName,
        productType: CartProductType.SMARTWATCH,
        productSubType: CATALOG_CODE_TO_PRODUCT_SUBTYPE_MAPPING[catalogCode],
        simTypeCompatibility: deviceDetails.simTypeCompatibility,
        manufacturer: deviceDetails.manufacturer,
      };

      const originalStickyCart = history[step]?.original ?? [];

      stickyCartDispatch({
        type: 'SET_STICKY_CART',
        payload: {
          items: [...originalStickyCart, device],
          history: { historyType: 'configured', step },
        },
      });
    },
    [
      deviceConfig,
      catalogCode,
      deviceDetails.id,
      deviceDetails.simTypeCompatibility,
      deviceDetails.manufacturer,
      history,
      step,
      stickyCartDispatch,
      getStockStatus,
    ],
  );

  const compareField = labels?.compareFields?.find(
    (t) => t.brandIdentifier === deviceDetails.manufacturer,
  ) as CompareField;

  // Any time the device config changes, create a new cart to add to display in the sticky cart.
  // We also use the returned recurringCharge from it, and check device availability.
  useEffect(() => {
    if (!caseSize || !caseColor || !bandName || !bandColor || !bandSize || !contractTerm || disableCartInteraction)
      return;

    updateDeviceBasketItem({
      caseSize,
      color: caseColor.value,
      bandName,
      bandColour: bandColor.value,
      bandSize,
      contractTerm,
      imageUrl: caseColor.images[0].imageUrl,
    });
    onContractTermChange(contractTerm || '');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [caseSize, caseColor, bandName, bandColor, bandSize, contractTerm, disableCartInteraction]);

  // set alertmessage according to stock availability
  useEffect(() => {
    const localDeviceStockStatus = stockStatus?.data?.stockStatus || deviceStockStatus;
    if (
      [DeviceStockStatus.UNAVAILABLE, DeviceStockStatus.NON_ORDERABLE].includes(localDeviceStockStatus) ||
      deviceDetails.hideStockMessaging
    ) {
      setCurrentDeviceStockStatus(
        deviceDetails.id === 'AW_SERIES_ULTRA'
          ? DeviceStockStatus.WEARABLE_BAND_UNAVAILABLE
          : DeviceStockStatus.WEARABLE_CASE_UNAVAILABLE,
      );
      setCtaDisabled(true);
    } else {
      setCurrentDeviceStockStatus(localDeviceStockStatus);
      setCtaDisabled(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stockStatus]);

  // track previously viewed products
  useEffect(() => {
    LocalStorageClient.trackViewedProduct({
      productName: deviceDetails.name,
      productSubType: CATALOG_CODE_TO_PRODUCT_SUBTYPE_MAPPING[catalogCode],
      productImg: {
        imageUrl: getSmartWatchPreviouslyViewedProductImage(deviceDetails, caseColor, bandColor, bandName),
        altText: deviceDetails.name,
      },
      productUrl: window.location.href,
      id: deviceDetails.id,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [catalogCode, deviceDetails, caseColor, bandColor, bandName]);

  // intial device feature selection
  useEffect(
    () => {
      if (hasInitialisedConfig.current) {
        return;
      }

      hasInitialisedConfig.current = true;

      trackPage({
        pageTitle: deviceDetails.seoTitle || '',
        path,
        nudgeReferrer: (query[QueryKey.NUDGE_REFERRER] || '').toString(),
        catalogue: deviceDetails.catalogCode,
        deviceCode: deviceDetails.id,
        deviceType: deviceDetails.deviceType,
        deviceSubType: deviceDetails.deviceSubType,
        deviceName: deviceDetails.name,
        deviceColor: initialCaseColorSelection?.value,
        deviceTerm: initialContractTermSelection?.value,
        deviceSku: deviceDetails.deviceSku,
        deviceBrand: deviceDetails.manufacturer,
        deviceMinCost: deviceDetails.minimumCharge,
        deviceCaseSize: initialCaseSizeSelection?.value,
        deviceBandName: initialBandNameSelection?.value,
        deviceBandColor: initialBandColorSelection?.value,
        deviceBandSize: initialBandSizeSelection?.value,
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [query],
  );

  useEffect(() => {
    getTradeData(); // get trade-in data and store into state
  }, []);

  // Any time the config values update, we should also reflect those changes in the query params
  useQuerySync([
    [QueryKey.DEVICE_CASE_SIZE, caseSize],
    [QueryKey.DEVICE_COLOR, caseColor?.value],
    [QueryKey.DEVICE_BAND_NAME, bandName],
    [QueryKey.DEVICE_BAND_COLOR, bandColor?.value],
    [QueryKey.DEVICE_BAND_SIZE, bandSize],
    [QueryKey.DEVICE_CONTRACT_TERM, contractTerm],
  ]);

  const onSubmit = useCallback(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    async (data: WatchConfigFormValues) => {
      trackEvent({
        pageEventAttributeOne: kebabCase(labels.ctaLabel),
        pageEventType: 'button',
        pageEventValue: 'click',
      });
      const items = history[step]?.configured ?? [];
      goToNextStep({
        items,
      });
    },
    [labels.ctaLabel, history, step, goToNextStep],
  );

  const getTradeData = async () => {
    const response = await getTradeAndSaveData();
    setTradeInDeviceData(response.asurionpricelist);

    setTradeInDeviceBrand(response.brandArray);
  };

  const deviceColors = uniqBy(
    deviceDetails.colors.filter((colour) => Object.keys(deviceConfig).includes(colour.value)),
    'value',
  );
  const caseSizes: DeviceCaseSize[] = deviceDetails.caseSizes.filter((cap) =>
    Object.keys(deviceConfig[caseColor?.value || initialCaseColorSelection?.value || '']).includes(cap.value),
  );
  const deviceBandNames = (): DeviceBandName[] => {
    return deviceDetails.bandNames.filter((name) =>
      Object.keys(
        deviceConfig[caseColor?.value || initialCaseColorSelection?.value || ''][initialCaseSizeSelection?.value || ''],
      ).includes(name.value),
    );
  };
  const deviceBandColors = () => {
    return deviceDetails.bandColors.filter((colr) =>
      Object.keys(
        deviceConfig[caseColor?.value || initialCaseColorSelection?.value || ''][initialCaseSizeSelection?.value || ''][
          initialBandNameSelection?.value || ''
        ],
      ).includes(colr.value),
    );
  };
  const deviceBandSizes = () => {
    let localBandColor = bandColor?.value || deviceDetails.defaultBandColor;
    if (
      !Object.keys(
        deviceConfig[caseColor?.value || initialCaseColorSelection?.value || ''][initialCaseSizeSelection?.value || ''][
          initialBandNameSelection?.value || ''
        ],
      ).includes(localBandColor)
    ) {
      // eslint-disable-next-line prefer-destructuring -- Need to explicitly set the values
      localBandColor = Object.keys(
        deviceConfig[caseColor?.value ?? initialCaseColorSelection?.value ?? ''][initialCaseSizeSelection?.value ?? ''][
          initialBandNameSelection?.value ?? ''
        ],
      )[0];
    }
    return deviceDetails.bandSizes.filter((siz) =>
      Object.keys(
        deviceConfig[caseColor?.value ?? initialCaseColorSelection?.value ?? ''][initialCaseSizeSelection?.value ?? ''][
          initialBandNameSelection?.value ?? ''
        ][localBandColor],
      ).includes(siz.value),
    );
  };
  const resolveUserSelection = (bName?: string, lColor?: DeviceColor, caseSiz?: string, bColor?: DeviceBandColor) => {
    const localCaseColor = lColor?.value || caseColor?.value || '';
    let localCaseSize = caseSiz || caseSize || '';
    let localBandName = bName;
    let localBandColor = bColor || bandColor;
    let localBandSize = bandSize || '';
    // resolve the case size
    if (!Object.keys(deviceConfig[localCaseColor]).includes(localCaseSize)) {
      if (!Object.keys(deviceConfig[localCaseColor]).includes(deviceDetails.defaultCaseSize)) {
        // eslint-disable-next-line prefer-destructuring
        localCaseSize = Object.keys(deviceConfig[localCaseColor])[0];
      } else {
        localCaseSize = deviceDetails.defaultCaseSize;
      }
    }

    // resolve band name
    if (!localBandName) {
      if (!Object.keys(deviceConfig[localCaseColor][localCaseSize]).includes(deviceDetails.defaultBandName)) {
        // eslint-disable-next-line prefer-destructuring -- Need to explicitly set the values
        localBandName = deviceDetails.bandNames.filter(
          (name) => Object.keys(deviceConfig[localCaseColor][localCaseSize])[0] === name.value,
        )[0].value;
      } else {
        localBandName = deviceDetails.defaultBandName;
      }
    }
    // resolve band colour
    if (
      !Object.keys(deviceConfig[localCaseColor][localCaseSize][localBandName || '']).includes(
        localBandColor?.value || '',
      )
    ) {
      if (
        !Object.keys(deviceConfig[localCaseColor][localCaseSize][localBandName || '']).includes(
          deviceDetails.defaultBandColor || '',
        )
      ) {
        // eslint-disable-next-line prefer-destructuring -- Need to explicitly set the values
        localBandColor = deviceDetails.bandColors.filter(
          (colr) => Object.keys(deviceConfig[localCaseColor][localCaseSize][localBandName || ''])[0] === colr.value,
        )[0];
      } else {
        // eslint-disable-next-line prefer-destructuring
        localBandColor = deviceDetails.bandColors.filter((colr) => deviceDetails.defaultBandColor === colr.value)[0];
      }
    }

    // resolve band size
    if (
      !Object.keys(
        deviceConfig[localCaseColor][localCaseSize][localBandName || ''][localBandColor?.value || ''],
      ).includes(localBandSize)
    ) {
      if (
        !Object.keys(
          deviceConfig[localCaseColor][localCaseSize][localBandName || ''][localBandColor?.value || ''],
        ).includes(deviceDetails.defaultBandSize)
      ) {
        localBandSize = deviceDetails.bandSizes.filter((size) =>
          Object.keys(
            deviceConfig[localCaseColor][localCaseSize][localBandName || ''][localBandColor?.value || ''],
          ).includes(size.value),
        )[0].value;
      } else {
        localBandSize = deviceDetails.defaultBandSize;
      }
    }
    setCaseSize(localCaseSize);
    setBandName(localBandName);
    setBandColor(localBandColor);
    setBandSize(localBandSize);
  };
  const onCaseColorChange = (colour: DeviceColor) => {
    setCaseColor(colour);
    resolveUserSelection(undefined, colour);
  };
  const onCaseSizeChange = (caseSiz: string) => {
    setCaseSize(caseSiz);
    resolveUserSelection(undefined, caseColor, caseSiz);
  };
  const onBandChange = (bName: string) => {
    setBandName(bName);
    resolveUserSelection(bName);
  };
  const onBandColorChange = (bandCol: DeviceBandColor) => {
    setBandColor(bandCol);
    resolveUserSelection(bandName, caseColor, caseSize, bandCol);
  };
  const onContractTermChange = (term: string) => {
    const selectedFeatureList = Object.values(
      deviceConfig[caseColor?.value || ''][caseSize || ''][bandName || initialBandNameSelection?.value || ''][
        bandColor?.value || initialBandColorSelection?.value || ''
      ][bandSize || initialBandSizeSelection?.value || ''],
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    ).filter((l: DeviceConfigPricingEntry) => l.ContractTermMonthlyInt === parseInt(term ?? '0', 10));
    setRecurringCharge(selectedFeatureList[0].FinalMRC ?? selectedFeatureList[0].MRC);
  };
  const carouselImages = useCallback(() => {
    if (showBandArea) {
      return (
        deviceDetails.colors.find(
          (col) =>
            col.value === caseColor?.value &&
            col.caseSize === caseSize &&
            col.bandName === bandName &&
            col.bandColor === bandColor?.value,
        )?.images ?? []
      );
    }
    const validCombination = deviceDetails.colors.find(
      (col) => col.value === caseColor?.value && col.caseSize === caseSize,
    );
    return validCombination?.images ?? [];
  }, [bandColor?.value, bandName, caseSize, caseColor?.value, deviceDetails.colors, showBandArea]);

  return (
    <>
      <SeoHead
        title={deviceDetails.seoTitle}
        aemMetaTags={deviceDetails.metaTags}
        structuredData={deviceDetails.seoData}
      />
      {!!fragmentHtml && <ExperienceFragment fragmentHtml={fragmentHtml} />}
      <BackButton
        as={backAs}
        data-testid="watch-back-button"
        href={decoratePathWithQueries(backHref || '', [QueryKey.DATE, QueryKey.NUDGE_REFERRER])}
        onClick={backOnClick}
      >
        {labels.breadcrumbLabel}
      </BackButton>
      <main>
        <Section spacingTop={{ xs: 's', l: 'xxl' }}>
          <Grid>
            <GridCol>
              <Container>
                <Title>
                  <Text
                    as="h1"
                    fontSize={{ xs: 'heading1Mobile', m: 'heading2' }}
                    lineHeight={{ xs: 'heading1Mobile', m: 'heading2' }}
                    marginBottom={{ xs: '0', m: '8px' }}
                    textAlign={{ xs: 'left', m: 'left' }}
                    fontFamily="light"
                    data-testid="smart-watch-title"
                  >
                    {deviceDetails.name}
                    <FeatureSubTitle>{deviceDetails.connectionType}</FeatureSubTitle>
                  </Text>
                </Title>
                <ImageContainer>
                  <Sticky>
                    <DeviceCarousel key={caseColor?.caseSize} images={carouselImages()} />
                  </Sticky>
                </ImageContainer>
                <Content>
                  <GridCol>
                    <Form onSubmit={handleSubmit(onSubmit)}>
                      <Grid rowGap="32px">
                        <GridCol>
                          <ColorPicker
                            colors={deviceColors}
                            id="caseColor"
                            onChange={(e) => {
                              onCaseColorChange(e);
                            }}
                            label={pageData.labels.colourLabel}
                            value={caseColor}
                          />
                        </GridCol>
                        <GridCol>
                          <OptionButtonGroup
                            disabled={isLoading}
                            id="caseSize"
                            name="caseSize"
                            label={pageData.labels.caseSizeLabel}
                            onChange={(e) => {
                              onCaseSizeChange(e);
                            }}
                            value={caseSize}
                          >
                            {caseSizes.map((c) => (
                              <OptionButton id={c.value} key={c.value} value={c.value}>
                                {c.label}
                              </OptionButton>
                            ))}
                          </OptionButtonGroup>
                        </GridCol>
                        {showBandArea && (
                          <>
                            <GridCol>
                              <OptionButtonGroup
                                disabled={isLoading}
                                id="bandName"
                                label={labels.bandLabel}
                                onChange={(e) => {
                                  onBandChange(e);
                                }}
                                name="bandName"
                                value={bandName}
                              >
                                {deviceBandNames().map((c) => (
                                  <OptionButton id={c.value} key={c.value} value={c.value}>
                                    {c.label}
                                  </OptionButton>
                                ))}
                              </OptionButtonGroup>
                            </GridCol>
                            <GridCol>
                              <ColorPicker
                                colors={deviceBandColors()}
                                id="bandColor"
                                onChange={(e) => {
                                  onBandColorChange(e);
                                }}
                                label={labels.bandColourLabel}
                                value={bandColor}
                              />
                            </GridCol>
                            <GridCol>
                              <OptionButtonGroup
                                disabled={isLoading}
                                id="bandSize"
                                name="bandSize"
                                label={labels.bandSizeLabel}
                                value={bandSize}
                                onChange={(e) => {
                                  setBandSize(e);
                                }}
                              >
                                {deviceBandSizes().map((c) => (
                                  <OptionButton id={c.value} key={c.value} value={c.value}>
                                    {c.label}
                                  </OptionButton>
                                ))}
                              </OptionButtonGroup>
                            </GridCol>
                          </>
                        )}
                        {deviceDetails.manufacturer === ProductManufacturer.APPLE && (
                          <DeviceStatusAlert
                            alerts={pageData.alerts}
                            status={currentDeviceStockStatus}
                            customStockAlertId={customStockAlertID}
                            hideStockMessaging={pageData.deviceDetails.hideStockMessaging}
                          />
                        )}
                        <GridCol>
                          <OptionButtonGroup
                            disabled={isLoading}
                            id="contractTerm"
                            label={pageData.labels.repaymentPeriodLabel}
                            onChange={(e) => {
                              setContractTerm(e);
                              onContractTermChange(e);
                            }}
                            name="contractTerm"
                            value={contractTerm}
                          >
                            {deviceDetails.contractTerm.map((c) => (
                              <OptionButton id={c.value} key={c.value} value={c.value}>
                                {c.label}
                              </OptionButton>
                            ))}
                          </OptionButtonGroup>
                        </GridCol>
                        <GridCol>
                          <RepaymentContainer disabled={isLoading}>
                            <Text
                              fontFamily="bold"
                              fontSize={{ xs: 'heading5Mobile', m: 'heading5' }}
                              lineHeight={{ xs: 'heading5Mobile', m: 'heading5' }}
                            >
                              Device repayment:
                            </Text>
                            <Price price={recurringCharge} label="per month" />
                            {/* [SHOP-7531]: Updated the minimum cost info text and added the condition to display the
                            minimum cost info only when it is available. */}
                            {liveMinimumCost && (
                              <MinimumCost>
                                {`Min cost $${formatCurrency(
                                  liveMinimumCost,
                                )} over ${contractTerm} months on an Accessories Payment Plan. Requires eligible mobile plan (cost additional). Vodafone NumberSync™ cost additional.`}
                              </MinimumCost>
                            )}
                          </RepaymentContainer>
                        </GridCol>
                        {!isAnnouncementPhase && deviceDetails.manufacturer !== ProductManufacturer.SAMSUNG && (
                          <GridCol>
                            <Grid>
                              <GridCol gridColSpan={{ xs: 12, m: 6 }}>
                                <Button
                                  data-testid="add-to-cart-cta"
                                  disabled={ctaDisabled}
                                  isLoading={isLoading}
                                  fullWidth={true}
                                  type="submit"
                                >
                                  {ctaLabel}
                                </Button>
                              </GridCol>
                            </Grid>
                          </GridCol>
                        )}
                        {deviceDetails.manufacturer === ProductManufacturer.SAMSUNG && (
                          <GridCol>
                            <Grid>
                              <GridCol display="flex" gridColSpan={{ xs: 12, m: 6, l: 4 }}>
                                <SAMSUNGCTAButton
                                  data-testid="call"
                                  fullWidth={true}
                                  type="button"
                                  onClick={callSamsung}
                                  size="s"
                                >
                                  Call 1300 300 404
                                </SAMSUNGCTAButton>
                              </GridCol>
                              <GridCol display="flex" gridColSpan={{ xs: 12, m: 6, l: 4 }}>
                                <SAMSUNGCTAButton
                                  data-testid="store"
                                  fullWidth={true}
                                  type="button"
                                  variant="tertiary"
                                  size="s"
                                  onClick={() => {
                                    window.location.href = 'https://www.vodafone.com.au/stores';
                                  }}
                                >
                                  Head in store
                                </SAMSUNGCTAButton>
                              </GridCol>
                            </Grid>
                          </GridCol>
                        )}
                        {isAnnouncementPhase && announcementAlertData && (
                          <GridCol>
                            <AnimatedAlert inline={true} variant="info">
                              <RichText>{announcementAlertData.alertText}</RichText>
                            </AnimatedAlert>
                          </GridCol>
                        )}
                      </Grid>
                    </Form>
                    {!isEmpty(compareField) && (
                      <Link href={compareField.compareUrl} target={compareField.openInNewBrowser ? '_blank' : '_self'}>
                        <CompareLink>{compareField.compareLabel}</CompareLink>
                      </Link>
                    )}
                    <Grid rowGap="32px">
                      {!disableTradeAndSave && tradeInDeviceBrandData.length > 0 && !tradeInToggle && (
                        <GridCol>
                          <TradeInCard
                            promotions={tradeInPromotions}
                            deviceData={tradeInDeviceData}
                            deviceName={deviceDetails.name}
                          />
                        </GridCol>
                      )}
                      {promotions.length > 0 && (
                        <GridCol>
                          <SpecialOffersCard promotions={promotions} heroOfferId={deviceDetails.heroOffer} />
                        </GridCol>
                      )}
                      {!!numberSyncContent && (
                        <GridCol>
                          <FrequencyBandCard alertContent={numberSyncContent} />
                        </GridCol>
                      )}
                      {!isAnnouncementPhase &&
                        deviceDetails.manufacturer !== ProductManufacturer.SAMSUNG &&
                        ![DeviceStockStatus.NON_ORDERABLE, DeviceStockStatus.UNAVAILABLE].includes(
                          currentDeviceStockStatus,
                        ) &&
                        !deviceDetails.hideStockMessaging && (
                          <GridCol>
                            <ExpressDeliveryCard
                              content={pageData.expressDelivery}
                              sku={deviceSku.current}
                              alerts={pageData.alerts}
                              postcode={postcode}
                              setPostcode={setPostcode}
                              showAlert={showAlert}
                              setShowAlert={setShowAlert}
                              inputError={inputError}
                              setInputError={setInputError}
                            />
                          </GridCol>
                        )}
                    </Grid>
                  </GridCol>
                </Content>
              </Container>
            </GridCol>
          </Grid>
        </Section>
        <DeviceInformationSection
          deviceDetails={deviceDetails}
          deviceInformationLabel={labels.deviceInformationLabel}
        />
        <Section
          backgroundColorValue="#f4f4f4"
          backgroundColor={true}
          spacingBottom={{ xs: 's', m: 'l', xl: 'xl' }}
          spacingHorizontal={true}
          spacingTop={null}
        >
          <Grid marginTop={{ xs: '32px', m: '48px', l: '60px' }} rowGap={{ xs: '32px', m: '48px' }}>
            <GridCol
              margin={{ xs: '32px 0px', m: '48px 0px 0px', l: '60px 0px 30px 0px' }}
              gridColStart={{ xs: 1, m: 3 }}
              gridColSpan={{ xs: 12, m: 8 }}
            >
              <TermsAndConditions description={pageData.deviceDetails.deviceTermsConditions} />
            </GridCol>
          </Grid>
        </Section>
      </main>
    </>
  );
};

export default WatchTemplate;
