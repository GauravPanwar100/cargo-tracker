import React from 'react';
import Router from 'next/router';
import { ThemeProvider } from 'styled-components';
import { Grid, GridCol } from '@src/components/core/Grid';
import HeroImageTitle from '@src/components/core/HeroImageTitle';
import PullUp from '@src/components/core/PullUp';
import Section from '@src/components/core/Section';
import Faq from '@src/components/vfe/Faq';
import ServiceCard from '@src/components/vfe/ServiceCard';
import { UpgradesPageHeaderContent, UpgradesPageResponse } from '@src/lib/api/types';
import { breakpoints, midTheme } from '@src/lib/theme';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import CtaItemsSection from '@src/templates/Upgrades/CtaItemsSection/CtaItemsSection';
import { useSetModal } from '@src/lib/context/modal';
import useWindowSize from '@src/lib/hooks/use-window-size';
import { useCustomerEligibility } from '@src/lib/util/customer';
import { useCustomerData } from '@src/lib/context/customer-data';
import { withAuthRequiredSeo } from '@src/lib/util/with-auth-required';
import { RedirectFlag, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { MaintenancePage } from '@src/lib/util/error';
import LinkedServices from '@src/components/vfe/LinkedServices';
import { LocalStorageClient } from '@src/lib/storage';
import TwoWaySmsAlertBox from '@src/components/vfe/TwoWaySmsAlertBox';
import RichText from '@src/components/core/RichText';

interface UpgradesTemplateProps {
  pageData: UpgradesPageResponse;
  push?: string;
  redirectFlag: RedirectFlag;
}

const UpgradesTemplate: React.FC<UpgradesTemplateProps> = ({ pageData, push, redirectFlag }) => {
  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });

  const [isLinkedServicesOpen, setLinkedServices] = React.useState(false);
  const [isTwoWaySmsAlertBoxOpen, setTwoWaySmsAlertBox] = React.useState(true);

  const { loading } = useCustomerEligibility();

  const setGlobalModal = useSetModal();
  const { width } = useWindowSize();

  const handleLinkedServiceClick = React.useCallback(() => {
    if (LocalStorageClient.getBasketId() !== '') {
      const onClose = () => setGlobalModal('');
      setGlobalModal({
        id: 'upgrade-cart-items-removed',
        isOpen: true,
        onClose,
        cancelCtaAction: onClose,
        confirmCtaAction: () => {
          LocalStorageClient.removeBasketId();
          onClose();
          setLinkedServices(true);
        },
      });
    } else {
      setLinkedServices(true);
    }
  }, [setGlobalModal]);

  const closePushModal = React.useCallback(() => {
    setGlobalModal('');
    Router.replace('/upgrade');
  }, [setGlobalModal]);

  // if we have a "push" notification popup, we render that as a modal
  React.useEffect(() => {
    if (push && !loading) {
      setGlobalModal({
        id: push,
        isOpen: true,
        onClose: closePushModal,
        cancelCtaAction: closePushModal,
        confirmCtaAction: closePushModal,
      });
    }
  }, [closePushModal, loading, push, setGlobalModal]);

  const {
    pageHeaderData: {
      alerts,
      altText,
      subtitle,
      title,
      theme,
      twoWaySmsMessage,
      twoWaySmsInvalidMessage,
      twoWaySmsIconUrl,
    },
    faqs,
    ctaItems,
  } = pageData;

  const {
    customerDetails: [customerDetailsState],
  } = useCustomerData();

  return (
    <>
      <main>
        {isTwoWaySmsAlertBoxOpen && (
          <TwoWaySmsAlertBox
            primaryContact={customerDetailsState.data?.primaryMobilePhone}
            message={twoWaySmsMessage}
            invalidMessage={twoWaySmsInvalidMessage}
            icon={twoWaySmsIconUrl}
            onClose={() => setTwoWaySmsAlertBox(false)}
          />
        )}
        <HeroImageTitle
          altText={altText}
          imageUrl={matchBannerWithWindowSize(pageData.pageHeaderData, width || breakpoints.l)}
          subtitle={subtitle}
          title={title}
          theme={theme}
        />
        {loading ? (
          <SpinnerSection />
        ) : (
          <ThemeProvider theme={midTheme}>
            <Section spacingTop={null}>
              <Grid>
                <GridCol>
                  <PullUp>
                    <ServiceCard
                      defaultIsOpen={true}
                      currentServiceAlert={alerts?.find((alert) => alert.alertId === 'no-plan-info')}
                      onLinkedServicesClick={handleLinkedServiceClick}
                    />
                  </PullUp>
                </GridCol>
              </Grid>
            </Section>
            <CtaItemsSection alerts={alerts} ctaItems={ctaItems} />
            <Section spacingTop={null}>
              <Grid>
                <GridCol textAlign="center">
                  <RichText>{pageData.pageHeaderData.customText}</RichText>
                </GridCol>
              </Grid>
            </Section>
            <Section spacingTop={null}>
              <Grid>
                <GridCol>
                  <Faq sectionTitle={faqs.sectionTitle} items={faqs.faqItems} />
                </GridCol>
              </Grid>
            </Section>
          </ThemeProvider>
        )}
      </main>
      <LinkedServices isOpen={isLinkedServicesOpen} onClose={() => setLinkedServices(false)} />
    </>
  );
};

function matchBannerWithWindowSize(header: UpgradesPageHeaderContent, width: number) {
  if (width >= breakpoints.l) return header.imageUrl;
  if (breakpoints.s < width && width < breakpoints.l) return header.imageTablet;
  if (width <= breakpoints.s) return header.imageMobile;
  return header.imageUrl;
}

export default withAuthRequiredSeo(UpgradesTemplate);
