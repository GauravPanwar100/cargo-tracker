import React from 'react';
import { DeviceEndpoint, DevicesPageResponse } from '@src/lib/api/types';
import TitleSection from '@src/templates/common/TitleSection';
import WhyVodafoneSection from '@src/templates/Devices/WhyVodafoneSection/WhyVodafoneSection';
import FaqTermsConditionsSection from '@src/templates/common/FaqTermsAndConditionsSection';
import DeviceSelectionSection from '@src/templates/Devices/DeviceSelectionSection';
import { useRouter } from 'next/router';
import { RedirectFlag, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { MaintenancePage } from '@src/lib/util/error';
import ExperienceFragment from '@src/components/vfe/ExperienceFragment';
import { getFragmentHtml } from '@src/lib/util/getFragmentHtml';

interface WatchesTemplateProps {
  pageData: DevicesPageResponse;
  redirectFlag: RedirectFlag;
}

const WatchesTemplate: React.FC<WatchesTemplateProps> = ({ pageData, redirectFlag }) => {
  const {
    pageHeaderData: { experienceFragments },
  } = pageData;
  const fragmentHtml = getFragmentHtml(experienceFragments);

  const router = useRouter();
  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });

  return (
    <main>
      {!!fragmentHtml && <ExperienceFragment fragmentHtml={fragmentHtml} />}
      <TitleSection pageHeaderData={pageData.pageHeaderData} />
      <DeviceSelectionSection
        asPath={router.asPath}
        devicesData={pageData.deviceListing?.devices}
        pathname={router.pathname}
        deviceType={DeviceEndpoint.WEARABLES}
      />
      <WhyVodafoneSection uspItems={pageData.uspItems} />
      <FaqTermsConditionsSection
        faqs={pageData.faqs}
        termsAndConditions={pageData.termsAndConditions}
        spacingTop={{ xs: 's', m: 'm', l: 'xxl' }}
      />
    </main>
  );
};

export default WatchesTemplate;
