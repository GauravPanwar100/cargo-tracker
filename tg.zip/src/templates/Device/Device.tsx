import { isEmpty, isUndefined, kebabCase, omitBy, round } from 'lodash';
import { NextPage } from 'next';
import { useRouter } from 'next/router';
import queryString from 'query-string';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { getApiClient } from '@src/lib/api';
import BackButton from '@src/components/core/BackButton';
import Button from '@src/components/core/Button';
import { Grid, GridCol } from '@src/components/core/Grid';
import { GoToNextStepHandler } from '@src/components/core/Journey/JourneyStep/JourneyStep';
import { OptionButton, OptionButtonGroup } from '@src/components/core/OptionButtonGroup';
import Price from '@src/components/core/Price';
import Section from '@src/components/core/Section';
import Text from '@src/components/core/Text';
import Sticky from '@src/components/core/Sticky';
import DeviceCarousel from '@src/components/vfe/DeviceCarousel';
import ExpressDeliveryCard from '@src/components/vfe/ExpressDeliveryCard';
import SpecialOffersCard from '@src/components/vfe/SpecialOffersCard';
import Nudge from '@src/components/vfe/Nudge';
import { NudgeVariant } from '@src/components/vfe/Nudge/Nudge';
import SeoHead from '@src/components/vfe/SeoHead';
import FiveGSVG from '@src/assets/svg/5g.svg';
import ESimSVG from '@src/assets/svg/eSIM.svg';
import {
  AddToBasketParams,
  Basket,
  CartItemType,
  CartProductType,
  CatalogCode,
  CompareField,
  DeviceBasketRequestItem,
  DeviceCapacity,
  DeviceColor,
  DeviceConfigPricingEntry,
  DeviceEndpoint,
  DevicePageResponse,
  DeviceStockStatus,
  ProductSubType,
  Promotion,
  TradeInJsonResponse,
} from '@src/lib/api/types';
import { StickyCartHistory, useCommitStickyCartToHistoryOnMount, useStickyCart } from '@src/lib/context/sticky-cart';
import useQuerySync from '@src/lib/hooks/use-query-sync';
import { calculateMinCost, isDeviceBasketItem } from '@src/lib/util/cart';
import { formatCurrency, formatPrice } from '@src/lib/util/number-formatter';
import { QueryKey } from '@src/lib/util/query';
import { decoratePathWithQueries, stripQueryFromPath } from '@src/lib/util/url';
import { trackEvent, useImperativeTrackPage } from '@src/lib/tracking';
import RichText from '@src/components/core/RichText';
import AnimatedAlert from '@src/components/core/Alert/AnimatedAlert';
import FrequencyBandCard from '@src/components/vfe/FrequencyBandCard';
import { Flag, RedirectFlag, useFeatureFlag, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { MaintenancePage } from '@src/lib/util/error';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import useQueryLogin from '@src/lib/hooks/use-query-login';
import { useSetModal } from '@src/lib/context/modal';
import { CalloutJunior, CalloutSenior } from '@src/components/vfe/Callout/CalloutWithAnimation';
import { LocalStorageClient } from '@src/lib/storage';
import { enrichPromotion } from '@src/lib/util/formatUtils';
import RelatedDevices from '@src/components/vfe/RelatedDevices';

import ESimNotification from '@src/components/vfe/ESimNotification';
import useServiceType from '@src/lib/hooks/use-service-type';
import { ServiceTypeValue } from '@src/lib/storage/types';
import TradeandSaveCard from '@src/components/vfe/TradeandSaveCard';
import PrepaidStarterPack from '@src/components/vfe/PrepaidStarterPack/PrepaidStarterPack';
import { useCustomerData } from '@src/lib/context/customer-data';
import { useBasketState } from '@src/lib/context/basket';
import { safeRouterPush } from '@src/lib/util/router';
import ColorPicker from '@src/components/core/ColorPicker';
import CheckDeliveryAvailability from '@src/components/vfe/CheckDeliveryAvailability';
import useScrollToQuery from '@src/lib/hooks/use-scroll-to-query';
import TradeInCard from '@src/components/vfe/TradeInCard';
import UpgradeHubSection from '@src/components/vfe/UpgradeHubSection';
import { useAuthentication } from '@src/lib/context/authentication';
import ExperienceFragment from '@src/components/vfe/ExperienceFragment';
import { getFragmentHtml } from '@src/lib/util/getFragmentHtml';
import { isReturningUser } from '@src/lib/util/upgradeHub';
import DeviceStatusAlert from './DeviceStatusAlert';
import DeviceInformationSection from './DeviceInformationSection';
import RelatedProductsTabsNav from './RelatedProductsTabsNav';
import {
  BadgeContainer,
  CompareLink,
  Container,
  Content,
  ESimBadge,
  FieldContainer,
  FiveGBadge,
  Form,
  ImageContainer,
  Link,
  MinCostModalLink,
  MinimumCost,
  RepaymentContainer,
  Title,
} from './Device.styles';
import { esimEnabledDeviceAltText, findConfigValue, fiveGAltText, getTradeAndSaveData } from './util';

interface DeviceTemplateProps {
  backAs?: string;
  backHref?: string;
  backOnClick?: React.MouseEventHandler;
  catalogCode: CatalogCode;
  ctaLabel: string;
  disableCartInteraction?: boolean;
  goToNextStep: GoToNextStepHandler;
  nudgeVariant?: NudgeVariant;
  pageData: DevicePageResponse;
  redirectFlag: RedirectFlag;
  step: number;
  deviceType?: string;
}

interface DeviceConfigFormValues {
  capacity: string | undefined;
  color: DeviceColor | undefined;
  contractTerm: string | undefined;
}

const defaultMobilePhoneConfig: DeviceConfigFormValues = {
  capacity: undefined,
  color: undefined,
  contractTerm: undefined,
};

interface DeviceProductConfig {
  capacity: string;
  color: string;
  contractTerm: string;
  imageUrl: string;
}

interface GetSavedConfigParams {
  history: StickyCartHistory[];
  pageData: DevicePageResponse;
  step: number;
}
const getSavedConfig = ({ history, pageData, step }: GetSavedConfigParams): DeviceConfigFormValues | undefined => {
  const historyForStep = history[step];
  if (!historyForStep || !historyForStep.configured) {
    return undefined;
  }

  const savedConfiguration = historyForStep.configured;
  const mobilePhone = savedConfiguration.find(isDeviceBasketItem);
  if (!mobilePhone) {
    return undefined;
  }

  return {
    capacity: mobilePhone.productConfig.capacity,
    color: pageData.deviceDetails.colors.find((c) => c.value === mobilePhone.productConfig.color),
    contractTerm: mobilePhone.productConfig.contractTerm,
  };
};

const CATALOG_CODE_TO_PRODUCT_SUBTYPE_MAPPING: { [C in CatalogCode]?: ProductSubType } = {
  [CatalogCode.POSTPAID_HANDSETS]: ProductSubType.HANDSET,
  [CatalogCode.POSTPAID_TABLET]: ProductSubType.TABLET,
  [CatalogCode.POSTPAID_WEARABLES]: ProductSubType.WEARABLES,
  [CatalogCode.PREPAID]: ProductSubType.PREPAID,
} as const;

const DeviceTemplate: NextPage<DeviceTemplateProps> = ({
  backAs,
  backHref,
  backOnClick,
  catalogCode,
  ctaLabel,
  disableCartInteraction,
  goToNextStep,
  nudgeVariant,
  pageData,
  redirectFlag,
  step,
  deviceType = DeviceEndpoint.PHONE,
}) => {
  useQueryLogin();
  const { isAuthenticated } = useAuthentication();
  const trackPage = useImperativeTrackPage();
  const router = useRouter();
  const { asPath, query } = router;
  const path = stripQueryFromPath(asPath);
  const disableTradeAndSave = !!useFeatureFlag(Flag.TRADE_IN_DEVICE).data;
  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });
  const setGlobalModal = useSetModal();
  const [{ history, stickyCart }, stickyCartDispatch] = useStickyCart();
  useCommitStickyCartToHistoryOnMount({ step, stickyCart });

  const configuredStickyCart = history[step]?.configured ?? [];

  // Saved config is only used once, as the `defaultValues` for the device config form. We put it inside a useState
  // hook so that we only run it once (when the useState hook first calculates its default value);
  const [savedConfig] = useState(getSavedConfig({ history, pageData, step }));

  /**
   * Device config form
   */
  const { control, handleSubmit, setValue, watch, formState } = useForm<DeviceConfigFormValues>({
    defaultValues: savedConfig ?? { ...defaultMobilePhoneConfig },
  });

  const { capacity, color, contractTerm } = watch();
  const tradeInToggle = !!useFeatureFlag(Flag.DISABLE_NEW_TRADE_IN_DEVICE).data;

  // We only want to initialise the device config state from query params once, when router.query
  // first becomes populated.
  // Track whether we have initialised the state in a ref to avoid triggering another render

  const { deviceConfig, deviceDetails, deviceStockStatus, labels, planDetails, experienceFragments } = pageData;
  const hasInitialisedConfig = useRef<boolean>(!!savedConfig);
  const deviceSku = useRef<string | undefined>(deviceDetails.deviceSku);
  const [postcode, setPostcode] = useState<string>('');
  const [showAlert, setShowAlert] = useState<boolean>(false);
  const [inputError, setInputError] = useState<string | null>(null);
  const [sddDiscountForBasket, setSddDiscountForBasket] = useState<number | null>(null);
  const [promotions, setPromotions] = useState<Promotion[]>(pageData.promotions ?? []);
  const [openEsimNotification, setOpenEsimNotification] = useState<boolean>(true);
  const [tradeInDeviceBrandData, setTradeInDeviceBrand] = useState<string[]>([]);
  const [tradeInDeviceData, setTradeInDeviceData] = useState<TradeInJsonResponse[]>([]);
  const tradeInPromotions: Promotion[] = promotions.filter((item) => item.tradeInAndSave);
  const filteredPromotions: Promotion[] = promotions.filter((item) =>
    !disableTradeAndSave ? !item.tradeInAndSave : item,
  );
  const clickAndCollectFeatureDisabled = useFeatureFlag(Flag.DISABLE_CLICK_AND_COLLECT_FEATURE);
  const [, addToBasket] = useImperativeData<AddToBasketParams, Basket>(getApiClient().addToBasket);
  const { customerBundleAndSaveCount } = useCustomerData();
  const { setBasket } = useBasketState();
  let liveDeviceStatus: DeviceStockStatus = deviceStockStatus;
  const [activeTabIndex, setActiveTabIndex] = useState<number>();
  const isMSOJourney = !!LocalStorageClient.getBasketId();
  // PTW-25 update compare link with respective manufacturer
  const compareField = labels?.compareFields?.find(
    (t) => t.brandIdentifier === deviceDetails.manufacturer,
  ) as CompareField;

  const fragmentHtml = getFragmentHtml(experienceFragments);

  // SHOP-3117 when color or capacity is changed on device page, postcode is reset and any related alerts are cleared
  const onRestPostCode = () => {
    setPostcode('');
    setShowAlert(false);
    setInputError(null);
  };

  // SHOP-4739 track previously viewed products
  useEffect(() => {
    LocalStorageClient.trackViewedProduct({
      productName: deviceDetails.name,
      productSubType: CATALOG_CODE_TO_PRODUCT_SUBTYPE_MAPPING[catalogCode],
      productImg: { imageUrl: deviceDetails.colors[0]?.images[0]?.imageUrl, altText: deviceDetails.name },
      productUrl: window.location.href,
      id: deviceDetails.id,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [catalogCode, deviceDetails.name]);

  useEffect(() => {
    onRestPostCode();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query[QueryKey.DEVICE_COLOR], query[QueryKey.DEVICE_CAPACITY]]);

  useEffect(
    () => {
      if (hasInitialisedConfig.current) {
        return;
      }

      hasInitialisedConfig.current = true;

      const defaultCapacity = findConfigValue(
        deviceDetails.capacities,
        query[QueryKey.DEVICE_CAPACITY] as string,
        deviceDetails.defaultCapacity,
      );

      const defaultColor = findConfigValue(
        deviceDetails.colors,
        query[QueryKey.DEVICE_COLOR] as string,
        deviceDetails.defaultColor,
      );

      const defaultContractTerm = findConfigValue(
        deviceDetails.contractTerm,
        query[QueryKey.DEVICE_CONTRACT_TERM] as string,
        deviceDetails.defaultContractTerm,
      );

      // ImageUrl is based on the color passed in so use that as the config search
      const defaultImageUrl = findConfigValue(
        deviceDetails.colors,
        query[QueryKey.DEVICE_COLOR] as string,
        deviceDetails.defaultImageUrl,
      );

      setValue('capacity', defaultCapacity?.value);
      setValue('color', defaultColor);
      setValue('contractTerm', defaultContractTerm?.value);

      trackPage({
        pageTitle: deviceDetails.seoTitle || '',
        path,
        nudgeReferrer: (query[QueryKey.NUDGE_REFERRER] || '').toString(),
        catalogue: deviceDetails.catalogCode,
        deviceCode: deviceDetails.id,
        deviceType: deviceDetails.deviceType,
        deviceSubType: deviceDetails.deviceSubType,
        deviceName: deviceDetails.name,
        deviceColor: defaultColor?.value,
        deviceCapacity: defaultCapacity?.value,
        deviceTerm: defaultContractTerm?.value,
        deviceImageUrl: defaultImageUrl?.value,
        deviceSku: deviceDetails.deviceSku,
        deviceBrand: deviceDetails.manufacturer,
        deviceMinCost: deviceDetails.minimumCharge,
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [query],
  );

  useEffect(() => {
    getTradeData();
  }, []);

  // always use the first image in the color.images array
  const MAIN_IMAGE_INDEX = 0;

  // Any time the config values update, we should also reflect those changes in the query params
  useQuerySync([
    [QueryKey.DEVICE_CAPACITY, capacity],
    [QueryKey.DEVICE_COLOR, color?.value],
    [QueryKey.DEVICE_CONTRACT_TERM, contractTerm],
  ]);

  const [stockStatus, getStockStatus] = useImperativeData(getApiClient().fetchDeviceStockStatus);

  // SDD: Dynamic populate promotions
  const enrichInvalidPromotions = useCallback(
    ({ ContractTerm, Discount, RRP }: DeviceConfigPricingEntry) => {
      const { invalidEnrichmentPromotions } = pageData;
      const sddPromotion =
        invalidEnrichmentPromotions &&
        invalidEnrichmentPromotions?.find((promotion) => promotion.promotionCode.includes('PROMO_SDD'));

      if (sddPromotion) {
        let excludedPromotion: Promotion | null = null;
        const monthlyDiscount = Discount && Discount !== 0 ? Discount : null;

        if (monthlyDiscount) {
          const enrichedPromotion = enrichPromotion(sddPromotion, {
            AT_CONTRACT_TERM: ContractTerm,
            DEVICE_RRP: RRP.toString(),
            MONTHLY_DEVICE_DISCOUNT: formatPrice(monthlyDiscount),
            TOTAL_DEVICE_DISCOUNT: formatPrice(monthlyDiscount * Number(ContractTerm.split(' ')[0])),
          });
          if (enrichedPromotion) {
            if (enrichedPromotion.title !== '' && enrichedPromotion.description !== '') {
              excludedPromotion = enrichedPromotion;
            }
          }
        }
        setPromotions((prevState) => {
          const currentPromotion = prevState.filter((p) => p.promotionCode !== sddPromotion.promotionCode);
          if (excludedPromotion) {
            currentPromotion.push(excludedPromotion);
          }
          return [...currentPromotion];
        });
      }
    },
    [pageData],
  );

  const updateDeviceBasketItem = useCallback(
    async (config: DeviceProductConfig) => {
      const matrixConfig =
        deviceType === DeviceEndpoint.PREPAIDPHONE
          ? deviceConfig[config.color]?.[config.capacity][0]
          : deviceConfig[config.color]?.[config.capacity]?.find(
              (entry) =>
                entry.ContractTerm.toLowerCase() === `${config.contractTerm} Months`.toLowerCase() &&
                entry.OrderType === 'Connect',
            );

      if (!matrixConfig) return;

      if (deviceSku.current !== matrixConfig.SKU) {
        deviceSku.current = matrixConfig.SKU;
        getStockStatus({ deviceSku: matrixConfig.SKU });
      }

      const device: DeviceBasketRequestItem = {
        catalogCode,
        childProducts: [],
        itemType: CartItemType.DEVICE,
        matrixRowKey: matrixConfig.MatrixRowKey,
        packageId: '',
        priceInfo: {
          recurringCharge:
            deviceType === DeviceEndpoint.PHONE ? matrixConfig.FinalMRC ?? matrixConfig.MRC : matrixConfig.FinalRCC,
          originalRecurringCharge: deviceType === DeviceEndpoint.PHONE ? matrixConfig.MRC : matrixConfig.RCC,
          discount: matrixConfig.Discount ?? 0,
          nonRecurringCharge: matrixConfig.FinalNRC,
          originalNonRecurringCharge: matrixConfig.NRC,
        },
        productCode: deviceDetails.id,
        productConfig: {
          capacity: config.capacity,
          color: config.color,
          contractTerm: config.contractTerm,
          deviceSku: matrixConfig.SKU,
          orderType: 'Connect',
          imageUrl: config.imageUrl,
        },
        productName: matrixConfig.ProductName,
        productType: CartProductType.DEVICE,
        productSubType: CATALOG_CODE_TO_PRODUCT_SUBTYPE_MAPPING[catalogCode],
        simTypeCompatibility: deviceDetails.simTypeCompatibility,
        manufacturer: deviceDetails.manufacturer,
      };

      // If device has a discount, set the device details
      let sddDeviceDiscount = null;
      if (matrixConfig.Discount && matrixConfig.ContractTermMonthlyInt) {
        sddDeviceDiscount = round(matrixConfig.Discount * matrixConfig.ContractTermMonthlyInt, 2);
      }

      enrichInvalidPromotions(matrixConfig);
      setSddDiscountForBasket(sddDeviceDiscount);

      const originalStickyCart = history[step]?.original ?? [];

      stickyCartDispatch({
        type: 'SET_STICKY_CART',
        payload: {
          items: [...originalStickyCart, device],
          history: { historyType: 'configured', step },
        },
      });
    },
    [
      deviceConfig,
      catalogCode,
      deviceDetails.id,
      deviceDetails.simTypeCompatibility,
      deviceDetails.manufacturer,
      enrichInvalidPromotions,
      history,
      step,
      stickyCartDispatch,
      getStockStatus,
      deviceType,
    ],
  );

  // Any time the device config changes, create a new cart to add to display in the sticky cart.
  // We also use the returned recurringCharge from it, and check device availability.
  useEffect(() => {
    if (deviceType === DeviceEndpoint.PREPAIDPHONE) {
      if (!color || disableCartInteraction) return;
      updateDeviceBasketItem({
        capacity: deviceDetails.defaultCapacity,
        color: color.value,
        contractTerm: deviceDetails.defaultContractTerm,
        imageUrl: color.images[MAIN_IMAGE_INDEX].imageUrl,
      });
    } else {
      if (!capacity || !color || !contractTerm || disableCartInteraction) return;
      updateDeviceBasketItem({
        capacity,
        color: color.value,
        contractTerm,
        imageUrl: color.images[MAIN_IMAGE_INDEX].imageUrl,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [capacity, color, contractTerm, disableCartInteraction]);

  const liveCapacities: DeviceCapacity[] =
    deviceType === DeviceEndpoint.PHONE
      ? deviceDetails.capacities.filter((cap) =>
          Object.keys(deviceConfig[color?.value ?? deviceDetails.defaultColor]).includes(cap.value),
        )
      : deviceDetails.capacities;

  if (deviceType === DeviceEndpoint.PHONE) {
    if (stockStatus.error || !liveCapacities.find((cap) => cap.value === capacity)) {
      liveDeviceStatus = DeviceStockStatus.NON_ORDERABLE;
    } else if (stockStatus.data?.stockStatus) {
      liveDeviceStatus = stockStatus.data.stockStatus;
    }
  } else if (deviceType === DeviceEndpoint.PREPAIDPHONE && deviceStockStatus === DeviceStockStatus.UNAVAILABLE) {
    liveDeviceStatus = DeviceStockStatus.PREPAIDUNAVAILABLE;
  }
  const isAnnouncementPhase = deviceDetails.announcementPhase;

  const mobilePhoneBasketItem = configuredStickyCart?.find(isDeviceBasketItem);

  const liveRecurringCharge: number | undefined = mobilePhoneBasketItem?.priceInfo.recurringCharge;
  const liveNonRecurringCharge: number | undefined = mobilePhoneBasketItem?.priceInfo.nonRecurringCharge;
  const liveOriginalNonRecurringCharge: number | undefined =
    mobilePhoneBasketItem?.priceInfo.originalNonRecurringCharge;
  const liveOriginalRecurringCharge: number | undefined = mobilePhoneBasketItem?.priceInfo.originalRecurringCharge;
  const liveContractTerm: string | undefined = mobilePhoneBasketItem?.productConfig.contractTerm;
  // [SHOP-7531]: Calculating the minimum total cost based on the live configuration of the item
  const liveDiscount = mobilePhoneBasketItem?.priceInfo?.discount ?? 0;
  const liveMinimumCost =
    liveOriginalRecurringCharge &&
    liveContractTerm &&
    calculateMinCost({ recurringCharge: liveOriginalRecurringCharge, contractTerm: liveContractTerm }) - liveDiscount;
  const { customStockAlertID } = pageData.deviceDetails;
  /**
   * CtaContainer
   */
  const isSimSelectionDisabledWithFeatureFlag = useFeatureFlag(Flag.DISABLE_SIM_SELECTION);
  const prepaidApiFailError = pageData.alerts.find((a) => a.alertId === 'prepaid-api-fail');
  const ctaDisabled =
    [DeviceStockStatus.NON_ORDERABLE, DeviceStockStatus.UNAVAILABLE, DeviceStockStatus.PREPAIDUNAVAILABLE].includes(
      liveDeviceStatus,
    ) ||
    stockStatus.isLoading ||
    isSimSelectionDisabledWithFeatureFlag.isLoading ||
    (!planDetails && deviceType === DeviceEndpoint.PREPAIDPHONE) ||
    deviceDetails.hideStockMessaging;
  const isLoading = formState.isSubmitting || formState.isSubmitted || stockStatus.isLoading;

  // In prepaid Device go direct cart page
  const onCartCtaGo = useCallback(
    async (items) => {
      const extraOffer = query[QueryKey.EXTRA] ? query[QueryKey.EXTRA]?.toString() : '';

      if (planDetails) {
        items[0].childProducts.push(planDetails?.planId);
      }

      const response = await addToBasket({
        items,
        additionalBnsCount: customerBundleAndSaveCount,
        extraOffer,
      });

      if (!response) return;
      LocalStorageClient.setBasketId(response.basketId);
      setBasket(response);
      safeRouterPush(decoratePathWithQueries('/cart', [QueryKey.NUDGE_REFERRER]));
    },
    [query, planDetails, addToBasket, customerBundleAndSaveCount, setBasket],
  );

  const onSubmit = useCallback(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    async (data: DeviceConfigFormValues) => {
      if (!mobilePhoneBasketItem) {
        return;
      }

      trackEvent({
        pageEventAttributeOne: kebabCase(pageData.labels.ctaLabel),
        pageEventType: 'button',
        pageEventValue: 'click',
      });

      const items = history[step]?.configured ?? [];

      if (deviceType === DeviceEndpoint.PREPAIDPHONE) {
        onCartCtaGo(items);
      } else {
        goToNextStep({
          items,
          isSimSelectionDisabledWithFeatureFlag,
        });
      }
    },
    [
      mobilePhoneBasketItem,
      pageData.labels.ctaLabel,
      history,
      step,
      goToNextStep,
      isSimSelectionDisabledWithFeatureFlag,
      deviceType,
      onCartCtaGo,
    ],
  );
  const announcementAlertData = pageData.alerts.find((a) => a.alertId === 'Announcement');
  const deviceDataCapabilityContent = pageData.alerts.find(
    (a) => a.alertId?.toUpperCase() === deviceDetails?.deviceDataCapability?.toUpperCase(),
  );
  // Validate colours have corresponding device config
  const availableConfigs = Object.keys(deviceConfig);
  const deviceColors = deviceDetails.colors.filter((colour) => availableConfigs.includes(colour.value));
  const relatedProductsNavFeatureFlag = useFeatureFlag(Flag.DISABLE_RELATED_PRODUCTS_NAV);

  const onRelatedProductsTabClick = useCallback(
    (relatedProductCode: string) => () => {
      const newQuery = {
        ...query,
        [QueryKey.DEVICE]: relatedProductCode,
        [QueryKey.DEVICE_CAPACITY]: undefined,
        [QueryKey.DEVICE_COLOR]: undefined,
        [QueryKey.DEVICE_CONTRACT_TERM]: undefined,
      };
      const clearedNewQuery = omitBy(newQuery, isUndefined);
      window.location.href = queryString.stringifyUrl({
        url: path,
        query: clearedNewQuery,
      });
    },
    [path, query],
  );

  const minCostModal = useCallback(() => {
    setGlobalModal({
      id: 'min-cost',
      isOpen: true,
      onClose: () => {
        setGlobalModal('');
      },
      cancelCtaAction: () => {
        setGlobalModal('');
      },
      confirmCtaAction: () => {
        setGlobalModal('');
      },
    });
  }, [setGlobalModal]);

  const showEsimBadge = (simType: string | undefined) => simType?.includes('e-SIM');
  const eSimOnly = (simType: string | undefined) => !!(simType?.includes('e-SIM') && !simType?.includes('Physical'));

  const relatedDevices = deviceDetails?.relatedProducts ? deviceDetails.relatedProducts : [];
  const showRelatedDevices =
    !relatedProductsNavFeatureFlag.isLoading && !relatedProductsNavFeatureFlag.data && relatedDevices?.length !== 0;
  const { networkCapability } = deviceDetails;
  const { simTypeCompatibility } = deviceDetails;
  const [serviceType] = useServiceType();

  const eSimModalId =
    serviceType === ServiceTypeValue.Upgrade ? 'esim-onboarding-upgrades' : 'esim-onboarding-acquisition-device';

  const eSimLabel = eSimOnly(simTypeCompatibility)
    ? pageData.labels.esimOnlyDeviceNotificationLabel
    : pageData.labels.esimDeviceNotificationLabel;

  // Only show the eSim notification if device is esim compatible.
  const showEsimNotification = useMemo(() => {
    return !!(openEsimNotification && showEsimBadge);
  }, [openEsimNotification]);

  const onNotificationClose = () => {
    setOpenEsimNotification(false);
  };

  const getTradeData = async () => {
    const response = await getTradeAndSaveData();
    setTradeInDeviceData(response.asurionpricelist);

    setTradeInDeviceBrand(response.brandArray);
  };

  const prepaidDeviceColour = (
    <Text
      fontSize={{ xs: 'heading5Mobile', m: 'heading5Mobile', l: 'heading5' }}
      lineHeight={{ xs: 'heading5Mobile', m: 'heading5Mobile', l: 'heading5Mobile' }}
      textAlign={{ xs: 'left', m: 'left' }}
      fontFamily="regular"
      data-testid="color"
    >
      {pageData.labels.colourLabel}:<strong>&nbsp;{deviceDetails.defaultColor}</strong>
    </Text>
  );

  const deliveryCardRef = useRef<HTMLDivElement>(null);
  useScrollToQuery({ queryKey: QueryKey.TAB, rootRef: deliveryCardRef });

  useEffect(() => {
    const CheckDeliveryAvailabilityTabsTitle = [
      kebabCase(pageData.expressDelivery?.tabTitle),
      kebabCase(pageData.clickAndCollect?.tabTitle),
    ];
    const activatedTabIndex = () => {
      const { hash } = window.location;
      const hashValue = hash?.replace('#', '');
      const activeInx = CheckDeliveryAvailabilityTabsTitle.indexOf(hashValue);
      if (
        !clickAndCollectFeatureDisabled?.data &&
        [CatalogCode.POSTPAID_HANDSETS, CatalogCode.POSTPAID_TABLET].includes(catalogCode) &&
        activeInx !== -1
      ) {
        setActiveTabIndex(activeInx);
      }
    };

    window.addEventListener('hashchange', activatedTabIndex);
    return () => {
      window.removeEventListener('hashchange', activatedTabIndex);
    };
  }, [pageData, catalogCode, clickAndCollectFeatureDisabled]);

  return (
    <>
      {nudgeVariant && <Nudge variant={nudgeVariant} />}
      <SeoHead
        title={deviceDetails.seoTitle}
        aemMetaTags={deviceDetails.metaTags}
        structuredData={deviceDetails.seoData}
      />
      {!!fragmentHtml && <ExperienceFragment fragmentHtml={fragmentHtml} />}
      <BackButton
        as={backAs}
        data-testid="device-back-button"
        href={decoratePathWithQueries(backHref || '', [QueryKey.DATE, QueryKey.NUDGE_REFERRER])}
        onClick={backOnClick}
      >
        {pageData.labels.breadcrumbLabel}
      </BackButton>
      <main>
        {!relatedProductsNavFeatureFlag.isLoading &&
          relatedProductsNavFeatureFlag.data &&
          !!deviceDetails.relatedProducts?.length && (
            <RelatedProductsTabsNav
              data-testid="related-products"
              deviceDetails={deviceDetails}
              onTabClick={step !== 0 ? onRelatedProductsTabClick : undefined}
            />
          )}
        <Section spacingTop={{ xs: 's', l: 'xxl' }}>
          <Grid marginBottom={{ xs: '0', m: networkCapability ? '8px' : '27px' }}>
            <GridCol>
              <Container>
                <Title>
                  <Text
                    as="h1"
                    fontSize={{ xs: 'heading1Mobile', m: 'heading2' }}
                    lineHeight={{ xs: 'heading1Mobile', m: 'heading2' }}
                    textAlign={{ xs: 'left', m: 'left' }}
                    fontFamily="light"
                    data-testid="mobile-phone-title"
                  >
                    {deviceDetails.name}
                  </Text>
                </Title>
              </Container>
            </GridCol>
          </Grid>
          <Grid>
            <GridCol>
              <Container>
                <BadgeContainer isEmpty={!(!!networkCapability || showEsimBadge(simTypeCompatibility))}>
                  {pageData.deviceDetails.is5gCapable && (
                    <FiveGBadge>
                      <img alt={fiveGAltText} src={FiveGSVG} />
                    </FiveGBadge>
                  )}

                  {showEsimBadge(simTypeCompatibility) && (
                    <>
                      <ESimBadge>
                        <img alt={esimEnabledDeviceAltText} src={ESimSVG} />
                      </ESimBadge>
                      {showEsimNotification && eSimLabel ? (
                        <ESimNotification label={eSimLabel} modalId={eSimModalId} onClose={onNotificationClose} />
                      ) : null}
                    </>
                  )}
                </BadgeContainer>
                <ImageContainer>
                  <Sticky>
                    <DeviceCarousel key={color?.value} images={color?.images ?? []} />
                  </Sticky>
                </ImageContainer>
                <Content>
                  <GridCol>
                    <Grid rowGap="32px">
                      {sddDiscountForBasket && (
                        <GridCol>
                          <Controller
                            as={CalloutJunior}
                            control={control}
                            dataTestId="sdd-junior"
                            id="ssd-junior"
                            name="sdd-junior"
                            device={deviceDetails?.deviceSubType}
                            saving={sddDiscountForBasket}
                          />
                        </GridCol>
                      )}
                    </Grid>
                    <Form onSubmit={handleSubmit(onSubmit)} isEmpty={isEmpty(compareField)}>
                      <Grid marginBottom={deviceType === DeviceEndpoint.PREPAIDPHONE ? '16px' : '32px'}>
                        <GridCol>
                          <Controller
                            as={deviceType === DeviceEndpoint.PREPAIDPHONE ? prepaidDeviceColour : ColorPicker}
                            colors={deviceColors}
                            control={control}
                            disabled={isLoading}
                            id="color"
                            label={pageData.labels.colourLabel}
                            name="color"
                          />
                        </GridCol>
                      </Grid>
                      <Grid rowGap="32px">
                        {deviceType === DeviceEndpoint.PHONE ? (
                          <GridCol>
                            <Controller
                              as={
                                <OptionButtonGroup
                                  disabled={isLoading}
                                  id="capacity"
                                  label={pageData.labels.capacityLabel}
                                >
                                  {liveCapacities.map((c) => (
                                    <OptionButton id={c.value} key={c.value} value={c.value}>
                                      {c.label}
                                    </OptionButton>
                                  ))}
                                </OptionButtonGroup>
                              }
                              control={control}
                              name="capacity"
                            />
                          </GridCol>
                        ) : (
                          <GridCol>
                            <Text
                              fontSize={{ xs: 'heading5Mobile', m: 'heading5Mobile', l: 'heading5' }}
                              lineHeight={{ xs: 'heading5Mobile', m: 'heading5Mobile', l: 'heading5Mobile' }}
                              textAlign={{ xs: 'left', m: 'left' }}
                              fontFamily="regular"
                              data-testid="capacity"
                            >
                              {pageData.labels.capacityLabel}: <strong>{deviceDetails.defaultCapacity}</strong>
                            </Text>
                          </GridCol>
                        )}
                        <DeviceStatusAlert
                          alerts={pageData.alerts}
                          status={liveDeviceStatus}
                          customStockAlertId={customStockAlertID}
                          hideStockMessaging={pageData.deviceDetails.hideStockMessaging}
                        />
                        {deviceType === DeviceEndpoint.PHONE && (
                          <GridCol>
                            <Controller
                              as={
                                <OptionButtonGroup
                                  disabled={isLoading}
                                  id="contractTerm"
                                  label={pageData.labels.repaymentPeriodLabel}
                                >
                                  {deviceDetails.contractTerm.map((c) => (
                                    <OptionButton id={c.value} key={c.value} value={c.value}>
                                      {c.label}
                                    </OptionButton>
                                  ))}
                                </OptionButtonGroup>
                              }
                              control={control}
                              name="contractTerm"
                            />
                          </GridCol>
                        )}
                        {sddDiscountForBasket && (
                          <GridCol>
                            <Controller
                              as={CalloutSenior}
                              control={control}
                              dataTestId="sdd-senior"
                              id="ssd-senior"
                              name="sdd-senior"
                              device={deviceDetails?.deviceSubType}
                              saving={sddDiscountForBasket}
                            />
                          </GridCol>
                        )}
                        {!planDetails && deviceType === DeviceEndpoint.PREPAIDPHONE && (
                          <GridCol>
                            <AnimatedAlert inline={true} variant="error">
                              <RichText>{prepaidApiFailError?.alertText}</RichText>
                            </AnimatedAlert>
                          </GridCol>
                        )}
                        <GridCol>
                          {deviceType === DeviceEndpoint.PHONE ? (
                            <RepaymentContainer disabled={isLoading}>
                              <Text
                                fontFamily="bold"
                                fontSize={{ xs: 'heading5Mobile', m: 'heading5' }}
                                lineHeight={{ xs: 'heading5Mobile', m: 'heading5' }}
                              >
                                Device repayment:
                              </Text>
                              <Price
                                price={liveRecurringCharge}
                                originalPrice={liveOriginalRecurringCharge}
                                label="per month"
                              />
                              {/* [SHOP-7531]: Updated the minimum cost info text and added the condition to display the
                              minimum cost info only when it is available. */}
                              {liveMinimumCost && (
                                <MinimumCost>
                                  {`Min cost $${formatCurrency(liveMinimumCost)} `}
                                  <MinCostModalLink
                                    onClick={() => {
                                      minCostModal();
                                    }}
                                  >
                                    {`over ${liveContractTerm} months`}.
                                  </MinCostModalLink>
                                  {' Plan cost additional.'}
                                </MinimumCost>
                              )}
                            </RepaymentContainer>
                          ) : (
                            <Price
                              deviceType={deviceType}
                              price={liveNonRecurringCharge}
                              originalPrice={liveOriginalNonRecurringCharge}
                            />
                          )}
                        </GridCol>
                        {planDetails && (
                          <GridCol>
                            <PrepaidStarterPack prepaidStarterData={planDetails} />
                          </GridCol>
                        )}
                        {!isAnnouncementPhase && (
                          <GridCol>
                            <Grid>
                              <GridCol gridColSpan={{ xs: 12, m: 6 }}>
                                <Button
                                  data-testid="choose-plan-cta"
                                  disabled={ctaDisabled}
                                  isLoading={isLoading}
                                  fullWidth={true}
                                  type="submit"
                                >
                                  {ctaLabel}
                                </Button>
                              </GridCol>
                            </Grid>
                          </GridCol>
                        )}
                        {!isAuthenticated &&
                          deviceDetails.catalogCode.includes(CatalogCode.POSTPAID_HANDSETS) &&
                          isReturningUser() && (
                            <GridCol>
                              <UpgradeHubSection
                                pageData={pageData}
                                redirectedTo={`/upgrade${asPath}`}
                                linkDisabled={
                                  [
                                    DeviceStockStatus.NON_ORDERABLE,
                                    DeviceStockStatus.UNAVAILABLE,
                                    DeviceStockStatus.PREPAIDUNAVAILABLE,
                                  ].includes(liveDeviceStatus) || deviceDetails.hideStockMessaging
                                }
                              />
                            </GridCol>
                          )}
                        {isAnnouncementPhase && announcementAlertData && (
                          <GridCol>
                            <AnimatedAlert inline={true} variant="info">
                              <RichText>{announcementAlertData.alertText}</RichText>
                            </AnimatedAlert>
                          </GridCol>
                        )}
                      </Grid>
                    </Form>
                    {!isEmpty(compareField) && (
                      <Link href={compareField.compareUrl} target={compareField.openInNewBrowser ? '_blank' : '_self'}>
                        <CompareLink>{compareField.compareLabel}</CompareLink>
                      </Link>
                    )}
                    <Grid rowGap="32px">
                      {!disableTradeAndSave &&
                        tradeInDeviceBrandData.length > 0 &&
                        catalogCode !== CatalogCode.PREPAID_HANDSETS &&
                        tradeInToggle && (
                          <GridCol>
                            <TradeandSaveCard
                              deviceID={deviceDetails.id}
                              promotions={tradeInPromotions}
                              deviceBrandData={tradeInDeviceBrandData}
                              deviceData={tradeInDeviceData}
                            />
                          </GridCol>
                        )}
                      {!disableTradeAndSave &&
                        tradeInDeviceBrandData.length > 0 &&
                        catalogCode !== CatalogCode.PREPAID_HANDSETS &&
                        !tradeInToggle && (
                          <GridCol>
                            <TradeInCard
                              promotions={tradeInPromotions}
                              deviceData={tradeInDeviceData}
                              deviceName={deviceDetails.name}
                            />
                          </GridCol>
                        )}
                      {filteredPromotions.length > 0 && (
                        <GridCol>
                          <SpecialOffersCard promotions={filteredPromotions} heroOfferId={deviceDetails.heroOffer} />
                        </GridCol>
                      )}
                      {deviceDataCapabilityContent && (
                        <GridCol>
                          <FrequencyBandCard alertContent={deviceDataCapabilityContent} />
                        </GridCol>
                      )}
                      {!isAnnouncementPhase &&
                        !clickAndCollectFeatureDisabled?.isLoading &&
                        ![
                          DeviceStockStatus.NON_ORDERABLE,
                          DeviceStockStatus.UNAVAILABLE,
                          DeviceStockStatus.PREPAIDUNAVAILABLE,
                        ].includes(liveDeviceStatus) &&
                        !deviceDetails.hideStockMessaging && (
                          <GridCol>
                            <FieldContainer ref={deliveryCardRef}>
                              {!clickAndCollectFeatureDisabled?.data &&
                              !isMSOJourney &&
                              [CatalogCode.POSTPAID_HANDSETS, CatalogCode.POSTPAID_TABLET].includes(catalogCode) ? (
                                <CheckDeliveryAvailability
                                  expressDelivery={pageData.expressDelivery}
                                  clickAndCollect={pageData.clickAndCollect}
                                  sku={deviceSku.current}
                                  activateTabIndex={activeTabIndex}
                                />
                              ) : (
                                <ExpressDeliveryCard
                                  content={pageData.expressDelivery}
                                  sku={deviceSku.current}
                                  alerts={pageData.alerts}
                                  postcode={postcode}
                                  setPostcode={setPostcode}
                                  showAlert={showAlert}
                                  setShowAlert={setShowAlert}
                                  inputError={inputError}
                                  setInputError={setInputError}
                                />
                              )}
                            </FieldContainer>
                          </GridCol>
                        )}
                    </Grid>
                  </GridCol>
                </Content>
              </Container>
            </GridCol>
          </Grid>
        </Section>
        {showRelatedDevices && (
          <RelatedDevices
            relatedDevices={relatedDevices}
            catalogCode={catalogCode}
            similarDevicesLabel={pageData.labels.similarDevicesLabel}
          />
        )}
        <DeviceInformationSection
          deviceDetails={deviceDetails}
          deviceInformationLabel={pageData.labels.deviceInformationLabel}
        />
      </main>
    </>
  );
};

export default DeviceTemplate;
