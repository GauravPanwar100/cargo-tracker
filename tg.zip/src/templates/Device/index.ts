export { default } from './Device';
