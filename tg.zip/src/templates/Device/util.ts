import { getApiClient } from '@src/lib/api';
import { TradeInJsonResponse } from '@src/lib/api/types';
import { compareDate } from '@src/lib/util/trade-and-save';

interface ConfigItem {
  value: string;
}

/** Temp hardcoded ALT text */
export const esimEnabledDeviceAltText = 'eSIM-enabled device';
export const fiveGAltText = '5G approved device';

/**
 * Searches through a list of configs -- [color, color, color] or [capacity, capacity] -- and checks
 * to see if that config was specified in a query param. If not, find and return the defaultValue
 * for that config
 */
export function findConfigValue<T extends ConfigItem>(
  configs: T[],
  queryValue: string,
  defaultValue: string,
): T | undefined {
  let config: T | undefined;
  if (queryValue) {
    config = configs.find((c) => c.value === queryValue);
  }

  return config || configs.find((c) => c.value === defaultValue);
}

export const getTradeAndSaveData = async () => {
  const response = await getApiClient().fetchDeviceAndPriceInfo();
  const deviceBrandArray: string[] = [];
  const asurionpricelist: TradeInJsonResponse[] = [];
  const todayDate = new Date();
  todayDate.setHours(0, 0, 0, 0);
  response.forEach((data) => {
    if (todayDate <= compareDate(data.ToDate) && data.GwoPrice !== 0) {
      asurionpricelist.push(data);
      if (!deviceBrandArray.includes(data.DeviceMake)) {
        deviceBrandArray.push(data.DeviceMake);
      }
    }
  });
  return { asurionpricelist, brandArray: deviceBrandArray };
};
