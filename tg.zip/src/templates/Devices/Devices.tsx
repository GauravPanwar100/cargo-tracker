import React from 'react';
import { useRouter } from 'next/router';
import { GoToNextStepHandler } from '@src/components/core/Journey/JourneyStep/JourneyStep';
import AuthenticatedBackButton from '@src/components/vfe/AuthenticatedBackButton';
import Nudge from '@src/components/vfe/Nudge';
import { NudgeVariant } from '@src/components/vfe/Nudge/Nudge';
import { DevicesPageResponse } from '@src/lib/api/types';
import { useCommitStickyCartToHistoryOnMount, useStickyCartState } from '@src/lib/context/sticky-cart';
import { useTrackPage } from '@src/lib/tracking';
import { MaintenancePage, doesNotContainError } from '@src/lib/util/error';
import { stripQueryFromPath } from '@src/lib/util/url';
import FaqTermsAndConditionsSection from '@src/templates/common/FaqTermsAndConditionsSection';
import TitleSection from '@src/templates/common/TitleSection';
import { RedirectFlag, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { QueryKey } from '@src/lib/util/query';
import { useClientQuery } from '@src/lib/util/router';
import LogoutErrorModal from '@src/components/vfe/LogoutErrorModal/LogoutErrorModal';
import ExperienceFragment from '@src/components/vfe/ExperienceFragment';
import { getFragmentHtml } from '@src/lib/util/getFragmentHtml';
import DeviceSelectionSection from './DeviceSelectionSection';
import WhyVodafoneSection from './WhyVodafoneSection';

interface DevicesTemplateProps {
  backAs?: string;
  backHref?: string;
  backOnClick?: React.MouseEventHandler;
  goToNextStep?: GoToNextStepHandler;
  hideDescription?: boolean;
  nudgeVariant?: NudgeVariant;
  pageData: DevicesPageResponse;
  redirectFlag: RedirectFlag;
  step?: number;
  deviceType?: string;
}

const DevicesTemplate: React.FC<DevicesTemplateProps> = ({
  backAs,
  backHref,
  backOnClick,
  goToNextStep,
  hideDescription,
  pageData,
  nudgeVariant,
  redirectFlag,
  step,
  deviceType,
}) => {
  const query = useClientQuery();
  const router = useRouter();
  const path = stripQueryFromPath(router.asPath);
  const push = typeof query?.push === 'string' ? query.push : undefined;
  const returnTo = typeof query?.returnTo === 'string' ? query.returnTo : undefined;

  const {
    pageHeaderData: { experienceFragments },
  } = pageData;
  const fragmentHtml = getFragmentHtml(experienceFragments);

  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });

  const { stickyCart } = useStickyCartState();
  useCommitStickyCartToHistoryOnMount({
    isInterimStep: true,
    step,
    stickyCart,
  });

  useTrackPage({
    pageTitle: pageData.pageHeaderData.seoTitle || '',
    path,
    nudgeReferrer: (router.query[QueryKey.NUDGE_REFERRER] || '').toString(),
  });

  const titleComponent = <TitleSection hideDescription={hideDescription} pageHeaderData={pageData.pageHeaderData} />;

  const deviceSelectionComponent = (
    <DeviceSelectionSection
      asPath={router.asPath}
      devicesData={pageData.deviceListing.devices}
      promosData={pageData.deviceListing.promos}
      goToNextStep={goToNextStep}
      pathname={router.pathname}
      deviceType={deviceType}
    />
  );

  const uniqueSellingPointsComponent = doesNotContainError(pageData.uspItems) && (
    <WhyVodafoneSection uspItems={pageData.uspItems} />
  );

  const faqTermsAndConditionsComponent = (
    <FaqTermsAndConditionsSection faqs={pageData.faqs} termsAndConditions={pageData.termsAndConditions} />
  );

  return (
    <main>
      {nudgeVariant && <Nudge variant={nudgeVariant} />}
      {!!fragmentHtml && <ExperienceFragment fragmentHtml={fragmentHtml} />}
      {titleComponent}
      <AuthenticatedBackButton as={backAs} href={backHref} onClick={backOnClick}>
        {pageData.pageHeaderData.altBreadcrumb || 'Back'}
      </AuthenticatedBackButton>
      {deviceSelectionComponent}
      {uniqueSellingPointsComponent}
      {faqTermsAndConditionsComponent}
      <LogoutErrorModal variant={push} path={path} returnTo={returnTo} />
    </main>
  );
};

export default DevicesTemplate;
