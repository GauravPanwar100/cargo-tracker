/* eslint-disable no-console */
import React, { useCallback, useEffect, useRef } from 'react';
import { sortBy } from 'lodash';
import { useRouter } from 'next/router';
import styled, { ThemeProvider } from 'styled-components';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import { FeaturedText, FeaturedTextItem } from '@src/components/core/FeaturedText';
import { GoToNextStepHandler } from '@src/components/core/Journey/JourneyStep/JourneyStep';
import QuickLink from '@src/components/core/QuickLink';
import AuthenticatedBackButton from '@src/components/vfe/AuthenticatedBackButton';
import Nudge from '@src/components/vfe/Nudge';
import { NudgeVariant } from '@src/components/vfe/Nudge/Nudge';
import { CardStyle } from '@src/components/vfe/PlanSelectorCard/PlanCardHead/PlanCardHead';
import {
  AddressCheckerResponse,
  BnsOffer,
  CatalogCode,
  OnlinePromoContentParams,
  PageContentSections,
  PlanBasketRequestItem,
  PlansPageResponse,
  PostpaidPlan,
  PrepaidPlan,
  PromoSubtype,
} from '@src/lib/api/types';
import { useCustomerData } from '@src/lib/context/customer-data';
import { Flag, RedirectFlag, useFeatureFlag, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { useCommitStickyCartToHistoryOnMount, useStickyCart } from '@src/lib/context/sticky-cart';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import {
  SpacingKey,
  Theme,
  lightGreyTheme,
  lightTheme,
  midTheme,
  upliftDarkTheme,
  upliftLightTheme,
  violetTheme,
} from '@src/lib/theme';
import { formatBundleForTracking, trackEvent, useTrackPage } from '@src/lib/tracking';
import { MaintenancePage } from '@src/lib/util/error';
import { isUpgradesRoute, shouldGoToExtrasPage } from '@src/lib/util/journey';
import { stripQueryFromPath } from '@src/lib/util/url';
import FaqTermsConditionsSection from '@src/templates/common/FaqTermsAndConditionsSection';
import TitleSection from '@src/templates/common/TitleSection';
import { removeExtrasItemTypeFromStickyCart } from '@src/templates/Plans/utils';
import PlanListingSection from '@src/templates/Plans/PlanListingSection';
import { QueryKey } from '@src/lib/util/query';
import { BnsOfferProvider } from '@src/lib/context/bns-offer-data';
import useQueryLogin from '@src/lib/hooks/use-query-login';
import { usePlanIconUrl } from '@src/lib/context/header-data';
import { ProductItem } from '@src/lib/storage/types';
import { storePreviouslyViewedProduct } from '@src/lib/util/previously-viewed';
import { usePreviouslyViewedContent, usePromotionalCampaignsContent } from '@src/lib/context/global-content';
import UspSection from '@src/components/vfe/UspSection';
import { PayIn4ContentProvider } from '@src/lib/context/pay-in-four-content-provider';
import { getPromoHeroLabelByIdentifier, storeOptimizeContent } from '@src/lib/util/promotional-campaigns';
import { isReOrderingContent } from '@src/lib/util/plan';
import RichText from '@src/components/core/RichText';
import Text from '@src/components/core/Text';
import InlineBanner from '@src/components/core/InlineBanner';
import AddressChecker from '@src/components/vfe/AddressChecker';
import { HomeInternetType } from '@src/templates/HomeWireless/HomeWireless.constants';
import { MixinProperty } from '@src/lib/util/mixins';
import { UpliftDataProvider } from '@src/lib/context/uplift-data-provider';
import ExperienceFragment from '@src/components/vfe/ExperienceFragment';
import useIsomorphicLayoutEffect from '@src/lib/hooks/use-isomorphic-layout-effect';
import { useBasketState } from '@src/lib/context/basket';
import { ProductMappings } from './constants';

export interface PlansTemplateProps {
  backAs?: string;
  backHref?: string;
  backLabel?: string;
  backOnClick?: React.MouseEventHandler;
  disableStickyCart?: boolean;
  goToNextStep: GoToNextStepHandler;
  /**
   * This prop is used when the Plans page is inside a Journey, and that Journey is loading the content
   * and data for the next step. We want to show a loading spinner for the currently selected plan, and
   * disable the CTA buttons for any other plans
   */
  isLoading?: boolean;
  nudgeVariant?: NudgeVariant;
  pageData: PlansPageResponse;
  redirectFlag: RedirectFlag;
  step: number;
  bnsOffer?: BnsOffer | null;
  extraOffer?: string;
  studentOfferValidationHandler?: () => void;
  onlinePromoContentParams?: OnlinePromoContentParams;
  addressFields?: AddressCheckerResponse;
  upliftFeatureFlag?: Flag;
  isSimOnly?: boolean;
}
export const SMCard = styled.div`
  max-width: 480px;
  padding: 30px;
  margin: auto;
  border-radius: 6px;
  box-shadow: 0 1px 3px 0 rgba(127, 127, 127, 0.5);
  background-color: #fff;
  padding: 40px;
  text-align: left;
`;
export const SMdiv = styled.div`
  @media screen and (min-width: 768px) {
    margin-left: -40px;
  }
`;

const PlansTemplate: React.FC<PlansTemplateProps> = ({
  backAs,
  backHref,
  backLabel,
  backOnClick,
  disableStickyCart = false,
  goToNextStep,
  isLoading,
  nudgeVariant,
  pageData,
  redirectFlag,
  step,
  bnsOffer,
  extraOffer,
  studentOfferValidationHandler,
  onlinePromoContentParams,
  addressFields,
  upliftFeatureFlag,
  isSimOnly = false,
}) => {
  useQueryLogin();
  const { asPath, query } = useRouter();
  const { extra } = query;
  const path = stripQueryFromPath(asPath);
  // eslint-disable-next-line react-hooks/exhaustive-deps, react-hooks/rules-of-hooks
  const upliftDisabled = upliftFeatureFlag ? useFeatureFlag(upliftFeatureFlag) : { data: true }; // if false, uplift is enabled
  const {
    catalogCode,
    planListing: { experienceFragments, inlineBanners, planListingTheme, planListingBackgroundColor },
  } = pageData;

  // set upliftEnabled to true if product page is upliftApplicable and upliftDisabled is false.
  const upliftEnabled = React.useMemo(() => {
    if (upliftDisabled.data === false) return true;
    return false;
  }, [upliftDisabled]);

  // Background for why vodafone section
  const whyVodafoneSectionBgColor =
    isSimOnly || upliftEnabled ? midTheme.variants.backgroundColor : lightGreyTheme.variants.backgroundColor;

  // if uplift enabled, check for planListingTheme and planListingBackgroundColor, if any of the 2 don't exist default to violetTheme
  // if uplift is disabled, don't check for 2 parameters, and default to midTheme

  let pageTheme: Theme = midTheme;
  if (upliftEnabled) {
    if (planListingTheme && planListingBackgroundColor) {
      pageTheme =
        planListingTheme === 'dark'
          ? JSON.parse(JSON.stringify(upliftDarkTheme))
          : JSON.parse(JSON.stringify(upliftLightTheme));
      pageTheme.variants.backgroundColor = planListingBackgroundColor;
    } else {
      pageTheme = violetTheme;
    }
  }

  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });

  const iconPath = usePlanIconUrl();
  const previouslyViewedContent = usePreviouslyViewedContent();
  // Get promotional campaign based on identifier ( catalog code SIMO Plans )
  const promoHeroLabel = useRef<string>(''); // default value
  const promoCampaignsContent = usePromotionalCampaignsContent();
  useEffect(() => {
    if (onlinePromoContentParams && promoCampaignsContent && extraOffer !== PromoSubtype.Student) {
      storeOptimizeContent({
        catalogCode: onlinePromoContentParams.catalogCode,
        promoCampaignsContent,
        promoAvailability: onlinePromoContentParams.promoAvailability,
        optimizeContentKey: onlinePromoContentParams.optimizeContentKey,
      });
    }
    const contentHeroLabel = getPromoHeroLabelByIdentifier({
      catalogCode: CatalogCode.POSTPAID_SIMO_PLANS,
      promoCampaignsContent,
    });

    if (contentHeroLabel) {
      promoHeroLabel.current = contentHeroLabel;
    }
  }, [promoCampaignsContent, onlinePromoContentParams, extraOffer]);

  // SHOP-4739 track previously viewed products
  useEffect(() => {
    // if we cannot find the mapping for this catalog code, we are not tracking this product.
    const config = ProductMappings[catalogCode];
    if (!config) {
      return;
    }

    const fallback: ProductItem = {
      productName: config.productNameFallback,
      productImg: { imageUrl: iconPath, altText: config.productNameFallback },
      productUrl: window.location.href,
      id: catalogCode,
    };
    storePreviouslyViewedProduct(catalogCode, fallback, previouslyViewedContent);
  }, [catalogCode, iconPath, previouslyViewedContent]);

  const {
    upgradePlanEligibility: [planEligibilityState],
  } = useCustomerData();

  const isUpgradeJourney = isUpgradesRoute(path);
  const isEligiblePlan = (plan: PostpaidPlan | PrepaidPlan) =>
    !isUpgradeJourney || !!planEligibilityState.data?.upgradeEligiblePlans?.includes(plan.planId);
  const getPlans = sortBy(pageData.planListing.plans?.filter(isEligiblePlan) ?? [], ['order']);
  const plans = getPlans.filter((plan) => plan.isTrialPlan === false);
  const secondaryPlans = pageData.secondaryPlanListing?.plans?.filter(isEligiblePlan) ?? [];
  // TODO: Why is this not used?
  // const secondaryPlans = sortBy(pageData.secondaryPlanListing?.plans.filter(isEligiblePlan) ?? [], ['order']);

  const [{ history, stickyCart }, stickyCartDispatch] = useStickyCart();
  useCommitStickyCartToHistoryOnMount({ restoreTo: 'original', step, stickyCart });

  useTrackPage({
    pageTitle: pageData.pageHeaderData.seoTitle || '',
    path,
    nudgeReferrer: (query[QueryKey.NUDGE_REFERRER] || '').toString(),
  });
  const { getBasketState } = useBasketState();

  const originalStickyCart = history[step]?.original;
  const isSimSelectionDisabledWithFeatureFlag = useFeatureFlag(Flag.DISABLE_SIM_SELECTION);
  const addPlanToStickyCart = useCallback(
    async (item: PlanBasketRequestItem) => {
      const updatedStickyCart = [...(originalStickyCart ?? []), item];
      trackEvent({
        pageEventType: 'button',
        pageEventValue: 'click',
        // TODO: Get ctaLabel again
        pageEventAttributeOne: '',
        stickyCart: [formatBundleForTracking(updatedStickyCart)],
      });

      const hasExtras = shouldGoToExtrasPage(item, isSimSelectionDisabledWithFeatureFlag?.data);

      if (!disableStickyCart) {
        if (!hasExtras) {
          removeExtrasItemTypeFromStickyCart({ items: updatedStickyCart, stickyCartDispatch });
        }
        stickyCartDispatch({
          type: 'SET_STICKY_CART',
          payload: { items: updatedStickyCart, history: { historyType: 'configured', step } },
        });
      }

      await goToNextStep({
        items: updatedStickyCart,
        hasExtras,
        isSimSelectionDisabledWithFeatureFlag,
        basketState: getBasketState?.data,
      });
    },
    [
      originalStickyCart,
      isSimSelectionDisabledWithFeatureFlag,
      disableStickyCart,
      goToNextStep,
      getBasketState?.data,
      stickyCartDispatch,
      step,
    ],
  );

  const [onCtaClickState, onCtaClick] = useImperativeData(addPlanToStickyCart);

  const hasWhyVodafoneSection = pageData.catalogCode === CatalogCode.PREPAID_COMBO_PLUS_PLANS;

  let paddingBottom: MixinProperty<SpacingKey> | undefined;
  if (hasWhyVodafoneSection) paddingBottom = { xs: 's', m: 'm', l: 'xxl' };
  else if (upliftEnabled) paddingBottom = { xs: 'l', l: 'xxxl' };
  else paddingBottom = undefined;

  const EXP_FRAG_ID_SIMO = 'simo-page';
  const EXP_FRAG_ID_STUDENT_OFFER_BANNER = 'student-offer-banner';
  const EXP_FRAG_ID_COUNTDOWN_TIMER = 'countdown-timer';
  let studentBanner;
  let banner;
  let countDownTimer;
  if (experienceFragments && experienceFragments.length > 0) {
    // If any of the banners are not defined in the server-side, they will not show
    if (isSimOnly) {
      studentBanner = experienceFragments.find((fragment) => fragment.fragmentId === EXP_FRAG_ID_STUDENT_OFFER_BANNER);
      banner = experienceFragments.find((fragment) => fragment.fragmentId === EXP_FRAG_ID_SIMO);
    } else {
      banner = experienceFragments.find((fragment) => fragment.fragmentId !== EXP_FRAG_ID_COUNTDOWN_TIMER);
    }
    countDownTimer = experienceFragments.find((fragment) => fragment.fragmentId === EXP_FRAG_ID_COUNTDOWN_TIMER);
  }

  let bottomBannerData;
  if (inlineBanners && inlineBanners.length > 0) {
    if (isSimOnly) {
      if (extra === 'student') {
        bottomBannerData = inlineBanners?.find((inlineBanner) => inlineBanner.bannerId === 'students-bottom-banner');
      }
      if (!extra) {
        bottomBannerData = inlineBanners?.find((inlineBanner) => inlineBanner.bannerId === 'bottom-banner');
      }
    } else {
      bottomBannerData = inlineBanners?.find((inlineBanner) => inlineBanner.bannerId === 'whistle-out');
    }
  }

  let spacingTop: MixinProperty<SpacingKey>;
  if (!isReOrderingContent(catalogCode, PageContentSections.USPS)) spacingTop = null;
  else if (upliftEnabled) spacingTop = { xs: 'l', m: 'l', l: 'l' };
  else {
    spacingTop = { xs: 'm', l: 'xxl' };
  }

  useIsomorphicLayoutEffect(() => {
    const handleDocumentReady = () => {
      const heroDiv = document.querySelector('vha-hero-banner-carousel') as HTMLElement;
      const shadowCarouselContainer = heroDiv?.shadowRoot?.querySelector('.carousel-container');
      const vhaHeroDiv = shadowCarouselContainer?.querySelector('vha-hero-banner') as HTMLElement;
      const shadowVHAHeroDiv = vhaHeroDiv?.shadowRoot?.querySelector('.herobanner-container') as HTMLElement;
      shadowVHAHeroDiv?.style.setProperty('background', planListingBackgroundColor ?? '#EBEBEB');
    };

    let handleLoad: () => void;

    if (typeof window !== 'undefined') {
      handleLoad = () => {
        handleDocumentReady();
        window.removeEventListener('load', handleLoad);
      };

      if (document.readyState === 'complete') {
        handleDocumentReady();
      } else {
        window.addEventListener('load', handleLoad);
      }
    }
    return () => {
      if (typeof window !== 'undefined' && handleLoad) {
        window.removeEventListener('load', handleLoad);
      }
    };
  }, [planListingBackgroundColor]);

  return (
    <>
      <main>
        {!isSimOnly && banner && <ExperienceFragment {...banner} />}
        <BnsOfferProvider offers={bnsOffer}>
          <PayIn4ContentProvider
            payIn4Content={{
              showPayIn4PromoContent: pageData.planListing.showPayIn4PromoContent,
              payIn4PromoContentThreshold: pageData.planListing.payIn4PromoContentThreshold,
            }}
          >
            <UpliftDataProvider upliftEnabled={upliftEnabled}>
              {extra !== 'student' && nudgeVariant && <Nudge variant={nudgeVariant} />}
              {isSimOnly && extra === 'student' && studentBanner && <ExperienceFragment {...studentBanner} />}
              {isSimOnly && extra !== 'student' && banner && <ExperienceFragment {...banner} />}
              {countDownTimer && <ExperienceFragment {...countDownTimer} />}
              {upliftDisabled.data !== null && (
                <>
                  {upliftEnabled && isReOrderingContent(catalogCode, PageContentSections.BREADCRUMB) && (
                    <AuthenticatedBackButton as={backAs} href={backHref} onClick={backOnClick}>
                      {backLabel}
                    </AuthenticatedBackButton>
                  )}
                  <TitleSection
                    pageHeaderData={pageData.pageHeaderData}
                    hideDescription={!!backLabel || isReOrderingContent(catalogCode, PageContentSections.TITLE_DESC)}
                    pageTheme={pageTheme}
                    planListingTheme={planListingTheme}
                  />
                  {!upliftEnabled && isReOrderingContent(catalogCode, PageContentSections.TITLE_DESC) && (
                    <AuthenticatedBackButton as={backAs} href={backHref} onClick={backOnClick}>
                      {backLabel}
                    </AuthenticatedBackButton>
                  )}
                  {!upliftEnabled &&
                    catalogCode !== CatalogCode.PREPAID_COMBO_PLUS_PLANS &&
                    isReOrderingContent(catalogCode, PageContentSections.USPS) && (
                      <UspSection
                        {...pageData.planListing}
                        isNewDesign={upliftEnabled}
                        isUpgradeJourney={isUpgradeJourney}
                        backgroundColor={midTheme.variants.backgroundColor}
                        iconSizeVariant={pageData.planListing.iconTilesVariant || 'smalls'}
                      />
                    )}
                  {catalogCode !== CatalogCode.PREPAID_COMBO_PLUS_PLANS &&
                    !isReOrderingContent(catalogCode, PageContentSections.USPS) && (
                      <UspSection
                        {...pageData.planListing}
                        isUpgradeJourney={isUpgradeJourney}
                        backgroundColor={pageData.planListing.iconTilesBgColor || midTheme.variants.backgroundColor}
                        iconSizeVariant={pageData.planListing.iconTilesVariant || 'smalls'}
                      />
                    )}
                  <ThemeProvider theme={pageTheme}>
                    {/* we need to exclude prepaid-combo-plus plan
                    listing to show USPS down in the page */}
                    <PlanListingSection
                      catalogCode={pageData.catalogCode}
                      dataTestId="plans"
                      disabled={isSimSelectionDisabledWithFeatureFlag.isLoading}
                      id="primaryPlans"
                      isLoading={isLoading}
                      onCtaClick={onCtaClick}
                      onCtaClickState={onCtaClickState}
                      plans={plans}
                      spacingBottom={paddingBottom}
                      spacingTop={spacingTop} // if plan listing is not first element, no need spacing top
                      extraOffer={extraOffer}
                      studentOfferValidationHandler={studentOfferValidationHandler}
                      promoHeroLabel={promoHeroLabel.current}
                    />
                  </ThemeProvider>
                  <ThemeProvider theme={midTheme}>
                    {bottomBannerData && <InlineBanner bannerData={bottomBannerData} simoLink={true} />}

                    {upliftEnabled &&
                      catalogCode !== CatalogCode.PREPAID_COMBO_PLUS_PLANS &&
                      isReOrderingContent(catalogCode, PageContentSections.USPS) && (
                        <UspSection
                          {...pageData.planListing}
                          isNewDesign={upliftEnabled}
                          isUpgradeJourney={isUpgradeJourney}
                          backgroundColor={
                            upliftEnabled
                              ? whyVodafoneSectionBgColor
                              : pageData.planListing.iconTilesBgColor || midTheme.variants.backgroundColor
                          }
                          iconSizeVariant={pageData.planListing.iconTilesVariant || 'smalls'}
                        />
                      )}

                    {!backLabel &&
                      isReOrderingContent(catalogCode, PageContentSections.DEFAULT_DESC) &&
                      pageData?.pageHeaderData?.defaultDescription && (
                        <ThemeProvider theme={isSimOnly ? midTheme : lightGreyTheme}>
                          <Section
                            spacingBottom={{ xs: 's', m: 's', l: isSimOnly ? 'l' : 'xxl' }}
                            spacingTop={{ xs: 's', m: 's', l: isSimOnly ? 'none' : 's' }}
                          >
                            <Grid>
                              <GridCol
                                gridColStart={{ xs: 1, m: isSimOnly ? 0 : 3 }}
                                gridColSpan={{ xs: 12, m: isSimOnly ? 12 : 8 }}
                              >
                                <Text
                                  fontSize={{ xs: 'base', m: 'heading5' }}
                                  lineHeight={{ xs: 'base', m: 'heading5' }}
                                  textAlign={isSimOnly ? 'left' : 'center'}
                                >
                                  <RichText>{pageData?.pageHeaderData?.defaultDescription}</RichText>
                                </Text>
                              </GridCol>
                            </Grid>
                          </Section>
                        </ThemeProvider>
                      )}
                    {/* we need to exclude prepaid-combo-plus plan
            listing to show USPS down in the page */}
                    {hasWhyVodafoneSection && (
                      <UspSection
                        usps={pageData.planListing.usps}
                        backgroundColor={pageData.planListing.iconTilesBgColor || lightTheme.variants.backgroundColor}
                        iconSizeVariant={pageData.planListing.iconTilesVariant || 'smalls'}
                        // TODO : we need AEM to provide this string.
                        title="Why choose Vodafone prepaid"
                        description=""
                      />
                    )}
                    {addressFields && catalogCode === CatalogCode.POSTPAID_SIMO_TPG_SM && (
                      <Section spacingTop={{ xs: 's', m: 'm' }}>
                        <SMCard>
                          <Text fontSize="heading4Tablet" marginBottom="16px">
                            Check your Vodafone mobile coverage
                          </Text>
                          <Text marginBottom="10px">See if you have 5G, 4G or 3G mobile coverage in your area</Text>
                          <SMdiv>
                            <AddressChecker
                              addressFields={addressFields}
                              id="simo-addressChecker"
                              internetType={HomeInternetType.FHW_4G}
                              pathName={path}
                              isOnlyMobileCoverage={true}
                            />
                          </SMdiv>
                        </SMCard>
                      </Section>
                    )}
                    {pageData.quickLinks && (
                      <>
                        <Section>
                          <Grid>
                            {pageData.quickLinks.quickLinks.map((item) => (
                              <GridCol gridColSpan={{ xs: 12, m: 6 }} key={`quicklink_${item.title}`}>
                                <QuickLink
                                  key={item.title}
                                  description={item.description}
                                  href={item.targetUrl}
                                  icon={item.iconUrl}
                                  title={item.title}
                                />
                              </GridCol>
                            ))}
                          </Grid>
                        </Section>
                      </>
                    )}
                  </ThemeProvider>
                  {/* We only want to show the Secondary plan section if there are eligible plans */}
                  {secondaryPlans.length > 0 && (
                    <ThemeProvider theme={midTheme}>
                      <Section spacingBottom={{ xs: 's', m: 'l' }} data-testid="planlisting-secondary-featured-detail">
                        <Grid>
                          <GridCol>
                            <FeaturedText
                              data-testid="planlisting-secondary-featured-list"
                              title={pageData.secondaryPlanListing!.title}
                              description={pageData.secondaryPlanListing!.description}
                            >
                              {/* we need to exclude prepaid-combo-plus plan
                    listing to show USPS down in the page */}
                              {pageData.catalogCode !== CatalogCode.PREPAID_COMBO_PLUS_PLANS &&
                                pageData.secondaryPlanListing!.usps?.map((p) => (
                                  <FeaturedTextItem icon={p.imageUrl} key={p.title} title={p.title}>
                                    {p.description}
                                  </FeaturedTextItem>
                                ))}
                            </FeaturedText>
                          </GridCol>
                        </Grid>
                      </Section>
                      <PlanListingSection
                        catalogCode={pageData.catalogCode}
                        cardStyle={CardStyle.Grey}
                        dataTestId="secondary-planlisting"
                        id="secondaryPlans"
                        onCtaClick={onCtaClick}
                        onCtaClickState={onCtaClickState}
                        plans={secondaryPlans}
                        studentOfferValidationHandler={studentOfferValidationHandler}
                        promoHeroLabel={promoHeroLabel.current}
                      />
                      {/* we need to exclude prepaid-combo-plus plan
            listing to show USPS down in the page */}
                      {pageData.catalogCode === CatalogCode.PREPAID_COMBO_PLUS_PLANS && (
                        <Section backgroundColor={false} spacingTop={{ xs: 's', l: 'xxl' }}>
                          <Grid>
                            <GridCol>
                              <FeaturedText
                                data-testid="planlisting-secondary-featured-list"
                                // TODO : we need AEM to provide this string.
                                title="Why choose Vodafone prepaid"
                                description=""
                              >
                                {pageData.secondaryPlanListing!.usps!.map((p) => (
                                  <FeaturedTextItem icon={p.imageUrl} key={p.title} title={p.title}>
                                    {p.description}
                                  </FeaturedTextItem>
                                ))}
                              </FeaturedText>
                            </GridCol>
                          </Grid>
                        </Section>
                      )}
                    </ThemeProvider>
                  )}
                  <FaqTermsConditionsSection
                    faqs={pageData.faqs}
                    termsAndConditions={pageData.termsAndConditions}
                    spacingTop={isSimOnly ? 'none' : { xs: 's', m: 'm', l: 'xxl' }}
                  />
                </>
              )}
            </UpliftDataProvider>
          </PayIn4ContentProvider>
        </BnsOfferProvider>
      </main>
    </>
  );
};

export default PlansTemplate;
