import { CatalogCode } from '@src/lib/api/types';

type ProductMappingsType = {
  [key in CatalogCode]?: PreviouslyViewedConfig;
};

type PreviouslyViewedConfig = {
  productNameFallback: string;
};

export const ProductMappings: ProductMappingsType = {
  [CatalogCode.POSTPAID_SIMO_PLANS]: { productNameFallback: 'SIM Only Plans' },
  [CatalogCode.PREPAID_PAY_AND_GO_PLANS]: { productNameFallback: 'Pay & Go Plans' },
  [CatalogCode.PREPAID_COMBO_PLUS_PLANS]: { productNameFallback: 'Prepaid Plus Plans' },
  [CatalogCode.POSTPAID_TABLET_SIMO_PLANS]: { productNameFallback: 'SIM Only Tablet Plans' },
};
