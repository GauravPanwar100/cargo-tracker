import { BasketRequestItem, CartItemType, Promotion } from '@src/lib/api/types';
import { StickyCartDispatch } from '@src/lib/context/sticky-cart';
import { isPlanBasketItem } from '@src/lib/util/cart';
import { QueryKey } from '@src/lib/util/query';

interface RemoveExtrasItemTypeFromStickyCartParams {
  items: BasketRequestItem[];
  stickyCartDispatch: StickyCartDispatch;
}

/**
 * Removes the Extras line item from the sticky cart. Used to avoid showing "Extras: Choose optional
 * extras" in the sticky cart, when there are none for a selected plan, and we are skipping the
 * extras page.
 */
export const removeExtrasItemTypeFromStickyCart = ({
  items,
  stickyCartDispatch,
}: RemoveExtrasItemTypeFromStickyCartParams) => {
  const itemTypesWithoutExtra = items
    .map((item) => item.itemType)
    .filter((itemType) => itemType !== CartItemType.EXTRA);

  stickyCartDispatch({
    type: 'SET_ITEM_TYPES',
    payload: itemTypesWithoutExtra,
  });
};

export const updatePlanQueryOnNextStep = (basketItems?: BasketRequestItem[]) => {
  const plan = basketItems?.find(isPlanBasketItem);
  return { [QueryKey.PLAN]: plan?.productCode };
};

export const getTotalAdjustedValueFromPromotions = (promotions: Promotion[] | undefined) => {
  if (!promotions || promotions.length === 0) return undefined;
  let adjustmentValue = 0;
  promotions.forEach((promo: Promotion) => {
    if (promo.priceAdjustmentValue) {
      adjustmentValue += parseInt(promo.priceAdjustmentValue, 10);
    }
  });

  return adjustmentValue;
};

export const makePlanCardId = (id: string) => `plan-card-${id}`;
