import { find, get, noop } from 'lodash';
import { useRouter } from 'next/router';
import React, { useEffect, useState } from 'react';
import { FieldRenderProps, Field as FinalFormField, Form, FormProps } from 'react-final-form';
import { FieldValidator } from 'final-form';
import { useSasData } from '@src/lib/context/sas-provider';
import Logger from '@src/lib/logger/logger';
import Field from '@src/components/core/Field';
import { Grid, GridCol } from '@src/components/core/Grid';
import { PinInput } from '@src/components/core/PinInput';
import SeoHead from '@src/components/vfe/SeoHead';
import Text from '@src/components/core/Text';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import { getApiClient } from '@src/lib/api';
import { PinPageResponse } from '@src/lib/api/types';
import { ExpressJourneySlug } from '@src/lib/constants/express';
import useRecaptcha, { RecaptchaError } from '@src/lib/hooks/use-recaptcha';
import { NullableRecord } from '@src/lib/types';
import { normalisePin, onKeyPressPreventNonNumericKey, preventCopyPaste } from '@src/lib/util/pin';
import { Flag, IAM_OMEGA_ENVIRONMENT, useFeatureFlag } from '@src/lib/context/feature-flags';
import { useSetModal } from '@src/lib/context/modal';
import { AlertContainer } from '@src/templates/EU/Checkout/Checkout.styles';
import Alert from '@src/components/core/Alert';
import RichText from '@src/components/core/RichText';
import { AlertVariant } from '@src/components/core/Alert/Alert';
import { stripQueryFromPath } from '@src/lib/util/url';
import { useTrackPage } from '@src/lib/tracking';
import { QueryKey } from '@src/lib/util/query';
import CI360 from '@src/lib/ci360/ci360';
import { SessionStorageClient } from '@src/lib/storage';
import {
  Background,
  DescriptionContainer,
  EmptySpace,
  ErrorImg,
  NoPinLockContent,
  PinContainer,
  PinContainerContent,
  PinContainerHeader,
  PinFooterBackButton,
  PinForgotLink,
  PinHeaderBackButton,
  StyledButton,
  StyledRichText,
} from './Pin.styles';

export interface PinTemplateProps {
  journey: ExpressJourneySlug;
  pageData: PinPageResponse;
}

type FormValues = { vodafoneNumber: string; code: string };

const PinTemplate: React.FC<PinTemplateProps> = ({ journey, pageData }) => {
  const setModal = useSetModal();
  const alertNSEUMaintenance = find(pageData.alertsContent, {
    alertId: 'eu-maintenance',
    alertType: 'negativeScenario',
  })!;
  const alertInlineRecaptchaScoreFailed = find(pageData.alertsContent, {
    alertId: 'otp-recaptcha-failed',
    alertType: 'inlineError',
  })!;
  const alertInlineOtpLimitExceeded = find(pageData.alertsContent, {
    alertId: 'otp-limit-exceeded',
    alertType: 'inlineError',
  })!;
  const alertInvalidNumber = find(pageData.alertsContent, {
    alertId: 'mobile-number-invalid',
  })!;
  const alertInvalidPin = find(pageData.alertsContent, {
    alertId: 'pin-invalid',
  })!;
  const alertInvalidCredentials = find(pageData.alertsContent, {
    alertId: 'credentials-invalid',
  })!;
  const alertOtpValidationApiError = find(pageData.alertsContent, { alertId: 'otp-validation-api-fail' })!;
  const alertOtpInvalid = find(pageData.alertsContent, { alertId: 'otp-invalid' })!;

  const ApiClient = getApiClient();
  const router = useRouter();
  const { creatives } = useSasData();
  // TODO: Should we fail if encryptedMsisdn is not provided?
  const encryptedMsisdn = creatives?.express?.journey?.msisdn_enc?.value;

  const path = stripQueryFromPath(router.asPath);

  useTrackPage({
    pageTitle: pageData.headerContent.seoTitle || '',
    path,
    nudgeReferrer: (router.query[QueryKey.NUDGE_REFERRER] || '').toString(),
  });

  const iamMaintenanceModeFlag = useFeatureFlag(Flag.IAM_MAINTENANCE_MODE, IAM_OMEGA_ENVIRONMENT);

  useRecaptcha();

  useEffect(() => {
    if (!encryptedMsisdn || !iamMaintenanceModeFlag.isSuccess || iamMaintenanceModeFlag.data) return noop;

    const controller = new AbortController();
    CI360.sendCustomPageTrack({
      pageTitle: pageData.headerContent.seoTitle || '',
      path,
      activeMsisdn: encryptedMsisdn || null,
      accountType: null,
      serviceType: null,
    });

    return controller.abort.bind(controller);
  }, [encryptedMsisdn, iamMaintenanceModeFlag, pageData.headerContent.seoTitle, path]);

  const [credentialsErrorMessage, setCredentialsErrorMessage] = useState('');
  const [ctaDisable, setButtonDisable] = useState(false);
  const [pinLock, setPinLock] = useState(false);
  const pinLockAlert = pageData.alertsContent?.find((eachAlert) => eachAlert.alertId === 'pin-lock');

  const showForgotPinModal: React.MouseEventHandler<HTMLButtonElement> = React.useCallback(
    (e) => {
      e.preventDefault();
      setModal('forgot-pin');
    },
    [setModal],
  );

  const onSubmit: FormProps<FormValues>['onSubmit'] = async (values) => {
    setButtonDisable(true);
    setCredentialsErrorMessage('');
    try {
      const response = await ApiClient.verifyPin({
        msisdn: encryptedMsisdn!,
        vfNumber: values.vodafoneNumber.replace(/^04/g, '614'),
        pin: values.code,
      });

      if (response.isPinValid) {
        SessionStorageClient.setEUPinSuccessFlag('Y');
        router.push(`/express/otp?journey=${journey}`);
      } else if (response.errorCode === 'VE352' || response.errorCode === 'VE353') {
        setPinLock(true);
      } else setCredentialsErrorMessage(alertInvalidCredentials.alertText);

      return undefined;
    } catch (error) {
      Logger.error('PIN Validation error', {
        error,
        ucode: 'f11b229',
      });

      if (error instanceof RecaptchaError) {
        return {
          // TODO: This is not a low score error
          code: alertInlineRecaptchaScoreFailed.alertText,
        };
      }

      const status = ((error as NullableRecord)?.response as NullableRecord)?.status as number | undefined;
      const service = get(error, ['response', 'data', 'error', 'service']) as string | undefined;
      const type = get(error, ['response', 'data', 'error', 'type']) as string | undefined;

      if (status === 429) setCredentialsErrorMessage(alertInlineOtpLimitExceeded.alertText);
      // TODO: This is not a low score error
      if (service === 'recaptcha' && type === 'invalid')
        setCredentialsErrorMessage(alertInlineRecaptchaScoreFailed.alertText);
      if (service === 'recaptcha' && type === 'low_score')
        setCredentialsErrorMessage(alertInlineRecaptchaScoreFailed.alertText);
      if (service === 'auth0' && status === 403) setCredentialsErrorMessage(alertOtpInvalid.alertText);
      return setCredentialsErrorMessage(alertOtpValidationApiError.alertText);
    }
  };

  const getInputError = (fieldProps: FieldRenderProps<string, HTMLElement, string>) => {
    return (
      // When the field is not dirty (unchanged) since last submit and there was a submit error
      (!fieldProps.meta.dirtySinceLastSubmit && fieldProps.meta.submitError) ||
      // When the field is not active (focused), but has been focused
      (!fieldProps.meta.active && fieldProps.meta.touched && fieldProps.meta.error) ||
      // When the field is active (focused), the submit failed and the field is not dirty
      (fieldProps.meta.active &&
        fieldProps.meta.submitFailed &&
        !fieldProps.meta.dirtySinceLastSubmit &&
        fieldProps.meta.error) ||
      ''
    );
  };

  const validateInput = (value: string, regex: RegExp, errorMessage: string): string | undefined => {
    if (!regex.test(value)) return errorMessage;
    return undefined;
  };
  const validateAccNumber: FieldValidator<string> = (value) => {
    const VALID_ACC_NUMBER_REGEX = /^(04\d{8}|614\d{8})$/;
    return validateInput(
      value,
      VALID_ACC_NUMBER_REGEX,
      alertInvalidNumber.alertText || 'Please provide a valid Vodafone number.',
    );
  };
  const validatePin: FieldValidator<string> = (value) => {
    const VALID_CODE_REGEX = /^\d{4}$/;
    return validateInput(value, VALID_CODE_REGEX, alertInvalidPin.alertText || 'Please provide a valid PIN.');
  };

  const head = (
    <SeoHead
      title={pageData.headerContent.seoTitle}
      aemMetaTags={pageData.headerContent.metaTags}
      structuredData={pageData.headerContent.seoData}
    />
  );

  // Whilst we're still loading the IAM maintenance flag, or if there is not PIN details and we're not in maintenance mode
  if (!iamMaintenanceModeFlag.isSuccess || (!pageData && !iamMaintenanceModeFlag.data)) {
    return (
      <>
        {head}
        <SpinnerSection />
      </>
    );
  }

  return (
    <Background>
      {head}
      <Grid>
        <GridCol>
          <PinContainer>
            <PinContainerHeader>
              <PinHeaderBackButton
                type="button"
                onClick={() => router.back()}
                id="eu-back-otp"
                data-testid="eu-back-otp"
              >
                {pageData.accountPinInfo.backTextLinkLabel}
              </PinHeaderBackButton>
            </PinContainerHeader>
            <PinContainerContent>
              {iamMaintenanceModeFlag.data && (
                <ErrorImg
                  src={alertNSEUMaintenance.alertIcon}
                  alt=""
                  marginTop={{ m: '16px' }}
                  marginBottom={{ xs: '32px', m: '40px' }}
                />
              )}
              <Text
                as="h2"
                fontFamily="light"
                textAlign="center"
                fontSize={{ xs: 'heading2Mobile', m: 'heading2Tablet' }}
                marginLeft={{ xs: 0, m: '-24px' }}
                marginRight={{ xs: 0, m: '-24px' }}
                role="heading"
              >
                {pageData.headerContent.defaultTitle}
              </Text>
              <DescriptionContainer marginTop={{ xs: '16px' }} marginBottom={{ xs: '16px', m: '32px' }}>
                <RichText textAlign={iamMaintenanceModeFlag.data ? { xs: 'center', m: 'left' } : 'left'}>
                  {/* eslint-disable-next-line no-nested-ternary */}
                  {pageData.headerContent.altDescription ||
                    '&lt;p&gt;For security, we&rsquo;ll need your Vodafone number and account PIN.&lt;/p&gt;'}
                </RichText>
                <StyledRichText
                  marginTop={{ xs: '16px' }}
                  textAlign={iamMaintenanceModeFlag.data ? { xs: 'center', m: 'left' } : 'left'}
                  style={{ color: 'red' }}
                >
                  {credentialsErrorMessage
                    ? credentialsErrorMessage ||
                      'Unfortunately your details are incorrect. Please check your details and try again.'
                    : ''}
                </StyledRichText>
              </DescriptionContainer>
              {pinLock && pinLockAlert ? (
                <AlertContainer>
                  <Alert title={pinLockAlert.alertTitle} variant={pinLockAlert.alertType as AlertVariant}>
                    <RichText>{pinLockAlert.alertText}</RichText>
                  </Alert>
                </AlertContainer>
              ) : (
                <NoPinLockContent>
                  <Form<FormValues> initialValues={{ vodafoneNumber: '', code: '' }} onSubmit={onSubmit}>
                    {(formProps) => (
                      <form onSubmit={formProps.handleSubmit}>
                        <FinalFormField<string> name="vodafoneNumber" validate={validateAccNumber} parse={normalisePin}>
                          {(fieldProps) => {
                            const err: string = getInputError(fieldProps);
                            return (
                              <Field
                                id="vodafone-number-label"
                                label={pageData.accountPinInfo.mobileNumberLabelText || 'Vodafone number'}
                                error={err && <StyledRichText color="inherit">{err}</StyledRichText>}
                                labelSpacing="modulePaddingSmallSmall"
                              >
                                <PinInput
                                  {...fieldProps.input}
                                  name="vodafone-number-search-input"
                                  id="vodafone-number-search-input"
                                  data-testid="vodafone-number-search-input"
                                  type="text"
                                  minLength={11}
                                  maxLength={11}
                                  pattern="[0-9]*"
                                  required={true}
                                  helpText={
                                    pageData.accountPinInfo.mobileNumberHelpText ||
                                    'This is your Vodafone mobile number that received the offer.'
                                  }
                                  invalid={!!err}
                                  mask={false}
                                  onKeyPress={onKeyPressPreventNonNumericKey}
                                  onCopy={(e: { preventDefault: () => void }) => preventCopyPaste(e)}
                                  onPaste={(e: { preventDefault: () => void }) => preventCopyPaste(e)}
                                />
                              </Field>
                            );
                          }}
                        </FinalFormField>
                        <EmptySpace />
                        <FinalFormField<string> name="code" validate={validatePin} parse={normalisePin}>
                          {(fieldProps) => {
                            const err: string = getInputError(fieldProps);
                            return (
                              <Field
                                id="account-pin-code"
                                label={pageData.accountPinInfo.accountPinLabelText || 'Account PIN'}
                                error={err && <StyledRichText color="inherit">{err}</StyledRichText>}
                                labelSpacing="modulePaddingSmallSmall"
                              >
                                {/* the input type here has been changed from password to search to get rid of browser autofills */}
                                {/* firefox has no support for :autofill pseudo class*/}
                                {/* also, the keyword "search" is added to the name to prevent autofill in Safari  */}
                                <PinInput
                                  {...fieldProps.input}
                                  name="account-pin-search-input"
                                  id="account-pin-search-input"
                                  data-test-id="account-pin-search-input"
                                  type="search"
                                  maxWidth="180px"
                                  minLength={4}
                                  maxLength={4}
                                  pattern="[0-9]*"
                                  required={true}
                                  mask={true}
                                  helpText={
                                    pageData.accountPinInfo.pinAlternateCtaLabel ||
                                    "This is the PIN you created when you signed up for your service. If your service sits under one account, you'll need the PIN of the account owner to log in."
                                  }
                                  invalid={!!err}
                                  onKeyPress={onKeyPressPreventNonNumericKey}
                                  onCopy={(e: { preventDefault: () => void }) => preventCopyPaste(e)}
                                  onPaste={(e: { preventDefault: () => void }) => preventCopyPaste(e)}
                                />
                              </Field>
                            );
                          }}
                        </FinalFormField>
                        <StyledButton
                          marginTop="32px"
                          marginBottom="16px"
                          // NOTE: The button here is only visually disabled as autofill doesn't
                          // actually let React know about field values until the form is
                          // attempted to be submitted. This allows the user to still click the
                          // button when React isn't aware that the form has already been filled.
                          visuallyDisabled={!formProps.values.vodafoneNumber || !formProps.values.code}
                          disabled={(!formProps.values.vodafoneNumber || !formProps.values.code) && ctaDisable}
                          isLoading={formProps.submitting}
                          variant="primary"
                          fullWidth={true}
                          type="submit"
                          data-testid="verify-pin"
                        >
                          {journey === ExpressJourneySlug.PHONE_AND_PLAN
                            ? pageData.accountPinInfo.pinCtaLabel
                            : pageData.accountPinInfo.pinCtaLabel}
                        </StyledButton>
                        <PinForgotLink type="button" onClick={showForgotPinModal}>
                          {pageData.accountPinInfo.forgotYourPinLinkLabel}
                        </PinForgotLink>
                      </form>
                    )}
                  </Form>
                </NoPinLockContent>
              )}
              <PinFooterBackButton type="button" onClick={() => router.back()}>
                {pageData.accountPinInfo.backTextLinkLabel}
              </PinFooterBackButton>
            </PinContainerContent>
          </PinContainer>
        </GridCol>
      </Grid>
    </Background>
  );
};

export default PinTemplate;
