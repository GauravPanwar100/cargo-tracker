export { default } from './Pin';
