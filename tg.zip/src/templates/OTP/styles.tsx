import styled from 'styled-components';
import Button from '@src/components/core/Button';
import {
  MixinProperty,
  buttonReset,
  fontLineHeightSize,
  marginBottomMixin,
  marginTopMixin,
  media,
} from '@src/lib/util/mixins';
import chevronSvg from '@src/assets/svg/chevron-left.svg';
import quoteUrl from '@src/lib/util/quoteUrl';
import RichText from '@src/components/core/RichText';
import React from 'react';

interface ErrorImgProps {
  marginTop?: MixinProperty<React.CSSProperties['marginTop']>;
  marginBottom?: MixinProperty<React.CSSProperties['marginBottom']>;
}

export const ErrorImg = styled.img<ErrorImgProps>`
  display: block;
  margin: 0 auto;
  height: 48px;
  width: 48px;
  ${(p) => marginTopMixin(p.marginTop)}
  ${(p) => marginBottomMixin(p.marginBottom)}

  ${media.m`
    height: 64px;
    width: 64px;
  `}
`;

const AEM_ASSET_BACKGROUND_IMG = 'https://www.vodafone.com.au/images/generic/authentication-background.jpg';

export const Background = styled.div`
  width: 100%;
  background: ${(p) => p.theme.colors.aluminium};

  ${media.m`
    height: 100%;
    min-height: 100vh;
    padding: 0 84px;
    background-image: url('${AEM_ASSET_BACKGROUND_IMG}');
    background-position: top center;
    background-size: cover;
  `}
`;

export const OtpContainer = styled.div`
  margin: 32px 0;
  color: ${(p) => p.theme.colors.darkGrey};

  ${media.m`
    margin: 56px 0;
    width: 480px;
    border-radius: 6px;
    background-color: ${(p) => p.theme.colors.white};
    box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.16);
  `}

  ${media.l`
    margin: 96px 0;
  `}
`;

export const OtpContainerHeader = styled.div`
  display: none;
  padding: 16px;
  border-bottom: 1px solid ${(p) => p.theme.colors.silver};

  ${media.m`
    display: block;
  `}
`;

export const OtpContainerContent = styled.div`
  padding: 0 16px;

  ${media.m`
    min-height: 500px;
    padding: 24px 60px 32px;
  `}
`;

interface StyledRichTextProps {
  marginTop?: MixinProperty<React.CSSProperties['marginTop']>;
  marginBottom?: MixinProperty<React.CSSProperties['marginBottom']>;
}

export const StyledRichText = styled(RichText)<StyledRichTextProps>`
  ${(p) => marginTopMixin(p.marginTop)}
  ${(p) => marginBottomMixin(p.marginBottom)}

  p:last-child {
    margin-bottom: 0;
  }
`;

export const OtpHeaderBackButton = styled.button`
  ${buttonReset}
  display: inline-grid;
  grid-auto-flow: column;
  align-items: center;
  color: ${(p) => p.theme.colors.darkGrey};
  cursor: pointer;
  ${fontLineHeightSize('baseLarge')}

  &::before {
    content: '';
    display: inline-block;
    height: 32px;
    width: 32px;
    margin-right: 5px;
    background-image: url(${quoteUrl(chevronSvg)});
  }
`;

export const OtpFooterBackButton = styled.button`
  ${buttonReset}
  display: block;
  margin: 32px auto 0;
  text-align: center;
  text-decoration: underline;
  cursor: pointer;

  ${media.m`
    display: none;
  `}
`;

interface StyledButtonProps {
  marginTop?: MixinProperty<React.CSSProperties['marginTop']>;
  marginBottom?: MixinProperty<React.CSSProperties['marginBottom']>;
}

export const StyledButton = styled(Button)<StyledButtonProps>`
  ${(p) => marginTopMixin(p.marginTop)}
  ${(p) => marginBottomMixin(p.marginBottom)}
`;
