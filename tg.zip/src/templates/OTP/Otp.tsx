import { find, get, noop } from 'lodash';
import { useRouter } from 'next/router';
import React, { useEffect } from 'react';
import { Field as FinalFormField, Form, FormProps } from 'react-final-form';
import { useTheme } from 'styled-components';
import { ReactComponent as ConsultantMidSvg } from '@src/assets/svg/consultant-mid.svg';
import { ReactComponent as WarningMidSvg } from '@src/assets/svg/warning-mid.svg';
import { useSasData } from '@src/lib/context/sas-provider';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import Logger from '@src/lib/logger/logger';
import { NBSP, enrichTextWithAttributes } from '@src/lib/util/formatUtils';
import Alert from '@src/components/core/Alert';
import Field from '@src/components/core/Field';
import { Grid, GridCol } from '@src/components/core/Grid';
import IconWrapper from '@src/components/core/IconWrapper';
import Input from '@src/components/core/Input';
import QuickLink from '@src/components/core/QuickLink';
import RichText from '@src/components/core/RichText';
import Section from '@src/components/core/Section';
import SeoHead from '@src/components/vfe/SeoHead';
import Text from '@src/components/core/Text';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import { getApiClient } from '@src/lib/api';
import { Alert as AlertType, OtpPageResponse } from '@src/lib/api/types';
import { ExpressJourneySlug } from '@src/lib/constants/express';
import useRecaptcha, { RecaptchaError } from '@src/lib/hooks/use-recaptcha';
import { SessionStorageClient } from '@src/lib/storage';
import { NullableRecord } from '@src/lib/types';
import { normaliseOtp, onKeyPressPreventNonNumericKey, validateOtp } from '@src/lib/util/otp';
import { assertNever } from '@src/lib/util/typescript';
import { Flag, IAM_OMEGA_ENVIRONMENT, useFeatureFlag } from '@src/lib/context/feature-flags';
import { safeRouterPush } from '@src/lib/util/router';
import { stripQueryFromPath } from '@src/lib/util/url';
import { trackEvent, useTrackPage } from '@src/lib/tracking';
import { QueryKey } from '@src/lib/util/query';
import CI360 from '@src/lib/ci360/ci360';
import useSasProductList from '@src/lib/ci360/use-sas-product-list';
import {
  Background,
  ErrorImg,
  OtpContainer,
  OtpContainerContent,
  OtpContainerHeader,
  OtpFooterBackButton,
  OtpHeaderBackButton,
  StyledButton,
  StyledRichText,
} from './styles';

export interface OtpTemplateProps {
  journey: ExpressJourneySlug;
  pageData: OtpPageResponse;
}

enum ResendInfo {
  NONE,
  SUCCESS,
  ERROR_TECH,
  ERROR_RECAPTCHA,
  ERROR_RECAPTCHA_LOW_SCORE,
  ERROR_TOO_MANY_ATTEMPTS,
}

type FormValues = { code: string };

const OtpTemplate: React.FC<OtpTemplateProps> = ({ journey, pageData }) => {
  const theme = useTheme();

  const alertNSEUMaintenance = find(pageData.alerts, { alertId: 'eu-maintenance', alertType: 'negativeScenario' })!;
  const alertNSRecaptchaNotLoaded = find(pageData.alerts, {
    alertId: 'recaptcha-not-loaded',
    alertType: 'negativeScenario',
  })!;
  const alertNSRecaptchaLowScore = find(pageData.alerts, {
    alertId: 'landing-recaptcha-failed',
    alertType: 'negativeScenario',
  })!;
  const alertInlineRecaptchaScoreFailed = find(pageData.alerts, {
    alertId: 'otp-recaptcha-failed',
    alertType: 'inlineError',
  })!;
  const alertInlineOtpLimitExceeded = find(pageData.alerts, {
    alertId: 'otp-limit-exceeded',
    alertType: 'inlineError',
  })!;
  const alertNSOtpRequestApiError = find(pageData.alerts, {
    alertId: 'otp-request-api-fail',
    alertType: 'negativeScenario',
  })!;
  const alertOtpValidationApiError = find(pageData.alerts, { alertId: 'otp-validation-api-fail' })!;
  const alertSuccess = find(pageData.alerts, { alertId: 'otp-success' })!;
  const alertOtpInvalid = find(pageData.alerts, { alertId: 'otp-invalid' })!;
  const alertOtpCodeNotReceived = find(pageData.alerts, { alertId: 'otp-code-not-received' })!;

  const ApiClient = getApiClient();
  const { items } = useSasProductList();
  const router = useRouter();
  const path = stripQueryFromPath(router.asPath);

  useTrackPage({
    pageTitle: pageData.pageHeaderData.seoTitle || '',
    path,
    nudgeReferrer: (router.query[QueryKey.NUDGE_REFERRER] || '').toString(),
  });

  const { creatives } = useSasData();
  // TODO: Should we fail if encryptedMsisdn is not provided?
  const encryptedMsisdn = creatives?.express?.journey?.msisdn_enc?.value;

  const iamMaintenanceModeFlag = useFeatureFlag(Flag.IAM_MAINTENANCE_MODE, IAM_OMEGA_ENVIRONMENT);

  const { executeAndReturnToken } = useRecaptcha();

  const [otpDetails, requestOtp] = useImperativeData(ApiClient.requestOtp);
  const [recaptchaError, setRecaptchaError] = React.useState<unknown>();

  useEffect(() => {
    if (
      !encryptedMsisdn ||
      !iamMaintenanceModeFlag.isSuccess ||
      iamMaintenanceModeFlag.data ||
      otpDetails.isInitialised
    )
      return noop;

    const controller = new AbortController();
    CI360.sendCustomPageTrack({
      pageTitle: pageData.pageHeaderData.seoTitle || '',
      path,
      activeMsisdn: encryptedMsisdn || null,
      accountType: otpDetails.data?.isComplexAccount ? 'Complex' : 'Simple',
      serviceType: null,
    });
    CI360.sendSasContextEventTrack(creatives, items);

    executeAndReturnToken().then(
      (recaptchaToken) => {
        if (controller.signal.aborted) return;

        requestOtp({ encryptedMsisdn, recaptchaToken });
      },
      (error) => {
        if (controller.signal.aborted) return;

        Logger.error(
          typeof error?.message === 'string' ? error.message : 'An error occurred when executing Recaptcha',
          {
            ucode: '7d6b864',
            error,
          },
        );
        setRecaptchaError(error);
      },
    );

    return controller.abort.bind(controller);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    encryptedMsisdn,
    executeAndReturnToken,
    iamMaintenanceModeFlag,
    otpDetails,
    pageData.pageHeaderData.seoTitle,
    path,
    requestOtp,
  ]);

  const onSubmit: FormProps<FormValues>['onSubmit'] = async (values) => {
    trackEvent({
      pageEventAttributeOne: 'OTP-verify',
      pageEventType: 'button',
      pageEventValue: 'click',
    });
    try {
      const recaptchaToken = await executeAndReturnToken();
      const response = await ApiClient.verifyOtp({
        encryptedMsisdn: encryptedMsisdn!,
        recaptchaToken,
        verificationCode: values.code,
      });

      if (response.id_token) {
        const dateTime = new Date();
        const expireInMinute = 20;
        const expireTime = dateTime.setMinutes(dateTime.getMinutes() + expireInMinute);

        SessionStorageClient.setEUPasswordlessTokenExpiry(String(expireTime));
        SessionStorageClient.setExpressUpgradePasswordlessToken(response.id_token);

        await safeRouterPush(
          `/express/${journey === ExpressJourneySlug.PHONE_AND_PLAN ? 'checkout' : 'confirm'}?${new URLSearchParams([
            ['journey', journey],
          ])}`,
        );
      }

      return {
        // TODO: This is not a low score error
        code: alertInlineRecaptchaScoreFailed.alertText,
      };
    } catch (error) {
      Logger.error('OTP Validation error', {
        error,
        ucode: 'f11b229',
      });

      if (error instanceof RecaptchaError) {
        return {
          // TODO: This is not a low score error
          code: alertInlineRecaptchaScoreFailed.alertText,
        };
      }

      const status = ((error as NullableRecord)?.response as NullableRecord)?.status as number | undefined;
      const service = get(error, ['response', 'data', 'error', 'service']) as string | undefined;
      const type = get(error, ['response', 'data', 'error', 'type']) as string | undefined;

      if (status === 429) {
        return {
          code: alertInlineOtpLimitExceeded.alertText,
        };
      }

      if (service === 'recaptcha' && type === 'invalid') {
        return {
          // TODO: This is not a low score error
          code: alertInlineRecaptchaScoreFailed.alertText,
        };
      }

      if (service === 'recaptcha' && type === 'low_score') {
        return {
          code: alertInlineRecaptchaScoreFailed.alertText,
        };
      }

      if (service === 'auth0' && status === 403) {
        return {
          code: alertOtpInvalid.alertText,
        };
      }

      return {
        code: alertOtpValidationApiError.alertText,
      };
    }
  };

  const [resendInfo, setResendInfo] = React.useState<ResendInfo>(ResendInfo.NONE);
  const [resendLoading, setResendLoading] = React.useState(false);

  const onResend = async () => {
    setResendLoading(true);
    setResendInfo(ResendInfo.NONE);

    try {
      const recaptchaToken = await executeAndReturnToken();
      await ApiClient.requestOtp({ encryptedMsisdn: encryptedMsisdn!, recaptchaToken });
      setResendInfo(ResendInfo.SUCCESS);
    } catch (error) {
      Logger.error('OTP resend error', {
        error,
        ucode: 'dc6db40',
      });

      if (error instanceof RecaptchaError) {
        setResendInfo(ResendInfo.ERROR_RECAPTCHA);
        return;
      }

      const status = get(error, ['response', 'status']) as number | undefined;
      if (status === 429) {
        setResendInfo(ResendInfo.ERROR_TOO_MANY_ATTEMPTS);
        return;
      }

      const service = get(error, ['response', 'data', 'error', 'service']) as string | undefined;
      const type = get(error, ['response', 'data', 'error', 'type']) as string | undefined;

      if (service === 'recaptcha' && type === 'low_score') {
        setResendInfo(ResendInfo.ERROR_RECAPTCHA_LOW_SCORE);
        return;
      }

      if (service === 'recaptcha') {
        setResendInfo(ResendInfo.ERROR_RECAPTCHA);
      }

      setResendInfo(ResendInfo.ERROR_TECH);
    } finally {
      setResendLoading(false);
    }
  };

  const head = (
    <SeoHead
      title={pageData.pageHeaderData.seoTitle}
      aemMetaTags={pageData.pageHeaderData.metaTags}
      structuredData={pageData.pageHeaderData.seoData}
    />
  );

  if (otpDetails.error || recaptchaError) {
    const alert: AlertType = (() => {
      if (recaptchaError) return alertNSRecaptchaNotLoaded;
      const errorService: string | undefined = get(otpDetails.error, ['response', 'data', 'error', 'service']);
      const errorType: string | undefined = get(otpDetails.error, ['response', 'data', 'error', 'type']);
      if (errorService === 'recaptcha' && errorType === 'invalid') return alertNSRecaptchaNotLoaded;
      if (errorService === 'recaptcha' && errorType === 'low_score') return alertNSRecaptchaLowScore;
      return alertNSOtpRequestApiError;
    })();
    return (
      <Section backgroundColorValue={theme.colors.aluminium} spacingTop={{ xs: 's', m: 'xxl' }}>
        {head}
        <Grid>
          <GridCol>
            {alert.alertIcon ? (
              <ErrorImg src={alert.alertIcon} alt="" />
            ) : (
              <IconWrapper
                svg={WarningMidSvg}
                marginLeft="auto"
                marginRight="auto"
                height={{ xs: '48px', m: '64px' }}
                width={{ xs: '48px', m: '64px' }}
              />
            )}
            <Text
              as="h1"
              marginTop={{ xs: '32px', m: '42px' }}
              marginBottom={{ xs: '20px', m: '42px' }}
              textAlign="center"
            >
              {alert.alertTitle}
            </Text>
            <StyledRichText marginBottom={{ xs: '32px', m: '60px' }} textAlign="center">
              {alert.alertText}
            </StyledRichText>
            <Grid>
              <GridCol gridColSpan={{ xs: 12, m: 6 }}>
                <QuickLink
                  icon={ConsultantMidSvg}
                  title="Need help?"
                  description="Call us from 8am-8pm AEST."
                  href="tel:1555"
                />
              </GridCol>
              <GridCol gridColSpan={{ xs: 12, m: 6 }}>
                <QuickLink
                  icon={ConsultantMidSvg}
                  title="Book a call with us"
                  description="Request a call back from our team."
                  onClick={(e) => {
                    e.preventDefault();
                    // TODO: Confirm queue name
                    window.OpenCallbackForm('express-upgrade', false);
                  }}
                />
              </GridCol>
            </Grid>
            <OtpFooterBackButton type="button" onClick={() => router.back()}>
              {pageData.content.backTextLink}
            </OtpFooterBackButton>
          </GridCol>
        </Grid>
      </Section>
    );
  }

  // Whilst we're still loading the IAM maintenance flag, or if there is not OTP details and we're not in maintenance mode
  if (!iamMaintenanceModeFlag.isSuccess || (!otpDetails.data && !iamMaintenanceModeFlag.data)) {
    return (
      <>
        {head}
        <SpinnerSection />
      </>
    );
  }

  return (
    <Background>
      {head}
      <Grid>
        <GridCol>
          <OtpContainer>
            <OtpContainerHeader>
              <OtpHeaderBackButton
                type="button"
                onClick={() => router.back()}
                id="eu-back-otp"
                data-testid="eu-back-otp"
              >
                {pageData.content.backTextLink}
              </OtpHeaderBackButton>
            </OtpContainerHeader>
            <OtpContainerContent>
              {iamMaintenanceModeFlag.data && (
                <ErrorImg
                  src={alertNSEUMaintenance.alertIcon}
                  alt=""
                  marginTop={{ m: '16px' }}
                  marginBottom={{ xs: '32px', m: '40px' }}
                />
              )}
              <Text
                as="h2"
                fontFamily="light"
                textAlign="center"
                fontSize={{ xs: 'heading2Mobile', m: 'heading2Tablet' }}
                marginLeft={{ xs: 0, m: '-24px' }}
                marginRight={{ xs: 0, m: '-24px' }}
                role="heading"
              >
                {otpDetails.data ? pageData.pageHeaderData.defaultTitle : alertNSEUMaintenance.alertTitle}
              </Text>
              <StyledRichText
                marginTop={{ xs: '20px', m: '24px' }}
                marginBottom={{ xs: '20px', m: '24px' }}
                textAlign={iamMaintenanceModeFlag.data ? { xs: 'center', m: 'left' } : 'left'}
                role="note"
              >
                {/* eslint-disable-next-line no-nested-ternary */}
                {otpDetails.data
                  ? otpDetails.data.isComplexAccount
                    ? enrichTextWithAttributes(pageData.pageHeaderData.defaultDescription, {
                        MSISDN_CONTACT: otpDetails.data.msisdnContact.replaceAll(' ', NBSP),
                      })
                    : pageData.pageHeaderData.altDescription
                  : alertNSEUMaintenance.alertText}
              </StyledRichText>
              {otpDetails.data && (
                <Form<FormValues> initialValues={{ code: '' }} onSubmit={onSubmit}>
                  {(formProps) => (
                    <form onSubmit={formProps.handleSubmit}>
                      <FinalFormField<string> name="code" validate={validateOtp} parse={normaliseOtp}>
                        {(fieldProps) => {
                          const err: string =
                            // When the field is not dirty (unchanged) since last submit and there was a submit error
                            (!fieldProps.meta.dirtySinceLastSubmit && fieldProps.meta.submitError) ||
                            // When the field is not active (focused), but has been focused
                            (!fieldProps.meta.active && fieldProps.meta.touched && fieldProps.meta.error) ||
                            // When the field is active (focused), the submit failed and the field is not dirty
                            (fieldProps.meta.active &&
                              fieldProps.meta.submitFailed &&
                              !fieldProps.meta.dirtySinceLastSubmit &&
                              fieldProps.meta.error) ||
                            '';
                          return (
                            <Field
                              id="one-time-code"
                              label={pageData.content.enterOtpCodeLabelText}
                              error={err && <StyledRichText color="inherit">{err}</StyledRichText>}
                            >
                              <Input
                                {...fieldProps.input}
                                name="otp"
                                id="one-time-code"
                                type="text"
                                inputMode="numeric"
                                autoComplete="one-time-code"
                                minLength={6}
                                maxLength={6}
                                pattern="[0-9]*"
                                required={true}
                                invalid={!!err}
                                data-testid="one-time-code"
                                onKeyPress={onKeyPressPreventNonNumericKey}
                              />
                            </Field>
                          );
                        }}
                      </FinalFormField>
                      <StyledButton
                        marginTop="32px"
                        marginBottom="32px"
                        // NOTE: The button here is only visually disabled as autofill doesn't
                        // actually let React know about field values until the form is
                        // attempted to be submitted. This allows the user to still click the
                        // button when React isn't aware that the form has already been filled.
                        visuallyDisabled={!formProps.values.code}
                        disabled={resendLoading}
                        isLoading={formProps.submitting}
                        variant="primary"
                        fullWidth={true}
                        type="submit"
                        id="eu-verify-otp"
                        data-testid="eu-verify-otp"
                      >
                        {journey === ExpressJourneySlug.PHONE_AND_PLAN
                          ? pageData.content.otpCtaLabel
                          : pageData.content.otpAlternateCtaLabel}
                      </StyledButton>
                      <StyledRichText
                        pTagMarginBottom={{ xs: '20px', m: '24px' }}
                        id="eu-cant-receive-otp"
                        data-testid="eu-cant-receive-otp"
                      >
                        {pageData.content.description}
                      </StyledRichText>
                      <StyledButton
                        marginTop={{ xs: '32px', m: '24px' }}
                        variant="secondary"
                        fullWidth={true}
                        disabled={formProps.submitting}
                        isLoading={resendLoading}
                        onClick={onResend}
                        type="button"
                        id="eu-resent-otp"
                        data-testid="eu-resent-otp"
                      >
                        {pageData.content.newCodeCtaLabel}
                      </StyledButton>
                      {(() => {
                        switch (resendInfo) {
                          case ResendInfo.NONE:
                            return null;
                          case ResendInfo.SUCCESS:
                            return (
                              <Alert
                                variant="success"
                                inline={true}
                                fullWidth={true}
                                fullHeight={true}
                                marginTop="32px"
                              >
                                <RichText>{alertSuccess.alertText}</RichText>
                              </Alert>
                            );
                          case ResendInfo.ERROR_TOO_MANY_ATTEMPTS:
                            return (
                              <Alert variant="error" inline={true} fullWidth={true} fullHeight={true} marginTop="32px">
                                <RichText>{alertInlineOtpLimitExceeded.alertText}</RichText>
                              </Alert>
                            );
                          case ResendInfo.ERROR_RECAPTCHA_LOW_SCORE:
                            return (
                              <Alert variant="error" inline={true} fullWidth={true} fullHeight={true} marginTop="32px">
                                <RichText>{alertInlineRecaptchaScoreFailed.alertText}</RichText>
                              </Alert>
                            );
                          case ResendInfo.ERROR_RECAPTCHA:
                          case ResendInfo.ERROR_TECH:
                            return (
                              <Alert variant="error" inline={true} fullWidth={true} fullHeight={true} marginTop="32px">
                                <RichText>{alertOtpCodeNotReceived.alertText}</RichText>
                              </Alert>
                            );
                          default:
                            return assertNever(resendInfo);
                        }
                      })()}
                    </form>
                  )}
                </Form>
              )}
              <OtpFooterBackButton type="button" onClick={() => router.back()}>
                {pageData.content.backTextLink}
              </OtpFooterBackButton>
            </OtpContainerContent>
          </OtpContainer>
        </GridCol>
      </Grid>
    </Background>
  );
};

export default OtpTemplate;
