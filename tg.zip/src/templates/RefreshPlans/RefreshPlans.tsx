import {
  BnsOffer,
  PageContentSections,
  PlanBasketRequestItem,
  RefreshPlansPageAndExperienceFragmentsResponse,
} from '@src/lib/api/types';
import React, { useCallback } from 'react';
import FaqTermsConditionsSection from '@src/templates/common/FaqTermsAndConditionsSection';
import UspSection from '@src/components/vfe/UspSection';
import { ThemeProvider } from 'styled-components';
import { lightTheme, midTheme } from '@src/lib/theme';
import PlanListingSection from '@src/templates/Plans/PlanListingSection';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import { formatBundleForTracking, trackEvent, useTrackPage } from '@src/lib/tracking';
import { useStickyCart } from '@src/lib/context/sticky-cart';
import { shouldGoToExtrasPage } from '@src/lib/util/journey';
import { Flag, RedirectFlag, useFeatureFlag, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { removeExtrasItemTypeFromStickyCart } from '@src/templates/Plans/utils';
import { GoToNextStepHandler } from '@src/components/core/Journey/JourneyStep/JourneyStep';
import { BnsOfferProvider } from '@src/lib/context/bns-offer-data';
import { PayIn4ContentProvider } from '@src/lib/context/pay-in-four-content-provider';
import BackButton from '@src/components/core/BackButton/BackButton';
import { isReOrderingContent } from '@src/lib/util/plan';
import { MaintenancePage } from '@src/lib/util/error';
import ExperienceFragment from '@src/components/vfe/ExperienceFragment';
import { stripQueryFromPath } from '@src/lib/util/url';
import { QueryKey } from '@src/lib/util/query';
import { useRouter } from 'next/router';
import SeoHead from '@src/components/vfe/SeoHead';

export interface RefreshPlansTemplateProps {
  bnsOffer?: BnsOffer | null;
  disableStickyCart?: boolean;
  goToNextStep: GoToNextStepHandler;
  isLoading?: boolean;
  pageData: RefreshPlansPageAndExperienceFragmentsResponse;
  redirectFlag: RedirectFlag;
  step: number;
}

const RefreshPlansTemplate: React.FC<RefreshPlansTemplateProps> = ({
  bnsOffer,
  disableStickyCart = false,
  goToNextStep,
  isLoading,
  pageData,
  redirectFlag,
  step,
}) => {
  const { asPath, query } = useRouter();
  const path = stripQueryFromPath(asPath);
  const { experienceFragments, pageHeaderData } = pageData;
  const topBannerData = experienceFragments?.find((fragment) => fragment.fragmentId === 'student-offer-banner');
  const isSimSelectionDisabledWithFeatureFlag = useFeatureFlag(Flag.DISABLE_SIM_SELECTION);
  const [{ history }, stickyCartDispatch] = useStickyCart();

  const originalStickyCart = history[step]?.original;

  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });

  useTrackPage({
    pageTitle: pageHeaderData.seoTitle || '',
    path,
    nudgeReferrer: (query[QueryKey.NUDGE_REFERRER] || '').toString(),
  });

  const addPlanToStickyCart = useCallback(
    async (item: PlanBasketRequestItem) => {
      const updatedStickyCart = [...(originalStickyCart ?? []), item];
      trackEvent({
        pageEventType: 'button',
        pageEventValue: 'click',
        // TODO: Get ctaLabel again
        pageEventAttributeOne: '',
        stickyCart: [formatBundleForTracking(updatedStickyCart)],
      });

      const hasExtras = shouldGoToExtrasPage(item, isSimSelectionDisabledWithFeatureFlag?.data);

      if (!disableStickyCart) {
        if (!hasExtras) {
          removeExtrasItemTypeFromStickyCart({ items: updatedStickyCart, stickyCartDispatch });
        }
        stickyCartDispatch({
          type: 'SET_STICKY_CART',
          payload: { items: updatedStickyCart, history: { historyType: 'configured', step } },
        });
      }

      await goToNextStep({
        items: updatedStickyCart,
        hasExtras,
        isSimSelectionDisabledWithFeatureFlag,
      });
    },
    [
      disableStickyCart,
      goToNextStep,
      originalStickyCart,
      step,
      stickyCartDispatch,
      isSimSelectionDisabledWithFeatureFlag,
    ],
  );

  const [onCtaClickState, onCtaClick] = useImperativeData(addPlanToStickyCart);

  return (
    <>
      <SeoHead
        title={pageHeaderData.seoTitle}
        aemMetaTags={pageHeaderData.metaTags}
        structuredData={pageHeaderData.seoData}
      />
      <main>
        {experienceFragments && !!experienceFragments.length && <ExperienceFragment {...experienceFragments[0]} />}
        <BnsOfferProvider offers={bnsOffer}>
          <PayIn4ContentProvider
            payIn4Content={{
              showPayIn4PromoContent: pageData.showPayIn4PromoContent || false,
              payIn4PromoContentThreshold: pageData.payIn4PromoContentThreshold || 0,
            }}
          >
            <BackButton href="/mobile/sim-only-phone-plans">Back to SIM Only Plans</BackButton>
            {topBannerData && <ExperienceFragment {...topBannerData} />}
            <ThemeProvider theme={midTheme}>
              <PlanListingSection
                catalogCode={pageData.catalogCode}
                dataTestId="plan-listing"
                id="plans"
                isLoading={isLoading}
                onCtaClick={onCtaClick}
                onCtaClickState={onCtaClickState}
                plans={[pageData.plan]}
                spacingTop={
                  !isReOrderingContent(pageData.catalogCode, PageContentSections.USPS)
                    ? null
                    : { xs: 'm', m: 'm', l: 'xxl' }
                }
              />
            </ThemeProvider>
            <ThemeProvider theme={lightTheme}>
              {pageData.usps && (
                <UspSection
                  usps={pageData.usps}
                  backgroundColor={pageData.iconTilesBgColor || lightTheme.variants.backgroundColor}
                  iconSizeVariant={pageData.iconTilesVariant || 'smalls'}
                  title="Why choose Vodafone"
                  description=""
                />
              )}
              <FaqTermsConditionsSection
                faqs={pageData.faqs}
                termsAndConditions={pageData.termsAndConditions}
                spacingTop={{ xs: 's', m: 'm', l: 'xxl' }}
              />
            </ThemeProvider>
          </PayIn4ContentProvider>
        </BnsOfferProvider>
      </main>
    </>
  );
};

export default RefreshPlansTemplate;
