import React from 'react';
import { render } from 'test-utils';
import RefreshPlansTemplate, { RefreshPlansTemplateProps } from '@src/templates/RefreshPlans/RefreshPlans';
import { CartItemType, RefreshPlansPageResponse } from '@src/lib/api/types';
import RouterMock from '@src/test/RouterMock';
import { StickyCartProvider, StickyCartState, defaultStickyCartState } from '@src/lib/context/sticky-cart';
import { mockMobilePhoneAndPlanBasketRequestItems } from '@src/lib/mock-data';
import { Flag } from '@src/lib/context/feature-flags';
import { AuthenticationProvider } from '@src/lib/context/authentication';
import { Auth0ClientOptions } from '@auth0/auth0-spa-js';
import mockPageResponse from '../mock-data/alwaysOnPageResponse.json';

const mockAuth0Options = {} as Auth0ClientOptions;

jest.mock('@src/lib/context/customer-data', () => ({
  useCustomerData: jest.fn().mockReturnValue({
    upgradePlanEligibility: [{}],
  }),
}));

jest.mock('@src/lib/tracking', () => ({
  __esModule: true,
  useTrackPage: jest.fn(),
}));

jest.mock('@src/lib/context/feature-flags', () => ({
  __esModule: true,
  useFeatureFlag: () => ({ data: false }),
  useRedirectFeatureFlag: jest.fn(),
  Flag: {
    DISABLE_SIM_SELECTION: '',
  },
}));

const defaultProps: RefreshPlansTemplateProps = {
  pageData: mockPageResponse as unknown as RefreshPlansPageResponse,
  step: 0,
  goToNextStep: jest.fn(),
  redirectFlag: {
    businessRedirect: Flag.DISABLE_PLANS_ALWAYS_ON_SIMO_BUSINESS,
    operationalRedirect: Flag.DISABLE_PLANS_ALWAYS_ON_SIMO_OPERATIONAL,
  },
};

const cartState: StickyCartState = {
  ...defaultStickyCartState,
  itemTypes: [CartItemType.DEVICE, CartItemType.PLAN, CartItemType.EXTRA],
  stickyCart: mockMobilePhoneAndPlanBasketRequestItems,
};

const setup = () => {
  const props = { ...defaultProps };
  return render(
    <RouterMock>
      <StickyCartProvider defaultState={cartState}>
        <AuthenticationProvider options={mockAuth0Options}>
          <RefreshPlansTemplate {...props} />
        </AuthenticationProvider>
      </StickyCartProvider>
    </RouterMock>,
  );
};

describe('RefreshPlansTemplate', () => {
  it('only renders 1 plan card', () => {
    const { queryByTestId, getAllByText } = setup();
    const plansWrapper = queryByTestId('plan-listing')?.querySelector('.slick-track') as HTMLElement;
    expect(getAllByText(/small sim only plan/i)).not.toBeNull();
    expect(plansWrapper.children).toHaveLength(1);
  });
});
