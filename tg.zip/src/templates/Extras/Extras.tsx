/* eslint-disable no-console */
/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-nested-ternary */
import { kebabCase } from 'lodash';
import React, { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { ThemeProvider } from 'styled-components';
import Alert from '@src/components/core/Alert';
import BackButton from '@src/components/core/BackButton';
import { Grid, GridCol } from '@src/components/core/Grid';
import RichText from '@src/components/core/RichText';
import Section from '@src/components/core/Section';
import TermsAndConditions from '@src/components/vfe/TermsAndConditions';
import { getApiClient } from '@src/lib/api';
import {
  AddToBasketParams,
  Basket,
  BasketRequestItem,
  ChildBasketRequestItem,
  Extra,
  ExtrasPageResponse,
} from '@src/lib/api/types';
import { useCustomerData } from '@src/lib/context/customer-data';
import { useSetModal } from '@src/lib/context/modal';
import { useCommitStickyCartToHistoryOnMount, useStickyCart } from '@src/lib/context/sticky-cart';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import useServiceType from '@src/lib/hooks/use-service-type';
import { LocalStorageClient } from '@src/lib/storage';
import { midTheme } from '@src/lib/theme';
import { formatBundleForTracking, trackEvent, useTrackPage } from '@src/lib/tracking';
import {
  accumulateExtrasFromCartItems,
  canSelectESimOrPSim,
  extraToChildBasketRequestItem,
  getRafUpdateRequestParams,
  hasESimCapableDeviceBasketItem,
  hasESimOnlyDeviceBasketItem,
  hasPostpaidSimoPlanBasketItem,
  isAddonSwapAndGO,
  isPlanBasketItem,
  isPostpaidSimoPlanBasketItem,
  setRafItemUpdated,
} from '@src/lib/util/cart';
import { useBasketState } from '@src/lib/context/basket';
import { safeRouterPush } from '@src/lib/util/router';
import { decoratePathWithQueries, stripQueryFromPath } from '@src/lib/util/url';
import { isServiceOfType } from '@src/lib/util/customer';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { SimProductCode, planWithSim } from '@src/lib/util/sim-selection';
import { isUpgradesRoute } from '@src/lib/util/journey';
import TitleSection from '@src/templates/common/TitleSection';
import { Flag, RedirectFlag, useFeatureFlag, useRedirectFeatureFlag } from '@src/lib/context/feature-flags';
import { MaintenancePage } from '@src/lib/util/error';
import { QueryKey } from '@src/lib/util/query';
import StudentOfferBanner from '@src/components/vfe/StudentOfferBanner/StudentOfferBanner';
import ExtrasListingSection from './ExtrasListingSection';
import SimSelectionSection from './SimSelectionSection';

interface ExtrasTemplateProps {
  backAs?: string;
  backHref?: string;
  backOnClick?: React.MouseEventHandler;
  backLabel: string;
  pageData: ExtrasPageResponse;
  redirectFlag: RedirectFlag;
  step: number;
  isStudentOfferValidated?: boolean;
}

const ExtrasTemplate: React.FC<ExtrasTemplateProps> = ({
  backAs,
  backHref,
  backLabel,
  backOnClick,
  pageData: {
    addOn,
    pageHeaderData,
    swapAndGo,
    termsAndConditions: { termsConditionsDesc },
  },
  redirectFlag,
  step,
  isStudentOfferValidated,
}) => {
  const [serviceType] = useServiceType();
  const { asPath, query } = useRouter();
  const path = stripQueryFromPath(asPath);

  // Redirect the customer to a maintenance page if the feature flag returns true
  useRedirectFeatureFlag({ flag: redirectFlag.businessRedirect, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: redirectFlag.operationalRedirect, redirect: MaintenancePage.OPERATIONAL });
  const {
    currentServiceData: [currentServiceState],
    customerBundleAndSaveCount,
  } = useCustomerData();

  const [addToBasketState, addToBasket] = useImperativeData<AddToBasketParams, Basket>(getApiClient().addToBasket);
  const { setBasket, getBasketState } = useBasketState();

  const setGlobalModal = useSetModal();
  const [{ isCtaLoading, stickyCart }, stickyCartDispatch] = useStickyCart();
  useCommitStickyCartToHistoryOnMount({ step, stickyCart });

  const swapAndGoDisabled = useFeatureFlag(Flag.DISABLE_SWAP_AND_GO);
  const isSimSelectionDisabledWithFeatureFlag = useFeatureFlag(Flag.DISABLE_SIM_SELECTION);
  const isSimSelectionEnabled = canSelectESimOrPSim(stickyCart, isSimSelectionDisabledWithFeatureFlag);

  const simoProduct = hasPostpaidSimoPlanBasketItem(stickyCart);
  const eSimOnlyProduct = hasESimOnlyDeviceBasketItem(stickyCart);
  const eSimCapableProduct = hasESimCapableDeviceBasketItem(stickyCart);

  // Initialise defaultSimSelection to an arbitrary value
  const defaultSimSelection = eSimOnlyProduct ? SimProductCode.ESIM : SimProductCode.PSIM;

  // Add state to simSelection and setSimSelection with initial value of defaultSimSelection
  const [simSelection, setSimSelection] = useState(() => {
    return defaultSimSelection;
  });

  const [continueToCartInitiated, setContinueToCartInitiated] = useState<boolean>(false);

  const newPageHeaderData = {
    ...pageHeaderData,
    defaultTitle:
      simoProduct && pageHeaderData.simOnlyTitleOverride
        ? pageHeaderData.simOnlyTitleOverride
        : eSimCapableProduct && pageHeaderData.esimDeviceTitleOverride
        ? pageHeaderData.esimDeviceTitleOverride
        : pageHeaderData.title,
    defaultDescription:
      simoProduct && pageHeaderData.simOnlyDescriptionOverride
        ? pageHeaderData.simOnlyDescriptionOverride
        : eSimCapableProduct && pageHeaderData.esimDeviceDescriptionOverride
        ? pageHeaderData.esimDeviceDescriptionOverride
        : pageHeaderData.description,
  };

  useEffect(() => {
    stickyCartDispatch({
      type: 'SET_STICKY_CART',
      payload: {
        items: (previous) =>
          previous?.map((item) => {
            if (!isPlanBasketItem(item)) return item;

            return planWithSim(item, simSelection);
          }),
        history: { historyType: 'configured', step },
      },
    });
  }, [simSelection, step, stickyCartDispatch]);

  const selectedExtraCodes = React.useMemo<string[]>(
    () => accumulateExtrasFromCartItems(stickyCart).map((e) => e.productCode),
    [stickyCart],
  );

  // If the Sticky Cart CTA request gets an error, set the error state to the Sticky Cart
  // Return a cleanup function so that if the user goes to a previous page then the error state for
  // this page will not pollute it
  useEffect(() => {
    const isError = !!addToBasketState.error;
    const isStickyCartCtaLoading = addToBasketState.isLoading;

    if (isStickyCartCtaLoading) {
      stickyCartDispatch({ type: 'SET_IS_ERROR', payload: false });
      stickyCartDispatch({ type: 'SET_IS_CTA_LOADING', payload: isStickyCartCtaLoading });
    }

    if (isError) {
      stickyCartDispatch({ type: 'SET_IS_ERROR', payload: isError });
      stickyCartDispatch({ type: 'SET_IS_CTA_LOADING', payload: false });
    }

    return () => {
      stickyCartDispatch({
        type: 'SET_IS_ERROR',
        payload: false,
      });
    };
  }, [addToBasketState, stickyCartDispatch]);

  useTrackPage({
    pageTitle: pageHeaderData.seoTitle || '',
    path,
    nudgeReferrer: (query[QueryKey.NUDGE_REFERRER] || '').toString(),
  });

  const onStickyCartCtaClick = useCallback(async () => {
    if (!stickyCart) {
      return;
    }

    const extraOffer = query[QueryKey.EXTRA] ? query[QueryKey.EXTRA]?.toString() : '';
    const response = await addToBasket({
      items: stickyCart,
      additionalBnsCount: customerBundleAndSaveCount,
      raf: getBasketState.data ? getRafUpdateRequestParams(stickyCart, getBasketState.data) : undefined,
      extraOffer,
    });

    if (!response) return;
    LocalStorageClient.setBasketId(response.basketId);

    // If raf has been applied to the item thats just being added, notify the cart page to show the RAF MSO Alert
    if (response.raf) {
      const { appliedCatalogCode, isValid } = response.raf;
      if (appliedCatalogCode && getBasketState.data?.raf?.appliedCatalogCode && isValid) {
        setRafItemUpdated(appliedCatalogCode, getBasketState.data.raf.appliedCatalogCode);
      }
    }

    setBasket(response);
    safeRouterPush(decoratePathWithQueries('/cart', [QueryKey.NUDGE_REFERRER]));
  }, [addToBasket, customerBundleAndSaveCount, setBasket, stickyCart, query, getBasketState.data]);

  // Fallback: Continue to cart straight away if there is no eSIM/pSIM selection and there are no extras
  useEffect(() => {
    if (continueToCartInitiated) {
      return;
    }

    const shouldContinueToCart =
      !isSimSelectionEnabled && !addOn.extras.length && (swapAndGoDisabled.data || !swapAndGo.extras.length);
    if (shouldContinueToCart) {
      onStickyCartCtaClick();
      setContinueToCartInitiated(true);
    }
  }, [
    addOn.extras.length,
    swapAndGo.extras.length,
    swapAndGoDisabled.data,
    isSimSelectionEnabled,
    onStickyCartCtaClick,
    continueToCartInitiated,
  ]);

  // When this template loads, set our Sticky Cart CTA handler so that the continue to cart
  // button shows in the sticky cart
  useEffect(() => {
    // if getBasket State is available, wait till it is fully loaded.
    if (
      getBasketState.isInitialised === false ||
      (getBasketState.isInitialised === true && getBasketState.isLoading === false)
    ) {
      stickyCartDispatch({
        type: 'SET_ON_CTA_CLICK',
        payload: {
          ctaLabel: 'Continue to cart',
          onCtaClick: onStickyCartCtaClick,
        },
      });
    }

    return () => {
      stickyCartDispatch({
        type: 'SET_ON_CTA_CLICK',
        payload: undefined,
      });
    };
  }, [onStickyCartCtaClick, stickyCartDispatch, getBasketState.isInitialised, getBasketState.isLoading]);

  const updateStickyCartExtra = useCallback(
    (
      extra: Extra | ChildBasketRequestItem,
      { ctaLabel, parent, remove }: { ctaLabel?: string; parent?: BasketRequestItem; remove?: boolean } = {},
    ) => {
      if (!stickyCart) return;

      stickyCartDispatch({
        type: 'SET_STICKY_CART',
        payload: {
          // WARNING: calling getCart with this cartContextKey will not contain the latest extras
          // NOTE: We're using the updater function variant here because `remove` needs to always
          // have access to the latest version of the cart state, otherwise updates might be missed
          items: (prevStickyCart) => [
            ...(prevStickyCart ?? []).reduce((acc: BasketRequestItem[], basketItem: BasketRequestItem) => {
              let updatedChildProducts = basketItem.childProducts || [];

              // Only publish the trackEvent if there has been a change to the childProducts,
              // otherwise we get 1 event per item in the cart (device and plan), when we
              // only want 1 for what has actually changed
              let publishTrackEvent = false;
              if (remove) {
                let childProductRemoved = false;
                updatedChildProducts = updatedChildProducts.filter((child) => {
                  if (child.productCode !== extra.productCode) {
                    childProductRemoved = true;
                    return true;
                  }
                  return false;
                });
                publishTrackEvent = !childProductRemoved;
              } else if (basketItem.productCode === parent?.productCode) {
                updatedChildProducts.push(extraToChildBasketRequestItem(extra as Extra));
                publishTrackEvent = true;
              }

              const updatedStickyCart = [...acc, { ...basketItem, childProducts: updatedChildProducts }];

              if (ctaLabel && publishTrackEvent) {
                trackEvent({
                  pageEventType: 'button',
                  pageEventValue: 'click',
                  pageEventAttributeOne: remove ? 'remove' : 'add',
                  pageEventAttributeTwo: kebabCase(
                    remove ? (extra as ChildBasketRequestItem).productName : (extra as Extra).name,
                  ),
                  stickyCart: [formatBundleForTracking(updatedStickyCart)],
                });
              }

              return updatedStickyCart;
            }, []),
          ],
          history: { historyType: 'configured', step },
        },
      });
    },
    [step, stickyCart, stickyCartDispatch],
  );

  const removeSwapAndGoExtraFromCart = useCallback(() => {
    const swapAndGoCodes = swapAndGo.extras.map((i) => i.productCode);
    const prevSelectedSwapAndGo = accumulateExtrasFromCartItems(stickyCart || []).find((child) =>
      swapAndGoCodes.includes(child.productCode),
    );

    if (!prevSelectedSwapAndGo) return;

    updateStickyCartExtra(prevSelectedSwapAndGo, { remove: true });
  }, [swapAndGo.extras, updateStickyCartExtra, stickyCart]);

  const onCardCtaClick = useCallback(
    (extra: Extra, ctaLabel: string) => {
      const parent = stickyCart?.find((cartItem) => cartItem.productCode === extra.parentProductCode);
      const extraInCart = parent?.childProducts?.find((child) => child.productCode === extra.productCode);

      if (extraInCart) {
        updateStickyCartExtra(extraInCart, { ctaLabel, parent, remove: true });
        return;
      }

      if (isAddonSwapAndGO(extra)) {
        const onModalConfirmClick = () => {
          setGlobalModal('');
          removeSwapAndGoExtraFromCart();
          const newParent = stickyCart?.find((item) => item.productCode === extra.parentProductCode);
          // NOTE: This should never occur in practice as we would only ever be adding swapAndGo
          // that is a child of the current cart items
          if (!newParent) return;
          updateStickyCartExtra(extra, { ctaLabel, parent: newParent });
        };

        setGlobalModal({
          id: parent?.productSubType
            ? `${extra.productCode}-${parent.productSubType.toLowerCase()}`
            : extra.productCode,
          isOpen: true,
          onClose: () => setGlobalModal(''),
          cancelCtaAction: () => setGlobalModal(''),
          confirmCtaAction: onModalConfirmClick,
        });

        return; // stop the cta click from adding the swapAndGo to the cart.
      }

      updateStickyCartExtra(extra, { ctaLabel, parent });
    },
    [removeSwapAndGoExtraFromCart, setGlobalModal, stickyCart, updateStickyCartExtra],
  );

  const alert =
    isServiceOfType(serviceType, ServiceTypeValue.Upgrade) &&
    currentServiceState.data?.extras.some(({ displayProductType }) =>
      ['AddOn', 'Insurance', 'Device Protection'].includes(displayProductType!),
    )
      ? pageHeaderData.alerts?.find(({ alertId }) => alertId === 'extras-upgrades')
      : undefined;

  const getSimSelectionType = () => {
    if (isUpgradesRoute(path)) {
      return 'simSelectionUpgrades';
    }

    return stickyCart!.some((basketItem) => isPostpaidSimoPlanBasketItem(basketItem))
      ? 'simSelectionSIMO'
      : 'simSelectionDevice';
  };

  const getStickyCartDeviceType = () =>
    stickyCart?.find(
      (cartItem) =>
        cartItem.itemType.toLocaleLowerCase() === 'device' || cartItem.itemType.toLocaleLowerCase() === 'wearable',
    )?.productSubType;

  const getStickyCartManufacturer = () =>
    stickyCart?.find(
      (cartItem) =>
        cartItem.itemType.toLocaleLowerCase() === 'device' || cartItem.itemType.toLocaleLowerCase() === 'wearable',
    )?.manufacturer;

  const simSelectionType = getSimSelectionType();

  return (
    <main>
      {isStudentOfferValidated && <StudentOfferBanner />}
      <TitleSection pageHeaderData={newPageHeaderData} data-testid="extras-page-title" />
      <BackButton as={backAs} data-testid="extras-page-back-button" href={backHref} onClick={backOnClick}>
        {backLabel}
      </BackButton>
      <ThemeProvider theme={midTheme}>
        {isSimSelectionEnabled && (
          <SimSelectionSection
            content={pageHeaderData[simSelectionType]}
            disabled={isCtaLoading || isSimSelectionDisabledWithFeatureFlag.isLoading}
            spacingTop={{ xs: 's', m: 'xxl' }}
            spacingBottom={null}
            simSelection={simSelection}
            setSimSelection={setSimSelection}
            eSimOnlyFlag={eSimOnlyProduct}
          />
        )}
        {alert && (
          <Section data-testid="extras-section-alerts" spacingTop={{ xs: 's', m: 'xxl' }} spacingBottom={null}>
            <Grid>
              <GridCol gridColStart={{ xs: 1, m: 3 }} gridColSpan={{ xs: 12, m: 8 }}>
                <Alert inline={true} variant="info">
                  <RichText>{alert.alertText}</RichText>
                </Alert>
              </GridCol>
            </Grid>
          </Section>
        )}
        {!!swapAndGo.extras.length && !swapAndGoDisabled.data && (
          <Section data-testid="extras-section-insurance" spacingTop={{ xs: 's', m: 'xxl' }} spacingBottom={null}>
            <Grid>
              <GridCol>
                <ExtrasListingSection
                  deviceType={getStickyCartDeviceType()}
                  disabled={isCtaLoading}
                  extrasContent={swapAndGo}
                  id="extras-insurance" // TODO: rename this when updating the cypress tests
                  manufacturer={getStickyCartManufacturer()}
                  onCtaClick={onCardCtaClick}
                  selectedExtraProductCodes={selectedExtraCodes}
                />
              </GridCol>
            </Grid>
          </Section>
        )}
        {!!addOn.extras.length && (
          <Section data-testid="extras-section-addons" spacingTop={{ xs: 's', m: 'xxl' }} spacingBottom={null}>
            <Grid>
              <GridCol>
                <ExtrasListingSection
                  disabled={isCtaLoading}
                  extrasContent={addOn}
                  id="extras-addons"
                  onCtaClick={onCardCtaClick}
                  selectedExtraProductCodes={selectedExtraCodes}
                />
              </GridCol>
            </Grid>
          </Section>
        )}
        <Section spacingTop={{ xs: 's', m: 'xxl' }}>
          <Grid>
            <GridCol>
              <TermsAndConditions data-testid="extras-section-terms-and-conditions" description={termsConditionsDesc} />
            </GridCol>
          </Grid>
        </Section>
      </ThemeProvider>
    </main>
  );
};

export default ExtrasTemplate;
