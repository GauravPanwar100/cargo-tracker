import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ThemeProvider } from 'styled-components';
import Nudge from '@src/components/vfe/Nudge';
import Section from '@src/components/core/Section';
import InlineBanner from '@src/components/core/InlineBanner';
import { AddressChecker1SQ } from '@src/components/vfe/AddressChecker';
import { HighSpeedPlanTiers } from '@src/components/vfe/AddressChecker/utils';
import {
  AddressCheckerResponse,
  HomeWirelessPageResponse,
  HomeWirelessPlan,
  HomeWirelessPlansResponse,
  NbnPageResponse,
  NbnPlan,
  NbnPlansResponse,
} from '@src/lib/api/types';
import UspSection from '@src/components/vfe/UspSection';
import { midTheme } from '@src/lib/theme';
import { useRouter } from 'next/router';
import { use1SQDetailsFn } from '@src/lib/util/home-internet';
import NewCustomerSplitter from '@src/templates/OneSQ/NewCustomerSplitter';
import FilterChips from '@src/templates/OneSQ/FilterChips/FilterChips';
import PlansCarousel from '@src/templates/OneSQ/PlansCarousel/PlansCarousel';
import useQueryLogin from '@src/lib/hooks/use-query-login';
import { stripQueryFromPath } from '@src/lib/util/url';
import { AddressDetails } from '@src/lib/storage/types';
import { Flag, useFeatureFlag } from '@src/lib/context/feature-flags';
import StickyCart from '@src/components/vfe/StickyCart';
import FaqTermsAndConditions from '@src/templates/OneSQ/FaqTermsAndConditions';
import { BottomBannerWrapper, StyledPlanSummary, UspSectionWrapper } from '@src/templates/OneSQ/OneSQ.styles';
import PlanSummary from '@src/templates/OneSQ/PlanSummary/PlanSummary';
import ModemTemplate from '@src/templates/OneSQ/Modem';
import { fromQueriesToHomeInternetTypes } from '@src/lib/util/queryMapping';
import { getFilteredPlans, homeInternetTypesArray } from '@src/lib/util/oneSQ';
import TopBanner from '@src/templates/OneSQ/TopBanner';
import { AddressStatusWithServiceQualification } from '@src/components/vfe/AddressChecker/AddressChecker.interfaces';
import { useTrackPage } from '@src/lib/tracking';
import { useAuthentication } from '@src/lib/context/authentication';
import TitleSection from '@src/templates/common/TitleSection/TitleSection';
import NbnInformationSection from '@src/templates/Nbn/NbnInformationSection';

export interface OneSQTemplateProps {
  pageData4g: HomeWirelessPageResponse;
  pageData5g: HomeWirelessPageResponse;
  pageDataNbn: NbnPageResponse;
  addressFields4g: AddressCheckerResponse;
  addressFields5g: AddressCheckerResponse;
  addressFieldsNbn: AddressCheckerResponse;
  plansResponse4g: HomeWirelessPlansResponse;
  plansResponse5g: HomeWirelessPlansResponse;
  plansResponseNbn: NbnPlansResponse;
  extraOffer?: string;
}

const OneSQTemplate: React.FC<OneSQTemplateProps> = ({
  pageData4g,
  pageData5g,
  pageDataNbn,
  addressFields4g,
  addressFields5g,
  addressFieldsNbn,
  plansResponse4g,
  plansResponse5g,
  plansResponseNbn,
}) => {
  useQueryLogin();
  const { asPath } = useRouter();
  const path = stripQueryFromPath(asPath);
  const { isAuthenticated } = useAuthentication();
  const isStuckCartDisabled = useFeatureFlag(Flag.DISABLE_STUCK_CART)?.data;
  const stuckCartRef = useRef<HTMLDivElement>(null);
  const byoAlertRef = useRef<HTMLDivElement>(null);
  const plansRef = useRef<HTMLDivElement>(null);

  const step1Ref = useRef<HTMLDivElement>(null);
  const step1InputRef = useRef<HTMLInputElement>(null);
  const [addressDetails, setAddressDetails] = useState<AddressDetails | null>(null);
  const [eligibleSpeedTiers, setEligibleSpeed] = useState<HighSpeedPlanTiers[]>([]);
  const store1SQDetails = use1SQDetailsFn(setAddressDetails, setEligibleSpeed, path);
  const [isExistingCustomer, setIsExistingCustomer] = useState<boolean>(true);
  const [modemTitle, setModemTitle] = useState<string>('');
  const [chips, setChips] = useState(homeInternetTypesArray);
  const [chipValue, setChipValue] = useState<string[]>([]);

  const filteredPlans = getFilteredPlans(plansResponse4g, plansResponse5g, plansResponseNbn, chips, chipValue);
  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [selectedPlan, setSelectedPlan] = useState<NbnPlan | HomeWirelessPlan | undefined>(
    filteredPlans.filter(({ planId }) => planId === selectedPlanId)[0],
  );
  const [planIncludesModem, setPlanIncludesModem] = useState<boolean>(true);

  const { inlineBanners, experienceFragments } = plansResponse5g!.planListing;
  const bottomBannerData = inlineBanners?.find((banner) => banner.bannerId === 'bottom-banner');

  const updateAddressStatus = useMemo(
    () => (addressStatus: AddressStatusWithServiceQualification) => {
      const { continueNbnJourney, continue4gFhwJourney, continue5gFhwJourney } = addressStatus;
      if (
        continue4gFhwJourney === !chips[0].disabled &&
        continue5gFhwJourney === !chips[1].disabled &&
        continueNbnJourney === !chips[2].disabled
      )
        return;
      const allFalse = !continueNbnJourney && !continue4gFhwJourney && !continue5gFhwJourney;
      const newChips = [
        {
          ...chips[0],
          disabled: allFalse ? false : !continue4gFhwJourney,
        },
        {
          ...chips[1],
          disabled: allFalse ? false : !continue5gFhwJourney,
        },
        {
          ...chips[2],
          disabled: allFalse ? false : !continueNbnJourney,
        },
      ];
      setChips(newChips);
    },
    [chips],
  );

  useTrackPage({
    pageTitle: pageData5g?.fhwTitleContent?.seoTitle || '',
    path,
    nudgeReferrer: '',
  });

  useEffect(() => {
    if (isAuthenticated) {
      if (!isExistingCustomer) setIsExistingCustomer(true);
    }
  }, [isAuthenticated, isExistingCustomer]);

  useEffect(() => {
    const types = [asPath.split('#')[1]];
    const newChipValue = fromQueriesToHomeInternetTypes(types);
    if (JSON.stringify(chipValue.sort()) !== JSON.stringify(newChipValue.sort())) setChipValue(newChipValue);
  }, [chipValue, asPath]);

  if (modemTitle)
    return (
      <ModemTemplate
        title={modemTitle}
        setModemTitle={setModemTitle}
        planIncludesModem={planIncludesModem}
        isStuckCartDisabled={isStuckCartDisabled}
        stuckCartRef={stuckCartRef}
        byoAlertRef={byoAlertRef}
        plansRef={plansRef}
        addressDetails={addressDetails}
        addressFieldsNbn={addressFieldsNbn}
        selectedPlan={selectedPlan}
        selectedPlanId={selectedPlanId}
        isExistingCustomer={isExistingCustomer}
        pageDataNbn={pageDataNbn}
        pageData4g={pageData4g}
        pageData5g={pageData5g}
        plansResponseNbn={plansResponseNbn}
        setSelectedPlanId={setSelectedPlanId}
        setSelectedPlan={setSelectedPlan}
        setPlanIncludesModem={setPlanIncludesModem}
      />
    );

  return (
    <ThemeProvider theme={midTheme}>
      <Nudge variant="fhw" />
      <TitleSection pageHeaderData={pageData5g.fhwTitleContent} showTitleSection={false} />
      <TopBanner experienceFragments={experienceFragments} />
      <Section ref={step1Ref} spacingTop={{ xs: 'xxs', m: 'xxs' }}>
        <AddressChecker1SQ
          updateAddressStatus={updateAddressStatus}
          addressFields4g={addressFields4g}
          addressFields5g={addressFields5g}
          addressFieldsNbn={addressFieldsNbn}
          pageData={pageData5g}
          id="addressChecker1SQ"
          storeHomeInternetDetails={store1SQDetails}
          step1InputRef={step1InputRef}
          pathName={path}
        />
      </Section>
      <NewCustomerSplitter
        isExistingCustomer={isExistingCustomer}
        setIsExistingCustomer={setIsExistingCustomer}
        selectedPlanId={selectedPlanId}
      />
      <FilterChips
        filteredPlansCount={filteredPlans.length}
        chips={chips}
        chipValue={chipValue}
        setChipValue={setChipValue}
      />
      <div ref={plansRef}>
        <PlansCarousel
          addressFields4g={addressFields4g}
          addressFields5g={addressFields5g}
          addressFieldsNbn={addressFieldsNbn}
          selectedPlanId={selectedPlanId}
          plans={filteredPlans}
          plansResponse4g={plansResponse4g}
          plansResponse5g={plansResponse5g}
          plansResponseNbn={plansResponseNbn}
          hideOnPlanCardCIS={plansResponseNbn ? plansResponseNbn.planListing.hideOnPlanCardCIS : false}
          hideOnPlanCardKFS={plansResponseNbn ? plansResponseNbn.planListing.hideOnPlanCardKFS : false}
          showPayIn4PromoContent={plansResponseNbn ? plansResponseNbn.planListing.showPayIn4PromoContent : false}
          payIn4PromoContentThreshold={plansResponseNbn ? plansResponseNbn.planListing.payIn4PromoContentThreshold : 0}
          needsAddressCheck={!addressDetails}
          eligibleHighSpeedTiers={eligibleSpeedTiers}
          isExistingCustomer={isExistingCustomer}
          setModemTitle={setModemTitle}
          pageData4g={pageData4g}
          pageData5g={pageData5g}
          pageDataNbn={pageDataNbn}
          step1Ref={step1Ref}
          stuckCartRef={stuckCartRef}
          step1InputRef={step1InputRef}
          addressDetails={addressDetails}
          setSelectedPlanId={setSelectedPlanId}
          setSelectedPlan={setSelectedPlan}
          setPlanIncludesModem={setPlanIncludesModem}
          selectedPlan={selectedPlan}
        />
      </div>
      {!isStuckCartDisabled && (
        <StyledPlanSummary ref={stuckCartRef}>
          <PlanSummary />
        </StyledPlanSummary>
      )}
      {isStuckCartDisabled && <StickyCart />}
      <UspSectionWrapper>
        <UspSection
          {...plansResponseNbn?.planListing}
          usps={plansResponseNbn?.planListing.usps || []}
          iconSizeVariant={plansResponseNbn?.planListing.iconTilesVariant || 'biggie'}
          backgroundColor={
            plansResponseNbn?.planListing.iconTilesBgColor || midTheme.variants.backgroundColor || 'white'
          }
          isUpgradeJourney={true}
        />
      </UspSectionWrapper>
      {bottomBannerData && (
        <BottomBannerWrapper>
          <InlineBanner bannerData={{ ...bottomBannerData, customBgColor: '#333333' }} />
        </BottomBannerWrapper>
      )}
      <NbnInformationSection content={pageDataNbn.nbnInfoContent} />
      <FaqTermsAndConditions
        faqArray={[pageDataNbn.nbnFaqContent, pageData4g.fhwFaqContent, pageData5g.fhwFaqContent]}
        tncArray={[pageDataNbn.nbnTncsContent, pageData4g.fhwTncsContent, pageData5g.fhwTncsContent]}
      />
    </ThemeProvider>
  );
};

export default OneSQTemplate;
