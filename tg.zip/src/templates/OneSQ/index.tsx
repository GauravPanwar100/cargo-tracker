export { default } from './OneSQ';
