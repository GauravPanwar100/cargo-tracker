import { media } from '@src/lib/util/mixins';
import styled from 'styled-components';

export const AddressCheckerSection = styled.div`
  display: grid;
  background: white;
  border-radius: 5px;
  padding: 16px 8px 8px 16px;
  margin-top: -40px;
  position: relative;

  ${media.m`
    padding-left: 24px;  
  `}

  ${media.l` 
    margin-top: -60px;
    padding-top: 40px 0 8px 40px;
  `}
`;

export const StyledPlanSummary = styled.div`
  [data-testid='stuck-cart-item']:nth-child(2) {
    div {
      div {
        div {
          border-bottom: 0px;
          padding-bottom: 9px;
        }
      }
    }
  }
  [data-testid='stuck-cart-item']:nth-child(3) {
    display: none;
  }
`;
export const AddressCheckerHeading = styled.div`
  h2 {
    font-size: 24px;
    line-height: 30px;
    padding: 18px 0;

    ${media.m`
      font-size: 40px;
      line-height: 48px; 
    `}
  }

  display: none;
  ${media.m`
    display: block;
  `}
`;

export const AddressCheckerHeadingMobile = styled(AddressCheckerHeading)`
  display: block;

  ${media.m`
    display: none;
  `}

  font-size: 28px;
  line-height: 36px;
  margin-bottom: 12px;
`;

export const UspSectionWrapper = styled.div`
  h2 {
    font-size: 24px;
    line-height: 30px;

    ${media.m`
      font-size: 34px;
      line-height: 40px; 
    `}

    ${media.l`
      font-size: 40px;
      line-height: 46px; 
    `}
  }

  .feature-text-item-title {
    ${media.m` 
      line-height: 24px;
      font-size: 18px;
    `}
    ${media.l` 
      line-height: 24px;
      font-size: 18px;
    `}
  }
`;

export const BottomBannerWrapper = styled.div`
  .inline-banner-description-text {
    p {
      font-size: 16px;

      ${media.m` 
        font-size: 20px;
        line-height: 28px;
      `}

      ${media.l` 
        font-size: 20px;
        line-height: 23px;
      `}
    }
  }

  button {
    ${media.m`  
      line-height: 20px;
    `}
  }
`;
