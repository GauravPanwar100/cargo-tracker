/* eslint-disable no-console */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ThemeProvider } from 'styled-components';
import { sleep } from '@src/common/js/sleep';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import Text from '@src/components/core/Text';
import CartCard from '@src/components/vfe/CartCard';
import CartSplitter from '@src/components/vfe/CartSplitter';
import TotalCostCard from '@src/components/vfe/TotalCostCard';
import {
  AddToBasketParams,
  Alert as AlertType,
  Basket,
  BasketParams,
  CartPageResponse,
  CartProductSubType,
  CartTradeInDeviceType,
  CatalogCode,
  CheckoutSplitterGroup,
  OnlinePromoContentParams,
  RafAction,
  RafAppliedItem,
  RemovePackageFromBasketParams,
  TradeInDetailsContentResponse,
} from '@src/lib/api/types';
import { ADD_NON_SAMSUNG_ITEM_TO_CART, REMOVE_ITEMS_FROM_CART } from '@src/lib/constants/errors';
import { TRADEMARK } from '@src/lib/constants/html-entities';
import { useSetModal } from '@src/lib/context/modal';
import { DataFetchState } from '@src/lib/hooks/data-fetch-reducer';
import {
  accumulateMinCost,
  flattenBasket,
  getCheckoutSplitterContentList,
  getImageFromRelatedContent,
  getMatchingPackage,
  getMaximumNumberOfCartBundles,
  getRafEligiblePackagesInBasketList,
  getRemainingCatalogCodes,
  getUniqueCatalogCodes,
  hasSamsungPlanBasketItem,
  isBasketLoadingOrEmpty,
  isBasketWithExpiredItems,
  isCartEligibleWithSmartWatch,
  isCartWithSmartWatch,
  isChangingDataSharingGroup,
  isDeviceBasketItem,
  isFhwPlanBasketItem,
  isModemBasketItem,
  isModemDeviceBasketItem,
  isNbnPlanBasketItem,
  isPlanBasketItem,
  isPostpaidCartItem,
  isPostpaidSimoPlanBasketItem,
  isPrepaidComboPlusPlanBasketItem,
  isPrepaidPayAndGoPlanBasketItem,
  isPrepaidPlanCartItem,
  isSamsungPlanCartItem,
  isSmartWatchWithHomeInternet,
  isValidAddServicesSmartWatchCart,
  isValidNewAcqSmartWatchCart,
  isWearableDeviceBasketItem,
  wrapNbnPlanName,
  wrapPostpaidSimoPlanName,
  wrapPrepaidPlanName,
} from '@src/lib/util/cart';
import { continueShoppingRouteMap, formatMSISDN, isServiceOfType } from '@src/lib/util/customer';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { midTheme } from '@src/lib/theme';
import AnimatedAlert from '@src/components/core/Alert/AnimatedAlert';
import { AlertProps, AlertVariant } from '@src/components/core/Alert/Alert';
import Alert from '@src/components/core/Alert';
import RichText from '@src/components/core/RichText';
import { trackEvent, useImperativeTrackPage } from '@src/lib/tracking';
import AdditionalServicesTitleSection from '@src/templates/AdditionalServices/AdditionalServicesTitleSection';
import { useAuthentication } from '@src/lib/context/authentication';
import { useCustomerData } from '@src/lib/context/customer-data';
import useServiceType from '@src/lib/hooks/use-service-type';
import { LocalStorageClient, SessionStorageClient } from '@src/lib/storage';
import { QueryKey } from '@src/lib/util/query';
import { useClientQuery } from '@src/lib/util/router';
import useQueryLogin from '@src/lib/hooks/use-query-login';
import { Image } from '@src/lib/types';
import StudentOfferBanner from '@src/components/vfe/StudentOfferBanner/StudentOfferBanner';
import { checkStudentOfferApplicable } from '@src/lib/util/student';
import { Flag, useFeatureFlag } from '@src/lib/context/feature-flags';
import { usePromotionalCampaignsContent } from '@src/lib/context/global-content';
import { storeOptimizeContent } from '@src/lib/util/promotional-campaigns';
import { AlertContainer } from '@src/components/core/Alert/Alert.styles';
import ReferAFriendComponent from '@src/components/vfe/ReferAFriendComponent/ReferAFriendComponent';
import { getApiClient } from '@src/lib/api';
import ContinueToCheckoutSection from './ContinueToCheckoutSection';
import EmptyCartSection from './EmptyCartSection';

export interface CartTemplateProps {
  getBasketState: DataFetchState<BasketParams, Basket>;
  eligibilityError: Error | null;
  onContinueToCheckout: () => void;
  onRemoveFromBasket: (
    packageId: string,
    raf?: { action: RafAction; rafCatalogCodes: Array<CatalogCode>; rafCode: string },
    setRafAppliedItem?: () => void,
  ) => void;
  pageData: CartPageResponse;
  addToBasketState: DataFetchState<AddToBasketParams, Basket>;
  removePackageFromBasketState: DataFetchState<RemovePackageFromBasketParams, Basket>;
  packageIdToRemove: string | null;
  titleRef: React.RefObject<HTMLDivElement>;
  isHomeInternetASDEligible: boolean;
  applyDiscount?: boolean;
  disableAsdCopy: boolean;
  checkoutSplitterLogo?: string;
  checkoutSplitterGroups?: CheckoutSplitterGroup[];
  onlinePromoContentParams: OnlinePromoContentParams;
  rafEligiblePackagesInBasket?: { [packageId: string]: CatalogCode };
  updateRafAppliedItemInCart: (item: RafAppliedItem | null) => void;
  rafAppliedItemInCart: RafAppliedItem | null;
  showRafTransferredAlert: boolean;
  updateShowRafTransferredAlert: (action: boolean) => void;
}

const CartTemplate: React.FC<CartTemplateProps> = ({
  getBasketState,
  eligibilityError,
  addToBasketState,
  removePackageFromBasketState,
  onRemoveFromBasket,
  onContinueToCheckout,
  pageData,
  titleRef,
  packageIdToRemove,
  isHomeInternetASDEligible,
  applyDiscount = true,
  disableAsdCopy,
  checkoutSplitterLogo,
  checkoutSplitterGroups,
  onlinePromoContentParams,
  rafEligiblePackagesInBasket,
  updateRafAppliedItemInCart,
  rafAppliedItemInCart = null,
  showRafTransferredAlert = false,
  updateShowRafTransferredAlert,
}) => {
  useQueryLogin();
  const { alerts } = pageData;
  const [serviceType] = useServiceType();
  const [showCartSplitter, setShowCartSplitter] = useState(false);

  let content: React.ReactNode;
  const MAX_CART_BUNDLES = getMaximumNumberOfCartBundles(serviceType);
  const MAX_NBN_CART_BUNDLES = Number(process.env.CART_NBN_MAX_BUNDLES) || 1;
  const MAX_FHW_CART_BUNDLES = Number(process.env.CART_FHW_MAX_BUNDLES) || 1;
  const MAX_HOME_INTERNET_CART_BUNDLES = Number(process.env.CART_HOME_INTERNET_MAX_BUNDLES) || 1;
  const MAX_PREPAID_CART_BUNDLES = Number(process.env.CART_PREPAID_MAX_BUNDLES) || 2;
  const { isAuthenticated, logout, user } = useAuthentication();

  const continueShoppingUrl =
    isAuthenticated && !isServiceOfType(serviceType, ServiceTypeValue.NewAcquisition)
      ? continueShoppingRouteMap[serviceType as Exclude<ServiceTypeValue, ServiceTypeValue.NewAcquisition>]
      : pageData.cartSummary.continueCtaUrl;
  const {
    activeMsisdn,
    activeService,
    currentServiceData: [currentServiceData],
  } = useCustomerData();
  const upgradeCost = isServiceOfType(serviceType, ServiceTypeValue.Upgrade)
    ? currentServiceData.data?.phone?.balanceAmount
    : undefined;

  const bundles = getBasketState.data?.packages;

  // Get Raf splitter data from pageData
  const rafSplitterData = pageData.checkoutSplitterGroups.find((item) => item.id === 'refer-a-friend');

  // RAF alerts
  const rafTranferredAlert = alerts.find((alert) => alert.alertId === 'raf-removed-item');
  const rafMultipleItemsAlert = alerts.find((alert) => alert.alertId === 'raf-multiple-items');

  const numberNbnPlans = bundles?.filter((bundle) => bundle.items.find(isNbnPlanBasketItem)).length ?? 0;
  const numberFhwPlans = bundles?.filter((bundle) => bundle.items.find(isFhwPlanBasketItem)).length ?? 0;
  const numberPrepaidBundles = bundles?.filter((bundle) => bundle.items.find(isPrepaidPlanCartItem)).length ?? 0;
  const numberPostpaidBundles = bundles?.filter((bundle) => bundle.items.find(isPostpaidCartItem)).length ?? 0;
  const numberHomeInternetPlans = numberFhwPlans + numberNbnPlans;

  const query = useClientQuery();
  const trackPage = useImperativeTrackPage();
  const hasTracked = useRef(false);
  const cart = getBasketState.data;
  const disableStudentOffer = !!useFeatureFlag(Flag.STUDENT_OFFER).data;

  const [tradeInMessages, setTradeInMessages] = useState<TradeInDetailsContentResponse>();
  const getTradeInDetailsData = useCallback(async () => {
    const data = await getApiClient().fetchTradeInDetailsContent();
    setTradeInMessages(data);
  }, []);

  useEffect(() => {
    getTradeInDetailsData();
  }, [getTradeInDetailsData]);

  const isStudentOfferApplicable = useCallback(() => {
    if (disableStudentOffer) return false;
    return checkStudentOfferApplicable(cart);
  }, [cart, disableStudentOffer]);
  const promoCampaignsContent = usePromotionalCampaignsContent();
  useEffect(() => {
    if (promoCampaignsContent)
      storeOptimizeContent({
        catalogCode: onlinePromoContentParams.catalogCode,
        promoCampaignsContent,
        promoAvailability: onlinePromoContentParams.promoAvailability,
        optimizeContentKey: onlinePromoContentParams.optimizeContentKey,
      });
  }, [promoCampaignsContent, onlinePromoContentParams]);

  useEffect(() => {
    if (hasTracked.current || !query) return;
    hasTracked.current = true;

    trackPage({
      pageTitle: pageData.seoTitle || '',
      path: `${window.location.pathname}${window.location.search}${window.location.hash}`,
      nudgeReferrer: (query[QueryKey.NUDGE_REFERRER] || '').toString(),
    });
  }, [pageData.seoTitle, query, trackPage]);

  const { rafCartLabels } = pageData;
  const disableReferAFriend = useFeatureFlag(Flag.DISABLE_REFER_A_FRIEND).data;
  const [showRafHigherItemUpdateAlert, setShowRafHigherItemUpdateAlert] = useState(false);

  useEffect(() => {
    if (LocalStorageClient.getRafItemUpdated()) {
      setShowRafHigherItemUpdateAlert(true);
      LocalStorageClient.clearRafItemUpdated();
    }
  }, []);

  // Find package in Basket to apply RAF discount based on applied Catalog Code
  const applyRafToItem = useCallback(
    (rafAppliedCatalogCode: CatalogCode, discountAmount: number, rafCode: string) => {
      // get in form [[packageId, catalogCode], ...]
      const rafEligiblePackagesInBasketList = getRafEligiblePackagesInBasketList(rafEligiblePackagesInBasket);

      if (rafEligiblePackagesInBasket && Object.keys(rafEligiblePackagesInBasket).length > 0) {
        const rafPackage = getMatchingPackage(rafEligiblePackagesInBasketList, rafAppliedCatalogCode);

        if (rafPackage) {
          updateRafAppliedItemInCart({
            packageId: rafPackage,
            catalogCode: rafAppliedCatalogCode,
            discountAmount,
            rafCode,
          });
        }

        if (rafCartLabels?.rafOfferData) {
          // Add rafOfferData to session storage to be used in checkout POS
          SessionStorageClient.setRafOfferData(rafCartLabels.rafOfferData);
        }
      }
    },
    [rafCartLabels?.rafOfferData, rafEligiblePackagesInBasket, updateRafAppliedItemInCart],
  );

  // If the basket already has RAF details associated from a previous RAF application - display the RAF Cart state through getBasket call.
  const basketRafData = getBasketState.data?.raf;

  // if Basket contains RAF data - setRafAppliedItem at page load
  useEffect(() => {
    if (basketRafData && rafAppliedItemInCart === null) {
      const { discountAmount, appliedCatalogCode, rafCode } = basketRafData;
      if (discountAmount && appliedCatalogCode) applyRafToItem(appliedCatalogCode, discountAmount, rafCode);
      if (rafCartLabels?.rafOfferData) SessionStorageClient.setRafOfferData(rafCartLabels.rafOfferData);
      if (showRafTransferredAlert === true) updateShowRafTransferredAlert(false);
    }
  }, [
    applyRafToItem,
    basketRafData,
    rafAppliedItemInCart,
    rafAppliedItemInCart?.discountAmount,
    rafCartLabels?.rafOfferData,
    showRafTransferredAlert,
    updateShowRafTransferredAlert,
  ]);

  // if packageId is '' in rafAppliedItem after package is deleted, update it
  useEffect(() => {
    if (rafAppliedItemInCart === null) return;
    const { packageId, catalogCode, discountAmount, rafCode } = rafAppliedItemInCart;

    if (packageId === '' && catalogCode && discountAmount && rafCode) {
      applyRafToItem(catalogCode, discountAmount, rafCode);
      if (showRafHigherItemUpdateAlert === true) setShowRafHigherItemUpdateAlert(false);
    }
  }, [applyRafToItem, rafAppliedItemInCart, showRafHigherItemUpdateAlert]);

  const rafEligibleCatalogCodesInBasket =
    rafEligiblePackagesInBasket && Object.keys(rafEligiblePackagesInBasket)
      ? Object.values(rafEligiblePackagesInBasket)
      : [];

  const removeRafCredit = useCallback(() => {
    updateRafAppliedItemInCart(null);
    if (showRafTransferredAlert === true) updateShowRafTransferredAlert(false);
  }, [showRafTransferredAlert, updateRafAppliedItemInCart, updateShowRafTransferredAlert]);

  // RAF credit is only eligible on new acquisition non-prepaid orders in the SHOP journey.
  const cartIsRafEligible = !!(
    bundles &&
    serviceType === ServiceTypeValue.NewAcquisition &&
    rafEligiblePackagesInBasket &&
    Object.keys(rafEligiblePackagesInBasket).length > 0
  );

  const setModal = useSetModal();
  const onClickCheckout = useCallback(() => {
    if (isAuthenticated) {
      if (numberPrepaidBundles) {
        // You cannot purchase a prepaid service whilst logged in
        setModal({
          isOpen: true,
          id: 'additionalservicesprepaid',
          cancelCtaAction: () => setModal(''),
          confirmCtaAction: () => {
            const trackingComplete = new Promise(() => {
              // TODO: Figure out if Adobe Launch Data Layer actually has a way to add a callback for when tracking is complete,
              // and resolve the Promise accordingly. With Google Analytics, this is simple with a field called `hitCallback`.
              // For now, this Promise will never resolve, and the `sleep(250)` will resolve first.
              const items = flattenBasket(getBasketState.data?.packages ?? []);
              trackEvent({
                pageEventType: 'button',
                pageEventValue: 'click',
                pageEventAttributeOne: 'checkout',
                pageEventAttributeThree: 'continued-to-checkout',
                basketSize: getBasketState.data?.packages.length,
                catalogueNames: items?.map((item) => item.productName),
                transactionAmount: accumulateMinCost(items),
              });
            });
            LocalStorageClient.setCheckoutCart(getBasketState.data, pageData.cartSummary.disclaimer);
            if (!disableAsdCopy) {
              LocalStorageClient.setHomeInternetASDEligibility(isHomeInternetASDEligible);
            }
            // Try to wait for the tracking to complete before navigating away, but only wait a maximum of 250ms
            Promise.race([sleep(250), trackingComplete]).then(() => {
              logout({
                returnTo: `${window.location.origin}/cart?continue=true`,
              });
            });
          },
          onClose: () => setModal(''),
        });
      } else {
        // When logged in and not purchasing a prepaid service, continue straight to checkout
        onContinueToCheckout();
      }
    } else if (numberPrepaidBundles) {
      // Proceed straight to checkout if not logged in and purchasing a prepaid service
      onContinueToCheckout();
    } else if (isStudentOfferApplicable()) {
      // Proceed straight to checkout if student offer is applicable
      onContinueToCheckout();
    } else {
      // Show the cart splitter when not logged in and not purchasing a prepaid service
      LocalStorageClient.setCheckoutCart(getBasketState.data, pageData.cartSummary.disclaimer);
      if (!disableAsdCopy) {
        LocalStorageClient.setHomeInternetASDEligibility(isHomeInternetASDEligible);
      }
      setShowCartSplitter(true);
    }
  }, [
    disableAsdCopy,
    getBasketState.data,
    isAuthenticated,
    isHomeInternetASDEligible,
    logout,
    numberPrepaidBundles,
    onContinueToCheckout,
    pageData.cartSummary.disclaimer,
    setModal,
    isStudentOfferApplicable,
  ]);

  // if there is already a samsung plan in the cart, with other plan, error message will display
  const samsungPlanInCart = bundles?.some((bundle) => hasSamsungPlanBasketItem(bundle.items));
  let showSamsungAlert = false;
  if (samsungPlanInCart) {
    let extraSamsungPlanInCart = 0;
    const onlyHasSamsungPlanInCart = bundles?.every((bundle) => {
      if (hasSamsungPlanBasketItem(bundle.items)) extraSamsungPlanInCart += 1;
      return hasSamsungPlanBasketItem(bundle.items);
    });
    showSamsungAlert = extraSamsungPlanInCart > 1 || !onlyHasSamsungPlanInCart;
  }

  // If there is no data -- i.e. the request has never kicked off because we never had a basketId,
  // or if there is data but no cart items (seems unlikely to reach this point), or
  // if there is a request currently loading, show the EmptyCartSection
  // NB: This section can also handle loading state
  const isBasketLoading = isBasketLoadingOrEmpty(getBasketState, addToBasketState);
  const isBasketWithExpiredThings = isBasketWithExpiredItems(getBasketState?.data?.packages);

  if (isBasketLoading || isBasketWithExpiredThings) {
    const cartMessage = isBasketLoading
      ? pageData.cartSummary.emptyCartMessage
      : 'Unfortunately the items you added to cart are no longer available'; // TODO: Get field from AEM after MVP
    content = (
      <EmptyCartSection
        buttonHref={continueShoppingUrl}
        buttonLabel={pageData.cartSummary.continueCta}
        isLoading={getBasketState.isLoading || addToBasketState.isLoading}
        title={cartMessage}
      />
    );
  } else if (getBasketState.data && bundles) {
    const cartCards = bundles.map((bundle, index) => {
      const device = bundle.items.find(isDeviceBasketItem);
      const plan = bundle.items.find(isPlanBasketItem);
      const planHeroLabel = plan?.relatedContent?.heroLabel; // Getting the heroLabel from related content
      // Assigning the value of heroLabel only when samsung item is present in cart
      const cartHeroLabel = plan && isSamsungPlanCartItem(plan) ? planHeroLabel : '';
      const smartWatch = bundle.items.find(isWearableDeviceBasketItem);
      const mbbModem = bundle.items.find(isModemDeviceBasketItem);
      const deviceSubTitle = (): string => {
        if (smartWatch) return 'Smart watch';
        if (
          device?.productSubType === CartProductSubType.HANDSET ||
          device?.productSubType === CartProductSubType.PREPAID_HANDSET
        ) {
          return 'Phone and plan';
        }
        return 'Tablet and plan';
      };

      let image: Image | undefined;
      let title = '';
      let subtitle = '';
      let cartTradeInDevice: CartTradeInDeviceType | undefined;
      let cartCardAlert: AlertType | undefined;

      if (
        isServiceOfType(serviceType, ServiceTypeValue.Upgrade) &&
        isChangingDataSharingGroup(currentServiceData.data?.plan, plan)
      ) {
        cartCardAlert = pageData.alerts.find((alert) => alert.alertId === 'data-sharing');
      }

      if (device) {
        title = device.productName;
        subtitle = deviceSubTitle();
        cartTradeInDevice = device?.tradeInDeviceDetails;

        image = smartWatch ? getImageFromRelatedContent(smartWatch) : getImageFromRelatedContent(device);

        if (plan) {
          title += ` and ${plan.productName}`;
        }
      } else if (plan && isNbnPlanBasketItem(plan)) {
        const modem = bundle.items.find(isModemBasketItem);
        title = wrapNbnPlanName(plan);
        // with modem
        // TODO: Make sure this works
        if (plan.relatedContent?.withModem && modem) {
          title += ` and ${modem.productName}`;
        }

        subtitle = `nbn${TRADEMARK} plan`;
        image = getImageFromRelatedContent(plan);
      } else if (plan && isPostpaidSimoPlanBasketItem(plan)) {
        subtitle = 'SIM Only plan';
        title += wrapPostpaidSimoPlanName(plan);
        image = getImageFromRelatedContent(plan);
      } else if (plan && (isPrepaidPayAndGoPlanBasketItem(plan) || isPrepaidComboPlusPlanBasketItem(plan))) {
        subtitle = 'Prepaid plan';
        title += wrapPrepaidPlanName(plan);
        image = getImageFromRelatedContent(plan);
      } else if (plan && isFhwPlanBasketItem(plan)) {
        subtitle = 'Home Internet Plan';
        title = wrapNbnPlanName(plan);
        image = getImageFromRelatedContent(plan);
      } else if (mbbModem) {
        subtitle = 'Device and plan';
        title = mbbModem.productName;
        image = getImageFromRelatedContent(mbbModem);

        if (plan) {
          title += ` and ${plan.productName}`;
        }
      }

      const checkOnRemoveRafItem = (packageId: string) => {
        // If the package clicked to remove is a rafAppliedItem, prepare remaining RAF eligible catalog codes for request.
        // If there are no more eligible catalog codes in the basket, notify Salesforce that RAF should be deleted from the basket with the removal of this item.
        if (showRafTransferredAlert === true) updateShowRafTransferredAlert(false);
        if (showRafHigherItemUpdateAlert === true) setShowRafHigherItemUpdateAlert(false);
        const isRafAppliedItem = rafAppliedItemInCart?.packageId === packageId;
        if (isRafAppliedItem) {
          const remainingCatalogCodesinCart = getRemainingCatalogCodes(packageId, rafEligiblePackagesInBasket);
          const request = {
            action: (remainingCatalogCodesinCart.length === 0 ? 'Delete' : 'Update') as RafAction,
            rafCatalogCodes: getUniqueCatalogCodes(remainingCatalogCodesinCart),
            rafCode: rafAppliedItemInCart.rafCode,
            toBeValidated: true,
          };
          if (remainingCatalogCodesinCart.length === 0) {
            SessionStorageClient.cleanupRafAttemptCount();
            SessionStorageClient.cleanupRafOfferData();
          }
          onRemoveFromBasket(packageId, request);
        } else {
          onRemoveFromBasket(packageId);
        }
      };

      const isRafAppliedPackage = bundle.packageId === rafAppliedItemInCart?.packageId;

      return (
        // eslint-disable-next-line react/no-array-index-key
        <Section key={index} spacingTop={null} spacingBottom={{ xs: 's', m: 'l' }}>
          <Grid>
            <GridCol>
              <CartCard
                applyDiscount={applyDiscount}
                bundle={bundle}
                disabled={removePackageFromBasketState.isLoading}
                image={image}
                onRemoveFromBasket={checkOnRemoveRafItem}
                packageIdToRemove={packageIdToRemove}
                pageData={pageData}
                subtitle={subtitle}
                title={title}
                isBundleSaveApplied={!!getBasketState.data?.bundleAndSaveApplied}
                alert={cartCardAlert}
                heroLabel={cartHeroLabel}
                rafAppliedPackage={isRafAppliedPackage ? rafAppliedItemInCart : undefined}
                rafSuccessLabel={rafCartLabels?.cartLabel}
                rafOfferData={isRafAppliedPackage ? rafCartLabels?.rafOfferData : undefined}
                tradeInMessages={tradeInMessages}
                cartTradeInDevice={cartTradeInDevice}
              />
            </GridCol>
          </Grid>
        </Section>
      );
    });

    const generateCartAlert = (
      alertId?: string,
      { fullWidth = true, inline = true, title = '', variant = 'error', showInCenter = false }: AlertProps = {},
    ) => {
      const alert = pageData.alerts.find((a) => a.alertId === alertId);
      if (!alert) return null;

      return (
        <Section spacingTop={null} spacingBottom={{ xs: 'xs', m: 'l' }}>
          <Grid>
            <GridCol textAlign="center">
              <AnimatedAlert
                inline={inline}
                title={title}
                variant={variant}
                fullWidth={fullWidth}
                showInCenter={showInCenter}
              >
                <RichText>{alert.alertText}</RichText>
              </AnimatedAlert>
            </GridCol>
          </Grid>
        </Section>
      );
    };

    const numberOfBundles = Object.keys(bundles).length;
    const allPostpaidItemsInCart = numberPostpaidBundles === numberOfBundles;

    const cartValidationAlerts = [
      {
        applies:
          numberOfBundles > MAX_CART_BUNDLES &&
          isServiceOfType(serviceType, ServiceTypeValue.NewAcquisition) &&
          !allPostpaidItemsInCart,
        alertId: `limit-of-${MAX_CART_BUNDLES}`,
      },
      {
        applies:
          numberPostpaidBundles > MAX_CART_BUNDLES &&
          !isServiceOfType(serviceType, ServiceTypeValue.Upgrade) &&
          allPostpaidItemsInCart,
        alertId: `postpaid-limit-${MAX_CART_BUNDLES}`,
      },
      {
        applies: numberOfBundles > MAX_CART_BUNDLES && isServiceOfType(serviceType, ServiceTypeValue.Upgrade),
        alertId: `${MAX_CART_BUNDLES}-upgrade`,
      },
      {
        applies: numberFhwPlans >= MAX_FHW_CART_BUNDLES && numberNbnPlans >= MAX_NBN_CART_BUNDLES,
        alertId: `home-internet-limit-of-${MAX_HOME_INTERNET_CART_BUNDLES}`,
      },
      { applies: numberFhwPlans > MAX_FHW_CART_BUNDLES, alertId: `fhw-limit-of-${MAX_FHW_CART_BUNDLES}` },
      { applies: numberNbnPlans > MAX_NBN_CART_BUNDLES, alertId: `nbn-limit-of-${MAX_NBN_CART_BUNDLES}` },
      {
        applies: numberPrepaidBundles > MAX_PREPAID_CART_BUNDLES,
        alertId: `prepaid-limit-${MAX_PREPAID_CART_BUNDLES}`,
      },
      { applies: numberPrepaidBundles > 0 && numberPrepaidBundles !== numberOfBundles, alertId: 'converged' },
      {
        applies:
          (!!eligibilityError || !!currentServiceData.error) && isServiceOfType(serviceType, ServiceTypeValue.Upgrade),
        alertId: 'cannot-display-current-plan',
      },
      {
        applies: isSmartWatchWithHomeInternet(bundles),
        alertId: 'watch-cart-invalid',
      },
    ]
      .filter(({ applies }) => applies)
      .map(({ alertId }) => generateCartAlert(alertId));

    // Neutral alerts are information only, should not stop checkout
    const cartNeutralAlerts = [
      {
        applies:
          isServiceOfType(serviceType, ServiceTypeValue.AnotherService) &&
          !isHomeInternetASDEligible &&
          !!numberHomeInternetPlans,
        alertId: 'home-internet-asd-eligibility',
        alertProps: { variant: 'info' },
      },
      {
        applies:
          (isServiceOfType(serviceType, ServiceTypeValue.NewAcquisition) &&
            !isSmartWatchWithHomeInternet(bundles) &&
            isCartWithSmartWatch(bundles) &&
            !isValidNewAcqSmartWatchCart(serviceType, bundles)) ||
          (isServiceOfType(serviceType, ServiceTypeValue.AnotherService) &&
            !isSmartWatchWithHomeInternet(bundles) &&
            isCartWithSmartWatch(bundles) &&
            !isValidAddServicesSmartWatchCart(serviceType, bundles, user!, activeService!)),
        alertId: 'watch-only-error',
        alertProps: { variant: 'info', inline: false, showInCenter: true },
      },
      {
        applies: isCartEligibleWithSmartWatch(serviceType, bundles, user!, activeService!),
        alertId: 'accessories-payment',
        alertProps: { variant: 'info', inline: false, showInCenter: true },
      },
    ]
      .filter(({ applies }) => applies)
      .map(({ alertId, alertProps }) => generateCartAlert(alertId, alertProps as AlertProps));

    // TODO: Fix in VFE-2895
    // This is a temp fix to exclude $5 recurring modem cost from total cost
    content = (
      <>
        {cartValidationAlerts}
        {cartNeutralAlerts}
        {cartCards}
        {(isServiceOfType(serviceType, ServiceTypeValue.Upgrade) || cartCards.length > 1) && (
          <Section spacingTop={null} spacingBottom={{ xs: 's', m: 'l' }}>
            <Grid>
              <GridCol>
                <TotalCostCard
                  cart={getBasketState.data}
                  remainingBalanceLabel={pageData.cartSummary.remainingBalanceLabel}
                  showASDPricing={isHomeInternetASDEligible && !disableAsdCopy}
                  applyDiscount={applyDiscount}
                  upgradeCost={upgradeCost}
                  DisableMinCost={samsungPlanInCart}
                />
              </GridCol>
            </Grid>
          </Section>
        )}
        {getBasketState.data.bundleAndSaveApplied && (
          <Section spacingTop={null} spacingBottom={{ xs: 's', m: 'l', l: 'xxl' }}>
            <Grid>
              <GridCol gridColStart={{ m: 3 }} gridColSpan={{ xs: 12, m: 8 }} textAlign={{ m: 'center' }}>
                <RichText pTagMarginBottom={{ xs: 0 }}>{pageData.cartSummary.disclaimer}</RichText>
              </GridCol>
            </Grid>
          </Section>
        )}
        {disableReferAFriend !== null && !disableReferAFriend && rafCartLabels && cartIsRafEligible && (
          <Section spacingTop={null} spacingBottom={null}>
            <Grid>
              <GridCol>
                <ReferAFriendComponent
                  rafData={rafCartLabels}
                  rafEligibleCatalogCodes={getUniqueCatalogCodes(rafEligibleCatalogCodesInBasket)}
                  attachRafCreditToItem={applyRafToItem}
                  removeRafCreditFromItem={removeRafCredit}
                  rafAppliedItemInCart={rafAppliedItemInCart || undefined}
                  basketRafData={basketRafData}
                  alerts={alerts}
                />
              </GridCol>
            </Grid>
          </Section>
        )}
        <Section spacingTop={null}>
          <Grid>
            <GridCol>
              <ContinueToCheckoutSection
                continueShoppingLabel={pageData.cartSummary.continueCta}
                continueShoppingUrl={continueShoppingUrl}
                continueShoppingItemDetails={flattenBasket(getBasketState.data?.packages ?? [])}
                checkoutButtonDisabled={
                  removePackageFromBasketState.isLoading || !!cartValidationAlerts.length || showSamsungAlert
                }
                displayContinueShoppingCTA={!samsungPlanInCart}
                onClickCheckout={onClickCheckout}
              />
            </GridCol>
          </Grid>
        </Section>
      </>
    );
  }

  const contentList = getCheckoutSplitterContentList({ cart, checkoutSplitterGroups });

  return (
    <ThemeProvider theme={midTheme}>
      <main>
        {isStudentOfferApplicable() && <StudentOfferBanner />}
        <Section
          spacingTop={{ xs: 's', m: 'l', l: 'xxl' }}
          spacingBottom={
            isAuthenticated && isServiceOfType(serviceType, ServiceTypeValue.AnotherService)
              ? { xs: 'xs', m: 's' }
              : { xs: 's', m: 'l', l: 'xxl' }
          }
          ref={titleRef}
        >
          <Grid>
            <GridCol>
              <Text as="h1" data-testid="cart-summary-title" textAlign="center">
                {pageData.cartSummary.title}
              </Text>
              {showSamsungAlert ? (
                <AlertContainer marginBottom={{ xs: 0, m: 0 }} style={{ marginTop: '32px' }}>
                  <Alert
                    data-testid="non-samsung-plan-alert"
                    variant="error"
                    inline={true}
                    fullWidth={true}
                    fullHeight={true}
                  >
                    <RichText>{ADD_NON_SAMSUNG_ITEM_TO_CART}</RichText>
                  </Alert>
                </AlertContainer>
              ) : null}
              {showRafTransferredAlert && rafTranferredAlert && (
                <AlertContainer
                  data-testid="raf-credit-transferred-alert"
                  marginBottom={{ xs: 0, m: 0 }}
                  style={{ marginTop: '32px' }}
                >
                  <Alert
                    variant={rafTranferredAlert.alertType as AlertVariant}
                    fullWidth={true}
                    inline={true}
                    fullHeight={true}
                  >
                    <RichText>{rafTranferredAlert.alertText}</RichText>
                  </Alert>
                </AlertContainer>
              )}
              {showRafHigherItemUpdateAlert && rafMultipleItemsAlert && (
                <AlertContainer
                  data-testid="raf-credit-mso-update-alert"
                  marginBottom={{ xs: 0, m: 0 }}
                  style={{ marginTop: '32px' }}
                >
                  <Alert
                    variant={rafMultipleItemsAlert.alertType as AlertVariant}
                    fullWidth={true}
                    inline={true}
                    fullHeight={true}
                  >
                    <RichText>{rafMultipleItemsAlert?.alertText}</RichText>
                  </Alert>
                </AlertContainer>
              )}
              {isServiceOfType(serviceType, ServiceTypeValue.Upgrade) && activeMsisdn && (
                <Text
                  fontSize={{ xs: 'base', m: 'baseLarge' }}
                  lineHeight={{ xs: 'base', m: 'baseLarge' }}
                  marginTop={{ xs: '20px', m: '32px' }}
                  textAlign="center"
                  data-testid="upgrading-service-number"
                >
                  You&apos;re upgrading: <strong>{formatMSISDN(activeMsisdn)}</strong>
                </Text>
              )}
            </GridCol>
          </Grid>
        </Section>
        <AdditionalServicesTitleSection checkServiceType={true} paddingTop={false} />
        {removePackageFromBasketState.error && (
          <Section spacingTop={null}>
            <Grid>
              <GridCol gridColStart={{ xs: 1, m: 3 }} gridColSpan={{ xs: 12, m: 8 }} textAlign="center">
                <AnimatedAlert inline={true} variant="error">
                  <p>{REMOVE_ITEMS_FROM_CART}</p>
                </AnimatedAlert>
              </GridCol>
            </Grid>
          </Section>
        )}
        {content}
      </main>
      <CartSplitter
        applyDiscount={applyDiscount}
        open={showCartSplitter}
        cart={cart}
        onClose={() => setShowCartSplitter(false)}
        backToCartSplitter={() => setShowCartSplitter(true)}
        logo={checkoutSplitterLogo}
        contentList={contentList}
        rafAppliedItemInCart={rafAppliedItemInCart || undefined}
        rafSplitterData={rafSplitterData}
      />
    </ThemeProvider>
  );
};

export default CartTemplate;
