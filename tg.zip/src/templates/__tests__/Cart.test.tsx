import React from 'react';
import { fireEvent, render, waitFor } from 'test-utils';
import RouterMock from '@src/test/RouterMock';
import { CartPageResponse, CatalogCode, OptimizeContentKey } from '@src/lib/api/types';
import {
  mockAsdEligibleFhwBasket,
  mockAuthenticationStateUnAuthed,
  mockCustomerData,
  mockDefaultDataFetchState,
  mockFhwPlanAndDevice,
  mockMobilePhoneAndPlanCart,
  mockMobilePhoneAndPlanCartWithRaf,
  mockMultipleRafEligibleItems,
  mockNbnPlanAndDevice,
  mockPrepaidPlanOnlyCart,
} from '@src/lib/mock-data';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { GlobalContentDataProvider } from '@src/lib/context/global-content';
import CartTemplate, { CartTemplateProps } from '../Cart/Cart';
import mockPageResponse from '../mock-data/cartPageResponse.json';
import mockMultipleNbn from '../mock-data/multipleNbnBundle.json';
import mockMultipleFhw from '../mock-data/multipleFhwBundle.json';

jest.mock('@src/lib/context/authentication', () => ({
  useAuthentication: jest.fn().mockImplementation(() => mockAuthenticationStateUnAuthed),
}));

jest.mock('@src/lib/hooks/use-asd-eligibility', () => ({
  __esModule: true,
  default: jest.fn().mockReturnValue(false),
}));

const useServiceTypeMock: jest.Mock<[ServiceTypeValue | undefined], []> = jest.fn();
jest.mock('@src/lib/hooks/use-service-type', () => ({
  __esModule: true,
  // eslint-disable-next-line react-hooks/rules-of-hooks
  default: () => useServiceTypeMock(),
}));

jest.mock('@src/lib/context/customer-data', () => ({
  useCustomerData: jest.fn().mockImplementation(() => mockCustomerData),
}));

jest.mock('@src/lib/tracking', () => ({
  useImperativeTrackPage: jest.fn().mockImplementation(() => jest.fn()),
}));

jest.mock('@src/lib/context/feature-flags', () => ({
  useRedirectFeatureFlag: jest.fn().mockImplementation(() => mockDefaultDataFetchState),
  useFeatureFlag: jest.fn().mockImplementation(() => mockDefaultDataFetchState),
  Flag: {
    DISABLE_ANOTHER_SERVICE_JOURNEY_BUSINESS: 'DEFAULT - 1.0 - 1.0 - ANOTHER - SERVICE.BUSINESS.DISABLED',
    DISABLE_MAX_SPEED: '',
  },
}));

const setBasket = jest.fn();

jest.mock('@src/lib/context/basket', () => {
  return {
    __esModule: true,
    useBasketState: () => {
      return {
        setBasket,
      };
    },
  };
});

jest.mock('@src/lib/context/feature-flags', () => ({
  useRedirectFeatureFlag: jest.fn().mockImplementation(() => mockDefaultDataFetchState),
  useFeatureFlag: () => ({ data: false }),
  Flag: {
    DISABLE_REFER_A_FRIEND: '',
  },
}));

jest.mock('@src/lib/api', () => ({
  __esModule: true,
  getApiClient: () => ({
    fetchPreviouslyViewedContent: jest.fn().mockImplementation(() => Promise.resolve()),
    fetchStudentOfferContent: jest.fn().mockImplementation(() => Promise.resolve()),
    fetchPromotionalCampaigns: jest.fn().mockImplementation(() => Promise.resolve()),
    fetchTradeInDetailsContent: jest.fn().mockImplementation(() => Promise.resolve()),
  }),
}));
const defaultDataFetchState = {
  data: null,
  error: null,
  isInitialised: false,
  isLoading: false,
  isSuccess: false,
  params: null,
};

const mockUpdateRafAppliedItemInCart = jest.fn();
const mockOnRemoveFromBasket = jest.fn();

const defaultProps: CartTemplateProps = {
  getBasketState: defaultDataFetchState,
  eligibilityError: null,
  onContinueToCheckout: jest.fn(),
  onRemoveFromBasket: mockOnRemoveFromBasket,
  addToBasketState: defaultDataFetchState,
  removePackageFromBasketState: defaultDataFetchState,
  packageIdToRemove: null,
  pageData: mockPageResponse as CartPageResponse,
  titleRef: React.createRef<HTMLDivElement>(),
  isHomeInternetASDEligible: false,
  disableAsdCopy: true,
  onlinePromoContentParams: {
    catalogCode: CatalogCode.CART_PROMO_OFFER,
    promoAvailability: false,
    optimizeContentKey: OptimizeContentKey.CART,
  },
  rafEligiblePackagesInBasket: {
    '12345': 'CATPOSTPAIDSIMOPLANS' as CatalogCode,
    '56789': 'CATPOSTPAIDHANDSETPLANS' as CatalogCode,
  },
  updateRafAppliedItemInCart: mockUpdateRafAppliedItemInCart,
  rafAppliedItemInCart: null,
  showRafTransferredAlert: false,
  updateShowRafTransferredAlert: jest.fn(),
};

const propsWithoutRaf: CartTemplateProps = {
  ...defaultProps,
  pageData: {
    ...(mockPageResponse as CartPageResponse),
    rafCartLabels: undefined,
  },
};

const propsWithSingleRafItem: CartTemplateProps = {
  ...defaultProps,
  rafEligiblePackagesInBasket: {
    '1': CatalogCode.POSTPAID_SIMO_PLANS,
  },
  rafAppliedItemInCart: {
    packageId: '1',
    rafCode: 'RAF00006',
    catalogCode: CatalogCode.POSTPAID_SIMO_PLANS,
    discountAmount: 25,
  },
};

const propsRafMultipleItems: CartTemplateProps = {
  ...defaultProps,
  rafEligiblePackagesInBasket: {
    '1': CatalogCode.FHW_4G_PLANS,
    '2': CatalogCode.POSTPAID_SIMO_PLANS,
  },
  rafAppliedItemInCart: {
    packageId: '1',
    rafCode: 'RAF00006',
    catalogCode: CatalogCode.FHW_4G_PLANS,
    discountAmount: 55,
  },
};

const propsWithRafIneligibleItems: CartTemplateProps = {
  ...defaultProps,
  rafEligiblePackagesInBasket: undefined,
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(
    <RouterMock>
      <GlobalContentDataProvider>
        <CartTemplate {...props} />
      </GlobalContentDataProvider>
    </RouterMock>,
  );
  return { utils, props };
};

describe('CartTemplate', () => {
  beforeEach(() => {
    useServiceTypeMock.mockReturnValue([ServiceTypeValue.NewAcquisition]);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should render cart summary title', () => {
    const { utils } = setup();
    utils.getByTestId('cart-summary-title');
  });

  it('should render cart card header', () => {
    const { utils } = setup();
    utils.getByTestId('cart-card-header');
  });

  it('should render empty cart text', () => {
    const { utils } = setup();
    utils.getByText('Your cart is empty.');
  });

  it('should not render alert when cart is empty', () => {
    const { utils } = setup();
    const alert = utils.queryByTestId('alert');
    expect(alert).toBeNull();
  });

  it('should render alert when multiple NBN plans are added to cart', () => {
    const dataFetchState = { ...defaultDataFetchState, data: mockMultipleNbn };
    const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
    utils.getByTestId('alert');
  });

  it('should disable checkout button when multiple NBN plans are added to cart', () => {
    const dataFetchState = { ...defaultDataFetchState, data: mockMultipleNbn };
    const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
    const checkout = utils.getByText('Checkout');
    expect(checkout.closest('button')?.disabled).toBeTruthy();
  });

  it('should render alert when multiple FHW plans are added to cart', () => {
    const dataFetchState = { ...defaultDataFetchState, data: mockMultipleFhw };
    const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
    utils.getByTestId('alert');
  });

  it('should disable checkout button when multiple FHW plans are added to cart', () => {
    const dataFetchState = { ...defaultDataFetchState, data: mockMultipleFhw };
    const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
    const checkout = utils.getByText('Checkout');
    expect(checkout.closest('button')?.disabled).toBeTruthy();
  });

  describe('Home internet additional service discount alert', () => {
    it('should render alert when service type is another service and NBN plan is added to cart and customer is NOT eligible for home internet additional service discount', () => {
      useServiceTypeMock.mockReturnValue([ServiceTypeValue.AnotherService]);
      const dataFetchState = { ...defaultDataFetchState, data: mockNbnPlanAndDevice };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      utils.getByTestId('alert');
    });

    it('should render alert when service type is another service and FHW plan is added to cart and customer is NOT eligible for home internet additional service discount', () => {
      useServiceTypeMock.mockReturnValue([ServiceTypeValue.AnotherService]);
      const dataFetchState = { ...defaultDataFetchState, data: mockFhwPlanAndDevice };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      utils.getByTestId('alert');
    });

    it('should not render alert when service type is another service and NBN plan is added to cart but customer is eligible for home internet additional service discount', () => {
      useServiceTypeMock.mockReturnValue([ServiceTypeValue.AnotherService]);
      const dataFetchState = { ...defaultDataFetchState, data: mockNbnPlanAndDevice };
      const { utils } = setup({ ...defaultProps, isHomeInternetASDEligible: true, getBasketState: dataFetchState });
      expect(utils.queryByTestId('alert')).not.toBeInTheDocument();
    });

    it('should not render alert when service type is another service and customer is not eligible for home internet additional service discount but cart has NO home internet product', () => {
      useServiceTypeMock.mockReturnValue([ServiceTypeValue.AnotherService]);
      const dataFetchState = { ...defaultDataFetchState, data: mockMobilePhoneAndPlanCart };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      expect(utils.queryByTestId('alert')).not.toBeInTheDocument();
    });

    it('should not render alert when service type is new acquisition and NBN plan is added to cart and customer is NOT eligible for home internet additional service discount', () => {
      useServiceTypeMock.mockReturnValue([ServiceTypeValue.NewAcquisition]);
      const dataFetchState = { ...defaultDataFetchState, data: mockNbnPlanAndDevice };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      expect(utils.queryByTestId('alert')).not.toBeInTheDocument();
    });

    it('should not render alert when service type is upgrade and NBN plan is added to cart and customer is NOT eligible for home internet additional service discount', () => {
      useServiceTypeMock.mockReturnValue([ServiceTypeValue.Upgrade]);
      const dataFetchState = { ...defaultDataFetchState, data: mockNbnPlanAndDevice };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      expect(utils.queryByTestId('alert')).not.toBeInTheDocument();
    });

    it('should render multiple alerts when service type is another service and multiple NBN plan is added to cart and customer is NOT eligible for home internet additional service discount', () => {
      useServiceTypeMock.mockReturnValue([ServiceTypeValue.AnotherService]);
      const dataFetchState = { ...defaultDataFetchState, data: mockMultipleNbn };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      const alerts = utils.getAllByTestId('alert');
      expect(alerts).toHaveLength(2);
    });
  });

  describe('total cost card', () => {
    it('should render when there are mutliple packages in the cart', () => {
      const dataFetchState = { ...defaultDataFetchState, data: mockMultipleNbn };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      const totalCostCard = utils.getByTestId('cart-total-cost-card');
      expect(totalCostCard).toBeDefined();
    });

    it('should not render when there is single package in the cart', () => {
      const dataFetchState = { ...defaultDataFetchState, data: mockMobilePhoneAndPlanCart };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      const totalCostCard = utils.queryByTestId('cart-total-cost-card');
      expect(totalCostCard).toBe(null);
    });

    it('should render when there is single package and serviceType is upgrade', () => {
      useServiceTypeMock.mockReturnValue([ServiceTypeValue.Upgrade]);
      const dataFetchState = { ...defaultDataFetchState, data: mockMobilePhoneAndPlanCart };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      const totalCostCard = utils.getByTestId('cart-total-cost-card');
      expect(totalCostCard).toBeInTheDocument();
    });

    it('should not render when there is no basket state', () => {
      const dataFetchState = { ...defaultDataFetchState };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      const totalCostCard = utils.queryByTestId('cart-total-cost-card');
      expect(totalCostCard).toBe(null);
    });
  });

  describe('Refer a Friend component', () => {
    it('should render the accordion when an eligible item is in the Cart and rafData is available', () => {
      const dataFetchState = { ...defaultDataFetchState, data: mockMobilePhoneAndPlanCart };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      expect(utils.getByTestId('raf-component')).toBeInTheDocument();
      expect(utils.getByTestId('input')).not.toBeVisible();
    });

    it('should not render the accordion when rafData is not available', () => {
      const dataFetchState = { ...defaultDataFetchState, data: mockMobilePhoneAndPlanCart };
      const { utils } = setup({ ...propsWithoutRaf, getBasketState: dataFetchState });
      expect(utils.queryByTestId('raf-component')).toBeNull();
    });

    it('should not render the accordion when only non-eligible items are in the Cart', () => {
      const dataFetchState = { ...defaultDataFetchState, data: mockPrepaidPlanOnlyCart };
      const { utils } = setup({ ...propsWithRafIneligibleItems, getBasketState: dataFetchState });
      expect(utils.queryByTestId('raf-component')).toBeNull();
    });

    it('should be hidden if there are no products in the Cart', () => {
      const dataFetchState = { ...defaultDataFetchState };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      expect(utils.queryByTestId('raf-component')).toBeNull();
    });

    it('should apply the RAF details available in Basket response on page load', () => {
      const dataFetchState = { ...defaultDataFetchState, data: mockMobilePhoneAndPlanCartWithRaf };
      const { utils } = setup({ ...defaultProps, getBasketState: dataFetchState });
      expect(utils.getByTestId('raf-component')).toBeInTheDocument();
      expect(utils.getByTestId('input')).toBeVisible();
      const mockRafAppliedItem = {
        packageId: '56789',
        catalogCode: mockMobilePhoneAndPlanCartWithRaf.raf?.appliedCatalogCode,
        discountAmount: mockMobilePhoneAndPlanCartWithRaf.raf?.discountAmount,
        rafCode: mockMobilePhoneAndPlanCartWithRaf.raf?.rafCode,
      };
      expect(mockUpdateRafAppliedItemInCart).toBeCalledWith(mockRafAppliedItem);
    });

    it('should ensure that remove request is called with RAF details when removing RAF applied item', async () => {
      const dataFetchState = { ...defaultDataFetchState, data: mockMultipleRafEligibleItems };
      const { utils } = setup({ ...propsRafMultipleItems, getBasketState: dataFetchState });
      const removeButtons = utils.getAllByTestId('remove-bundle-cta');
      fireEvent.click(removeButtons[0]);
      const removeRequest = {
        action: 'Update',
        rafCatalogCodes: ['CATPOSTPAIDSIMOPLANS' as CatalogCode],
        rafCode: propsRafMultipleItems.rafAppliedItemInCart?.rafCode,
        toBeValidated: true,
      };
      expect(mockOnRemoveFromBasket).toBeCalledWith('1', removeRequest);
      await waitFor(() => expect(mockOnRemoveFromBasket).toBeCalledWith('1', removeRequest));
    });

    it('should display the RAF transfer alert when the rafApplied packageId is empty', async () => {
      const dataFetchState = { ...defaultDataFetchState, data: mockAsdEligibleFhwBasket };
      const { utils } = setup({ ...propsWithSingleRafItem, getBasketState: dataFetchState });
      const removeButton = utils.getByTestId('remove-bundle-cta');
      fireEvent.click(removeButton);
      const removeRequest = {
        action: 'Delete',
        rafCatalogCodes: [],
        rafCode: propsRafMultipleItems.rafAppliedItemInCart?.rafCode,
        toBeValidated: true,
      };
      await waitFor(() => expect(mockOnRemoveFromBasket).toBeCalledWith('1', removeRequest));
    });
  });
});
