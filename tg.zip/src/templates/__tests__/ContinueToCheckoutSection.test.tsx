import React from 'react';
import { render } from 'test-utils';
import ContinueToCheckoutSection from '@src/templates/Cart/ContinueToCheckoutSection';
import { ContinueToCheckoutSectionProps } from '@src/templates/Cart/ContinueToCheckoutSection/ContinueToCheckoutSection';
import RouterMock from '@src/test/RouterMock';
import { GlobalContentDataProvider } from '@src/lib/context/global-content';

const defaultProps: ContinueToCheckoutSectionProps = {
  continueShoppingLabel: 'Continue shopping',
  continueShoppingUrl: '/',
  onClickCheckout: jest.fn(),
  checkoutButtonDisabled: false,
  displayContinueShoppingCTA: true,
};
const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(
    <RouterMock>
      <GlobalContentDataProvider>
        <ContinueToCheckoutSection {...props} />
      </GlobalContentDataProvider>
    </RouterMock>,
  );
  return { utils, props };
};
describe('ContinueToCheckoutSection', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should render the "cart-checkout-cta" button ', () => {
    const { utils } = setup({});
    utils.getByTestId('cart-checkout-cta');
  });

  it('should not disable the checkout button when "checkoutButtonDisabled" is false ', () => {
    const { utils } = setup({ ...defaultProps });
    expect(utils.queryByTestId('cart-checkout-cta')).not.toBeDisabled();
  });

  it('should disable the checkout button when "checkoutButtonDisabled" is true ', () => {
    const { utils } = setup({ ...defaultProps, checkoutButtonDisabled: true });
    expect(utils.queryByTestId('cart-checkout-cta')).toBeDisabled();
  });

  it('should render the "continue shopping CTA" ', () => {
    const { utils } = setup({});
    expect(utils.getByTestId('cart-continue-shopping-cta'));
  });

  it('should not render the "continue shopping CTA" when "displayContinueShoppingCTA" prop is false ', () => {
    const { utils } = setup({ ...defaultProps, displayContinueShoppingCTA: false });
    expect(utils.queryByTestId('cart-continue-shopping-cta')).not.toBeInTheDocument();
  });
});
