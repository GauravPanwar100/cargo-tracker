const { createConfigItem, transformSync } = require('@babel/core');
const pluginTransformReactConstantElements = require('@babel/plugin-transform-react-constant-elements');
const presetReact = require('@babel/preset-react');
const presetEnv = require('@babel/preset-env');
const convert = require('@svgr/core').default;
const jsx = require('@svgr/plugin-jsx').default;
const svgo = require('@svgr/plugin-svgo').default;
const crypto = require('crypto');

/**
 * @type {import('@babel/core').TransformOptions}
 */
const babelOptions = {
  babelrc: false,
  configFile: false,
  presets: [
    createConfigItem(presetReact, { type: 'preset' }),
    createConfigItem([presetEnv, { modules: 'commonjs' }], { type: 'preset' }),
  ],
  plugins: [createConfigItem(pluginTransformReactConstantElements)],
};

/**
 * @type {import('@jest/transform').Transformer}
 */
module.exports = {
  getCacheKey(sourceText, sourcePath) {
    return `svgr-transformer-v1-${crypto.createHash('sha256').update(sourceText).digest('hex')}-${crypto
      .createHash('sha256')
      .update(sourcePath)
      .digest('hex')}`;
  },
  process(sourceText, sourcePath) {
    return transformSync(
      convert.sync(
        sourceText,
        {},
        {
          caller: {
            name: 'svgr-transformer',
            previousExport: `export default ${JSON.stringify('https://www.vodafone.com.au/static/img/asset.svg')};`,
            defaultPlugins: [svgo, jsx],
          },
          filePath: sourcePath,
        },
      ),
      babelOptions,
    );
  },
};
