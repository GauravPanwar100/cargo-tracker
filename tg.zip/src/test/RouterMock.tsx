// From: https://gitmemory.com/issue/zeit/next.js/7479/568546815
import React from 'react';
import { MemoryRouterProvider } from 'next-router-mock/MemoryRouterProvider';
import PropTypes from 'prop-types';

interface MockRouterParams {
  children: React.ReactNode;
}

function RouterMock({ children }: MockRouterParams) {
  return <MemoryRouterProvider>{children}</MemoryRouterProvider>;
}

RouterMock.propTypes = {
  children: PropTypes.node.isRequired,
};

export default RouterMock;
