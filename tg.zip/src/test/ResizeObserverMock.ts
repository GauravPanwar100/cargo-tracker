/* eslint-disable class-methods-use-this */

export default class ResizeObserverMock implements ResizeObserver {
  // eslint-disable-next-line no-useless-constructor, @typescript-eslint/no-unused-vars
  constructor(callback: ResizeObserverCallback) {
    // empty
  }

  public observe() {
    // empty
  }

  public unobserve() {
    // empty
  }

  public disconnect() {
    // empty
  }
}
