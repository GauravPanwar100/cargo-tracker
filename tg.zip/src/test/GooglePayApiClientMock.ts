/* eslint-disable class-methods-use-this */
/* eslint-disable @typescript-eslint/no-unused-vars */

/**
 * Mock implementation of the Google Pay PaymentsClient for testing purposes.
 */

class PaymentsClient {
  isReadyToPay(request: google.payments.api.IsReadyToPayRequest): Promise<google.payments.api.IsReadyToPayResponse> {
    return Promise.resolve({
      result: true,
      paymentMethodPresent: true,
    });
  }

  loadPaymentData(request: google.payments.api.PaymentDataRequest): Promise<google.payments.api.PaymentData> {
    return Promise.resolve({
      apiVersion: request.apiVersion,
      apiVersionMinor: request.apiVersionMinor,
      paymentMethodData: {
        type: 'CARD',
        tokenizationData: {
          type: 'PAYMENT_GATEWAY',
          token: 'token',
        },
      },
    });
  }

  createButton(request: google.payments.api.ButtonOptions): HTMLElement {
    const container = document.createElement('div');
    const button = document.createElement('button');
    button.innerHTML = 'Pay with GPay';
    button.onclick = request.onClick;
    container.appendChild(button);
    return container;
  }

  prefetchPaymentData(request: google.payments.api.PaymentDataRequest): void {}
}

export default PaymentsClient;
