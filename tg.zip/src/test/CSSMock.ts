import 'css.escape';

type ICSS = typeof CSS;

class CSSMock implements ICSS {
  public [Symbol.toStringTag] = 'CSS';

  /**
   * Polyfilled by `css.escape`
   */
  public escape: typeof CSS.escape;

  public constructor() {
    this.escape = CSS.escape;
    window.CSS = this;
    global.CSS = this;
  }

  public supports(condition: string): boolean;

  public supports(property: string, value: string): boolean;

  // eslint-disable-next-line class-methods-use-this
  public supports(conditionOrProperty: string, value?: string): boolean {
    throw new Error(
      `Not implemented: CSS.supports(${
        typeof value === 'string'
          ? `property: ${JSON.stringify(conditionOrProperty)}, value: ${JSON.stringify(value)}`
          : `condition: ${JSON.stringify(conditionOrProperty)}`
      }). If you're seeing this error in a test, you probably need to create a stub.`,
    );
  }
}

export default new CSSMock();
