import React from 'react';
import styled, { css } from 'styled-components';
import { ColorKey } from '@src/lib/theme';
import {
  MixinProperty,
  displayMixin,
  heightMixin,
  leftMixin,
  marginBottomMixin,
  marginLeftMixin,
  marginRightMixin,
  marginTopMixin,
  rotate,
  topMixin,
  widthMixin,
} from '@src/lib/util/mixins';

interface BaseIconWrapperProps {
  // Allow a class name so we can add styles with styled-components
  className?: string;
  svg: React.FC<React.SVGProps<SVGSVGElement>>;
}

type IconWrapperProps = {
  // Rotate the icon with a constant animation
  animateRotate?: boolean;
  // Note: In order for the color prop to work, the provided SVG must have fill="currentColor"
  // attribute set on the path that we want to fill
  color?: ColorKey;
  display?: MixinProperty<string>;
  height?: MixinProperty<string>;
  marginBottom?: MixinProperty;
  marginLeft?: MixinProperty;
  marginRight?: MixinProperty;
  marginTop?: MixinProperty;
  // Transform rotate the icon
  rotate?: string;
  stroke?: ColorKey;
  top?: MixinProperty<string>;
  width?: MixinProperty<string>;
  position?: string;
  left?: MixinProperty<string>;
};

const BaseIconWrapper: React.FC<BaseIconWrapperProps> = ({ className, svg: Icon }) => (
  <Icon role="presentation" className={className} />
);

const IconWrapper = styled(BaseIconWrapper)<IconWrapperProps>`
  ${(p) => `position:  ${p.position || 'relative'};`}
  ${(p) => p.color && `color: ${p.theme.colors[p.color]};`}
  ${(p) => p.stroke && `stroke: ${p.theme.colors[p.stroke]};`}

  ${(p) => displayMixin(p.display)}
  ${(p) => heightMixin(p.height)}
  ${(p) => widthMixin(p.width)}
  ${(p) => topMixin(p.top)}
  ${(p) => leftMixin(p.left)}
  ${(p) => marginBottomMixin(p.marginBottom)}
  ${(p) => marginTopMixin(p.marginTop)}
  ${(p) => marginLeftMixin(p.marginLeft)}
  ${(p) => marginRightMixin(p.marginRight)}

  ${(p) =>
    p.animateRotate &&
    css`
      animation: ${rotate} 1s linear infinite;
    `}

  ${(p) =>
    p.rotate &&
    css`
      transform: rotate(${p.rotate});
    `}
`;

IconWrapper.defaultProps = {
  display: 'block',
  height: '24px',
  width: '24px',
};

export default IconWrapper;
