import React from 'react';
import { storiesOf } from '@storybook/react';
import { ReactComponent as ErrorSVG } from '@src/assets/svg/error.svg';
import { ReactComponent as InfoSVG } from '@src/assets/svg/info.svg';
import { ReactComponent as SuccessSVG } from '@src/assets/svg/success.svg';
import { Sections } from '@src/lib/constants/storybook';
import IconWrapper from './IconWrapper';

export const IconWrapperDemo = () => (
  <div>
    Error <IconWrapper color="darkRed" svg={ErrorSVG} />
    <br />
    Info <IconWrapper color="lemonYellow" svg={InfoSVG} />
    <br />
    Success <IconWrapper color="uiGreen" svg={SuccessSVG} />
  </div>
);

storiesOf(`${Sections.CORE}|IconWrapper`, module).add('Default', () => <IconWrapperDemo />);
