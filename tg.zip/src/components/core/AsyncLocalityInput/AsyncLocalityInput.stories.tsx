import React, { useCallback, useState } from 'react';
import { storiesOf } from '@storybook/react';
import Section from '@src/components/core/Section';
import { Grid, GridCol } from '@src/components/core/Grid';
import { Sections } from '@src/lib/constants/storybook';
import { formatLocalityEndpointUrl } from '@src/lib/api';
import { Locality } from '@src/lib/api/types';
import { formatLocality } from './utils';
import AsyncLocalityInput from './AsyncLocalityInput';

storiesOf(`${Sections.CORE}|AsyncLocalityInput`, module).add('Default', () => {
  const [value, setValue] = useState<string>('');
  const onChange = useCallback((newValue: string) => {
    setValue(newValue);
  }, []);
  const onSelect = useCallback((locality: Locality) => {
    setValue(formatLocality(locality));
  }, []);
  return (
    <Section>
      <Grid>
        <GridCol gridColSpan={{ xs: 12, m: 4, l: 3 }}>
          <AsyncLocalityInput
            formatEndpointUrl={formatLocalityEndpointUrl}
            id="storybook"
            name="autoCompleteAddress"
            onChange={onChange}
            placeholder="Suburb or postcode"
            onSelect={onSelect}
            value={value}
          />
        </GridCol>
      </Grid>
    </Section>
  );
});
