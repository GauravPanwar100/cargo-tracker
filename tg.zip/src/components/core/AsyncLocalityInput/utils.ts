import { Locality, LocalityResponse } from '@src/lib/api/types';
import { AxiosResponse } from 'axios';

const capitalizeEachWord = (string: string) =>
  string
    .split(' ')
    .map((word: string) => word[0].toUpperCase() + word.substring(1).toLowerCase())
    .join(' ');

export const formatLocality = (locality: Locality) => {
  return `${locality.location}, ${locality.postcode}, ${locality.state}`;
};

export const parseResponse = (response: AxiosResponse<LocalityResponse>): Locality[] => {
  return response.data.localities.map((locality) => ({
    ...locality,
    location: capitalizeEachWord(locality.location),
  }));
};

export const shouldCallApi = (searchCriteria: string) => searchCriteria.length > 2;
