import React from 'react';
import AsyncInput from '@src/components/core/AsyncInput';
import { AsyncInputProps } from '@src/components/core/AsyncInput/AsyncInput';
import { Locality, LocalityResponse } from '@src/lib/api/types';
import { formatLocality, parseResponse, shouldCallApi } from './utils';

export type AsyncLocalityInputProps = Omit<
  AsyncInputProps<LocalityResponse, Locality>,
  'formatLocality' | 'parseResponse' | 'shouldCallApi'
>;

const AsyncLocalityInput: React.FC<AsyncLocalityInputProps> = (props) => (
  <AsyncInput
    {...props}
    formatSuggestion={formatLocality}
    parseResponse={parseResponse}
    shouldCallApi={shouldCallApi}
  />
);

export default AsyncLocalityInput;
