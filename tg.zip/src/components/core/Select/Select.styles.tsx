import styled, { css } from 'styled-components';
import { fontLineHeightSize, media } from '@src/lib/util/mixins';

interface SelectProps {
  fullWidth?: boolean;
  invalid?: boolean;
}
export const Select = styled.select<SelectProps>`
  ${(p) =>
    p.fullWidth &&
    css`
      width: 100%;
    `}

  ${(p) =>
    !p.fullWidth &&
    css`
      ${media.m`
        width: 288px;
      `}
      width: 100%;
    `}
  display: block;
  appearance: none;
  -webkit-appearance: none;
  margin: 0;
  color: ${(p) => p.theme.colors.mainColor};
  font-family: ${(p) => p.theme.fonts.regular};
  border: 1px solid ${(p) => p.theme.colors.midGrey};
  border-radius: 6px;
  background: ${(p) => p.theme.colors.white};
  padding: 10px 50px 10px 12px;
  ${fontLineHeightSize('base')};
  box-shadow: none;
  background-image: url("data:image/svg+xml, %3Csvg width='32' height='32' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath fill='none' d='M32 0H0v32h32z' /%3E%3Cpath stroke='%23E60000' stroke-linecap='round' stroke-linejoin='round' d='M4.667 11.333L16 22.667l11.333-11.334' /%3E%3C/g%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: calc(100% - 6px) calc(100% - 6px);

  &::-ms-expand {
    display: none;
  }

  &:focus {
    /* Remove 1px from each side default padding */
    padding: 9px 50px 9px 11px;
    background-position: calc(100% - 5px) calc(100% - 5px);
    border-width: 2px;
    border-color: ${(p) => p.theme.colors.focusColor};
    outline: none;
  }

  ${(p) =>
    p.invalid &&
    css`
      /* Remove 1px from each side default padding */
      padding: 9px 50px 9px 11px;
      background-position: calc(100% - 5px) calc(100% - 5px);
      border-width: 2px;
      border-color: ${p.theme.colors.darkRed};
      outline: none;
    `}

  &:disabled {
    background-color: ${(p) => p.theme.colors.aluminium};
    opacity: 0.6;
    cursor: not-allowed;
  }

  &[multiple] {
    background-image: none;
    padding: 12px;
  }

  ${media.m<SelectProps>`
    ${fontLineHeightSize('baseLarge')};
    padding: 10px 50px 10px 12px;
    background-position: calc(100% - 8px) calc(100% - 8px);

    &:focus {
      /* Remove 1px from each side default padding */
      padding: 9px 50px 9px 11px;
      background-position: calc(100% - 7px) calc(100% - 7px);
    }

    ${(p) =>
      p.invalid &&
      `
      /* Remove 1px from each side default padding */
      padding: 9px 50px 9px 11px
      background-position: calc(100% - 7px) calc(100% - 7px);
    `}
  `}
`;
