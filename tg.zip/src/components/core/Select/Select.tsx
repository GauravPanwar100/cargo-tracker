import React, { forwardRef } from 'react';
import Field from '@src/components/core/Field';
import { FieldProps } from '@src/components/core/Field/Field';
import { Theme } from '../../../lib/theme';
import { Select as StyledSelect } from './Select.styles';

export type DropdownProps = {
  children?: React.ReactNode;
  defaultOptionText?: string;
  disabled?: React.HTMLProps<HTMLSelectElement>['disabled'];
  fullWidth?: boolean;
  multiple?: React.HTMLProps<HTMLSelectElement>['multiple'];
  name?: React.HTMLProps<HTMLSelectElement>['name'];
  onBlur?: React.HTMLProps<HTMLSelectElement>['onBlur'];
  onChange?: React.HTMLProps<HTMLSelectElement>['onChange'];
  showDefaultOption?: boolean;
  value?: string[] | string;
  labelSpacing?: keyof Theme['sizes'];
} & FieldProps;

/**
 * Ref is forwarded to the <select> element using `forwardRef` at the point of export
 */
const Select: React.RefForwardingComponent<HTMLSelectElement, DropdownProps> = (
  {
    children,
    defaultOptionText,
    disabled,
    fullWidth,
    multiple,
    name,
    onBlur,
    onChange,
    showDefaultOption = true,
    value,
    // Field props
    label,
    error,
    helpText,
    id,
    hasControlMargins,
    required,
    size,
    labelSpacing,
    ...props
  },
  ref,
) => (
  <Field
    label={label}
    error={error}
    hasControlMargins={hasControlMargins}
    helpText={helpText}
    id={id}
    required={required}
    size={size}
    labelSpacing={labelSpacing}
  >
    <StyledSelect
      aria-required={required}
      disabled={disabled}
      fullWidth={fullWidth}
      id={id}
      invalid={!!error}
      multiple={multiple}
      name={name}
      onBlur={onBlur}
      onChange={onChange}
      required={required}
      ref={ref}
      value={value}
      {...props}
    >
      {showDefaultOption && <option value="">{defaultOptionText || 'Please select'}</option>}
      {children}
    </StyledSelect>
  </Field>
);

export default forwardRef<HTMLSelectElement, DropdownProps>(Select);
