import React, { useCallback, useState } from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import Select from './Select';

const options = (
  <>
    <option value="1">Option 1</option>
    <option value="2">Option 2</option>
    <option value="3">Option 3</option>
    <option value="4">Option 4</option>
    <option value="5">Option 5</option>
  </>
);

const DefaultDropdown = () => {
  const [value, setValue] = useState<string>('');
  const onChange = useCallback((event: React.ChangeEvent<HTMLSelectElement>) => {
    setValue(event.currentTarget.value);
  }, []);

  return (
    <Select id="storybook" label="My default select field" onChange={onChange} value={value}>
      {options}
    </Select>
  );
};

const MultipleSelectDropdown = () => {
  const [values, setValues] = useState<string[]>([]);
  const onChange = useCallback((event: React.ChangeEvent<HTMLSelectElement>) => {
    const value = Array.from(event.currentTarget.selectedOptions, (option) => option.value);
    setValues(value);
  }, []);

  return (
    <Select
      id="storybook"
      label="My multiple select dropdown Field"
      multiple={true}
      onChange={onChange}
      showDefaultOption={false}
      value={values}
    >
      {options}
    </Select>
  );
};

const RequiredSelectDropdown = () => {
  const [value, setValue] = useState<string>('');
  const onChange = useCallback((event: React.ChangeEvent<HTMLSelectElement>) => {
    setValue(event.currentTarget.value);
  }, []);

  return (
    <Select id="storybook" label="My required dropdown Field" onChange={onChange} required={true} value={value}>
      {options}
    </Select>
  );
};

const DisabledSelectDropdown = () => {
  const [value, setValue] = useState<string>('');
  const onChange = useCallback((event: React.ChangeEvent<HTMLSelectElement>) => {
    setValue(event.currentTarget.value);
  }, []);

  return (
    <Select disabled={true} id="storybook" label="My disabled dropdown Field" onChange={onChange} value={value}>
      {options}
    </Select>
  );
};

const DropdownWithoutADefaultOption = () => {
  const [values, setValue] = useState<string>('');

  const onChange = useCallback((event: React.ChangeEvent<HTMLSelectElement>) => {
    setValue(event.currentTarget.value);
  }, []);

  return (
    <Select
      id="storybook"
      label="My dropdown without 'please select' option"
      onChange={onChange}
      showDefaultOption={false}
      value={values}
    >
      {options}
    </Select>
  );
};

const DropdownWithACustomizedDefaultOptiontext = () => {
  const [value, setValue] = useState<string>('');
  const onChange = useCallback((event: React.ChangeEvent<HTMLSelectElement>) => {
    setValue(event.currentTarget.value);
  }, []);

  return (
    <Select
      defaultOptionText="Select one from the following.."
      id="storybook"
      label="My dropdown with customized default option field text"
      onChange={onChange}
      value={value}
    >
      {options}
    </Select>
  );
};

const DropdownWithAHelptext = () => {
  const [values, setValues] = useState<string>('');
  const onChange = useCallback((event: React.ChangeEvent<HTMLSelectElement>) => {
    setValues(event.currentTarget.value);
  }, []);

  return (
    <Select
      helpText="I am a help text"
      id="storybook"
      label="My dropdown with help text"
      onChange={onChange}
      value={values}
    >
      {options}
    </Select>
  );
};

storiesOf(`${Sections.CORE}|Select`, module)
  .add('Default', () => <DefaultDropdown />)
  .add('Multiple Select Dropdown', () => <MultipleSelectDropdown />)
  .add('Required Dropdown', () => <RequiredSelectDropdown />)
  .add('Disabled Dropdown', () => <DisabledSelectDropdown />)
  .add('Dropdown with a default option', () => <DropdownWithoutADefaultOption />)
  .add('Dropdown with customized default option', () => <DropdownWithACustomizedDefaultOptiontext />)
  .add('Dropdown with help text', () => <DropdownWithAHelptext />);
