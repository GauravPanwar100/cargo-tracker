import React from 'react';
import { render } from 'test-utils';
import DescriptionList from './DescriptionList';

const setup = (extraProps = {}) => {
  const props = { ...extraProps };
  const utils = render(<DescriptionList>Description text</DescriptionList>);
  return { utils, props };
};

describe('DescriptionList', () => {
  it('should be rendered', () => {
    const { utils } = setup();
    utils.getByText('Description text');
  });
});
