import React from 'react';
import { DescriptionList as StyledDescriptionList } from './DescriptionList.styles';

const DescriptionList: React.FC = ({ children }) => <StyledDescriptionList>{children}</StyledDescriptionList>;

export default DescriptionList;
