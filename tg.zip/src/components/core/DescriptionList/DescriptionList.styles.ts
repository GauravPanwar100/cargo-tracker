import styled from 'styled-components';
import { fontLineHeightSize, media } from '@src/lib/util/mixins';

export const DescriptionList = styled.dl`
  ${fontLineHeightSize('base')}
  margin: 0;

  dt {
    font-family: ${(p) => p.theme.fonts.bold};
  }

  dt {
    margin: 0;
  }

  dd {
    margin: 0 0 22px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  ${media.m`
    ${fontLineHeightSize('baseLarge')}

    dd {
      margin: 0 0 24px;
    }
  `}
`;
