import styled, { css } from 'styled-components';
import { MixinProperty, createResponsiveMixin, heightMixin, objectPositionMixin } from '@src/lib/util/mixins';

const aspectRatioMixin = createResponsiveMixin<number>(
  (propValue) => css`
    &:before {
      content: '';
      width: 1px;
      margin-left: -1px;
      float: left;
      height: 0;
      padding-top: calc(${propValue} * 100%);
    }

    &:after {
      content: '';
      display: table;
      clear: both;
    }
  `,
);

interface HeroImageProps {
  aspectRatio?: MixinProperty<number>;
  h?: MixinProperty;
  objectPosition?: MixinProperty;
  dataTestId?: string;
}
export const HeroImage = styled.img<HeroImageProps>`
  display: block;
  width: 100%;
  object-fit: cover;
  ${(p) => heightMixin(p.h)}
  ${(p) => aspectRatioMixin(p.aspectRatio)}
  ${(p) => objectPositionMixin(p.objectPosition)}
`;
