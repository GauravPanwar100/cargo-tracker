export { default } from './HeroImage';
