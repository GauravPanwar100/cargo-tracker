import React from 'react';
import { MixinProperty } from '@src/lib/util/mixins';
import { HeroImage as StyledHeroImage } from './HeroImage.styles';

export interface HeroImageProps {
  alt: string;
  aspectRatio?: MixinProperty<number>;
  height?: MixinProperty;
  objectPosition?: MixinProperty;
  src: string;
}

const HeroImage: React.FC<HeroImageProps> = ({ alt, aspectRatio, height, objectPosition = 'center', src }) => (
  <div>
    <StyledHeroImage
      alt={alt}
      aspectRatio={aspectRatio}
      h={height}
      objectPosition={objectPosition}
      src={src}
      dataTestId="hero-image"
    />
  </div>
);

export default HeroImage;
