import React from 'react';
import { render } from 'test-utils';
import HeroImage, { HeroImageProps } from './HeroImage';

const defaultProps: HeroImageProps = {
  alt: 'alt text',
  src: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/devices/samsung/samsung-galaxy-s10/Samsung-Galaxy-S10-Black-Front-M.jpg',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<HeroImage {...props} />);
  return { utils, props };
};

describe('HeroImage', () => {
  it('should render HeroImage', () => {
    const { utils, props } = setup();
    const image = utils.getByAltText(props.alt) as HTMLImageElement;
    expect(image.src).toBe(props.src);
  });
});
