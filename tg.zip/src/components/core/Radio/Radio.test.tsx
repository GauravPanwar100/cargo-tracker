import Radio, { RadioProps } from '@src/components/core/Radio/Radio';
import React from 'react';
import { fireEvent, render } from 'test-utils';

const defaultProps: RadioProps = {
  id: '1234',
  name: 'radioButtonName',
  value: 'radioButtonValue',
  checked: false,
  onChange: jest.fn(),
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<Radio {...props} />);
  return { utils, props };
};

describe('Radio', () => {
  it('renders radio', () => {
    const { utils } = setup();
    const radioButton = utils.getByTestId('radio-input-radioButtonName');
    expect(radioButton).toBeInTheDocument();
  });
  it('checks input field on click', () => {
    const { utils, props } = setup();
    const input = utils.getByTestId('radio-input-radioButtonName') as HTMLInputElement;
    expect(input.checked).toEqual(false);
    fireEvent.click(input);
    expect(props.onChange).toBeCalled();
  });
  it('renders radio with dynamic height width and margin', () => {
    const { utils } = setup({ height: '18px', width: '18px', wrapperMarginBottom: { xs: '10px' } });
    const radioButton = utils.getByTestId('radio-input-radioButtonName');
    const style = window.getComputedStyle(radioButton);
    expect(style.getPropertyValue('height')).toEqual('18px');
    expect(style.getPropertyValue('height')).toEqual('18px');
  });
});
