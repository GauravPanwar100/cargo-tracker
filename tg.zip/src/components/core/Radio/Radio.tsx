import { MixinProperty } from '@src/lib/util/mixins';
import React from 'react';
import { RadioWrapper } from './Radio.styles';

export type RadioProps = {
  wrapperMarginBottom?: MixinProperty<string>;
} & React.ComponentProps<'input'>;

const Radio: React.FC<RadioProps> = ({
  name,
  id,
  value,
  height = '16px',
  width = '16px',
  wrapperMarginBottom = { xs: '0' },
  checked,
  onChange,
}) => (
  <>
    <RadioWrapper key={id} marginBottom={wrapperMarginBottom}>
      <input
        data-testid={`radio-input-${name}`}
        name={name}
        type="radio"
        id={id}
        value={value}
        onChange={onChange}
        checked={checked}
        style={{ height, width, verticalAlign: 'middle' }}
      />
    </RadioWrapper>
  </>
);

export default Radio;
