import { MixinProperty, marginBottomMixin } from '@src/lib/util/mixins';
import styled from 'styled-components';

interface RadioWrapperProps {
  marginBottom: MixinProperty<string>;
}

export const RadioWrapper = styled.div<RadioWrapperProps>`
  ${(p) => marginBottomMixin(p.marginBottom)}
  &:checked {
    background-color: ${(p) => p.theme.colors.turquoise};
  }
`;
