import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import { GridCol } from '@src/components/core/Grid';
import Radio from './Radio';

storiesOf(`${Sections.CORE}|Radio`, module).add('Default', () => (
  <>
    <GridCol display="flex">
      <Radio value="value" onChange={() => {}} /> Radio Button
    </GridCol>
  </>
));
