import React, { useCallback, useEffect, useRef, useState } from 'react';
import axios, { AxiosResponse } from 'axios';
import { noop } from 'lodash';
import { useDebounceCallback } from '@react-hook/debounce';
import { ReactComponent as LoadingSpinner } from '@src/assets/svg/loading-spinner.svg';
import Input from '@src/components/core/Input';
import IconWrapper from '@src/components/core/IconWrapper';
import Datalist from '@src/components/core/Datalist';
import { ContainerInner, ContainerOuter, Label, LoadingSpinnerContainer } from './AsyncInput.styles';

export interface AsyncInputProps<T, S> {
  className?: string;
  formatEndpointUrl: (searchCriteria: string) => string;
  formatSuggestion?: (suggestion: S) => string;
  forwardedRef?: React.Ref<HTMLInputElement>;
  id: string;
  label?: string;
  name: string;
  noSuggestionsFoundLabel?: React.ReactNode;
  onChange: (value: string) => void;
  onNoSuggestionsFoundSelect?: () => void;
  onSelect: (suggestion: S) => void;
  onSuggestionsLoadError?: () => void;
  onSuggestionsLoadSuccess?: (suggestions: S[]) => void;
  placeholder?: string;
  parseResponse: (response: AxiosResponse<T>, searchCriteria: string) => S[];
  shouldCallApi: (searchCriteria: string) => boolean;
  value: string;
}

type AsyncInputViewState = 'default' | 'error' | 'loading';

const AsyncInput = <T extends object = {}, S = string>({
  className,
  formatEndpointUrl,
  formatSuggestion,
  forwardedRef,
  id,
  label,
  name,
  noSuggestionsFoundLabel,
  onChange: externalOnChange,
  onSelect: externalOnSelect,
  onNoSuggestionsFoundSelect,
  onSuggestionsLoadError = noop,
  onSuggestionsLoadSuccess = noop,
  parseResponse,
  placeholder,
  shouldCallApi,
  value,
}: AsyncInputProps<T, S>) => {
  const [suggestions, setSuggestions] = useState<S[]>([]);
  const [areSuggestionsVisible, setAreSuggestionsVisible] = useState<boolean>(false);
  const [viewState, setViewState] = useState<AsyncInputViewState>('default');
  const isSuggestionClick = useRef<boolean>(false);

  const callApi = useDebounceCallback(async (searchCriteria: string) => {
    setViewState('loading');

    axios({
      method: 'get',
      url: formatEndpointUrl(searchCriteria),
    })
      .then((response) => {
        const parsedSuggestions = parseResponse(response, searchCriteria);
        setSuggestions(parsedSuggestions);
        onSuggestionsLoadSuccess(parsedSuggestions);

        setViewState('default');
      })
      .catch(() => {
        onSuggestionsLoadError();

        setViewState('error');
      });
  }, 300);

  const onBlur = useCallback(() => {
    setAreSuggestionsVisible(false);
  }, []);

  const onChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const { value: newValue } = event.currentTarget;
      if (value !== newValue) {
        setAreSuggestionsVisible(true);
        externalOnChange(newValue);
      }
    },
    [externalOnChange, value],
  );

  const onFocus = useCallback(() => {
    setAreSuggestionsVisible(true);
  }, []);

  const onSelect = useCallback(
    (suggestion: S) => {
      // Keep track of this so we can remember not to call the suggestion API because of a changed value
      isSuggestionClick.current = true;
      // Hide the suggestions when we pick one
      setAreSuggestionsVisible(false);
      // Let the consuming component know about the new selection
      externalOnSelect(suggestion);
    },
    [externalOnSelect],
  );

  // Prevent default on onMouseDown to pass to Datalist. If we don't do this here, then onBlur will be
  // called on the input box before the selection handler for the suggestion can run, because onBlur
  // will have already hidden the suggestions popup, thinking the user has clicked outside of the input
  const onMouseDown = useCallback((event: React.MouseEvent<HTMLElement>) => {
    event.preventDefault();
  }, []);

  useEffect(() => {
    // If the value just changed from clicking one of the autocomplete suggestions, we don't want to
    // call the API
    if (isSuggestionClick.current) {
      isSuggestionClick.current = false;
      return;
    }

    // Custom rules for when we should call the API, mostly just dependent on the length of the entered text
    if (shouldCallApi(value)) {
      callApi(value);
    } else {
      // If the entered text is too short to warrant requesting suggestions, clear them so we aren't
      // showing irrelevant suggestions
      setSuggestions([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- Omit callApi because it is not cached and will trigger the effect every render
  }, [shouldCallApi, value]);

  return (
    <ContainerOuter className={className}>
      {label && <Label htmlFor={id}>{label}</Label>}
      <ContainerInner>
        <Input
          autoComplete="off"
          id={id}
          invalid={viewState === 'error'}
          list="autocomplete-values"
          name={name}
          onBlur={onBlur}
          onChange={onChange}
          onFocus={onFocus}
          placeholder={placeholder}
          ref={forwardedRef}
          value={value}
        />
        {viewState === 'loading' && (
          <LoadingSpinnerContainer>
            <IconWrapper animateRotate={true} color="darkGrey" svg={LoadingSpinner} width="24px" height="24px" />
          </LoadingSpinnerContainer>
        )}
      </ContainerInner>
      {areSuggestionsVisible && shouldCallApi(value) && (
        <Datalist
          formatSuggestion={formatSuggestion}
          noSuggestionsFoundLabel={noSuggestionsFoundLabel}
          onMouseDown={onMouseDown}
          onNoSuggestionsFoundSelect={onNoSuggestionsFoundSelect}
          onSelect={onSelect}
          suggestions={suggestions}
        />
      )}
    </ContainerOuter>
  );
};

export default AsyncInput;
