import styled from 'styled-components';
import { fontLineHeightSize, media } from '@src/lib/util/mixins';

export const ContainerOuter = styled.div`
  position: relative;
  width: 100%;
`;

export const ContainerInner = styled.div`
  position: relative;
`;

export const LoadingSpinnerContainer = styled.div`
  position: absolute;
  right: 16px;
  top: 50%;
  transform: translateY(-50%);
`;
export const Label = styled.label`
  display: inline-block;
  margin-bottom: 8px;
  ${fontLineHeightSize('base')}

  ${media.m`
    ${fontLineHeightSize('baseLarge')}
  `}
`;
