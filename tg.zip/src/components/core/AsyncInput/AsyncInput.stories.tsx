import React, { useCallback, useState } from 'react';
import { storiesOf } from '@storybook/react';
import { formatLocality, parseResponse, shouldCallApi } from '@src/components/core/AsyncLocalityInput/utils';
import { Sections } from '@src/lib/constants/storybook';
import Section from '@src/components/core/Section';
import { Grid, GridCol } from '@src/components/core/Grid';
import { formatLocalityEndpointUrl } from '@src/lib/api';
import { Locality } from '@src/lib/api/types';
import AsyncInput from './AsyncInput';

const Wrapper: React.FC = ({ children }) => (
  <Section>
    <Grid>
      <GridCol gridColSpan={{ xs: 12, m: 4, l: 3 }}>{children}</GridCol>
    </Grid>
  </Section>
);

storiesOf(`${Sections.CORE}|AsyncInput`, module)
  .add('Default', () => {
    const [value, setValue] = useState<string>('');
    const onChange = useCallback((newValue: string) => {
      setValue(newValue);
    }, []);
    const onSelect = useCallback((locality: Locality) => {
      setValue(formatLocality(locality));
    }, []);
    return (
      <Wrapper>
        <AsyncInput
          formatEndpointUrl={formatLocalityEndpointUrl}
          formatSuggestion={formatLocality}
          id="storybook"
          name="autoCompleteAddress"
          onChange={onChange}
          placeholder="Suburb or postcode"
          parseResponse={parseResponse}
          onSelect={onSelect}
          shouldCallApi={shouldCallApi}
          value={value}
        />
      </Wrapper>
    );
  })
  .add('Postcode Input', () => {
    const [value, setValue] = useState<string>('');
    const onChange = useCallback((newValue: string) => {
      setValue(newValue);
    }, []);
    const onSelect = useCallback((locality: Locality) => {
      setValue(`${locality.postcode}`);
    }, []);
    return (
      <Wrapper>
        <AsyncInput
          formatEndpointUrl={formatLocalityEndpointUrl}
          formatSuggestion={formatLocality}
          id="storybook"
          name="autoCompleteAddress"
          onChange={onChange}
          placeholder="Suburb or postcode"
          parseResponse={parseResponse}
          onSelect={onSelect}
          shouldCallApi={shouldCallApi}
          value={value}
        />
      </Wrapper>
    );
  });
