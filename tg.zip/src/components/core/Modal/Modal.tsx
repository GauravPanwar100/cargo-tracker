import React from 'react';
import RichText from '@src/components/core/RichText';
import IconWrapper from '@src/components/core/IconWrapper';
import { ReactComponent as Close } from '@src/assets/svg/close.svg';
import { MixinProperty } from '@src/lib/util/mixins';
import { MergedUnion } from '@src/lib/types';
import {
  CancelButton,
  CancelLink,
  CloseButton,
  ContentWrapper,
  CtaButton,
  CtaLink,
  CtaWrapper,
  StyledModal,
  SubTitle,
  Title,
} from './Modal.styles';
import { ArticleContainer } from '../ArticleContainer/ArticleContainer.styles';

export interface BaseModalProps {
  isOpen: boolean;
  id: string;
  title?: string;
  subTitle?: string;
  content?: string;
  children?: React.ReactNode;
  borderRadius?: MixinProperty<string>;
  maxWidth?: MixinProperty<string>;
  showContentBeforeChildren?: boolean;
  /**
   * This may be `null` if the modal may not be dismissed
   */
  onClose: (() => void) | null;
}

interface CtaProps {
  cancelCtaLabel: string;
  cancelCtaAction: string | (() => void); // href or function
  confirmCtaLabel: string;
  confirmCtaAction: string | (() => void); // href or function
  style?: Object;
}

// MergedUnion allows ModalProps to have either all of CtaProps, or to have them all `undefined`
export type ModalProps = BaseModalProps & MergedUnion<CtaProps | {}>;
/** This Modal core is opiniated, and seems to originally be built for Global Modal (driven from AEM) not a true blank Modal.
 *  If there are more use cases it'll be good to pull layout-related things out so that
 *    this component is only responsible for the representation of the Modal on the screen (the overlay of Modal body on the page)
 *    while the arrangements of the layout can be in own modules.
 *
 *  - CartSplitter and ErrorModal currently uses this as HOC. The refactor should also use it this way and pull out the whole Title-Content-CTA section.
 *
 *  Split this out into GlobalModal and base Modal component
 *  - aim so that GlobalModal is rendered into Modal {children} like how CartSplitter is now. Modal is only responsible for Modal-Base page relationship.
 *  - Title, Content, CTA structures can be moved into own AEMModals (aka GlobalModal) module.
 *  - pull out the associated props as well.
 */
const Modal = ({
  cancelCtaAction,
  cancelCtaLabel,
  children,
  confirmCtaAction,
  confirmCtaLabel,
  content,
  id,
  isOpen,
  onClose,
  title,
  subTitle,
  showContentBeforeChildren = true,
  ...props
}: ModalProps) => {
  const onClickClose = React.useCallback(() => onClose?.(), [onClose]);

  const contentItem = (
    <ArticleContainer>
      <RichText>{content}</RichText>
    </ArticleContainer>
  );

  return (
    <StyledModal isOpen={isOpen} onBackgroundClick={onClickClose} data-testid={`modal-${id}`} {...props}>
      {onClose && (
        <CloseButton onClick={onClickClose} data-testid="modal-close-button">
          <IconWrapper svg={Close} width="24px" height="24px" color="darkGrey" />
        </CloseButton>
      )}
      {/* GlobalModal layout */}
      <ContentWrapper>
        {title && <Title data-testid="modal-title">{title}</Title>}
        {subTitle && <SubTitle>{subTitle}</SubTitle>}
        {content && showContentBeforeChildren && contentItem}
      </ContentWrapper>
      {/* HOC */}
      {children && <>{children}</>}
      {content && !showContentBeforeChildren && <ContentWrapper>{contentItem}</ContentWrapper>}
      {/* GlobalModal layout */}
      {confirmCtaLabel && (
        <CtaWrapper>
          {typeof cancelCtaAction === 'string' ? (
            <CancelLink href={cancelCtaAction} data-testid="cta-link-cancel">
              <CancelButton variant="tertiary">{cancelCtaLabel}</CancelButton>
            </CancelLink>
          ) : (
            <CancelButton variant="tertiary" onClick={cancelCtaAction} data-testid="cta-button-cancel">
              {cancelCtaLabel}
            </CancelButton>
          )}
          {typeof confirmCtaAction === 'string' ? (
            <CtaLink href={confirmCtaAction} data-testid="cta-link-confirm">
              <CtaButton variant="primary">{confirmCtaLabel}</CtaButton>
            </CtaLink>
          ) : (
            <CtaButton variant="primary" onClick={confirmCtaAction} data-testid="cta-button-confirm">
              {confirmCtaLabel}
            </CtaButton>
          )}
        </CtaWrapper>
      )}
    </StyledModal>
  );
};

export default Modal;
