/* eslint-disable @typescript-eslint/no-explicit-any */
import styled from 'styled-components';
import StyledReactModal from 'styled-react-modal';
import Button from '@src/components/core/Button';
import {
  borderRadiusMixin,
  buttonReset,
  fontLineHeightSize,
  fontSizeLineHeightMixin,
  maxWidthMixin,
  media,
} from '@src/lib/util/mixins';

export const StyledModal = StyledReactModal.styled`
  position: relative;
  border-radius: 0;
  display: flex;
  flex-direction: column;
  background-color: ${(p: any) => p.theme.colors.white};
  padding: 24px 16px 32px;
  width: 100%;  
  max-height: 95%;
  overflow-y: auto;

  ${media.m`
    padding: 40px 60px 48px;
    ${(p: any) => borderRadiusMixin(p.borderRadius ?? '6px')}
    ${(p: any) => maxWidthMixin(p.maxWidth ?? { m: '768px' })};
    margin: 0 16px;
  `}
`;

export const CloseButton = styled.button`
  ${buttonReset}
  align-self: flex-end;
  cursor: pointer;
  z-index: 10;
  position: fixed;
  transform: translateY(-8px);

  ${media.m`
    transform: translate(40px, -20px);
  `}
`;

export const ContentWrapper = styled.div`
  // Note: Using the CSS child combinator (>) here with * as we cannot used styled(RichText) here
  // due to circular dependencies. This selector targets the first child of RichText (likely a
  // heading) to apply a right margin to avoid overlap with the close button. This is not required
  // for wider breakpoints as the Modal's intrinsic padding is larger than the close button.
  & > * > * > :first-child {
    margin-right: 24px;

    ${media.m`
      margin-right: 0;
    `}
  }

  ${media.xs`
    table {
      width: 640px;
      font-size: ${(p) => p.theme.fontSizes.baseSmall}px;
    }
  `}

  ${media.s`
    table {
      width: 768px;
      font-size: ${(p) => p.theme.fontSizes.base}px;
    }
  `}

  ${media.m`
    table {
      width: 768px;
      font-size: ${(p) => p.theme.fontSizes.base}px;
    }
  `}

  ${media.l`
    table {
      width: 100% !important;
      font-size: ${(p) => p.theme.fontSizes.baseLarge}px;
    }
  `}
`;

export const Title = styled.h3`
  display: flex;
  align-items: center;
  font-family: ${(p) => p.theme.fonts.light};
  ${fontLineHeightSize('heading3Mobile')};
  padding-bottom: 16px;
  margin-right: 12px;

  ${media.m`
    ${fontLineHeightSize('heading3')};
  `}
`;

export const SubTitle = styled.p`
  display: flex;
  align-items: center;
  margin-right: 12px;
  padding-bottom: 16px;
  ${fontSizeLineHeightMixin({ xs: 'base', m: 'baseLarge' })}
`;

export const CtaWrapper = styled.div`
  display: grid;
  grid-template-areas:
    'cta'
    'cancel';
  row-gap: 16px;
  column-gap: 32px;
  margin-top: 24px;

  ${media.m`
    grid-template-areas: 'cancel cta';
    justify-content: end;
    align-items: center;
    margin-top: 32px;
    margin-left: auto;
  `}
`;

export const CtaLink = styled.a`
  grid-area: cta;
  text-decoration: none;
`;

export const CtaButton = styled(Button)`
  grid-area: cta;

  &:focus {
    box-shadow: none;
  }
`;

export const CancelButton = styled(Button)`
  grid-area: cancel;
  border: none;
  text-decoration: underline;
  font-size: 16px;
  padding: 0;
  min-width: 0;

  &:hover,
  &:focus,
  &:active {
    background: transparent;
    box-shadow: none;
    transform: none;
    color: ${(p) => p.theme.colors.red};
  }
`;

export const CancelLink = styled.a`
  grid-area: cancel;
  text-decoration: underline;
  transition: all 0.2s ease-in-out;
  &:hover {
    color: ${(p) => p.theme.colors.focusColor};
  }
`;
