import React from 'react';
import { render } from 'test-utils';
import Modal, { ModalProps } from './Modal';

const defaultProps: ModalProps = {
  isOpen: true,
  onClose: jest.fn(),
  id: 'id',
  title: 'title',
  content:
    '&lt;p&gt;&lt;b&gt;Remaining phone balance&lt;br&gt;&lt;br&gt;&lt;/b&gt;To get a new phone today, you&rsquo;ll need to pay $90.00 on your next bill. This is the remaining balance for your current phone.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Here are some other repayment options&lt;br&gt;&lt;br&gt;&lt;/b&gt;Give us a call on 1555 to discuss these options.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;You could trade-up your current phone if eligible and put the amount towards your new phone&lt;/li&gt;&lt;li&gt;You could pay the monthly repayments of your new phone if eligible, together with the repayments of your current phone&lt;/li&gt;&lt;/ul&gt;',
};

jest.mock('styled-react-modal', () => ({
  default: {
    // eslint-disable-next-line global-require
    styled: jest.fn().mockReturnValue(require('@kablamo/kerosene-test').createStubComponent('StyledModal')),
  },
  __esModule: true,
}));

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<Modal {...props} />);
  return { utils, props };
};

describe('Modal', () => {
  it('should render the content', () => {
    const { utils } = setup();
    utils.getByTestId('modal-id');
  });

  it('should call onClose on close', () => {
    const { utils, props } = setup();
    const closeButton = utils.getByTestId('modal-close-button') as HTMLButtonElement;
    closeButton.click();
    expect(props.onClose).toBeCalled();
  });

  it('should call onConfirm when confirmCta is clicked', () => {
    const onConfirm = jest.fn();
    const extraProps = {
      confirmCtaAction: onConfirm,
      confirmCtaLabel: 'Confirm',
    };
    const { utils } = setup(extraProps);
    const confirmButton = utils.getByTestId('cta-button-confirm') as HTMLButtonElement;
    confirmButton.click();
    expect(onConfirm).toBeCalled();
  });

  it('should call onCancel when cancelCta is clicked', () => {
    const onCancel = jest.fn();
    const extraProps = {
      cancelCtaAction: onCancel,
      confirmCtaLabel: 'Confirm',
      cancelCtaLabel: 'Cancel',
    };
    const { utils } = setup(extraProps);
    const cancelButton = utils.getByTestId('cta-button-cancel') as HTMLButtonElement;
    cancelButton.click();
    expect(onCancel).toBeCalled();
  });

  it('should contain the Cta buttons', () => {
    const { utils } = setup({
      cancelCtaLabel: 'cancel',
      cancelCtaAction: 'cancel',
      confirmCtaLabel: 'confirm',
      confirmCtaAction: 'confirmlink',
    });
    utils.getByTestId('cta-link-cancel');
    utils.getByTestId('cta-link-confirm');
  });

  it('should not have Title child when title is absent', () => {
    const { utils } = setup({ title: '' });
    expect(utils.queryByTestId(/modal-title/i)).toBeNull();
  });
});
