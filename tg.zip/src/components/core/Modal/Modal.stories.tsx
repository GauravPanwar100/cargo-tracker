import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import Modal from './Modal';

const defaultProps = (isOpen: boolean, setOpen: React.Dispatch<React.SetStateAction<boolean>>) => ({
  isOpen,
  onClose: () => setOpen(false),
  id: 'Some String',
  title: 'Title',
  content:
    '&lt;p&gt;An eSIM, as opposed to a physical SIM card, is a SIM that&rsquo;s already embedded into selected mobile phones, tablets and smart watches.&lt;/p&gt;&lt;p&gt;An eSIM allows you to use up to 5 different numbers on the same device.&lt;/p&gt;&lt;p&gt;For example, you&rsquo;ll be able to use one number for business and another number for personal use.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Popular eSIM enabled devices with Vodafone&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Here are some popular eSIM enabled devices with Vodafone.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;iPhone 11&amp;nbsp;&lt;/li&gt;&lt;li&gt;iPhone 11 Pro&lt;/li&gt;&lt;li&gt;iPhone 11 Pro Max&lt;/li&gt;&lt;li&gt;iPhone XR&lt;/li&gt;&lt;li&gt;iPhone XS&lt;/li&gt;&lt;li&gt;iPhone XS Max&lt;/li&gt;&lt;li&gt;10.5 inch iPad Air&lt;/li&gt;&lt;li&gt;11 inch iPad Pro&lt;/li&gt;&lt;li&gt;12.9 inch iPad Pro&lt;/li&gt;&lt;li&gt;iPad (7&lt;sup&gt;th&lt;/sup&gt; gen)&lt;/li&gt;&lt;li&gt;iPad mini&lt;/li&gt;&lt;/ul&gt;',
});

const Default = () => {
  const [open, setOpen] = React.useState(true);
  const props = defaultProps(open, setOpen);
  return <Modal {...props} />;
};

const CTA = () => {
  const [open, setOpen] = React.useState(true);
  const props = defaultProps(open, setOpen);
  return (
    <Modal
      {...props}
      cancelCtaLabel="No, go back"
      cancelCtaAction="http://localhost:9009/?path=/story/core-modal--default"
      confirmCtaLabel="Confirm"
      confirmCtaAction="http://localhost:9009/?path=/story/core-modal--default"
    />
  );
};

const WithoutTitle = () => {
  const [open, setOpen] = React.useState(true);
  const props = defaultProps(open, setOpen);
  return <Modal {...props} title="" />;
};

storiesOf(`${Sections.CORE}|Modal`, module).add('Default', () => <Default />);
storiesOf(`${Sections.CORE}|Modal`, module).add('CTA Buttons', () => <CTA />);
storiesOf(`${Sections.CORE}|Modal`, module).add('Without Title', () => <WithoutTitle />);
