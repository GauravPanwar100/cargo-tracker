import React from 'react';
import { render } from 'test-utils';
import Youtube, { YoutubeProps } from './Youtube';

const defaultProps: YoutubeProps = {
  url: 'https://www.youtube.com/watch?v=5XQOK0v_YRE',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<Youtube {...props} />);
  return { utils, props };
};

describe('Sticky', () => {
  it('should render Sticky', () => {
    const { utils, props } = setup();
    const iframe = utils.getByTestId('youtube') as HTMLIFrameElement;
    expect(iframe.src).toBe(props.url);
  });
});
