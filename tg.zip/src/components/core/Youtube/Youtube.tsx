import React from 'react';
import { Container, IFrame } from './Youtube.styles';

export interface YoutubeProps {
  url: string;
}

const Youtube: React.FC<YoutubeProps> = ({ url }) => (
  <Container>
    <IFrame frameBorder={0} src={url} data-testid="youtube" loading="lazy" />
  </Container>
);

export default Youtube;
