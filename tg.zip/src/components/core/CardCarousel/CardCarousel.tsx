import { useUpliftDataContent } from '@src/lib/context/uplift-data-provider';
import React, { useEffect, useState } from 'react';
import Slider, { Settings as SliderSettings } from 'react-slick';
import {
  BlockItem,
  BlockView,
  CarouselView,
  Container,
  Dot,
  DotContainer,
  PageArrow,
  Slide,
} from './CardCarousel.styles';

interface CarouselItem {
  component: JSX.Element;
  id: string;
  tabletStyles?: string;
}
interface CardCarouselProps {
  children: CarouselItem[];
  id: string;
  sliderRef?: (node: Slider) => void;
}

const CAROUSEL_BLOCK_VIEW_ID = 'carousel-block-view';
export const makeCarouselBlockViewId = (id: string) => `${CAROUSEL_BLOCK_VIEW_ID}-${id}`;

const CardCarousel: React.FC<CardCarouselProps> = ({ children, id, sliderRef }) => {
  const [isInitialised, setIsInitialised] = React.useState(false);
  const upliftEnabled = useUpliftDataContent();

  const slidesToShow = 3;
  const inputRef = React.useRef<HTMLInputElement>(null);

  const [carouselProps, setCarouselProps] = useState({});

  const handleScroll = () => {
    const { offsetLeft: left, offsetWidth: width } = inputRef.current || {};
    const { bottom, top } = inputRef.current?.getBoundingClientRect() || {};
    setCarouselProps({
      bottom,
      left,
      top,
      width,
    });
  };

  const settings: SliderSettings = {
    dots: true,
    infinite: false,
    swipeToSlide: true,
    slidesToShow,
    slidesToScroll: 1,
    prevArrow: <PageArrow hostingContainer={carouselProps} />,
    nextArrow: <PageArrow isNext={true} hostingContainer={carouselProps} />,
    customPaging: () => <Dot />,
    appendDots: (dots: JSX.Element) => <DotContainer>{dots}</DotContainer>,
    onInit: () => setIsInitialised(true),
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <Container columns={children?.length} id={id} isInitialised={isInitialised} slidesToShow={slidesToShow}>
      <CarouselView ref={inputRef}>
        {children?.length > 0 && (
          <Slider {...settings} ref={sliderRef}>
            {children?.map((carouselItem) => (
              <Slide key={carouselItem.id}>{carouselItem.component}</Slide>
            ))}
          </Slider>
        )}
      </CarouselView>
      <BlockView id={makeCarouselBlockViewId(id)} upliftEnabled={upliftEnabled}>
        {children?.map((carouselItem) => (
          <BlockItem key={carouselItem.id} tabletStyles={carouselItem.tabletStyles}>
            {carouselItem.component}
          </BlockItem>
        ))}
      </BlockView>
    </Container>
  );
};

export default CardCarousel;
