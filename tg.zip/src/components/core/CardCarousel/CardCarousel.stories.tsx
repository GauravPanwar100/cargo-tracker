import React, { useCallback } from 'react';
import { storiesOf } from '@storybook/react';
import { CatalogCode } from '@src/lib/api/types';
import { Sections } from '@src/lib/constants/storybook';
import { mockPlans } from '@src/lib/mock-data';
import CardCarousel from './CardCarousel';
import Section from '../Section';
import PostpaidMobilePlanCard from '../../vfe/PlanSelectorCard/PostpaidMobilePlanCard';

const plans = mockPlans;

storiesOf(`${Sections.CORE}|CardCarousel`, module).add('default', () => {
  const onCtaClick = useCallback(() => Promise.resolve(), []);

  return (
    <Section>
      <CardCarousel id="storybook">
        {plans.map((plan, index) => {
          const shouldPadTablet = index % 2 === 1 && plans[index - 1].heroLabel;
          return {
            component: (
              <PostpaidMobilePlanCard
                catalogCode={CatalogCode.POSTPAID_HANDSET_PLANS}
                key={plan.planId}
                onCtaClick={onCtaClick}
                plan={plan}
              />
            ),
            id: plan.planId,
            tabletStyles: shouldPadTablet ? 'padding-top: 36px;' : '',
          };
        })}
      </CardCarousel>
    </Section>
  );
});
