export { default, makeCarouselBlockViewId } from './CardCarousel';
