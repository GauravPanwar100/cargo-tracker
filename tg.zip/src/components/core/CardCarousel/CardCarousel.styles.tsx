import styled from 'styled-components';
import { media } from '@src/lib/util/mixins';

interface BlockItemProps {
  tabletStyles?: string;
}

interface BlockViewProps {
  upliftEnabled?: boolean;
}

interface ContainerProps {
  columns: number;
  isInitialised: boolean;
  slidesToShow: number;
}

interface PageArrowContainerProps {
  bottom?: number;
  left?: number;
  top?: number;
  width?: number;
}
interface PageArrowProps {
  isNext?: boolean;
  hostingContainer: PageArrowContainerProps;
}

export const Dot = styled.div`
  width: 10px;
  height: 10px;
  border-radius: 6px;
  background-color: ${(p) => p.theme.colors.midGrey};
`;

export const Slide = styled.div`
  padding: 0 10px 10px;
  outline: none;
`;

export const BlockItem = styled.div<BlockItemProps>`
  ${media.m<BlockItemProps>`
    ${(p) => p.tabletStyles};
  `}

  ${media.l`
    display: none;
  `}
`;

export const Container = styled.div<ContainerProps>`
  & .slick-slider {
    display: grid;
    & > div.slick-disabled {
      display: none !important;
    }
  }

  & .slick-track {
    display: grid;
    width: 100%;
    grid-template-columns: repeat(${(p) => p.columns}, 1fr);

    & .slick-slide {
      width: 100% !important;
      &:nth-child(1n + ${(p) => p.slidesToShow + 1}) {
        display: ${(p) => (p.isInitialised ? 'block' : 'none')};
      }
      &:first-child {
        grid-column-start: 1;
      }
      & > div {
        height: 100%;

        ${Slide} {
          height: 100%;
        }
      }
    }
  }

  & .slick-active {
    ${Dot} {
      width: 12px;
      height: 12px;
      border: solid 2px ${(p) => p.theme.colors.darkGrey};
      background-color: transparent;
    }
  }

  & .slick-dots {
    position: relative;
  }

  & .slick-dots li {
    width: 12px;
    height: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  & .slick-list {
    margin-bottom: -10px;
  }
`;

export const DotContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: ${(p) => p.theme.sizes.modulePaddingSmallMedium}px;
  bottom: 0px;
`;

const arrowPositionFromTop = 180;
const arrowPaddingBottom = 280;

export const PageArrow = styled.div<PageArrowProps>`
  width: 48px;
  height: 48px;
  border-radius: 24px;
  box-shadow: 0 1px 4px 1px rgba(130, 130, 130, 0.5);
  background-color: ${(p) => p.theme.colors.white} !important;

  ${(p) => {
    if (!p.hostingContainer) return {};
    const {
      hostingContainer: {
        bottom: containerBottom = 0,
        left: containerLeft = 0,
        top: containerTop = 0,
        width: containerWidth = 0,
      },
    } = p;

    const isScrollInContainer = containerTop < 0 && containerBottom > 0;
    const isScrollPastContainer = containerBottom !== 0 && containerBottom <= arrowPaddingBottom;
    const commonStyles = {
      top: isScrollPastContainer ? `92%` : `${arrowPositionFromTop}px`,
      position: isScrollInContainer && !isScrollPastContainer ? 'fixed' : 'absolute',
      'z-index': '800',
    };

    return p.isNext
      ? {
          ...commonStyles,
          left: isScrollInContainer && !isScrollPastContainer ? `${containerLeft + containerWidth + 18}px` : '',
          right: !isScrollInContainer || isScrollPastContainer ? '-66px' : '',
        }
      : {
          ...commonStyles,
          left: isScrollInContainer && !isScrollPastContainer ? `${containerLeft - 66}px` : `-66px`,
        };
  }}

  &:before {
    content: '';
  }

  &:after {
    display: block;
    content: '';
    width: 36px;
    height: 36px;
    position: absolute;
    left: ${(p) => (p.isNext ? '9px' : '2px')};
    top: ${(p) => (p.isNext ? '22px' : '26px')};
    transform: translateY(-50%) rotate(${(p) => (p.isNext ? '270deg' : '90deg')});
    background-image: url("data:image/svg+xml, %3Csvg width='36' height='36' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath fill='none' d='M32 0H0v32h32z' /%3E%3Cpath stroke=${(
      prop,
    ) =>
      `'${prop.theme.colors.greyDark.replace(
        '#',
        '%23',
      )}'`} stroke-linecap='round' stroke-linejoin='round' d='M4.667 11.333L16 22.667l11.333-11.334' /%3E%3C/g%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right center;
    background-size: contain;
  }

  :hover::after {
    background-image: url("data:image/svg+xml, %3Csvg width='36' height='36' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath fill='none' d='M32 0H0v32h32z' /%3E%3Cpath stroke=${(
      prop,
    ) =>
      `'${prop.theme.colors.red.replace(
        '#',
        '%23',
      )}'`} stroke-linecap='round' stroke-linejoin='round' d='M4.667 11.333L16 22.667l11.333-11.334' /%3E%3C/g%3E%3C/svg%3E");
  }
`;

export const CarouselView = styled.div`
  display: none;
  ${media.l`
    display: block;
  `}
`;

export const BlockView = styled.div<BlockViewProps>`
  display: grid;
  grid-template-columns: 1fr;
  grid-column-gap: 20px;
  grid-row-gap: 32px;

  ${media.m`
    grid-template-columns: 1fr 1fr;
  `}

  ${media.l`
    display: none;
  `}
`;
