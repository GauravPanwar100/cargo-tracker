import React, { useCallback } from 'react';
import { noop } from 'lodash';
import Field from '@src/components/core/Field';
import { FieldProps } from '@src/components/core/Field/Field';
import RadioButtonGroup from '@src/components/core/RadioButtonGroup';
import { RadioButtonGroupProps } from '@src/components/core/RadioButtonGroup/RadioButtonGroup';
import { DeviceBandColor, DeviceColor } from '@src/lib/api/types';
import ColorInput from './ColorInput';

export type ColorPickerProps = {
  colors: DeviceColor[] | DeviceBandColor[];
  onChange?: (value: DeviceColor) => void;
  value?: DeviceColor | DeviceBandColor;
} & FieldProps &
  Omit<RadioButtonGroupProps, 'onChange' | 'value'>;

const ColorPicker: React.FC<ColorPickerProps> = ({
  colors,
  disabled,
  name,
  onChange: externalOnChange = noop,
  value,
  // Field props
  className,
  error,
  id,
  hasControlMargins = true,
  label,
  required,
  size = 'large',
}) => {
  let labelContent: React.ReactNode = label;
  if (value) {
    labelContent = (
      <>
        {label}
        {': '}
        <strong>{value.label}</strong>
      </>
    );
  }

  const onChange = useCallback(
    (v: string) => {
      const color = colors.find((c) => c.value === v);
      if (!color) {
        return;
      }

      externalOnChange(color);
    },
    [colors, externalOnChange],
  );

  return (
    <Field
      className={className}
      error={error}
      hasControlMargins={hasControlMargins}
      id={id}
      label={labelContent}
      required={required}
      size={size}
    >
      <RadioButtonGroup disabled={disabled} id={id} name={name} onChange={onChange} value={value?.value ?? ''}>
        {colors.map((color) => (
          <ColorInput hex={`#${color.hexCode ?? '000000'}`} id={color.label} key={color.value} value={color.label} />
        ))}
      </RadioButtonGroup>
    </Field>
  );
};

export default ColorPicker;
