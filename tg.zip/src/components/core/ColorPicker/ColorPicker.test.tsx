import React from 'react';
import { fireEvent, render } from 'test-utils';
import { DeviceColor } from '@src/lib/api/types';
import ColorPicker, { ColorPickerProps } from './ColorPicker';

const colors: DeviceColor[] = [
  {
    value: 'Black',
    disabled: false,
    readonly: false,
    defaultSelected: false,
    label: 'Black',
    hexCode: '000000',
    images: [
      {
        imageUrl: '/content/dam/vha/IPH_XR.png',
        altText: '',
        useInCart: true,
      },
      {
        imageUrl: '/content/dam/vha/devices/apple/iphone-xr-black-box-201809.jpeg',
        altText: '',
        useInCart: false,
      },
    ],
  },
  {
    value: 'White',
    disabled: false,
    readonly: false,
    defaultSelected: true,
    label: 'White',
    hexCode: 'FFFFFF',
    images: [
      {
        imageUrl: '/content/dam/vha/IPH_XR_WHITE.png',
        altText: '',
        useInCart: false,
      },
      {
        imageUrl: '/content/dam/vha/IPH_XR_WHITE_2.jpg',
        altText: '',
        useInCart: false,
      },
    ],
  },
  {
    value: '(PRODUCT)RED™',
    disabled: false,
    readonly: false,
    defaultSelected: false,
    label: '(PRODUCT)RED™',
    hexCode: '950517',
    images: [
      {
        imageUrl: '/content/dam/vha/devices/apple/iphone-xr-red-select-201809 (1).png',
        altText: '',
        useInCart: true,
      },
    ],
  },
];

const defaultProps: ColorPickerProps = {
  id: 'unit-test-color-picker',
  label: 'Choose your phone color',
  onChange: jest.fn(),
  colors,
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<ColorPicker {...props} />);
  return { utils, props };
};

describe('ColorPicker', () => {
  it('should render color picker with a label', () => {
    const { utils } = setup();
    utils.getByText('Choose your phone color');
  });

  it('should fire onChange with the selected colour.', () => {
    const { utils, props } = setup();
    const whiteButton = utils.getByTestId('color-input-white');
    fireEvent.click(whiteButton);
    expect(props.onChange).toBeCalledWith(props.colors[1]);
    const blackButton = utils.getByTestId('color-input-black');
    fireEvent.click(blackButton);
    expect(props.onChange).toBeCalledWith(props.colors[0]);
  });

  it('should not fire onChange when disabled.', () => {
    const { utils } = setup({ onChange: jest.fn(), disabled: true });
    const whiteButton = utils.getByTestId('color-input-white') as HTMLInputElement;
    expect(whiteButton.disabled).toBeTruthy();
  });
});
