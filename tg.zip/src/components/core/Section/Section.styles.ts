import styled, { css } from 'styled-components';
import {
  MixinProperty,
  alignItemsMixin,
  bottomMixin,
  boxShadowMixin,
  colorMixin,
  createResponsiveMixin,
  displayMixin,
  flexDirectionMixin,
  heightMixin,
  leftMixin,
  marginMixin,
  paddingLeftMixin,
  paddingRightMixin,
  positionMixin,
  rightMixin,
  topMixin,
  variantThemeColors,
  widthMixin,
} from '@src/lib/util/mixins';
import { ColorKey, SpacingKey } from '@src/lib/theme';

const spacingTopMixin = createResponsiveMixin<SpacingKey>(
  (propValue) =>
    css`
      padding-top: ${(p) => p.theme.spacing[propValue]}px;
    `,
);

const spacingBottomMixin = createResponsiveMixin<SpacingKey>(
  (propValue) =>
    css`
      padding-bottom: ${(p) => p.theme.spacing[propValue]}px;
    `,
);

interface SectionProps {
  backgroundColor?: boolean;
  spacingBottom?: MixinProperty<SpacingKey>;
  spacingHorizontal?: boolean;
  spacingTop?: MixinProperty<SpacingKey>;
  backgroundColorValue?: string;
  spacingRight?: MixinProperty<string>;
  spacingLeft?: MixinProperty<string>;
  margin?: MixinProperty<string>;
  fixedHeight?: MixinProperty<string>;
  fixedWidth?: MixinProperty<string>;
  boxShadowValue?: MixinProperty<string>;
  zIndexValue?: string;
  topValue?: MixinProperty<string>;
  rightValue?: MixinProperty<string>;
  bottomValue?: MixinProperty<string>;
  leftValue?: MixinProperty<string>;
  positionValue?: MixinProperty<string>;
  colorValue?: MixinProperty<ColorKey>;
  displayValue?: MixinProperty<string>;
  alignItemsValue?: MixinProperty<string>;
  flexDirectionValue?: MixinProperty<string>;
}
export const Section = styled.section<SectionProps>`
  ${(p) => spacingTopMixin(p.spacingTop)}
  ${(p) => spacingBottomMixin(p.spacingBottom)}
  ${(p) => p.spacingHorizontal && paddingRightMixin(p.spacingRight)}
  ${(p) => p.spacingHorizontal && paddingLeftMixin(p.spacingLeft)}
  ${(p) => marginMixin(p.margin)}
  ${(p) => p.fixedHeight && heightMixin(p.fixedHeight)}
  ${(p) => p.fixedWidth && widthMixin(p.fixedWidth)}
  ${(p) => p.boxShadowValue && boxShadowMixin(p.boxShadowValue)}
  ${(p) => p.colorValue && colorMixin(p.colorValue)}
  ${(p) => p.positionValue && positionMixin(p.positionValue)}
  ${(p) => p.topValue && topMixin(p.topValue)}
  ${(p) => p.rightValue && rightMixin(p.rightValue)}
  ${(p) => p.bottomValue && bottomMixin(p.bottomValue)}
  ${(p) => p.leftValue && leftMixin(p.leftValue)}
  ${(p) => p.displayValue && displayMixin(p.displayValue)}
  ${(p) => p.alignItemsValue && alignItemsMixin(p.alignItemsValue)}
  ${(p) => p.flexDirectionValue && flexDirectionMixin(p.flexDirectionValue)}

  ${(p) =>
    p.zIndexValue &&
    css`
      z-index: ${p.zIndexValue};
    `}
  
  ${variantThemeColors}
  ${(p) =>
    !p.backgroundColor &&
    css`
      background-color: transparent;
    `}
  ${(p) =>
    p.backgroundColorValue &&
    css`
      background-color: ${p.backgroundColorValue};
    `}
`;
