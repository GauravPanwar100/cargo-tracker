import React, { forwardRef } from 'react';
import { ColorKey, SpacingKey, spacing } from '@src/lib/theme';
import { MixinProperty } from '@src/lib/util/mixins';
import { Section as StyledSection } from './Section.styles';

interface SectionProps {
  backgroundColor?: boolean;
  children?: React.ReactNode;
  spacingBottom?: MixinProperty<SpacingKey>;
  spacingHorizontal?: boolean;
  spacingTop?: MixinProperty<SpacingKey>;
  backgroundColorValue?: string;
  spacingRight?: MixinProperty<string>;
  spacingLeft?: MixinProperty<string>;
  margin?: MixinProperty<string>;
  fixedHeight?: MixinProperty<string>;
  fixedWidth?: MixinProperty<string>;
  boxShadowValue?: MixinProperty<string>;
  zIndexValue?: string;
  topValue?: MixinProperty<string>;
  rightValue?: MixinProperty<string>;
  bottomValue?: MixinProperty<string>;
  leftValue?: MixinProperty<string>;
  positionValue?: MixinProperty<string>;
  colorValue?: MixinProperty<ColorKey>;
  displayValue?: MixinProperty<string>;
  alignItemsValue?: MixinProperty<string>;
  flexDirectionValue?: MixinProperty<string>;
}

/**
 * default spacingTop = 32px mobile, 48px tablet+
 * default spacingBottom = 32px mobile, 60px tablet+
 * If you pass your own spacingBottom or spacingTop objects, you should try to always specify values
 * for at least both xs and m screen sizes
 */
const Section: React.ForwardRefRenderFunction<HTMLDivElement, SectionProps> = (
  {
    backgroundColor = true,
    spacingBottom = { xs: 's', m: 'xxl' },
    spacingHorizontal = true,
    spacingTop = { xs: 's', m: 'l' },
    backgroundColorValue,
    spacingRight = { xs: `${spacing.xxs}px`, xl: `${spacing.none}` },
    spacingLeft = { xs: `${spacing.xxs}px`, xl: `${spacing.none}` },
    ...props
  }: SectionProps,
  ref,
) => (
  <StyledSection
    backgroundColor={backgroundColor}
    spacingBottom={spacingBottom}
    spacingHorizontal={spacingHorizontal}
    spacingTop={spacingTop}
    backgroundColorValue={backgroundColorValue}
    spacingRight={spacingRight}
    spacingLeft={spacingLeft}
    ref={ref}
    {...props}
  />
);

export default forwardRef(Section);
