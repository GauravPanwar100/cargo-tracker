import React, { useEffect, useState } from 'react';
import AnimateHeight from 'react-animate-height';

interface AnimateOpenOnMountProps {
  delay?: number;
  disabled?: boolean;
}

const AnimateOpenOnMount: React.FC<AnimateOpenOnMountProps> = ({ children, delay, disabled }) => {
  const [isMounted, setIsMounted] = useState<boolean>(false);
  useEffect(() => {
    setIsMounted(true);
  }, []);

  const height = isMounted || disabled ? 'auto' : 0;

  return (
    <AnimateHeight delay={delay} duration={250} height={height}>
      {children}
    </AnimateHeight>
  );
};

export default AnimateOpenOnMount;
