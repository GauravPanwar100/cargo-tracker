import React from 'react';
import LoadingOverlay from 'react-loading-overlay';
import IconWrapper from '@src/components/core/IconWrapper';
import { ColorKey } from '@src/lib/theme';
import { ReactComponent as LoadingSpinner } from '@src/assets/svg/loading-spinner.svg';
import { IconContainer } from '@src/components/vfe/ServiceCard/ServiceCardTitle/ServiceCardTitle.styles';

export interface PageSpinnerProps {
  active: boolean;
  children: React.ReactNode;
  color?: ColorKey;
  width?: number;
  height?: number;
  background?: string;
  opacity?: number;
  position?: string;
}

const PageSpinner: React.FC<PageSpinnerProps> = ({
  active,
  children,
  color = 'darkGrey',
  width = 48,
  height = 48,
  position = 'fixed',
}) => (
  <LoadingOverlay
    active={active}
    spinner={
      <IconContainer data-testid="page-spinner-icon">
        <IconWrapper
          animateRotate={true}
          color={color}
          svg={LoadingSpinner}
          width={`${width}px`}
          height={`${height}px`}
          position={`${position}`}
          top={`calc(50% - ${height / 2}px)`}
          left={`calc(50% - ${width / 2}px)`}
        />
      </IconContainer>
    }
    styles={{
      /* eslint-disable @typescript-eslint/no-explicit-any */
      overlay: (base: any) => ({
        ...base,
        background: 'rgba(255,255,255,0.78)',
      }),
    }}
  >
    {children}
  </LoadingOverlay>
);

export default PageSpinner;
