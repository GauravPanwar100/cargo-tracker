import React from 'react';
import { render } from 'test-utils';
import RouterMock from '@src/test/RouterMock';
import PageSpinner, { PageSpinnerProps } from './PageSpinner';
import '@testing-library/jest-dom';

const defaultProps: PageSpinnerProps = {
  active: false,
  children: undefined,
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(
    <RouterMock>
      <PageSpinner {...props} />
    </RouterMock>,
  );
  return { utils, props };
};

describe('PageSpinner', () => {
  it('should not render spinner by default', () => {
    const { utils } = setup();
    const pageSpinnerIcon = utils.queryByTestId('page-spinner-icon');
    expect(pageSpinnerIcon).not.toBeInTheDocument();
  });

  it('should render spinner when active is true', () => {
    defaultProps.active = true;
    const { utils } = setup();
    const pageSpinnerIcon = utils.getByTestId('page-spinner-icon');
    const pageSpinnerOverlay = utils.getByTestId('overlay');
    expect(pageSpinnerIcon).toBeTruthy();
    expect(pageSpinnerOverlay).toBeTruthy();
  });
});
