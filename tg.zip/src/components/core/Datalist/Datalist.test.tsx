import React from 'react';
import { render } from 'test-utils';
import RouterMock from '@src/test/RouterMock';
import Datalist, { DatalistProps } from './Datalist';

const suggestions = ['hello', 'goodbye', 'adios'];

const defaultProps: DatalistProps<string> = {
  suggestions,
  noSuggestionsFoundLabel: () => <span>No suggestions found</span>,
  onSelect: () => null,
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(
    <RouterMock>
      <Datalist {...props} />
    </RouterMock>,
  );
  return { utils, props };
};

describe('Datalist', () => {
  it('should render unhappy path with no suggestions', () => {
    const { utils } = setup();
    utils.getByTestId('unhappy-result');
  });

  it('should render suggestions', () => {
    const { utils } = setup();
    utils.getByTestId(suggestions[0]);
    utils.getByTestId(suggestions[1]);
    utils.getByTestId(suggestions[2]);
  });
});
