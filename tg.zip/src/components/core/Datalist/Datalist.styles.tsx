import styled from 'styled-components';
import { fontLineHeightSize } from '@src/lib/util/mixins';

export const Datalist = styled.div`
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  max-height: 300px;
  box-sizing: border-box;
  border-bottom-left-radius: ${(p) => p.theme.sizes.borderRadius}px;
  border-bottom-right-radius: ${(p) => p.theme.sizes.borderRadius}px;
  background-color: #ffffff;
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.4);
  overflow: auto;
  z-index: 1;
`;

export const ListItem = styled.div`
  padding: 12px 16px;
  ${fontLineHeightSize('baseLarge')}

  &:hover {
    background-color: ${(p) => p.theme.colors.greyLight};
    cursor: pointer;
  }
`;
