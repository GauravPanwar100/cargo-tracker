import React from 'react';
import { storiesOf } from '@storybook/react';
import { mockDataListData } from '@src/lib/mock-data';
import { Sections } from '@src/lib/constants/storybook';
import Section from '@src/components/core/Section';
import { Grid, GridCol } from '@src/components/core/Grid';

import Datalist from './Datalist';

storiesOf(`${Sections.CORE}| Datalist`, module).add('default', () => (
  <Section>
    <Grid>
      <GridCol gridColSpan={{ xs: 12, m: 6, l: 4 }}>
        <div style={{ position: 'relative', height: '50px' }}>
          <Datalist suggestions={mockDataListData} onSelect={() => {}} />
        </div>
      </GridCol>
    </Grid>
  </Section>
));
