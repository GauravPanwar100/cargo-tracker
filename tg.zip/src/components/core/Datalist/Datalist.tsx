import React from 'react';
import { kebabCase } from 'lodash';
import { ListItem, Datalist as StyledDatalist } from './Datalist.styles';

export interface DatalistProps<S> {
  formatSuggestion?: (suggestion: S) => string;
  onMouseDown?: (event: React.MouseEvent<HTMLElement>) => void;
  noSuggestionsFoundLabel?: React.ReactNode;
  onSelect: (suggestion: S) => void;
  onNoSuggestionsFoundSelect?: () => void;
  suggestions: S[];
}

const Datalist = <S,>({
  formatSuggestion = (suggestion: unknown) => suggestion as string,
  onMouseDown,
  noSuggestionsFoundLabel,
  onNoSuggestionsFoundSelect,
  onSelect,
  suggestions,
}: DatalistProps<S>) => {
  let noSuggestionsItem: React.ReactNode;

  if (noSuggestionsFoundLabel) {
    noSuggestionsItem = (
      <ListItem onMouseDown={onNoSuggestionsFoundSelect} data-testid="unhappy-result">
        {noSuggestionsFoundLabel}
      </ListItem>
    );
  }
  const content: React.ReactNode = (
    <>
      {suggestions.map((suggestion) => {
        const formattedSuggestion = String(formatSuggestion(suggestion));
        if (formattedSuggestion) {
          return (
            <ListItem
              aria-label={formattedSuggestion}
              data-testid={kebabCase(formattedSuggestion.replace(/,/g, '').toLowerCase())}
              key={formattedSuggestion}
              onClick={() => onSelect(suggestion)}
              onMouseDown={onMouseDown}
            >
              {formattedSuggestion}
            </ListItem>
          );
        }
        return '';
      })}
    </>
  );

  if (!content) {
    return null;
  }

  return (
    <StyledDatalist>
      {content} {noSuggestionsItem}
    </StyledDatalist>
  );
};

export default Datalist;
