import React from 'react';
import { ColorKey } from '@src/lib/theme';
import { MixinProperty } from '@src/lib/util/mixins';
import { TabsNav as StyledTabsNav } from './TabsNav.styles';

interface TabsNavProps {
  id?: string;
  role?: string;
  tabsNavBackgroundColor?: MixinProperty<ColorKey>;
  fullWidth?: boolean;
}

const MAX_TOTAL_TAB_CHARACTER_COUNT = 36;

const TabsNav: React.FC<TabsNavProps> = ({
  children,
  id,
  role,
  tabsNavBackgroundColor = 'white',
  fullWidth = false,
}) => {
  // If the number of child tabs is less than or equal to 3, and none of them have particularly long
  // labels, then we should always center the children. However, if some of the labels are long or
  // there are more than 3 of them, they should not be centered on mobile because they need to
  // overflow the container horizontally
  let count = 0;
  let totalCharacterCount = 0;
  React.Children.forEach(children, (child) => {
    count += 1;
    if (React.isValidElement(child) && typeof child.props.children === 'string') {
      const characterCount = child.props.children.length;
      totalCharacterCount += characterCount;
    }
  });

  let isCenteredOnMobile = false;
  if (count <= 2 || (count <= 3 && totalCharacterCount <= MAX_TOTAL_TAB_CHARACTER_COUNT)) {
    isCenteredOnMobile = true;
  }

  return (
    <StyledTabsNav
      data-testid="tabs-nav"
      id={id}
      isCenteredOnMobile={isCenteredOnMobile}
      role={role}
      backgroundColor={tabsNavBackgroundColor}
      fullWidth={fullWidth}
    >
      {children}
    </StyledTabsNav>
  );
};

export default TabsNav;
