import React, { ComponentPropsWithoutRef } from 'react';
import Link, { LinkProps } from 'next/link';
import { useRouter } from 'next/router';
import { stripQueryFromPath } from '@src/lib/util/url';
import { Tab } from '@src/components/core/Tabs';

// Our active path matching will not work with LinkProps Url type for the `as` prop, so we force
// it to be a string here by Omitting 'as' from LinkProps
type TabLinkProps = ComponentPropsWithoutRef<typeof Tab> &
  Omit<LinkProps, 'as'> & {
    as?: string;
  };

export const BaseTabLink = ({
  // LinkProps
  as,
  children,
  href,
  passHref = true,
  prefetch,
  replace,
  scroll,
  shallow,
  // Other props
  ...props
}: TabLinkProps) => (
  <Link as={as} href={href} passHref={passHref} prefetch={prefetch} replace={replace} scroll={scroll} shallow={shallow}>
    <Tab as="a" {...props}>
      {children}
    </Tab>
  </Link>
);

const TabLink = ({ as, href, ...props }: TabLinkProps) => {
  const router = useRouter();
  let active: boolean;
  if (as) {
    active = stripQueryFromPath(router.asPath) === stripQueryFromPath(as);
  } else {
    active = router.pathname === href;
  }

  return <BaseTabLink active={active} aria-current={active ? 'page' : false} as={as} href={href} {...props} />;
};

export default TabLink;
