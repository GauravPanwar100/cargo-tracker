import React from 'react';
import { ThemeProvider } from 'styled-components';
import { storiesOf } from '@storybook/react';
import Section from '@src/components/core/Section';
import { Sections } from '@src/lib/constants/storybook';
import { midTheme } from '@src/lib/theme';
import TabsNav from './TabsNav';
// In a real Next.js application, you would use TabLink instead of BaseTabLink. TabLink adds some
// additional functionality to detect the active tab based on Next.js useRouter function. This
// function does not work in environments outside a Next.js app, e.g. inside Storybook. So we import
// BaseTab here instead
import { BaseTabLink as TabLink } from './TabLink';

storiesOf(`${Sections.CORE}|TabsNav`, module).add('Default', () => (
  <ThemeProvider theme={midTheme}>
    {/* No need to use Section around the TabsNav outside of Storybook. Using it here for the
    background color */}
    <Section spacingBottom={null} spacingHorizontal={false} spacingTop={null}>
      <Section spacingHorizontal={false}>
        {/* Do not pass active in the Next.js application, this will be provided automatically */}
        <TabsNav>
          <TabLink active={true} href="/">
            Features
          </TabLink>
          <TabLink href="/">Specifications</TabLink>
        </TabsNav>
      </Section>
      <Section spacingHorizontal={false} spacingTop={null}>
        <TabsNav>
          <TabLink active={true} href="/">
            Samsung Galaxy Note 10+
          </TabLink>
          <TabLink href="/">Samsung Galaxy Note 10</TabLink>
          <TabLink href="/">Samsung Galaxy Note 9</TabLink>
        </TabsNav>
      </Section>
      <Section spacingHorizontal={false} spacingTop={null}>
        <TabsNav>
          <TabLink active={true} href="/">
            Google Pixel 4 4G
          </TabLink>
          <TabLink href="/">Google Pixel 3a</TabLink>
        </TabsNav>
      </Section>
      <Section spacingHorizontal={false} spacingTop={null}>
        <TabsNav>
          <TabLink active={true} href="/">
            iPhone XR
          </TabLink>
          <TabLink href="/">iPhone XS</TabLink>
          <TabLink href="/">iPhone X</TabLink>
        </TabsNav>
      </Section>
      <Section spacingHorizontal={false} spacingTop={null}>
        <TabsNav>
          <TabLink active={true} href="/">
            Tab
          </TabLink>
          <TabLink href="/">Tab</TabLink>
        </TabsNav>
      </Section>
      <Section spacingHorizontal={false} spacingTop={null}>
        <TabsNav>
          <TabLink active={true} href="/">
            Tab
          </TabLink>
          <TabLink href="/">Tab</TabLink>
          <TabLink href="/">Tab</TabLink>
        </TabsNav>
      </Section>
      <Section spacingHorizontal={false} spacingTop={null}>
        <TabsNav>
          <TabLink active={true} href="/">
            Tab
          </TabLink>
          <TabLink href="/">Tab</TabLink>
          <TabLink href="/">Tab</TabLink>
          <TabLink href="/">Tab</TabLink>
        </TabsNav>
      </Section>
    </Section>
  </ThemeProvider>
));
