import styled, { css } from 'styled-components';
import { MixinProperty, backgroundColorMixin, media } from '@src/lib/util/mixins';
import { ColorKey } from '@src/lib/theme';

interface TabsNavProps {
  isCenteredOnMobile?: boolean;
  backgroundColor: MixinProperty<ColorKey>;
  fullWidth?: boolean;
}

export const TabsNav = styled.nav<TabsNavProps>`
  display: flex;
  padding: 0 16px;
  ${(p) =>
    p.fullWidth &&
    css`
      padding: 0;
    `}
  overflow: auto;
  white-space: nowrap;
  ${(p) => backgroundColorMixin(p.backgroundColor)}

  ${(p) =>
    p.isCenteredOnMobile &&
    css`
      justify-content: center;
    `}

  > * {
    flex-shrink: 0;
  }

  ${media.m`
    justify-content: center;
    padding: 0;
  `}
`;
