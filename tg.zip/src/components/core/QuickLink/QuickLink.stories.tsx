import React from 'react';
import { ReactComponent as Placeholder } from '@src/assets/svg/placeholder.svg';
import { storiesOf } from '@storybook/react';
import { ThemeProvider } from 'styled-components';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import { Sections } from '@src/lib/constants/storybook';
import { midTheme } from '@src/lib/theme';
import QuickLink from './QuickLink';

storiesOf(`${Sections.CORE}|QuickLink`, module).add('default', () => (
  <ThemeProvider theme={midTheme}>
    <Section>
      <Grid>
        <GridCol gridColSpan={{ xs: 12, m: 6 }}>
          <QuickLink
            description="You can change your plan through My Vodafone."
            href="#"
            icon={Placeholder}
            title="Change your plan"
          />
        </GridCol>
        <GridCol gridColSpan={{ xs: 12, m: 6 }}>
          <QuickLink
            description="Bundle eligible plans under one account. T&C apply."
            href="#"
            icon={Placeholder}
            title="Add another service"
          />
        </GridCol>
      </Grid>
    </Section>
    <Section>
      <Grid>
        <GridCol gridColSpan={{ xs: 12, m: 6 }}>
          <QuickLink href="#" icon={Placeholder} title="Phone and Plan" />
        </GridCol>
        <GridCol gridColSpan={{ xs: 12, m: 6 }}>
          <QuickLink href="#" icon={Placeholder} title="Home Broadband" />
        </GridCol>
        <GridCol gridColSpan={{ xs: 12, m: 6 }}>
          <QuickLink href="#" icon={Placeholder} title="SIM Only Phone Plans" />
        </GridCol>
        <GridCol gridColSpan={{ xs: 12, m: 6 }}>
          <QuickLink href="#" icon={Placeholder} title="Mobile Broadband" />
        </GridCol>
        <GridCol gridColSpan={{ xs: 12, m: 6 }}>
          <QuickLink href="#" icon={Placeholder} title="SIM Only Tablet Plans" />
        </GridCol>
        <GridCol gridColSpan={{ xs: 12, m: 6 }}>
          <QuickLink href="#" icon={Placeholder} title="nbn Plan" />
        </GridCol>
      </Grid>
    </Section>
  </ThemeProvider>
));
