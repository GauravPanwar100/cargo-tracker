import React from 'react';
import { render } from 'test-utils';
import QuickLink, { QuickLinkProps } from './QuickLink';

const defaultProps: QuickLinkProps = {
  href: '//www.google.com',
  target: '_blank',
  icon: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOTIiIGhlaWdodD0iMTkyIj4KICA8cGF0aCBmaWxsPSJub25lIiBkPSJNMCAwaDE5MnYxOTJIMHoiLz4KICA8cGF0aCBmaWxsPSJub25lIiBkPSJNMCAwaDE5MnYxOTJIMHoiLz4KICA8cGF0aCBmaWxsPSJub25lIiBzdHJva2U9IiMzMzMiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSI4IiBkPSJNMjcuODIgOTJoMTM2djcyaC0xMzZ6TTIwIDY4aDE1MnYyNEgyMHoiLz4KICA8cGF0aCBkPSJNNTcuNTEgNTUuMzFDNjMuNzUgNjEuNTYgOTIuODIgNjggOTIuODIgNjhzLTYuNDQtMjkuMDctMTIuNjktMzUuMzFhMTYgMTYgMCAwMC0yMi42MiAyMi42MnptNzYuOTggMEMxMjguMjUgNjEuNTYgOTkuMTggNjggOTkuMTggNjhzNi40NC0yOS4wNyAxMi42OS0zNS4zMWExNiAxNiAwIDAxMjIuNjIgMjIuNjJ6IiBmaWxsPSJub25lIiBzdHJva2U9IiMzMzMiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIHN0cm9rZS13aWR0aD0iOCIvPgogIDxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzMzMyIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjMiIGQ9Ik0yOCA5Mmg1NiIvPgogIDxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzMzMyIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjgiIGQ9Ik0xMDggNjh2OTZNODQgNjh2OTYiLz4KPC9zdmc+Cg==',
  title: 'Heading for this',
  description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<QuickLink {...props} />);
  return { utils, props };
};

describe('QuickLink', () => {
  it('should render a link', () => {
    const { utils, props } = setup();
    if (props.title && props.description) {
      utils.getByText(props.title);
      utils.getByText(props.description);
    }
  });

  it('should wrap content in an anchor tag', () => {
    const { utils, props } = setup();
    const anchor = utils.getByTestId('quick-link') as HTMLAnchorElement;
    expect(anchor.href).toBe(`http:${props.href}/`);
    expect(anchor.target).toBe(props.target);
  });

  it('should render the tile image with src', () => {
    const { utils, props } = setup();
    const image = utils.getByTestId('quick-link-image') as HTMLImageElement;
    if (props.icon) {
      expect(image.src).toBe(props.icon);
    }
  });
});
