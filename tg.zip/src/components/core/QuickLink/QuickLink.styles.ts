import styled, { css } from 'styled-components';
import { listingCardFoundation, media } from '@src/lib/util/mixins';

export const ContainerOuter = styled.a`
  ${listingCardFoundation}
  cursor: pointer;
  border: none;
  padding: 0;
  text-align: left;
  height: 100%;
`;

interface ContainerInnerProps {
  isCentered?: boolean;
  isTripleQuickLink?: boolean;
}
export const ContainerInner = styled.div<ContainerInnerProps>`
  display: flex;
  padding: 16px 16px 20px 10px;
  ${(p) =>
    p.isCentered &&
    css`
      align-items: center;
      padding: 16px;
    `}

  ${media.m<ContainerInnerProps>`
    padding: 20px 20px 24px;
    ${(p) =>
      p.isTripleQuickLink &&
      css`
        padding: 16px 16px 16px 8px;
      `}
    ${(p) =>
      p.isCentered &&
      css`
        padding: 20px;
      `}
  `}
`;

interface ContentInnerProps {
  isTripleQuickLink?: boolean;
}

export const Content = styled.div<ContentInnerProps>`
  flex: 1;
  margin-left: 10px;
  margin-right: 12px;

  ${media.m<ContentInnerProps>`
    margin-left: 20px;
    ${(p) =>
      p.isTripleQuickLink &&
      css`
        margin-left: 4px;
      `}
  `}
  ${media.l`
    margin-left: 20px;
  `}
`;
