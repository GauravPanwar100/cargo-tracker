export { default } from './QuickLink';
