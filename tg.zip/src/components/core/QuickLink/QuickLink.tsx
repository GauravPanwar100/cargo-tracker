import React from 'react';
import { ReactComponent as ChevronRightRed } from '@src/assets/svg/chevron-right-red.svg';
import IconWrapper from '@src/components/core/IconWrapper';
import Image from '@src/components/core/Image';
import Text from '@src/components/core/Text';
import RichText from '@src/components/core/RichText';
import { CSSProperty, MixinProperty } from '@src/lib/util/mixins';
import { ContainerInner, ContainerOuter, Content } from './QuickLink.styles';

export interface QuickLinkProps {
  description?: string;
  href?: string;
  icon: string | React.FC<React.SVGProps<SVGSVGElement>>;
  title?: string;
  target?: string;
  id?: string;
  iconSize?: MixinProperty<CSSProperty>;
  isTripleQuickLink?: boolean;
  onClick?: React.MouseEventHandler<HTMLAnchorElement>;
}

const QuickLink: React.FC<QuickLinkProps> = ({
  description,
  href,
  icon,
  title,
  target,
  id,
  iconSize,
  onClick,
  isTripleQuickLink,
}) => (
  <ContainerOuter as="a" href={href} target={target} onClick={onClick} id={id} data-testid="quick-link">
    <ContainerInner isCentered={!description} isTripleQuickLink={isTripleQuickLink}>
      {typeof icon === 'string' ? (
        <Image
          alt=""
          data-testid="quick-link-image"
          desktopImageUrl={icon}
          height={iconSize || { xs: '32px', m: '64px' }}
          role="presentation"
          width={iconSize || { xs: '32px', m: '64px' }}
        />
      ) : (
        <IconWrapper height={{ xs: '32px', m: '64px' }} svg={icon} width={{ xs: '32px', m: '64px' }} />
      )}
      <Content isTripleQuickLink={isTripleQuickLink}>
        {title && (
          <Text as="h4" fontFamily={{ xs: 'regular', m: 'light' }} marginBottom={description ? '4px' : null}>
            <RichText data-testid="quick-link-text">{title}</RichText>
          </Text>
        )}
        {description && (
          <Text fontSize={{ xs: 'base', m: 'baseLarge' }} lineHeight={{ xs: 'base', m: 'baseLarge' }}>
            <RichText>{description}</RichText>
          </Text>
        )}
      </Content>
      <IconWrapper
        height={{ xs: '24px', m: '32px' }}
        marginTop="4px"
        marginBottom="4px"
        svg={ChevronRightRed}
        width={{ xs: '24px', m: '32px' }}
      />
    </ContainerInner>
  </ContainerOuter>
);

export default QuickLink;
