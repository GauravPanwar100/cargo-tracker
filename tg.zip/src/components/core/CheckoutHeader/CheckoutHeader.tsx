import React from 'react';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import IconWrapper from '@src/components/core/IconWrapper';
import { ReactComponent as LogoIcon } from '@src/assets/svg/logo.svg';
import {
  ContainerInner,
  ContainerOuter,
  LeftContainer,
  PadlockIcon,
  PadlockText,
  RightContainer,
  Title,
} from './CheckoutHeader.styles';

const CheckoutHeader = () => (
  <ContainerOuter>
    <Section spacingBottom={null} spacingTop={null} data-testid="checkout-header">
      <Grid>
        <GridCol>
          <ContainerInner>
            <LeftContainer>
              <a href="/">
                <IconWrapper
                  svg={LogoIcon}
                  height={{ xs: '32px', l: '48px' }}
                  width={{ xs: '32px', l: '48px' }}
                  marginRight={{ xs: '20px', l: '32px' }}
                />
              </a>
              <Title>Secure Checkout</Title>
            </LeftContainer>
            <RightContainer>
              <PadlockIcon />
              <PadlockText>Secure page</PadlockText>
            </RightContainer>
          </ContainerInner>
        </GridCol>
      </Grid>
    </Section>
  </ContainerOuter>
);

export default CheckoutHeader;
