import styled from 'styled-components';
import { fontLineHeightSize, media } from '@src/lib/util/mixins';

export const ContainerOuter = styled.div`
  padding: 8px 0;
  background-color: ${(p) => p.theme.colors.white};
  border-bottom: 1px solid ${(p) => p.theme.colors.silver};

  ${media.m`
    padding: 12px 0;
  `}
`;

export const ContainerInner = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

export const LeftContainer = styled.div`
  display: flex;
  align-items: center;
`;

export const Title = styled.div`
  font-family: ${(p) => p.theme.fonts.regular};
  color: ${(p) => p.theme.colors.darkGrey};
  ${fontLineHeightSize('heading4Mobile')};

  ${media.m`
    font-family: ${(p) => p.theme.fonts.light};
    ${fontLineHeightSize('heading4Tablet')}
  `}

  ${media.l`
    font-family: ${(p) => p.theme.fonts.light};
    ${fontLineHeightSize('heading4')};
  `}
`;

export const RightContainer = styled.div`
  display: flex;
  align-items: center;
`;

export const PadlockIcon = styled.div`
  height: 24px;
  width: 24px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg id='Layer_1' data-name='Layer 1' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 192 192'%3e%3cdefs%3e%3cstyle%3e.cls-1,.cls-2,.cls-3%7bfill:none;%7d.cls-1,.cls-3%7bstroke:%23333;stroke-linejoin:round;stroke-width:8px;%7d.cls-1%7bstroke-linecap:round;%7d%3c/style%3e%3c/defs%3e%3ctitle%3epadlock-close%3c/title%3e%3cg id='f915913c-1ae5-4bd8-af0c-0be4fefd76c3'%3e%3cline id='d2661afd-c0e4-4db3-802c-27c50556112e' class='cls-1' x1='96' y1='100' x2='96' y2='148'/%3e%3c/g%3e%3crect class='cls-2' width='192' height='192'/%3e%3crect class='cls-1' x='36' y='76' width='120' height='96' rx='12'/%3e%3cpath class='cls-3' d='M68,76V48A28,28,0,0,1,96,20h0a28,28,0,0,1,28,28V76' transform='translate(0 0)'/%3e%3c/svg%3e");
`;

export const PadlockText = styled.div`
  display: none;
  margin-left: 12px;
  font-family: ${(p) => p.theme.fonts.regular};
  ${fontLineHeightSize('base')}
  color: ${(p) => p.theme.colors.darkGrey};

  ${media.l`
    display: block;
  `}
  align-self: flex-end;
`;
