import React from 'react';
import { render } from 'test-utils';
import RouterMock from '@src/test/RouterMock';
import CheckoutHeader from './CheckoutHeader';

const setup = (extraProps = {}) => {
  const props = { ...extraProps };
  const utils = render(
    <RouterMock>
      <CheckoutHeader {...props} />
    </RouterMock>,
  );
  return { utils, props };
};

describe('CheckoutHeader', () => {
  it('should render CheckoutHeader', () => {
    const { utils } = setup();
    utils.getByText('Secure Checkout');
    utils.getByText('Secure page');
  });
});
