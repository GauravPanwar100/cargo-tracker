import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import CheckoutHeader from './CheckoutHeader';

storiesOf(`${Sections.CORE}|CheckoutHeader`, module).add('default', () => <CheckoutHeader />);
