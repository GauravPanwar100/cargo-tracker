import React from 'react';
import { render } from 'test-utils';
import ArticleContainer, { ArticleContainerProps } from './ArticleContainer';

const defaultProps: ArticleContainerProps = {};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<ArticleContainer {...props}>Article Content</ArticleContainer>);
  return { utils, props };
};

describe('ArticleContainer', () => {
  it('should render content', () => {
    const { utils } = setup();
    utils.getByText('Article Content');
  });
});
