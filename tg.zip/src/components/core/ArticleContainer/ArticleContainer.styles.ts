import styled, { css } from 'styled-components';
import { media, variantThemeColors, variantThemeLinkColors } from '@src/lib/util/mixins';

interface ArticleContainerProps {
  spacingBottom?: boolean;
  spacingTop?: boolean;
}
export const ArticleContainer = styled.div<ArticleContainerProps>`
  overflow: auto;

  ${variantThemeColors}
  ${variantThemeLinkColors}
  /* Overwrite theme background colour in case this exists inside an already themed element */
  background-color: transparent;

  a:hover,
  a:active {
    text-decoration: none;
  }

  img {
    max-width: 100%;
  }

  ul,
  ol {
    margin: 0;
    padding-left: 0;
    line-height: 1.375;
    list-style: none;
  }

  > ul > li:first-child,
  > ol > li:first-child {
    padding-top: 0;
  }

  li {
    padding: 0.5em 0 0 1.5em;
  }

  li:before {
    display: inline-block;
    text-indent: -1.25em;
  }

  ul li:before {
    content: '●';
  }

  ol {
    counter-reset: ol-counter;
  }

  ol > li {
    counter-increment: ol-counter;
  }

  ol > li:before {
    content: counter(ol-counter) '.';
  }

  ${media.l`
    ul,
    ol {
      max-width: ${(p) => p.theme.sizes.textMaxWidth}px;
    }
  `}

  pre {
    width: 100%;
    margin: 1em 0;
    padding: 0 2em;
    font: inherit;
    line-height: 1.375;
    white-space: pre-wrap;
  }

  ${media.l`
    pre {
      max-width: ${(p) => p.theme.sizes.textMaxWidth}px;
    }
  `}

  table {
    border-collapse: collapse;
    border: 1px solid ${(p) => p.theme.colors.silver};
    border-bottom: none;
    line-height: 1.375;
  }

  table caption {
    margin-bottom: 0.5em;
  }

  tr {
    border-bottom: 1px solid ${(p) => p.theme.colors.silver};
  }

  th,
  td {
    padding: 1em;
    text-align: left;
  }

  th {
    font-family: ${(p) => p.theme.fonts.bold};
    text-align: left;
    background: ${(p) => p.theme.variants.tableHeaderBackgroundColor};
  }

  td {
    background: ${(p) => p.theme.variants.tableCellBackgroundColor};
  }

  ${media.l`
    table {
      width: auto;
      font-size: 18px;
      line-height: 1.333;
    }

    table caption {
      font-size: 0.8em;
    }
  `}

  q {
    position: relative;
    display: block;
    margin: 1em 0;
    padding: 0 0 0 calc(0.5em + 32px);
    line-height: 1.4;
    font-size: 20px;
    font-family: ${(p) => p.theme.fonts.light};
  }

  q:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    display: inline-block;
    width: 32px;
    height: 32px;
    background-image: url("data:image/svg+xml,%3Csvg id='Layer_1' data-name='Layer 1' xmlns='http://www.w3.org/2000/svg' width='32' height='32' viewBox='0 0 32 32'%3E%3Cdefs%3E%3Cstyle%3E .cls-1 %7B fill: %23e60000; %7D %3C/style%3E%3C/defs%3E%3Ctitle%3EArtboard 1%3C/title%3E%3Cpath class='cls-1' d='M12.75,6a33.9,33.9,0,0,0-3.82,4.66,11.58,11.58,0,0,0-2.18,5.25,6,6,0,0,1,4.57,2,6.94,6.94,0,0,1,1.88,4.88,6.63,6.63,0,0,1-1.65,4.65,5.8,5.8,0,0,1-4.5,1.79A5.72,5.72,0,0,1,2,26.8,10,10,0,0,1,.3,20.88a19.07,19.07,0,0,1,3-10.13,31.16,31.16,0,0,1,6.9-8Zm18.5,0a33.9,33.9,0,0,0-3.82,4.66,11.58,11.58,0,0,0-2.18,5.25,6,6,0,0,1,4.57,2,6.94,6.94,0,0,1,1.88,4.88,6.63,6.63,0,0,1-1.65,4.65,5.8,5.8,0,0,1-4.5,1.79,5.72,5.72,0,0,1-5-2.47,10,10,0,0,1-1.73-5.92,19.07,19.07,0,0,1,3-10.13,31.16,31.16,0,0,1,6.9-8Z'/%3E%3C/svg%3E%0A");
  }

  q:after {
    content: none;
  }

  ${media.l`
    q {
      max-width: calc(780px - 4em);
      padding: 0 2em 0 calc(2.5em + 32px);
      line-height: 1.2;
      font-size: 28px;
    }

    q:before {
      left: 2em;
    }
  `}

  /*
  * Spacing rules
  */

  h2 {
    padding: 16px 0;
    margin: 0;
  }

  ${media.s`
    h2 {
      padding: 24px 0;
      margin: 0;
    }
  `}

  h3,
  h4,
  h5,
  h6 {
    padding: 8px 0 12px 0;
    margin: 0;
  }

  ${media.s`
    h3,
    h4,
    h5,
    h6 {
      padding: 16px 0;
      margin: 0;
    }
  `}

  p,
  ul,
  ol {
    padding: 0 0 16px 0;
    margin: 0;
  }

  table {
    margin: 0 0 16px 0;
  }

  img {
    padding: 16px 0;
    margin: 0;
    max-width: 100%;
    display: inline-block;
  }

  p > img {
    padding: 16px 0 0 0;
    display: block;
  }

  ${(p) =>
    !p.spacingTop &&
    css`
      & > div > *:first-child {
        padding-top: 0;
      }
    `}
  ${(p) =>
    !p.spacingBottom &&
    css`
      & > div > *:last-child {
        padding-bottom: 0;
      }
    `}
`;
