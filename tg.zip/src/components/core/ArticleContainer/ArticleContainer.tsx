import React from 'react';
import RichText from '@src/components/core/RichText';
import { ArticleContainer as StyledArticleContainer } from './ArticleContainer.styles';

/**
 * Assumed this rich text will be unescaped before given to this component.
 */
export interface ArticleContainerProps {
  children?: string | React.ReactNode;
  spacingTop?: boolean;
  spacingBottom?: boolean;
  onClick?: React.MouseEventHandler;
  id?: string;
  dataTestid?: string;
}

const ArticleContainer: React.FC<ArticleContainerProps> = ({
  children,
  spacingBottom = true,
  spacingTop = true,
  dataTestid,
  ...props
}) => (
  <StyledArticleContainer spacingBottom={spacingBottom} spacingTop={spacingTop} {...props} data-testid={dataTestid}>
    <RichText>{children}</RichText>
  </StyledArticleContainer>
);

export default ArticleContainer;
