import { compact } from 'lodash';
import React from 'react';
import { ParsedQuery } from 'query-string';
import { useId } from 'react-id-generator';
import useScrollToQuery from '@src/lib/hooks/use-scroll-to-query';
import useUpdatingRef from '@src/lib/hooks/use-updating-ref';
import { MixinProperty } from '@src/lib/util/mixins';
import { QueryKey, encodeQueryStringId } from '@src/lib/util/query';
import { useClientQuery } from '@src/lib/util/router';
import { Container, Icon, Title } from './Accordion.styles';
import { AccordionItemProps } from './AccordionItem/AccordionItem';

export type AccordionVariant = 'card' | 'flat' | 'attached';

export interface AccordionProps {
  allowOverflow?: boolean;
  children: React.ReactNode;
  className?: string;
  dataTestId?: string;
  hasSeparator?: MixinProperty<boolean>;
  multiple?: boolean;
  title?: string;
  icon?: string;
  variant?: AccordionVariant;
  ignoreQuery?: boolean;
  parentRole?: string;
}

interface GetDefaultOpenItemsParams {
  children: React.ReactNode;
  defaultIds: string[];
  query: ParsedQuery | null;
}
const getDefaultOpenItems = ({ children, defaultIds, query }: GetDefaultOpenItemsParams) =>
  // React.Children.map can return undefined if there are no children, so use toArray instead
  React.Children.toArray(children)
    .map((child, i) => {
      if (!React.isValidElement<AccordionItemProps>(child)) {
        return '';
      }
      const id = child.props.id ?? defaultIds[i];
      // The child accordion item should be opened by default if the child has defaultIsOpen set to
      // true, or if the child's ID is present in the accordion query key
      return child.props.defaultIsOpen || query?.[QueryKey.ACCORDION] === id ? id : '';
    })
    .filter((item) => !!item);

export interface AccordionInstance {
  onToggle: (id: string) => void;
}

const Accordion: React.RefForwardingComponent<AccordionInstance, AccordionProps> = (
  {
    allowOverflow,
    children,
    className,
    dataTestId,
    hasSeparator,
    multiple,
    title,
    icon,
    variant = 'card',
    ignoreQuery = false,
    parentRole,
  },
  ref,
) => {
  const containerRef = React.useRef<HTMLDivElement>(null);

  const generatedIds = useId(React.Children.count(children), 'accordion-item-');
  const defaultIds =
    React.Children.map(children, (child, i) => {
      if (!React.isValidElement<AccordionItemProps>(child) || typeof child.props.title !== 'string') {
        return generatedIds[i];
      }
      return encodeQueryStringId(child.props.title);
    }) || [];
  const [openItems, setOpenItems] = React.useState<string[]>([]);
  const query = useClientQuery();
  const defaultOpenParams = useUpdatingRef({
    children,
    defaultIds,
    query,
  });
  const isQueryReady = !!query;
  React.useEffect(() => {
    if (isQueryReady && !ignoreQuery) {
      setOpenItems(getDefaultOpenItems(defaultOpenParams.current));
    }
  }, [defaultOpenParams, ignoreQuery, isQueryReady]);

  useScrollToQuery({ queryKey: QueryKey.ACCORDION, rootRef: containerRef });

  const onToggle = React.useCallback(
    (id: string) => {
      const isOpen = openItems.includes(id);

      if (isOpen) {
        setOpenItems(openItems.filter((i) => i !== id));
      } else if (multiple) {
        setOpenItems([...openItems, id]);
      } else {
        setOpenItems([id]);
      }
    },
    [multiple, openItems],
  );

  // We have to count the amount of children ourselves because React.Children.count would count
  // `null` or `false` children in the count, which we don't want
  const childCount = compact(React.Children.toArray(children)).length;

  const enhancedChildren = React.Children.map(children, (child, i) => {
    if (!React.isValidElement<AccordionItemProps>(child)) {
      return child;
    }

    const id = child.props.id ?? defaultIds[i];
    const isOpen = openItems.includes(id);

    return React.cloneElement(child, {
      id,
      // isFirstItem and isLastItem are used to turn on/off the focus style border radius
      isFirstItem: i === 0,
      // Don't round the focus border outline when there is a footer
      isLastItem: i === childCount - 1 && !child.props.footer,
      isOpen: child.props.isOpen ?? isOpen,
      onToggle: child.props.onToggle ?? onToggle,
    });
  });

  React.useImperativeHandle(
    ref,
    () => ({
      onToggle,
    }),
    [onToggle],
  );

  return (
    <Container
      allowOverflow={allowOverflow}
      className={className}
      data-testid={dataTestId}
      hasSeparator={hasSeparator}
      variant={variant}
      ref={containerRef}
      {...{ role: parentRole }}
    >
      {title && (
        <Title>
          {icon && <Icon role="presentation" src={icon} />}
          {title}
        </Title>
      )}
      {enhancedChildren}
    </Container>
  );
};

export default React.forwardRef(Accordion);
