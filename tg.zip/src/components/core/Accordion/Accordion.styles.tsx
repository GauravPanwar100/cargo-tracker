import styled, { css } from 'styled-components';
import { MixinProperty, createResponsiveMixin, fontLineHeightSize, media } from '@src/lib/util/mixins';
import { AccordionVariant } from './Accordion';

const separatorMixin = createResponsiveMixin<boolean>((propValue) => {
  if (propValue) {
    return css`
      border-bottom: 1px solid ${(p) => p.theme.variants.accordionSeparatorColor};
    `;
  }

  return css`
    border-bottom: none;
  `;
});

interface AccordionInnerProps {
  allowOverflow?: boolean;
  hasSeparator?: MixinProperty<boolean>;
  variant: AccordionVariant;
}
export const Container = styled.div<AccordionInnerProps>`
  overflow: ${(p) => (p.allowOverflow ? 'visible' : 'hidden')};
  display: flex;
  flex-direction: column;
  width: 100%;

  ${(p) => separatorMixin(p.hasSeparator)}

  ${(p) =>
    p.variant === 'card' &&
    css`
      border-radius: 6px;
      border-bottom: none;
      box-shadow: ${p.theme.variants.accordionBoxShadow};
    `}

  ${(p) =>
    p.variant === 'attached' &&
    css`
      border-radius: 0 0 6px 6px;
    `}
`;

export const Title = styled.div`
  display: flex;
  align-items: center;
  height: 48px;
  padding: 14px 10px;
  ${fontLineHeightSize('heading5Mobile')};
  font-family: ${(p) => p.theme.fonts.bold};
  color: ${(p) => p.theme.colors.white};
  background-color: ${(p) => p.theme.colors.grey};

  ${media.l`
    height: 56px;
    ${fontLineHeightSize('heading5')};
  `}
`;

export const Icon = styled.img`
  width: 24px;
  height: auto;
  margin-right: 10px;
`;
