/* eslint-disable no-underscore-dangle */
import React from 'react';
import { fireEvent, render, timeout } from 'test-utils';
import RouterMock from '@src/test/RouterMock';
import Accordion, { AccordionProps } from './Accordion';
import AccordionItem, { AccordionItemProps } from './AccordionItem/AccordionItem';

const defaultProps: AccordionProps = {
  children: null,
  title: 'Accordion Title',
};

const defaultAccordionItemProps: AccordionItemProps = {
  title: 'Accordion Item Title',
};

const disabledAccordionItemProps: AccordionItemProps = {
  title: 'Accordion Item Title - Disabled',
  disabled: true,
};
const customBackgroundAccordionItemProps: AccordionItemProps = {
  title: 'Accordion Item Title - White',
};

const setup = (extraProps = {}, extraItemProps = {}, single = true, disabled = false, customBackground = '') => {
  const props = { ...defaultProps, ...extraProps };
  const itemProps = { ...defaultAccordionItemProps, ...extraItemProps };
  let utils;
  if (disabled) {
    utils = render(
      <RouterMock>
        <Accordion {...props}>
          <AccordionItem {...disabledAccordionItemProps} title="Accordion Item Title - Disabled">
            Accordion Item Content - disabled
          </AccordionItem>
        </Accordion>
      </RouterMock>,
    );
  } else if (!single) {
    utils = render(
      <RouterMock>
        <Accordion {...props}>
          <AccordionItem {...itemProps} title="Accordion Item Title 1">
            Accordion Item Content 1
          </AccordionItem>
          <AccordionItem {...itemProps} title="Accordion Item Title 2">
            Accordion Item Content 2
          </AccordionItem>
        </Accordion>
      </RouterMock>,
    );
  } else if (customBackground === 'white') {
    utils = render(
      <RouterMock>
        <Accordion {...props}>
          <AccordionItem
            {...customBackgroundAccordionItemProps}
            title="Accordion Item Title - White"
            customBackgroundColor="white"
          >
            Accordion Item Content - White
          </AccordionItem>
        </Accordion>
      </RouterMock>,
    );
  } else {
    utils = render(
      <RouterMock>
        <Accordion {...props}>
          <AccordionItem {...itemProps} title="Accordion Item Title">
            Accordion Item Content - general
          </AccordionItem>
        </Accordion>
      </RouterMock>,
    );
  }

  return { utils, props };
};

describe('Accordion', () => {
  it('should expand on click', async () => {
    const { utils } = setup();
    const accordionItem = utils.getByText('Accordion Item Title');
    let accordionItemContent = utils.getByTestId('accordion-item');
    const style = window.getComputedStyle(accordionItemContent);

    expect(style.getPropertyValue('height')).toEqual('0px');

    // click the accordion item.
    fireEvent.click(accordionItem);

    // wait for the transition to complete.
    await timeout(300);

    accordionItemContent = utils.getByTestId('accordion-item');
    const newStyle = window.getComputedStyle(accordionItemContent);
    expect(newStyle.getPropertyValue('height')).not.toEqual('0px');
  });

  it('should collapse on click when open', async () => {
    const { utils } = setup({}, { defaultIsOpen: true });
    const accordionItem = utils.getByText('Accordion Item Title');

    // // wait for the transition of initial render to complete.
    await timeout(300);

    let accordionItemContent = utils.getByTestId('accordion-item');
    const style = window.getComputedStyle(accordionItemContent);
    expect(style.getPropertyValue('height')).toEqual('auto');

    // click the accordion item.
    fireEvent.click(accordionItem);

    // wait for the transition to complete.
    await timeout(300);

    accordionItemContent = utils.getByTestId('accordion-item');
    const newStyle = window.getComputedStyle(accordionItemContent);
    expect(newStyle.getPropertyValue('height')).toEqual('0px');
  });

  it('should display the accordion title', () => {
    const { utils } = setup();
    utils.getByText('Accordion Title');
  });

  it('should collapse an open AccordionItem if another is opened with multiple prop false', async () => {
    const { utils } = setup({ multiple: false }, {}, false);

    // open the first accordion item.
    const accordionItem = utils.getByText('Accordion Item Title 1');
    let accordionItemsContent = utils.getAllByTestId('accordion-item');
    const style = window.getComputedStyle(accordionItemsContent[0]);

    expect(style.getPropertyValue('height')).toEqual('0px');

    // click the accordion item.
    fireEvent.click(accordionItem);

    // wait for the transition to complete.
    await timeout(300);

    accordionItemsContent = utils.getAllByTestId('accordion-item');
    const newStyle = window.getComputedStyle(accordionItemsContent[0]);
    expect(newStyle.getPropertyValue('height')).not.toEqual('0px');

    // open the second accordion item

    const accordionItem2 = utils.getByText('Accordion Item Title 2');

    // click the accordion item.
    fireEvent.click(accordionItem2);

    // wait for the transition to complete.
    await timeout(300);

    // assert that accordion item 2 is now open and 1 is not.
    accordionItemsContent = utils.getAllByTestId('accordion-item');

    // asserting accordion 2 is now open.
    const accordItem2ContentStyle = window.getComputedStyle(accordionItemsContent[1]);
    expect(accordItem2ContentStyle.getPropertyValue('height')).not.toEqual('0px');

    // asserting accordion 2 is now open.
    const accordItem1ContentStyle = window.getComputedStyle(accordionItemsContent[0]);
    expect(accordItem1ContentStyle.getPropertyValue('height')).toEqual('0px');
  });

  it('should not change height of accordion item on click with disabled prop true', async () => {
    const { utils } = setup({}, {}, true, true);
    const accordionItem = utils.getByText('Accordion Item Title - Disabled');
    let accordionItemContent = utils.getByTestId('accordion-item');
    const style = window.getComputedStyle(accordionItemContent);

    expect(style.getPropertyValue('height')).toEqual('auto');

    // click the accordion item.
    fireEvent.click(accordionItem);

    // wait for the transition to complete.
    await timeout(300);

    accordionItemContent = utils.getByTestId('accordion-item');
    const newStyle = window.getComputedStyle(accordionItemContent);
    expect(newStyle.getPropertyValue('height')).toEqual('auto');
  });

  it('should have a custom background', async () => {
    const { utils } = setup({}, {}, true, false, 'white');
    const accordionItemContent = utils.getByTestId('accordion-item-content');
    const style = window.getComputedStyle(accordionItemContent);
    expect(style.getPropertyValue('background-color')).toEqual('white');
  });
});
