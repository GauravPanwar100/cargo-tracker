import React, { useCallback, useState } from 'react';
import { ThemeProvider } from 'styled-components';
import { storiesOf } from '@storybook/react';
import { Acceleration, Camera, CommunityRed, Wifi } from '@src/assets/base64/icons-system';
import ArticleContainer from '@src/components/core/ArticleContainer';
import DescriptionList from '@src/components/core/DescriptionList';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import { Sections } from '@src/lib/constants/storybook';
import { darkTheme, midTheme } from '@src/lib/theme';
import Accordion from './Accordion';
import AccordionItem from './AccordionItem';
import AccordionItemDesktopOpen from './AccordionItemDesktopOpen';

const Demo = () => {
  const [isOpen, setIsOpen] = useState(false);
  const onToggle = useCallback(() => {
    setIsOpen(!isOpen);
  }, [isOpen]);
  return (
    <>
      <ThemeProvider theme={midTheme}>
        <Section>
          <Grid>
            <GridCol>
              <ArticleContainer>
                <h2>Title</h2>
              </ArticleContainer>
              <Accordion>
                <AccordionItem isOpen={isOpen} onToggle={onToggle} title="Accordion with html nodes as children">
                  <ArticleContainer>
                    <h4>Heading 4</h4>
                    <p>
                      Maecenas faucibus mollis interdum. Sed posuere consectetur est at lobortis. Maecenas sed diam eget
                      risus varius blandit sit amet non magna. Cras mattis consectetur purus sit amet fermentum. Nullam
                      id dolor id nibh ultricies vehicula ut id elit.
                    </p>
                    <p>
                      <img alt="storybook" src="https://source.unsplash.com/WLUHO9A_xik/400x300" />
                    </p>
                    <h5>Heading 5</h5>
                    <p>Etiam porta sem malesuada magna mollis euismod.</p>
                    <h6>Heading 6</h6>
                    <p>Donec id elit non mi porta gravida at eget metus.</p>
                  </ArticleContainer>
                </AccordionItem>
                <AccordionItem title="Ornare Sit Etiam">
                  <ArticleContainer>
                    <p>
                      Our Mobile Broadband plans are packed with value, so it’s easier than ever to keep all of your
                      devices connected. Sign up to one of our new Red Mobile Broadband plans with no lock-in contract
                      and get a modem or tablet on an interest free repayment period of 12, 24 or 36 months. If your Red
                      Plan is cancelled, you will need to pay off your phone on your next bill. Or choose from our Month
                      to Month or 12 month SIM Only Plans if you want to bring your own device. Our Mobile Broadband
                      plans also come with $5 Roaming so you can use your plan in 80 countries for $5 extra a day. These
                      countries may vary, so check our current countries before you travel. T&C apply.
                    </p>
                    <p>
                      If you&apos;re already with us, you can upgrade to a new Mobile Broadband plan by calling our team
                      on 1300 301 474
                    </p>
                  </ArticleContainer>
                </AccordionItem>
              </Accordion>
            </GridCol>
          </Grid>
        </Section>
        <Section spacingTop={null}>
          <Grid>
            <GridCol>
              <Accordion>
                <AccordionItem defaultIsOpen={true} title="Data Share" icon={CommunityRed}>
                  <ArticleContainer>
                    <p>
                      As Plus Plans can only share data with Plus Plans, you&apos;ll no longer be able to share data
                      with other plans.
                    </p>
                  </ArticleContainer>
                </AccordionItem>
              </Accordion>
            </GridCol>
          </Grid>
        </Section>
      </ThemeProvider>
      <Section>
        <Grid>
          <GridCol>
            <ArticleContainer>
              <h2>Title</h2>
            </ArticleContainer>
            <Accordion>
              <AccordionItem title="Accordion with string as children">
                <ArticleContainer>
                  <h4>Heading 4</h4>
                  <p>
                    Maecenas faucibus mollis interdum. Sed posuere consectetur est at lobortis. Maecenas sed diam eget
                    risus varius blandit sit amet non magna. Cras mattis consectetur purus sit amet fermentum. Nullam id
                    dolor id nibh ultricies vehicula ut id elit.
                  </p>
                  <p>
                    <img alt="storybook" src="https://source.unsplash.com/WLUHO9A_xik/400x300" />
                  </p>
                  <h5>Heading 5</h5>
                  <p>Etiam porta sem malesuada magna mollis euismod.</p>
                  <h6>Heading 6</h6>
                  <p>Donec id elit non mi porta gravida at eget metus.</p>
                </ArticleContainer>
              </AccordionItem>
              <AccordionItem title="Ornare Sit Etiam">
                <ArticleContainer>
                  <p>
                    Our Mobile Broadband plans are packed with value, so it’s easier than ever to keep all of your
                    devices connected. Sign up to one of our new Red Mobile Broadband plans with no lock-in contract and
                    get a modem or tablet on an interest free repayment period of 12, 24 or 36 months. If your Red Plan
                    is cancelled, you will need to pay off your phone on your next bill. Or choose from our Month to
                    Month or 12 month SIM Only Plans if you want to bring your own device. Our Mobile Broadband plans
                    also come with $5 Roaming so you can use your plan in 80 countries for $5 extra a day. These
                    countries may vary, so check our current countries before you travel. T&C apply.
                  </p>
                  <p>
                    If you&apos;re already with us, you can upgrade to a new Mobile Broadband plan by calling our team
                    on 1300 301 474
                  </p>
                </ArticleContainer>
              </AccordionItem>
            </Accordion>
          </GridCol>
        </Grid>
      </Section>
      <ThemeProvider theme={darkTheme}>
        <Section>
          <Grid>
            <GridCol>
              <ArticleContainer>
                <h2>Title</h2>
              </ArticleContainer>
              <Accordion>
                <AccordionItem title="Title 1">
                  <ArticleContainer>
                    <h4>Heading 4</h4>
                    <p>
                      Maecenas faucibus mollis interdum. Sed posuere consectetur est at lobortis. Maecenas sed diam eget
                      risus varius blandit sit amet non magna. Cras mattis consectetur purus sit amet fermentum. Nullam
                      id dolor id nibh ultricies vehicula ut id elit.
                    </p>
                    <p>
                      <img alt="storybook" src="https://source.unsplash.com/WLUHO9A_xik/400x300" />
                    </p>
                    <h5>Heading 5</h5>
                    <p>Etiam porta sem malesuada magna mollis euismod.</p>
                    <h6>Heading 6</h6>
                    <p>Donec id elit non mi porta gravida at eget metus.</p>
                  </ArticleContainer>
                </AccordionItem>
                <AccordionItem title="Ornare Sit Etiam">
                  <ArticleContainer>
                    <p>
                      Our Mobile Broadband plans are packed with value, so it’s easier than ever to keep all of your
                      devices connected. Sign up to one of our new Red Mobile Broadband plans with no lock-in contract
                      and get a modem or tablet on an interest free repayment period of 12, 24 or 36 months. If your Red
                      Plan is cancelled, you will need to pay off your phone on your next bill. Or choose from our Month
                      to Month or 12 month SIM Only Plans if you want to bring your own device. Our Mobile Broadband
                      plans also come with $5 Roaming so you can use your plan in 80 countries for $5 extra a day. These
                      countries may vary, so check our current countries before you travel. T&C apply.
                    </p>
                    <p>
                      If you&apos;re already with us, you can upgrade to a new Mobile Broadband plan by calling our team
                      on 1300 301 474
                    </p>
                  </ArticleContainer>
                </AccordionItem>
              </Accordion>
            </GridCol>
          </Grid>
        </Section>
      </ThemeProvider>
    </>
  );
};

const OpenAccordion = () => (
  <>
    <Section>
      <Grid>
        <GridCol>
          <ArticleContainer>
            <h2>Open Accordion</h2>
          </ArticleContainer>
        </GridCol>
      </Grid>
      <Grid rowGap={0}>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen disableFocusBorderRadius={true} icon={Acceleration} title="Hardware">
              <DescriptionList>
                <dt>Processor Chip</dt>
                <dd>Octa-Core 2.73GHz</dd>
                <dt>RAM</dt>
                <dd>12GB</dd>
                <dt>Internal Memory</dt>
                <dd>256GB</dd>
                <dt>External Memory</dt>
                <dd>microSD up to 512GB</dd>
                <dt>Battery Capacity</dt>
                <dd>4300mAh</dd>
                <dt>SIM Type</dt>
                <dd>Nano SIM</dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen disableFocusBorderRadius={true} icon={Wifi} title="Software">
              <DescriptionList>
                <dt>Operating System</dt>
                <dd>Android 9 (Pie)</dd>
                <dt>Apps</dt>
                <dd>My Vodafone</dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen disableFocusBorderRadius={true} icon={Camera} title="Camera">
              <DescriptionList>
                <dt>Front-facing camera</dt>
                <dd>10MP AF (Wide, F2.2)</dd>
                <dt>Rear-facing camera</dt>
                <dd>12MP (Wide, F1.5/F2.4) + 12MP (Telephoto, F2.1) + 16MP (Ultra Wide, F2.2) + VGA 3D Depth Camera</dd>
                <dt>Digital Zoom</dt>
                <dd>10 x Digital Zoom</dd>
                <dt>Flash Type</dt>
                <dd>LED</dd>
                <dt>Video Recording</dt>
                <dd>UHD 4K Recording</dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
      </Grid>
    </Section>
  </>
);

storiesOf(`${Sections.CORE}|Accordion`, module).add('Default', () => <Demo />);
storiesOf(`${Sections.CORE}|Accordion`, module).add('Open on Desktop', () => <OpenAccordion />);
