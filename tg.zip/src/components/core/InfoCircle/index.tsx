import React from 'react';

import { AssetsLinks } from '../../../assets/assets';

interface InfoCircleProps {
  width?: string;
  height?: string;
}

// eslint-disable-next-line react/display-name

const InfoCircle = ({ width = '24', height = '24' }: InfoCircleProps) => (
  <img src={AssetsLinks.AEM_ASSET_INFO_CIRCLE} width={width} height={height} alt="" />
);

export { InfoCircle };
