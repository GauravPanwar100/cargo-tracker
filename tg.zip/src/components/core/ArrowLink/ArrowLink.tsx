import React from 'react';
import { ReactComponent as ChevronRightRed } from '@src/assets/svg/chevron-right-red.svg';
import IconWrapper from '@src/components/core/IconWrapper';
import { MixinProperty } from '@src/lib/util/mixins';
import { ArrowLink as StyledArrowLink } from './ArrowLink.styles';

interface ArrowLinkProps {
  children?: string;
  onClick?: React.MouseEventHandler;
  href?: string;
  marginBottom?: MixinProperty;
  marginTop?: MixinProperty;
  as?: React.ElementType;
}

const ArrowLink: React.FC<ArrowLinkProps> = ({ as, onClick, children, marginBottom, marginTop, href }) => (
  <StyledArrowLink as={as} href={href} onClick={onClick} marginBottom={marginBottom} marginTop={marginTop}>
    {children}
    <IconWrapper height="16px" marginLeft="2px" svg={ChevronRightRed} width="16px" />
  </StyledArrowLink>
);

export default ArrowLink;
