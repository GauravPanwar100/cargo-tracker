import styled from 'styled-components';
import { MixinProperty, fontLineHeightSize, marginBottomMixin, marginTopMixin, media } from '@src/lib/util/mixins';

interface ArrowLinkProps {
  marginBottom?: MixinProperty;
  marginTop?: MixinProperty;
}

export const ArrowLink = styled.a<ArrowLinkProps>`
  display: inline-flex;
  align-items: center;
  color: ${(p) => p.theme.variants.featuredLinkColor};
  text-decoration: none;
  ${(p) => marginBottomMixin(p.marginBottom)}
  ${(p) => marginTopMixin(p.marginTop)}
  ${fontLineHeightSize('base')}
  border: none;
  background-color: transparent;

  ${media.m`
    ${fontLineHeightSize('baseLarge')}
  `}

  &:hover {
    text-decoration: underline;
  }

  &:visited,
  &:hover,
  &:focus {
    color: ${(p) => p.theme.variants.featuredLinkColor};
  }
`;
