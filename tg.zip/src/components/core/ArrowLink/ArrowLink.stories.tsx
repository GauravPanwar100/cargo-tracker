import React from 'react';
import { storiesOf } from '@storybook/react';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import Text from '@src/components/core/Text';
import { Sections } from '@src/lib/constants/storybook';
import ArrowLink from './ArrowLink';

storiesOf(`${Sections.CORE}|ArrowLink`, module).add('Default', () => (
  <Section>
    <Grid>
      <GridCol>
        <Text as="h5" marginBottom="12px">
          Arrow Link
        </Text>
        <ArrowLink href="#">View your other services</ArrowLink>
      </GridCol>
    </Grid>
  </Section>
));
