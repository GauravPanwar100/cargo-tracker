export { default } from './ArrowLink';
