import React from 'react';
import { ReactComponent as Facebook } from '@src/assets/svg/facebook-white.svg';
import { ReactComponent as Twitter } from '@src/assets/svg/twitter-white.svg';
import { ThemeProvider } from 'styled-components';
import { Accordion } from '@src/components/core/Accordion';
import { Grid, GridCol } from '@src/components/core/Grid';
import IconWrapper from '@src/components/core/IconWrapper';
import Section from '@src/components/core/Section';
import Text from '@src/components/core/Text';
import { footerTheme } from '@src/lib/theme';
import FooterAccordionItem from './FooterAccordionItem';
import {
  Container,
  FooterLink,
  FooterLinkItem,
  FooterLinkList,
  NavContainer,
  SecondaryLink,
  SecondaryLinkItem,
  SecondaryLinkList,
  SocialContainer,
} from './Footer.styles';

export interface FooterProps {}

const Footer: React.FC<FooterProps> = () => (
  <ThemeProvider theme={footerTheme}>
    <Container>
      <Section spacingBottom={{ xs: 'xs', m: 's', l: 'l' }} spacingTop={{ xs: 'xs', m: 's', l: 'xxl' }}>
        <NavContainer>
          <Grid rowGap={0}>
            <GridCol gridColSpan={{ xs: 12, l: 3 }}>
              <Accordion hasSeparator={{ xs: true, l: false }} variant="flat">
                <FooterAccordionItem title="Already with us">
                  <FooterLinkList>
                    <FooterLinkItem>
                      <FooterLink href="#">Support</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Prepaid recharge</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Activate SIM</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Upgrade</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">International roaming</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">International calls</FooterLink>
                    </FooterLinkItem>
                  </FooterLinkList>
                </FooterAccordionItem>
              </Accordion>
            </GridCol>
            <GridCol gridColSpan={{ xs: 12, l: 3 }}>
              <Accordion hasSeparator={{ xs: true, l: false }} variant="flat">
                <FooterAccordionItem title="Devices & Plans">
                  <FooterLinkList>
                    <FooterLinkItem>
                      <FooterLink href="#">Hot Offers</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Mobile phones</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Tablets & plans</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Phone plans</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">SIM only plans</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Mobile broadband plans</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">nbn&trade; plans</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Prepaid phone plans</FooterLink>
                    </FooterLinkItem>
                  </FooterLinkList>
                </FooterAccordionItem>
              </Accordion>
            </GridCol>
            <GridCol gridColSpan={{ xs: 12, l: 3 }}>
              <Accordion hasSeparator={{ xs: true, l: false }} variant="flat">
                <FooterAccordionItem title="About Vodafone">
                  <FooterLinkList>
                    <FooterLinkItem>
                      <FooterLink href="#">Careers</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Company information</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Check your coverage</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Our network</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Terms and policies</FooterLink>
                    </FooterLinkItem>
                  </FooterLinkList>
                </FooterAccordionItem>
              </Accordion>
            </GridCol>
            <GridCol gridColSpan={{ xs: 12, l: 3 }}>
              <Accordion hasSeparator={{ xs: true, l: false }} variant="flat">
                <FooterAccordionItem title="Contact Us">
                  <FooterLinkList>
                    <FooterLinkItem>
                      <FooterLink href="#">Contact us</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Find a store</FooterLink>
                    </FooterLinkItem>
                    <FooterLinkItem>
                      <FooterLink href="#">Compliments and Complaints</FooterLink>
                    </FooterLinkItem>
                  </FooterLinkList>
                </FooterAccordionItem>
              </Accordion>
              <SocialContainer>
                <IconWrapper height="32px" marginRight="24px" svg={Facebook} width="32px" />
                <IconWrapper height="32px" svg={Twitter} width="32px" />
              </SocialContainer>
            </GridCol>
          </Grid>
        </NavContainer>
      </Section>
      <Section spacingBottom={{ xs: 'xs', m: 's', l: 'xxl' }} spacingTop={null}>
        <Grid rowGap={0}>
          <GridCol gridColSpan={{ xs: 12, l: 6 }}>
            <SecondaryLinkList>
              <SecondaryLinkItem>
                <SecondaryLink href="#">Fair use policy</SecondaryLink>
              </SecondaryLinkItem>
              <SecondaryLinkItem>
                <SecondaryLink href="#">Privacy policy</SecondaryLink>
              </SecondaryLinkItem>
              <SecondaryLinkItem>
                <SecondaryLink href="#">Terms & conditions</SecondaryLink>
              </SecondaryLinkItem>
              <SecondaryLinkItem>
                <SecondaryLink href="#">Accessibility</SecondaryLink>
              </SecondaryLinkItem>
            </SecondaryLinkList>
          </GridCol>
          <GridCol gridColStart={{ xs: 1, l: 7 }} gridColSpan={{ xs: 12, l: 6 }} textAlign={{ xs: 'left', l: 'right' }}>
            <Text fontSize={{ xs: 'base', l: 'baseLarge' }} lineHeight={{ xs: 'base', l: 'baseLarge' }}>
              &copy; 2019 Vodafone Hutchison Australia Pty Limited. ABN 76 096 304 620
            </Text>
          </GridCol>
        </Grid>
      </Section>
    </Container>
  </ThemeProvider>
);

export default Footer;
