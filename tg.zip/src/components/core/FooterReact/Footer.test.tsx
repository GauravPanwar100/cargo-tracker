import React from 'react';
import { render } from 'test-utils';
import Footer, { FooterProps } from './Footer';

const defaultProps: FooterProps = {};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<Footer {...props} />);
  return { utils, props };
};

describe('Footer', () => {
  it('should be rendered', () => {
    const { utils } = setup();
    utils.getByText('Already with us');
    utils.getByText('Support');
    utils.getByText('Prepaid recharge');
    utils.getByText('Activate SIM');
    utils.getByText('Upgrade');
    utils.getByText('International roaming');
    utils.getByText('International calls');
    utils.getByText('Devices & Plans');
    utils.getByText('Hot Offers');
    utils.getByText('Mobile phones');
    utils.getByText('Tablets & plans');
    utils.getByText('Phone plans');
    utils.getByText('SIM only plans');
    utils.getByText('Mobile broadband plans');
    utils.getByText('Prepaid phone plans');
    utils.getByText('About Vodafone');
  });
});
