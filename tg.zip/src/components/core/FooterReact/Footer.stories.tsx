import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import Footer from './Footer';

storiesOf(`${Sections.CORE}|Footer (React)`, module).add('Default', () => <Footer />);
