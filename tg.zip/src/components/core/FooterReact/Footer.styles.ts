import styled from 'styled-components';
import { fontLineHeightSize, listReset, media, variantThemeLinkColors } from '@src/lib/util/mixins';

export const Container = styled.footer`
  margin-top: auto;
  ${variantThemeLinkColors}

  a {
    text-decoration: none;

    &:hover {
      text-decoration: underline;
    }
  }
`;

export const NavContainer = styled.div`
  border-top: 1px solid ${(p) => p.theme.variants.accordionSeparatorColor};

  ${media.l`
    border-top: none;
  `}
`;

export const SocialContainer = styled.div`
  padding: 24px 10px;
  display: flex;
  align-items: center;
  border-bottom: 1px solid ${(p) => p.theme.variants.accordionSeparatorColor};

  ${media.m`
    padding: 32px 10px;
  `}

  ${media.l`
    padding: 40px 0;
    border-bottom: none;
  `}
`;

export const FooterLinkList = styled.ul`
  ${listReset}

  ${media.l`
    padding: 12px 0 0;
  `}
`;

export const FooterLinkItem = styled.li`
  padding: 12px 20px;

  ${media.l`
    padding: 6px 0;
  `}
`;

export const FooterLink = styled.a`
  ${fontLineHeightSize('baseLarge')}
`;

export const SecondaryLinkList = styled.ul`
  ${listReset}
  margin-bottom: 8px;

  ${media.l`
    margin-bottom: 0;
  `}
`;

export const SecondaryLinkItem = styled.li`
  display: inline-block;
  padding: 0;
  padding-right: 12px;
  margin: 0 12px 8px 0;
  border-right: 1px solid ${(p) => p.theme.colors.white};

  &:last-child {
    margin-right: 0;
    border-right: none;
  }

  ${media.l`
    margin-bottom: 0;
  `}
`;

export const SecondaryLink = styled.a`
  ${fontLineHeightSize('base')}

  ${media.l`
    ${fontLineHeightSize('baseLarge')}
  `}
`;
