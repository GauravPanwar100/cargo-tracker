import React, { useCallback } from 'react';
import Button from '@src/components/core/Button';
import { InlineBannerType } from '@src/lib/api/types';
import Link from 'next/link';
import RichText from '@src/components/core/RichText';
import NextImage from 'next/image';
import {
  BannerContainer,
  BannerImageContainer,
  BannerWrapper,
  CTAButton,
  DescriptionText,
  TextWrap,
  TitleText,
} from './InlineBanner.styles';

export interface InlineBannerProps {
  bannerData?: InlineBannerType;
  simoLink?: boolean;
}

export const BOTTOM_BANNER_ID = 'bottom-banner';

const InlineBanner: React.FC<InlineBannerProps> = ({ bannerData, simoLink = false }) => {
  const {
    bannerId,
    customBgColor,
    description,
    theme,
    heroImage,
    title,
    ctaLink = {},
    ctaLabel,
    termsAndConditions,
    callbackQueueName,
  } = bannerData || {};

  const textBlock = title || description;

  // Responsive behaviour: grid span adjustment based on available banner data fields

  const bannerTextVariant = (): string => {
    if (!heroImage && textBlock && ctaLabel) return '2 / 10';
    if (!heroImage && textBlock && !ctaLabel) return '2 / 12';
    if (heroImage && textBlock && !ctaLabel) return '5 / 12';
    return '4 / 10';
  };

  // Determine theme for richtext based on theme on endpoint
  const rteColor = theme === 'dark' ? 'black' : 'white';

  const linkAction = bannerId !== BOTTOM_BANNER_ID ? ctaLink : {};

  const initializeCallbackWidget = useCallback(() => {
    if (bannerId === BOTTOM_BANNER_ID) {
      // eslint-disable-next-line no-unused-expressions
      simoLink ? (window.location.href = ctaLink as string) : window.OpenCallbackForm(callbackQueueName, false);
    }
  }, [bannerId, callbackQueueName, ctaLink, simoLink]);

  return (
    <BannerContainer backgroundColor={customBgColor} data-testid="inline-banner-container">
      <BannerWrapper data-testid="inline-banner-wrapper">
        {heroImage && (
          <BannerImageContainer>
            <NextImage src={heroImage} data-testid="inline-banner-image" height={102} width={180} layout="responsive" />
          </BannerImageContainer>
        )}
        <TextWrap variant={bannerTextVariant()} alignCenter={!heroImage} hasCta={!!ctaLabel}>
          {title && (
            <TitleText data-testid="inline-banner-title">
              <RichText color={rteColor}>{title}</RichText>
            </TitleText>
          )}
          {description && (
            <DescriptionText className="inline-banner-description-text" data-testid="inline-banner-description">
              <RichText color={rteColor}>{description}</RichText>
            </DescriptionText>
          )}
          {termsAndConditions && (
            <div data-testid="inline-banner-tandc" style={{ textAlign: 'center' }}>
              <RichText color={rteColor}>{termsAndConditions}</RichText>
            </div>
          )}
        </TextWrap>
        {ctaLabel && (
          <CTAButton
            data-testid="inline-banner-button"
            onClick={(e) => {
              e.preventDefault();
              initializeCallbackWidget();
            }}
          >
            {bannerId !== BOTTOM_BANNER_ID && (
              <Link href={linkAction}>
                <Button size="s" fullWidth={true} variant={theme === 'dark' ? 'secondary' : 'tertiaryInverse'}>
                  {ctaLabel}
                </Button>
              </Link>
            )}
            {bannerId === BOTTOM_BANNER_ID && (
              <Button size="s" fullWidth={true} variant={theme === 'dark' ? 'secondary' : 'tertiaryInverse'}>
                {ctaLabel}
              </Button>
            )}
          </CTAButton>
        )}
      </BannerWrapper>
    </BannerContainer>
  );
};

export default InlineBanner;
