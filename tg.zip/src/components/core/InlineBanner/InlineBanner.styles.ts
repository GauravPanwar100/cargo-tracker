/* eslint-disable no-nested-ternary */
import styled from 'styled-components';
import { media } from '@src/lib/util/mixins';

interface TextWrapProps {
  variant: string;
  alignCenter: boolean;
  hasCta: boolean;
}

export const BannerContainer = styled.div<{ backgroundColor?: string }>`
  background-color: ${(p) => (p.backgroundColor ? p.backgroundColor : '#5E2750')};
  max-width: 100%;
`;

export const BannerWrapper = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: auto auto auto;
  padding: 24px 15px;
  align-items: center;
  row-gap: 15px;
  width: auto;
  column-gap: 15px;

  ${media.m`
    grid-template-columns: repeat(12, 1fr);
    max-width: 1180px;
    margin: 0 auto;
  `};

  ${media.l`
    grid-template-rows: auto;
    row-gap: 0px;
    justify-content: center;
  `};
`;

export const BannerImg = styled.img`
  max-width: 160px;
  height: auto;
  grid-row: 1 / 2;
  grid-column: 2 / 4;
  justify-self: center;
  max-height: 90px;
  ${media.m`
     
     max-width: 180px;
     grid-column: 6 / 8;
     align-self: center;
  `};

  ${media.l<{ variant?: string }>`
     grid-column: ${(p) => p.variant};
     grid-row: 1 / 2;
     justify-self: end;
  `};
`;

export const BannerImageContainer = styled.div`
  height: 90px;
  max-width: 160px;
  grid-row: 1 / 2;
  grid-column: 2 / 4;

  object-fit: contain;
  ${media.m`
   max-width: 180px;
   grid-column: 6 / 8;
   align-self: center;   
`};

  ${media.l<{ variant?: string }>`
   grid-column: 2 / 4;
   height: 102px;
   
`};
`;

export const TextWrap = styled.div<TextWrapProps>`
  display: flex;
  flex-direction: column;
  align-items: center;
  grid-row: 2 / 3;
  grid-column: 1 / 5;
  p {
    font-size: 15px;
    margin-bottom: 10px;
  }

  ${media.m`
     grid-column: 1 / 13;
     align-self: center;
  `};

  ${media.l<{ variant?: string; alignCenter?: boolean; hasCta?: boolean }>`
    grid-column: ${(p) => p.variant};
    grid-row: 1 / 2;
    align-items: ${(p) => (p.alignCenter ? 'center' : 'flex-start')};
    margin-right: ${(p) => (p.alignCenter || !p.hasCta ? '' : '15px')};
  `};
`;

export const TitleText = styled.div`
  p {
    margin: 0px 0px 12px 0px;
    font-size: 24px;
    text-align: center;
    line-height: 1;

    ${media.m`
    font-size: 34px;
    inline-height: 40px;
    margin: 0px 0px 12px 0px;
  `};

    ${media.l`
    font-size: 40px;
    inline-height: 48px;
    margin: 0px 0px 12px 0px;
    text-align: left;
  `};
  }
`;

export const DescriptionText = styled.div`
  p {
    margin-bottom: 12px;
    font-size: 18px;
    inline-height: 24px;
    text-align: center;

    ${media.l`
    font-size: 20px;
    inline-height: 28px;
    text-align: left;
  `}
  }
`;

export const CTAButton = styled.div`
  grid-row: 3 / 4;
  grid-column: 1 / 5;
  margin: 0px;
  justify-self: center;
  width: 100%;

  ${media.m`
     grid-column: 5 / 9;
  `};

  ${media.l`
     grid-column-end: 12;
     grid-row: 1 / 2;
     max-width: 170px;
     justify-self: end;
  `};
`;
