export { default } from './InlineBanner';
