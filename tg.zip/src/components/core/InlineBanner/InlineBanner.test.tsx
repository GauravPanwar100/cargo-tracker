import React from 'react';
import { fireEvent, render } from 'test-utils';
import InlineBanner from '@src/components/core/InlineBanner';
import { InlineBannerProps } from '@src/components/core/InlineBanner/InlineBanner';
import { InlineBannerType } from '@src/lib/api/types';

const defaultBannerData: InlineBannerType = {
  bannerId: 'top-banner',
  customBgColor: 'red',
  description: 'This is a Description',
  theme: 'light',
  heroImage: '/public/omniout/assets/images/loader/loader-icon.gif',
  title: 'This is a title',
  ctaLink: 'Button link',
  ctaLabel: 'Find out more',
  termsAndConditions: 'terms and conditions',
  callbackQueueName: 'TEST_CALLBACK_NAME',
};

const emptyBannerData: InlineBannerType = {
  bannerId: 'top-banner',
  customBgColor: '',
  description: '',
  theme: 'dark',
  heroImage: '',
  title: '',
  ctaLink: '',
  ctaLabel: '',
  termsAndConditions: '',
  callbackQueueName: '',
};

const mandatoryBannerData: InlineBannerType = {
  bannerId: 'bottom-banner',
  customBgColor: '',
  description: '',
  theme: '',
  heroImage: '',
  title: 'A Title',
  ctaLink: '',
  ctaLabel: '',
  termsAndConditions: '',
  callbackQueueName: '',
};

const defaultProps: InlineBannerProps = {
  bannerData: defaultBannerData,
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<InlineBanner {...props} />);
  return { utils, props };
};

describe('InlineBanner', () => {
  const mockedCallbackWidget = jest.fn();

  beforeAll(() => {
    Object.defineProperty(window, 'OpenCallbackForm', {
      value: mockedCallbackWidget,
    });
  });

  afterEach(() => {
    jest.resetAllMocks();
  });

  it('Should render all banner fields for fully configured inline banner', () => {
    const { utils, props } = setup();
    const title = utils.getByTestId('inline-banner-title');
    const description = utils.getByTestId('inline-banner-description');
    const image = utils.getByTestId('inline-banner-image') as HTMLImageElement;
    expect(image).toBeTruthy();
    expect(title).toBeTruthy();
    expect(description).toBeTruthy();
    expect(utils.getByTestId('inline-banner-container')).toHaveStyle(
      `background-color: ${props.bannerData?.customBgColor};`,
    );
    expect(utils.getByTestId('inline-banner-container')).toHaveStyle(`max-width: 100%;`);
  });

  it('Should not render any banner data for empty inline banner', () => {
    const { utils } = setup({ bannerData: emptyBannerData });
    const title = utils.queryByTestId('inline-banner-title');
    const image = utils.queryByTestId('inline-banner-image');
    const description = utils.queryByTestId('inline-banner-description');
    const ctaButton = utils.queryByTestId('inline-banner-button');
    const termsAndConditions = utils.queryByTestId('inline-banner-tandc');
    expect(title).toBe(null);
    expect(image).toBe(null);
    expect(description).toBe(null);
    expect(ctaButton).toBe(null);
    expect(termsAndConditions).toBe(null);
  });

  it('Should render default background for inline banner', () => {
    const { utils } = setup({ bannerData: mandatoryBannerData });
    const title = utils.queryByTestId('inline-banner-title');
    const image = utils.queryByTestId('inline-banner-image');
    const description = utils.queryByTestId('inline-banner-description');
    const ctaButton = utils.queryByTestId('inline-banner-button');
    const termsAndConditions = utils.queryByTestId('inline-banner-tandc');
    expect(title).toBeTruthy();
    expect(image).toBe(null);
    expect(description).toBe(null);
    expect(ctaButton).toBe(null);
    expect(termsAndConditions).toBe(null);
    expect(utils.getByTestId('inline-banner-container')).toHaveStyle(`background-color: #5E2750`);
  });

  it('Should call genesys callback widget when bottom-banner', () => {
    const { utils } = setup({ bannerData: { ...defaultBannerData, bannerId: 'bottom-banner' } });
    const bannerCtaButton = utils.getByTestId('inline-banner-button');
    fireEvent.click(bannerCtaButton);
    expect(mockedCallbackWidget).toBeCalledWith(defaultBannerData.callbackQueueName, false);
  });

  it('Should not call genesys callback widget when top-banner', () => {
    const { utils } = setup({ bannerData: { ...defaultBannerData, bannerId: 'top-banner' } });
    const bannerCtaButton = utils.getByTestId('inline-banner-button');
    fireEvent.click(bannerCtaButton);
    expect(mockedCallbackWidget).toBeCalledTimes(0);
  });
});
