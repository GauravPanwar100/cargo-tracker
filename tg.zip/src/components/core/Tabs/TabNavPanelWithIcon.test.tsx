import React from 'react';
import { render } from 'test-utils';
import TabNavPanelWithIcon, { TabNavPanelWithIconProps } from './TabNavPanelWithIcon';

const defaultProps: TabNavPanelWithIconProps = {
  isActive: true,
  icon: 'icons/free-delivery.svg',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<TabNavPanelWithIcon {...props} />);
  return { utils, props };
};

describe('TabNavPanelWithIcon', () => {
  it('should render TabNavPanelWithIcon', () => {
    const { utils } = setup();
    expect(utils.getByTestId('tab-nav-panel-item-image')).toBeDefined();
  });
});
