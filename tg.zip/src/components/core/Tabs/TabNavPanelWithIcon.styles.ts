import styled from 'styled-components';
import { fontLineHeightSize, media, variantThemeLinkColors } from '@src/lib/util/mixins';
import { ReactComponent as ArrowRight } from '@src/assets/svg/chevron-right.svg';

interface FeatureTextNavItem {
  isActive: boolean;
}

export const Container = styled.li`
  display: grid;
  grid-template-areas:
    'image'
    'description';
  font-size: ${(p) => p.theme.fontSizes.baseSmall}px;
  line-height: ${(p) => p.theme.lineHeights.footnote}px;
`;

export const Content = styled.div<FeatureTextNavItem>`
  grid-area: description;
  font-family: ${(p) => p.theme.fonts.regular};
  ${fontLineHeightSize('base')}
  ${variantThemeLinkColors}
  ${media.m`
    ${fontLineHeightSize('baseLarge')}
    text-align: center;
    margin-left: 0px;
  `}
  ${(p) =>
    p.isActive &&
    `
    font-weight: bold;
  `}
  & p:last-child {
    margin-bottom: 0;
  }
`;

export const Icon = styled(ArrowRight)`
  width: 15px;
  height: 15px;
  margin-left: 2px;
  position: relative;
  transition: all 0.2s ease-in-out;
`;

export const Image = styled.img<FeatureTextNavItem>`
  grid-area: image;
  width: 24px;
  height: 24px;
  margin: 0 auto;
  ${(p) =>
    p.isActive &&
    `
    filter: invert(23%) sepia(85%) saturate(6846%) hue-rotate(3deg) brightness(83%) contrast(128%);
  `}
`;
