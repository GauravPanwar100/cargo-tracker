import React, { ComponentPropsWithRef, RefForwardingComponent, forwardRef } from 'react';
import { Tab as StyledTab } from './Tab.styles';

export type TabProps = {
  active?: boolean;
  hasIcon?: boolean;
  noOfTabs?: number;
  fullWidth?: boolean;
  children: JSX.Element[];
} & Omit<ComponentPropsWithRef<typeof StyledTab>, 'children'>;

const Tab: RefForwardingComponent<HTMLButtonElement, TabProps> = (
  { active, hasIcon, fullWidth, children, noOfTabs, className, role = 'tab', type = 'button', ...props }: TabProps,
  ref,
) => (
  <StyledTab
    active={active}
    hasIcon={hasIcon}
    fullWidth={fullWidth}
    noOfTabs={noOfTabs}
    aria-selected={active}
    className={className}
    ref={ref}
    role={role}
    type={type}
    {...props}
  >
    {children}
  </StyledTab>
);

export default forwardRef(Tab);
