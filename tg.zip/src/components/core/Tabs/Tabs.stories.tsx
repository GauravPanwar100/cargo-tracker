import React from 'react';
import { storiesOf } from '@storybook/react';
import { PriceTag, Rewards, Tick } from '@src/assets/base64/icons-system';
import { Accordion, AccordionItem } from '@src/components/core/Accordion';
import { FeaturedText, FeaturedTextItem } from '@src/components/core/FeaturedText';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import { Sections } from '@src/lib/constants/storybook';
import Tab from './Tab';
import Tabs from './Tabs';

storiesOf(`${Sections.CORE}|Tabs`, module)
  .add('Default', () => (
    <>
      <Tabs id="101">
        <Tab title="Samsung Galaxy Note 10+ 4G">
          <Section>
            <FeaturedText>
              <FeaturedTextItem icon={PriceTag} title="Endless data in Oz">
                <p>
                  {'Get 45GB at Your Max Speed, then keep using data at speeds of up to '}
                  <a href="# ">1.5Mbps</a>
                </p>
              </FeaturedTextItem>
              <FeaturedTextItem icon={Rewards} title="Standard int’l minutes">
                <p>
                  {'1000 mins to '}
                  <a href="# ">Zone 1</a>
                  {' & 100 mins to '}
                  <a href="# ">Zone 2</a>
                </p>
              </FeaturedTextItem>
              <FeaturedTextItem icon={Tick} title="Standard national calls">
                <p>Unlimited standard national calls & unlimited text in Oz and to overseas</p>
              </FeaturedTextItem>
            </FeaturedText>
          </Section>
        </Tab>
        <Tab title="Samsung Galaxy Note 10">
          <Section>
            <Grid>
              <GridCol>
                <Accordion>
                  <AccordionItem title="First accordion item">
                    <h4>Heading 4</h4>
                    <p>
                      Maecenas faucibus mollis interdum. Sed posuere consectetur est at lobortis. Maecenas sed diam eget
                      risus varius blandit sit amet non magna. Cras mattis consectetur purus sit amet fermentum. Nullam
                      id dolor id nibh ultricies vehicula ut id elit.
                    </p>
                    <p>
                      <img alt="sample" src="https://source.unsplash.com/WLUHO9A_xik/400x300" />
                    </p>
                    <h5>Heading 5</h5>
                    <p>Etiam porta sem malesuada magna mollis euismod.</p>
                    <h6>Heading 6</h6>
                    <p>Donec id elit non mi porta gravida at eget metus.</p>
                  </AccordionItem>
                  <AccordionItem title="Second accordion item">Some test content</AccordionItem>
                  <AccordionItem title="Third accordion item">Some test content</AccordionItem>
                  <AccordionItem title="Fourth accordion item">Some test content</AccordionItem>
                </Accordion>
              </GridCol>
            </Grid>
          </Section>
        </Tab>
        <Tab title="About Vodafone">
          <Section>
            <Grid>
              <GridCol>
                The name Vodafone comes from voice data fone (the latter a sensational spelling of phone).
              </GridCol>
            </Grid>
          </Section>
        </Tab>
      </Tabs>
    </>
  ))
  .add('Level 2', () => (
    <Tabs id="101" withGrid={true}>
      <Tab title="Samsung Galaxy Note 10+ 4G">
        <Section>
          <Grid>
            <GridCol>
              <FeaturedText>
                <FeaturedTextItem icon={PriceTag} title="Endless data in Oz">
                  <p>
                    {'Get 45GB at Your Max Speed, then keep using data at speeds of up to '}
                    <a href="# ">1.5Mbps</a>
                  </p>
                </FeaturedTextItem>
                <FeaturedTextItem icon={Rewards} title="Standard int’l minutes">
                  <p>
                    {'1000 mins to '}
                    <a href="# ">Zone 1</a>
                    {' & 100 mins to '}
                    <a href="# ">Zone 2</a>
                  </p>
                </FeaturedTextItem>
                <FeaturedTextItem icon={Tick} title="Standard national calls">
                  <p>Unlimited standard national calls & unlimited text in Oz and to overseas</p>
                </FeaturedTextItem>
              </FeaturedText>
            </GridCol>
          </Grid>
        </Section>
      </Tab>
      <Tab title="Samsung Galaxy Note 10">
        <Section>
          <Grid>
            <GridCol>
              <Accordion>
                <AccordionItem title="First accordion item">
                  <h4>Heading 4</h4>
                  <p>
                    <img alt="sample" src="https://source.unsplash.com/WLUHO9A_xik/400x300" />
                  </p>
                  <h5>Heading 5</h5>
                  <p>Etiam porta sem malesuada magna mollis euismod.</p>
                  <h6>Heading 6</h6>
                  <p>Donec id elit non mi porta gravida at eget metus.</p>
                </AccordionItem>
                <AccordionItem title="Second accordion item">Some test content</AccordionItem>
                <AccordionItem title="Third accordion item">Some test content</AccordionItem>
              </Accordion>
            </GridCol>
          </Grid>
        </Section>
      </Tab>
      <Tab title="About Vodafone">
        <Section>
          <Grid>
            <GridCol>
              The name Vodafone comes from voice data fone (the latter a sensational spelling of phone).
            </GridCol>
          </Grid>
        </Section>
      </Tab>
    </Tabs>
  ));
