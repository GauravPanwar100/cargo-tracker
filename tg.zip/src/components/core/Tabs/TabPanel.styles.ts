import styled from 'styled-components';

interface TabPanelProps {
  isOpen: boolean;
}
export const TabPanel = styled.div<TabPanelProps>`
  display: block;
  ${(p) => !p.isOpen && 'display: none;'}
`;
