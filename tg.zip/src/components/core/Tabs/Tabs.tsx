import React from 'react';
import { ParsedQuery } from 'query-string';
import { useId } from 'react-id-generator';
import { Grid, GridCol } from '@src/components/core/Grid';
import { TabsNav } from '@src/components/core/TabsNav';
import useScrollToQuery from '@src/lib/hooks/use-scroll-to-query';
import useUpdatingRef from '@src/lib/hooks/use-updating-ref';
import { QueryKey, encodeQueryStringId } from '@src/lib/util/query';
import { useClientQuery } from '@src/lib/util/router';
import { MixinProperty } from '@src/lib/util/mixins';
import { ColorKey } from '@src/lib/theme';
import { trackEvent } from '@src/lib/tracking';
import { kebabCase } from 'lodash';
import TabNavPanelWithIcon from './TabNavPanelWithIcon';
import { TabProps } from './Tab';
import TabPanel from './TabPanel';

export interface TabsProps {
  id?: string;
  withGrid?: boolean;
  activeIndex?: number;
  onTabClick?: (index: number) => void;
  tabsNavBackgroundColor?: MixinProperty<ColorKey>;
  fullWidth?: boolean;
}

interface GetDefaultActiveIndexParams {
  children: React.ReactNode;
  defaultIds: string[];
  query: ParsedQuery | null;
}
const getDefaultActiveIndex = ({ children, defaultIds, query }: GetDefaultActiveIndexParams): number => {
  const activeIndex = React.Children.toArray(children).findIndex((child, i) => {
    if (!React.isValidElement<TabProps>(child)) return false;

    const id = child.props.id ?? defaultIds[i];
    // Find a tab that matches the query parameter for tabs
    return query?.[QueryKey.TAB] === id;
  });

  return activeIndex !== -1 ? activeIndex : 0;
};

const Tabs: React.FC<TabsProps> = ({
  children,
  id: containerId,
  withGrid,
  activeIndex,
  onTabClick,
  tabsNavBackgroundColor,
  fullWidth = false,
}) => {
  const generatedIds = useId(React.Children.count(children), 'tab-item-');
  const defaultIds = React.Children.toArray(children).map((child, i) => {
    if (!React.isValidElement<TabProps>(child) || typeof child.props.title !== 'string') {
      return generatedIds[i];
    }

    return encodeQueryStringId(child.props.title);
  });

  const [activeTabIndex, setActiveTabIndex] = React.useState(activeIndex ?? 0);
  const query = useClientQuery();
  const getDefaultActiveIndexParams = useUpdatingRef({
    children,
    defaultIds,
    query,
  });
  const isQueryReady = !!query;
  React.useEffect(() => {
    if (isQueryReady) {
      setActiveTabIndex(activeIndex ?? getDefaultActiveIndex(getDefaultActiveIndexParams.current));
    }
  }, [activeIndex, getDefaultActiveIndexParams, isQueryReady]);

  const handleTabClick = React.useCallback(
    (index: number, title: string) => () => {
      if (onTabClick) {
        onTabClick(index);
      }
      trackEvent({
        pageEventType: 'tabs-open',
        pageEventValue: 'click',
        pageEventAttributeOne: kebabCase(title),
      });
      setActiveTabIndex(index);
    },
    [setActiveTabIndex, onTabClick],
  );

  const tabs = React.useMemo(
    () =>
      React.Children.toArray(children).map((child, index) => {
        if (!React.isValidElement<TabProps>(child)) {
          return { tab: '', tabPanel: '' };
        }
        const id = child.props.id ?? defaultIds[index];
        const tab = React.cloneElement(child, {
          'aria-controls': `tabpanel-${id}`,
          active: activeTabIndex === index,
          hasIcon: !!child.props.iconUrl,
          noOfTabs: React.Children.toArray(children).filter(Boolean).length,
          fullWidth: fullWidth ?? false,
          children:
            child.props.iconUrl && child.props.title ? (
              <TabNavPanelWithIcon
                key={child.props.title}
                icon={child.props.iconUrl}
                isActive={activeTabIndex === index}
              >
                {child.props.title}
              </TabNavPanelWithIcon>
            ) : (
              child.props.title
            ),
          key: id,
          id,
          onClick: handleTabClick(index, child.props.title),
        });

        const tabPanel = (
          <TabPanel key={id} id={id} isOpen={activeTabIndex === index}>
            {child.props.children}
          </TabPanel>
        );

        return { tab, tabPanel };
      }),
    [children, defaultIds, activeTabIndex, handleTabClick, fullWidth],
  );

  useScrollToQuery({ queryKey: QueryKey.TAB });

  let tabsNav = (
    <TabsNav id={containerId} role="tablist" tabsNavBackgroundColor={tabsNavBackgroundColor} fullWidth={fullWidth}>
      {tabs && tabs.map((n) => n.tab)}
    </TabsNav>
  );

  if (withGrid) {
    tabsNav = (
      <Grid data-testid="tab-nav-grid">
        <GridCol>{tabsNav}</GridCol>
      </Grid>
    );
  }

  return (
    <>
      {tabsNav}
      {tabs && tabs.map((n) => n.tabPanel)}
    </>
  );
};

export default Tabs;
