import React from 'react';
import '@testing-library/jest-dom';
import { render } from '@src/test-utils';
import Tabs, { TabsProps } from './Tabs';
import Tab from './Tab';

const defaultTabs = [
  <div key="tab-1" data-testId="tab-1">
    Tab 1
  </div>,
  <div key="tab-2" data-testId="tab-2">
    Tab 2
  </div>,
];

const setup = (extraProps?: object) => {
  const props: TabsProps = {
    ...extraProps,
  };
  const utils = render(
    <Tabs {...props}>
      {defaultTabs.map((tab) => (
        <Tab title={`${tab.key}-title`} key={tab.key as string}>
          {tab}
        </Tab>
      ))}
    </Tabs>,
  );
  return { props, utils };
};

describe('Tabs', () => {
  it('should render tabs', () => {
    const { utils } = setup();
    expect(utils.getByTestId('tabs-nav')).toBeDefined();
    expect(utils.getByText('tab-1-title')).toBeDefined();
    expect(utils.getByText('tab-2-title')).toBeDefined();
  });

  it('tabs should be clickable', () => {
    const { utils } = setup();
    const tab1 = utils.getByText('Tab 1');
    const tab2 = utils.getByText('Tab 2');
    expect(tab1).toBeVisible();
    expect(tab2).not.toBeVisible();
    utils.getByText('tab-2-title').click();
    expect(tab1).not.toBeVisible();
    expect(tab2).toBeVisible();
  });

  it('should render with grid', () => {
    const { utils } = setup({ withGrid: true });
    expect(utils.getByTestId('tab-nav-grid')).toBeDefined();
  });

  it('should display active index when set', () => {
    const { utils } = setup({ activeIndex: 1 });
    expect(utils.getByText('Tab 2')).toBeVisible();
    expect(utils.getByText('Tab 1')).not.toBeVisible();
  });
});
