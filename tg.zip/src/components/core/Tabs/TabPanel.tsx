import React from 'react';
import { TabPanel as StyledTabPanel } from './TabPanel.styles';

export interface TabPanelProps {
  children?: React.ReactNode;
  id: string;
  isOpen?: boolean;
}

const TabPanel: React.FC<TabPanelProps> = ({ children, id, isOpen = false }) => (
  <StyledTabPanel id={`tabpanel-${id}`} role="tabpanel" aria-labelledby={id} isOpen={isOpen}>
    {children}
  </StyledTabPanel>
);

export default TabPanel;
