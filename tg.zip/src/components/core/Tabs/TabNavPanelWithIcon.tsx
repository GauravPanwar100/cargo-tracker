import React from 'react';
import RichText from '@src/components/core/RichText';
import { Container, Content, Image } from './TabNavPanelWithIcon.styles';

export interface TabNavPanelWithIconProps {
  isActive: boolean;
  icon: string;
}

const TabNavPanelWithIcon: React.FC<TabNavPanelWithIconProps> = ({ icon, isActive, children }) => {
  return (
    <Container>
      {icon && <Image src={icon} alt="" data-testid="tab-nav-panel-item-image" isActive={isActive} />}
      {children && (
        <Content isActive={isActive}>
          <RichText data-testid="tab-nav-panel-item-text">{children}</RichText>
        </Content>
      )}
    </Container>
  );
};

export default TabNavPanelWithIcon;
