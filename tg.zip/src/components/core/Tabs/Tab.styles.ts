import styled, { css } from 'styled-components';
import { buttonReset, focusOutline, fontLineHeightSize, media } from '@src/lib/util/mixins';

interface TabProps {
  active?: boolean;
  hasIcon?: boolean;
  fullWidth?: boolean;
  noOfTabs?: number;
}
export const Tab = styled.button<TabProps>`
  ${buttonReset}
  display: block;
  position: relative;
  ${(p) =>
    p.fullWidth &&
    p.noOfTabs &&
    p.noOfTabs > 0 &&
    css`
      width: ${Math.floor(100 / p.noOfTabs)}%;
      padding: 16px 0;
      margin: 0 auto;
    `}
  ${(p) =>
    !p.fullWidth &&
    css`
      margin-right: 10px;
      min-width: 80px;
      max-width: 124px;
      padding: 10px 5px;

      ${media.m`
        padding: 16px 5px;
        margin-right: 56px;
        max-width: initial;
        ${fontLineHeightSize('baseLarge')}
      `}
    `}
  color: ${(p) => p.theme.colors.anthracite};
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  white-space: initial;
  ${fontLineHeightSize('base')}

  &:focus {
    ${focusOutline()}
  }

  &:last-child {
    margin-right: 0;
  }

  &:hover {
    color: ${(p) => p.theme.colors.darkGrey};
  }

  ${(p) =>
    p.hasIcon &&
    css`
      &:before {
        content: '';
        display: block;
        position: absolute;
        left: 0;
        top: 0;
        width: 0;
        height: 3px;
        background-color: transparent;
        transition: all 250ms ease-out;
      }
    `}

  ${(p) =>
    !p.hasIcon &&
    css`
      &:after {
        content: '';
        display: block;
        position: absolute;
        left: 0;
        bottom: 0;
        width: 0;
        height: 3px;
        background-color: transparent;
        transition: all 250ms ease-out;
      }
    `}

  ${(p) =>
    p.active &&
    css`
      color: ${p.theme.colors.darkGrey};
      font-family: ${p.theme.fonts.bold};
    `}

  ${(p) =>
    p.active &&
    p.hasIcon &&
    css`
      background-color: ${p.theme.colors.white};
      &:before {
        background-color: ${p.theme.colors.red};
        width: 100%;
      }
    `}

  ${(p) =>
    p.active &&
    !p.hasIcon &&
    css`
      &:after {
        background-color: ${p.theme.colors.red};
        width: 100%;
      }
    `}
`;
