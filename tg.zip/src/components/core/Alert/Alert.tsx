import React from 'react';
import { ReactComponent as ErrorIcon } from '@src/assets/svg/error.svg';
import { ReactComponent as InfoIcon } from '@src/assets/svg/info.svg';
import { ReactComponent as SuccessIcon } from '@src/assets/svg/success.svg';
import IconWrapper from '@src/components/core/IconWrapper';
import { MixinProperty } from '@src/lib/util/mixins';
import { Container, Content, Header, Title } from './Alert.styles';

export type AlertVariant = 'info' | 'success' | 'error' | 'positive' | 'customInformation';

const IconMap: Record<AlertVariant, React.FC<React.SVGProps<SVGSVGElement>>> = {
  error: ErrorIcon,
  info: InfoIcon,
  success: SuccessIcon,
  positive: SuccessIcon, // alert variant added for new launch handsets
  customInformation: InfoIcon,
};

export interface AlertProps {
  fullWidth?: boolean;
  fullHeight?: boolean;
  inline?: boolean;
  marginBottom?: MixinProperty;
  marginTop?: MixinProperty;
  size?: 's' | 'm';
  title?: string;
  variant?: AlertVariant;
  showInCenter?: boolean;
}

const Alert: React.FC<AlertProps> = ({
  children,
  fullWidth = false,
  fullHeight = false,
  inline = false,
  marginBottom,
  marginTop,
  size = 'm',
  title,
  variant = 'info',
  showInCenter = false,
}) => (
  <Container
    data-testid="alert"
    fullWidth={fullWidth}
    fullHeight={fullHeight}
    inline={inline}
    marginBottom={marginBottom}
    marginTop={marginTop}
    variant={variant}
    showInCenter={showInCenter}
  >
    <Header variant={variant} inline={inline}>
      <IconWrapper svg={IconMap[variant]} width={{ xs: '24px', m: '28px' }} height={{ xs: '24px', m: '28px' }} />
    </Header>
    <Content inline={inline} size={size}>
      {title && <Title>{title}</Title>}
      {children}
    </Content>
  </Container>
);

export default Alert;
