import React, { useEffect, useRef } from 'react';
import AnimateHeight from 'react-animate-height';
import Alert, { AlertProps } from './Alert';

// Animates closed when there are no children being passed
// You MUST remember to pass falsy children if you want the height to properly collapse
const AnimatedAlert: React.FC<AlertProps> = ({ children, ...props }) => {
  const cachedChildren = useRef(children);

  // Cache the children so that when the height is animating closed (because there are no children
  // being passed), we can still show the cached version of the children as content.
  // This avoids a scenario where the height animation jumps closed too suddenly because the
  // children are no longer taking up any space
  useEffect(() => {
    if (children) {
      cachedChildren.current = children;
    }
  }, [children]);

  return (
    <AnimateHeight duration={250} easing="ease-out" height={children ? 'auto' : 0}>
      <Alert {...props}>{children || cachedChildren.current}</Alert>
    </AnimateHeight>
  );
};

export default AnimatedAlert;
