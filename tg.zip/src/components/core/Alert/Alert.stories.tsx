import React from 'react';
import { storiesOf } from '@storybook/react';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import { Sections } from '@src/lib/constants/storybook';
import Alert from './Alert';

storiesOf(`${Sections.CORE}|Alert`, module).add('Info', () => (
  <Section>
    <Grid>
      <GridCol>
        <Alert title="Is your device eSIM enabled?">
          <p>To use an eSIM your device needs to be compatible.</p>
          <p>
            <a href="#">Here’s a list of popular eSIM enabled devices</a>
          </p>
        </Alert>
      </GridCol>
      <GridCol>
        <Alert inline={true}>
          <p>
            We are experiencing high levels of demand, so wait times could be longer than usual. Check the estimated
            delivery time below.
          </p>
        </Alert>
      </GridCol>
      <GridCol>
        <Alert inline={true}>
          <p>Short description to demonstrate inline behaviour</p>
        </Alert>
      </GridCol>
    </Grid>
  </Section>
));

storiesOf(`${Sections.CORE}|Alert`, module).add('Error', () => (
  <Section>
    <Grid>
      <GridCol>
        <Alert title="Is your device eSIM enabled?" variant="error">
          <p>To use an eSIM your device needs to be compatible.</p>
          <p>
            <a href="#">Here’s a list of popular eSIM enabled devices</a>
          </p>
        </Alert>
      </GridCol>
      <GridCol>
        <Alert inline={true} variant="error">
          <p>
            We are experiencing high levels of demand, so wait times could be longer than usual. Check the estimated
            delivery time below.
          </p>
        </Alert>
      </GridCol>
      <GridCol>
        <Alert inline={true} variant="error">
          <p>Short description to demonstrate inline behaviour</p>
        </Alert>
      </GridCol>
    </Grid>
  </Section>
));

storiesOf(`${Sections.CORE}|Alert`, module).add('Success', () => (
  <Section>
    <Grid>
      <GridCol>
        <Alert title="Is your device eSIM enabled?" variant="success">
          <p>To use an eSIM your device needs to be compatible.</p>
          <p>
            <a href="#">Here’s a list of popular eSIM enabled devices</a>
          </p>
        </Alert>
      </GridCol>
      <GridCol>
        <Alert inline={true} variant="success">
          <p>
            We are experiencing high levels of demand, so wait times could be longer than usual. Check the estimated
            delivery time below.
          </p>
        </Alert>
      </GridCol>
      <GridCol>
        <Alert inline={true} variant="success">
          <p>Short description to demonstrate inline behaviour</p>
        </Alert>
      </GridCol>
    </Grid>
  </Section>
));
