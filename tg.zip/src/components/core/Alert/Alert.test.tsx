import React from 'react';
import { render } from 'test-utils';
import Alert, { AlertProps } from './Alert';

const defaultProps: AlertProps = {
  title: 'Alert Title',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<Alert {...props} />);
  return { utils, props };
};

describe('Alert', () => {
  it('displays a title', () => {
    const { utils, props } = setup();
    if (props.title) {
      utils.getByText(props.title);
    }
  });
});
