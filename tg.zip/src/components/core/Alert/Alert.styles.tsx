import styled, { css } from 'styled-components';
import { MixinProperty, fontLineHeightSize, marginBottomMixin, marginTopMixin, media } from '@src/lib/util/mixins';
import { ColorKey } from '@src/lib/theme';
import { AlertVariant } from './Alert';

type ColorMap = Record<AlertVariant, Partial<ColorKey>>;

const ColorMap: ColorMap = {
  error: 'red',
  info: 'freshOrange',
  success: 'uiGreen',
  positive: 'uiGreen',
  customInformation: 'persianBlue',
};

interface ContainerProps {
  fullWidth?: boolean;
  fullHeight?: boolean;
  inline: boolean;
  marginBottom?: MixinProperty;
  marginTop?: MixinProperty;
  variant: AlertVariant;
  showInCenter?: boolean;
}
export const Container = styled.div<ContainerProps>`
  display: ${(p) => (p.inline ? 'inline-flex' : 'flex')};
  flex-direction: ${(p) => (p.inline ? 'row' : 'column')};
  border: 1px solid ${(p) => p.theme.colors[ColorMap[p.variant]]};
  border-radius: 6px;
  overflow: hidden;
  text-align: left;
  ${(p) => marginBottomMixin(p.marginBottom)}
  ${(p) => marginTopMixin(p.marginTop)}
  ${(p) =>
    p.fullWidth &&
    css`
      width: 100%;
    `}
  ${(p) =>
    p.fullHeight &&
    css`
      min-height: 100%;
    `}
  ${(p) =>
    p.showInCenter &&
    css`
      margin: 0 auto;
    `}
  ${media.m`
    max-width: ${(p) => p.theme.sizes.textMaxWidthTablet}px;
  `}

  ${media.l`
    max-width: ${(p) => p.theme.sizes.textMaxWidth}px;
  `}
`;

interface HeaderProps {
  inline: boolean;
  variant: AlertVariant;
}
export const Header = styled.div<HeaderProps>`
  display: flex;
  align-items: center;
  justify-content: center;
  padding: ${(p) => (p.inline ? '0 14px' : '6px 0')};
  background-color: ${(p) => p.theme.colors[ColorMap[p.variant]]};
  color: ${(p) => p.theme.colors.white};
`;

export const Title = styled.h4`
  font-family: ${(p) => p.theme.fonts.regular};
  margin-bottom: 8px;

  ${media.m`
    font-family: ${(p) => p.theme.fonts.light};
  `}
`;

interface ContentProps {
  inline: boolean;
  size: 's' | 'm';
}
export const Content = styled.div<ContentProps>`
  flex: 1;
  background: ${(p) => p.theme.colors.white};
  padding: ${(p) => (p.inline ? '10px 16px' : '16px 20px')};

  p {
    margin-bottom: 8px;
    ${fontLineHeightSize('base')}

    :last-child {
      margin-bottom: 0;
    }
  }

  ${media.m<ContentProps>`
    padding: ${(p) => !p.inline && p.size !== 's' && '16px 24px'};
    ${(p) =>
      p.size !== 's' &&
      css`
        p {
          ${fontLineHeightSize('baseLarge')}
        }
      `}
  `}

  h4 {
    font-family: ${(p) => p.theme.fonts.regular};
    margin-bottom: 8px;
    ${media.m`
      font-family: ${(p) => p.theme.fonts.light};
    `}
  }
`;

interface AlertContainerProps {
  marginBottom?: MixinProperty;
}

export const AlertContainer = styled.div<AlertContainerProps>`
  margin: 0 auto 32px;
  ${media.m`
    max-width: 600px;
    margin-bottom: 48px;
  `}
  ${(p) => marginBottomMixin(p.marginBottom)};
  & div {
    ${media.m`
      max-width: 600px;
    `}
  }
`;
