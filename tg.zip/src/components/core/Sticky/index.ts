export { default } from './Sticky';
