import React from 'react';
import { Sticky as StyledSticky } from './Sticky.styles';

export interface StickyProps {
  topOffset?: string;
}

const Sticky: React.FC<StickyProps> = ({ children, topOffset = '0' }) => (
  <StyledSticky topOffset={topOffset} data-testid="sticky">
    {children}
  </StyledSticky>
);

export default Sticky;
