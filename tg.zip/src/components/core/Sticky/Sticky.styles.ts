import styled from 'styled-components';

interface StickyProps {
  topOffset: string;
}
export const Sticky = styled.div<StickyProps>`
  position: sticky;
  top: ${(p) => p.topOffset};
`;
