import React from 'react';
import { render } from 'test-utils';
import Sticky, { StickyProps } from './Sticky';

const defaultProps: StickyProps = {
  topOffset: '',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<Sticky {...props} />);
  return { utils, props };
};

describe('Sticky', () => {
  it('should render Sticky', () => {
    const { utils } = setup();
    utils.getByTestId('sticky');
  });
});
