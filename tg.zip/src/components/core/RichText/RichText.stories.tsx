import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import RichText from './RichText';

storiesOf(`${Sections.CORE}|RichText`, module).add('default', () => (
  <>
    <RichText>
      <h2>This is a text that passes in a React Element</h2>
    </RichText>
    <RichText>{'<h2>While this is a text that passes in a string</h2>'}</RichText>
  </>
));
