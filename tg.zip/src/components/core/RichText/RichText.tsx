/* eslint react/no-danger: 0 */
import { kebabCase } from 'lodash';
import React from 'react';
import styled, { css } from 'styled-components';
import he from 'he';
import sanitize from 'sanitize-html';
import { useSetModal } from '@src/lib/context/modal';
import { ColorKey, FontSizeKey } from '@src/lib/theme';
import {
  MixinProperty,
  fontLineHeightSize,
  fontSizeMixin,
  lineHeightMixin,
  marginBottomMixin,
  marginTopMixin,
  paddingBottomMixin,
  textAlignMixin,
} from '@src/lib/util/mixins';
import { trackEvent } from '@src/lib/tracking';

interface RootProps {
  color?: ColorKey | 'inherit';
  pTagMarginTop?: MixinProperty;
  pTagMarginBottom?: MixinProperty;
  pTagPaddingBottom?: MixinProperty;
  textAlign?: MixinProperty<React.CSSProperties['textAlign']>;
  pTagFontSize?: MixinProperty<FontSizeKey>;
  pTagLineHeight?: MixinProperty<FontSizeKey>;
  pTagFontLineHeightSize?: FontSizeKey;
  pNoMargin?: boolean;
}
interface RichTextProps extends RootProps, Omit<React.HTMLAttributes<HTMLDivElement>, keyof RootProps | 'children'> {
  /**
   * Although `React.ReactNode` already includes `string`, this field will be handled specially when a `string` is
   * passed (i.e. unescaping and sanitising HTML)
   */
  children?: string | React.ReactNode;
}
const MODAL_TRIGGER_ELEM = 'vha-modal-trigger';
const ALERT_LINK_ELEM = 'vha-alert-link';
const BUNDLE_AND_SAVE = 'bundle-title';

/**
 * Certain modal triggers require tracking when activated
 * @param id
 * @param anchor
 */
const trackModalTriggerIfRequired = (id: string, anchor: HTMLAnchorElement) => {
  switch (id) {
    case 'remainingbalance':
      trackEvent({
        pageEventAttributeOne: kebabCase(anchor.innerText),
        pageEventType: 'show-remaining-balance-modal',
        pageEventValue: 'show-remaining-balance',
      });
      break;

    case 'bundleandsave':
      trackEvent({
        pageEventAttributeOne: kebabCase(anchor.innerText),
        pageEventType: 'show-eligible-plans-modal',
        pageEventValue: 'show-eligible-plans',
      });
      break;

    default:
    // Do nothing
  }
};

const RichText: React.FC<RichTextProps> = ({ children, onClick, ...props }) => {
  const setModalId = useSetModal();

  const handleOnClick: React.MouseEventHandler<HTMLDivElement> = React.useCallback(
    (e) => {
      const target = e.target as Element;
      const el = target.closest(`a[data-type="${MODAL_TRIGGER_ELEM}"]`) as HTMLAnchorElement | null;
      const id = el?.getAttribute('id');
      if (id && el && e.currentTarget.contains(el)) {
        e.preventDefault();
        e.stopPropagation();
        setModalId(id);
        trackModalTriggerIfRequired(id, el);
      }

      onClick?.(e);
    },
    [onClick, setModalId],
  );

  if (typeof children === 'string') {
    const unescaped = he.unescape(children);
    const sanitized = sanitize(unescaped, {
      allowedTags: sanitize.defaults.allowedTags.concat([
        'h1',
        'h2',
        'h4',
        MODAL_TRIGGER_ELEM,
        'u',
        'a',
        'span',
        'sup',
        'small',
        'img',
      ]),
      allowedAttributes: {
        [MODAL_TRIGGER_ELEM]: ['id'],
        a: ['data-type', 'href', 'id', 'target', 'title', 'style', 'onclick', 'class'],
        table: ['border', 'cellpadding', 'cellspacing', 'width', 'height', 'style'],
        th: ['colspan', 'rowspan', 'style'],
        td: ['colspan', 'rowspan', 'style'],
        p: ['style'],
        b: ['style'],
        sup: ['style'],
        span: ['style', 'id', 'data-value', 'class'],
        img: ['alt', 'src', 'id', 'width', 'height', 'style'],
        div: ['id', 'data-value'],
      },
      allowedSchemes: ['http', 'https', 'ftp', 'mailto', 'tel'],
      transformTags: {
        [MODAL_TRIGGER_ELEM]: sanitize.simpleTransform(
          'a',
          { 'data-type': MODAL_TRIGGER_ELEM, href: '#', title: 'More information' },
          true,
        ),
      },
    });

    return <Root {...props} dangerouslySetInnerHTML={{ __html: sanitized }} onClick={handleOnClick} />;
  }
  return <Root {...props}>{children}</Root>;
};

const Root = styled.div<RootProps>`
  color: ${(p) => {
    if (p.color === 'inherit') return p.color;
    return p.color ? p.theme.colors[p.color] : p.theme.variants.mainColor;
  }};
  ${(p) => textAlignMixin(p.textAlign)}

  a {
    color: inherit;
    &[data-type='${MODAL_TRIGGER_ELEM}'],
    &[data-type='${ALERT_LINK_ELEM}'],
    &[href^='tel:'] {
      color: inherit;
    }
    &[data-type='${BUNDLE_AND_SAVE}'] {
      color: ${(p) => p.theme.colors.white};
    }
    &:hover,
    &:focus,
    &:active {
      text-decoration: none;
      color: ${(p) => p.theme.colors.red};
    }
  }

  p {
    ${(p) => marginTopMixin(p.pTagMarginTop)}
    ${(p) => marginBottomMixin(p.pTagMarginBottom)}
    ${(p) => paddingBottomMixin(p.pTagPaddingBottom)}
    ${(p) => fontSizeMixin(p.pTagFontSize)}
    ${(p) => lineHeightMixin(p.pTagLineHeight)}
    ${(p) => p.pTagFontLineHeightSize && fontLineHeightSize(p.pTagFontLineHeightSize)}
    ${(p) =>
      p.pNoMargin &&
      css`
        margin: 0;
      `}
  }
`;

export default React.memo(RichText);
