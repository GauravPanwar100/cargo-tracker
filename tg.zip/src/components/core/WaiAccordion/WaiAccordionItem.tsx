import { first, last } from 'lodash';
import React from 'react';
import styled, { css } from 'styled-components';
import { ReactComponent as ChevronDownRedSmall } from '@src/assets/svg/chevron-down-red-small.svg';
import useCollapsableState from '@src/lib/hooks/use-collapsable-state';
import useIsomorphicLayoutEffect from '@src/lib/hooks/use-isomorphic-layout-effect';
import AccordionContext from '@src/components/core/WaiAccordion/context';
import { focusOutline, unitlessToPx } from '@src/lib/util/mixins';
import { KeyboardEventKeyValue } from '@src/lib/util/dom';
import { useId } from 'react-id-generator';
import { trackEvent } from '@src/lib/tracking';

interface WaiAccordionHeaderProps {
  $disabled: boolean | NonNullable<React.CSSProperties['cursor']>;
  $padding?: number;
  $withDefaults: boolean;
}

const AccordionHeader = styled.div<WaiAccordionHeaderProps>`
  padding: ${(p) => unitlessToPx(p.$padding)};
  cursor: pointer;

  &:focus {
    @supports not selector(:focus-visible) {
      // Using outline instead of box-shadow due to issues with stacking context
      ${focusOutline()}
    }

    &:focus-visible {
      // Using outline instead of box-shadow due to issues with stacking context
      ${focusOutline()}
    }
  }

  &[aria-disabled='true'] {
    cursor: ${(p) => (typeof p.$disabled === 'string' ? p.$disabled : 'not-allowed')};
  }

  ${(p) =>
    p.$withDefaults &&
    css`
      position: relative;
      padding-right: ${unitlessToPx((p.$padding ?? 0) + 40)};
    `}
`;

interface DefaultIndicatorProps {
  $isOpen: boolean;
  $padding?: number;
}

const DefaultIndicator = styled(ChevronDownRedSmall)<DefaultIndicatorProps>`
  position: absolute;
  top: 50%;
  right: ${(p) => unitlessToPx(p.$padding ?? 0)};
  height: 40px;
  width: 40px;
  transform: translateY(-50%) rotate(${(p) => (p.$isOpen ? 180 : 0)}deg);
`;

const getAllAccordionHeadersByGroupId = (id: string) =>
  Array.from(document.querySelectorAll<HTMLElement>(`${AccordionHeader}[data-accordion-id="${id}"]`));

const AccordionBody = styled.div``;

export interface WaiAccordionItemProps {
  children: React.ReactNode | ((props: { isOpen: boolean }) => React.ReactNode);
  defaultOpen?: boolean;
  /**
   * Set to `true`, or specify a custom `cursor` value to disable toggling by the user.
   * NOTE: The Accordion Item can still be toggled imperatively or by `atLeastOne`/`atMostOne`
   * @default false
   */
  disabled?: boolean | React.CSSProperties['cursor'];
  header: React.ReactNode | ((props: { isOpen: boolean; disabled: boolean }) => React.ReactNode);
  headerPadding?: number;
  id?: string;
  reverseOrder?: boolean;
  'data-testid'?: string;
}

export interface WaiAccordionItemRef {
  disabled: boolean;
  isOpen: boolean;
  open: (immediate?: boolean) => void;
  close: (immediate?: boolean) => void;
  toggle: (immediate?: boolean) => void;
}

/**
 * WAI-ARIA Accessible Accordion Item Component
 *
 * NOTE: This is a mostly functional component and styles should not be directly modified. Instead,
 * pass a function to `header` and/or `children`, or create a wrapper component which handles the
 * styling outside this component.
 *
 * @see https://www.w3.org/TR/wai-aria-practices-1.1/#accordion
 *
 * @param props
 * @param ref Ref for imperative control of the Accordion Item
 */
const WaiAccordionItem = (
  {
    children,
    defaultOpen = false,
    disabled = false,
    header,
    headerPadding,
    id: suppliedId,
    reverseOrder = false,
    'data-testid': dataTestid,
  }: WaiAccordionItemProps,
  ref: React.Ref<WaiAccordionItemRef>,
) => {
  const [generatedId] = useId(1, 'wai-accordion-item-');
  const id = suppliedId || generatedId;
  const headerId = `${id}-header`;

  const [state, dispatch] = React.useContext(AccordionContext);
  const isOpen = state.opened.includes(id);

  const open = React.useCallback((immediate = false) => dispatch({ type: 'open', id, immediate }), [dispatch, id]);
  const close = React.useCallback((immediate = false) => dispatch({ type: 'close', id, immediate }), [dispatch, id]);
  const toggle = React.useCallback((immediate = false) => dispatch({ type: 'toggle', id, immediate }), [dispatch, id]);

  const needsOpening = React.useRef(defaultOpen);
  useIsomorphicLayoutEffect(() => {
    if (needsOpening.current) open(true);
  }, [open]);

  React.useImperativeHandle(
    ref,
    () => ({
      disabled: !!disabled,
      isOpen,
      open,
      close,
      toggle,
    }),
    [close, disabled, isOpen, open, toggle],
  );

  const onFocus: React.FocusEventHandler<HTMLElement> = React.useCallback(
    (e) => {
      if (e.target !== e.currentTarget) return;
      dispatch({ type: 'focus', id });
    },
    [dispatch, id],
  );

  const onBlur: React.FocusEventHandler<HTMLElement> = React.useCallback(
    (e) => {
      if (e.target !== e.currentTarget) return;
      dispatch({ type: 'blur', id });
    },
    [dispatch, id],
  );

  const onClick: React.MouseEventHandler<HTMLElement> = React.useCallback(
    (e) => {
      // TODO: Filter out clicks on contained interactive elements (e.g. button or link)
      if (e.isDefaultPrevented()) return;
      if (!disabled) toggle();
      trackEvent({
        pageEventType: 'accordion',
        pageEventValue: isOpen ? 'close' : 'open',
        pageEventAttributeOne: headerId,
      });
    },
    [disabled, headerId, isOpen, toggle],
  );

  const headerRef = React.useRef<HTMLElement>(null);

  const onKeyDown: React.KeyboardEventHandler<HTMLElement> = React.useCallback(
    (e) => {
      if (e.target !== e.currentTarget || e.isDefaultPrevented()) return;

      switch (e.key) {
        case KeyboardEventKeyValue.ENTER:
        case KeyboardEventKeyValue.SPACE:
          // NOTE: If the header is a `<button />`, it will automatically fire a click event that
          // we're already handling. Ignoring such cases so we don't double-handle the event.
          if (headerRef.current!.tagName !== 'BUTTON') {
            e.preventDefault();
            if (!disabled) toggle();
          }
          break;

        case KeyboardEventKeyValue.ARROW_DOWN: {
          e.preventDefault();
          const headers = getAllAccordionHeadersByGroupId(state.id);
          headers[(headers.indexOf(headerRef.current!) + 1) % headers.length].focus();
          break;
        }

        case KeyboardEventKeyValue.ARROW_UP: {
          e.preventDefault();
          const headers = getAllAccordionHeadersByGroupId(state.id);
          headers[(headers.length + headers.indexOf(headerRef.current!) - 1) % headers.length].focus();
          break;
        }

        case KeyboardEventKeyValue.HOME:
          e.preventDefault();
          first(getAllAccordionHeadersByGroupId(state.id))!.focus();
          break;

        case KeyboardEventKeyValue.END:
          e.preventDefault();
          last(getAllAccordionHeadersByGroupId(state.id))!.focus();
          break;

        default:
        // do nothing
      }
    },
    [disabled, state.id, toggle],
  );

  const isHeaderDisabled = (state.atLeastOne && state.opened.length < 2 && isOpen) || !!disabled;

  const {
    ref: collapsableRef,
    render,
    style,
  } = useCollapsableState(isOpen, {
    immediate: state.immediate,
  });

  const body = (
    <AccordionBody
      id={id}
      role="region"
      aria-labelledby={headerId}
      ref={collapsableRef as React.ComponentPropsWithRef<typeof AccordionBody>['ref']}
      style={style}
      tabIndex={isOpen ? undefined : -1}
      hidden={!render}
      aria-hidden={!isOpen}
      data-testid={dataTestid && `${dataTestid}-body`}
    >
      {typeof children === 'function' ? children({ isOpen: render }) : children}
    </AccordionBody>
  );

  return (
    <>
      {reverseOrder && body}
      <AccordionHeader
        id={headerId}
        role="button"
        onFocus={onFocus}
        onBlur={onBlur}
        onClick={onClick}
        onKeyDown={onKeyDown}
        tabIndex={0}
        aria-expanded={isOpen}
        aria-controls={id}
        aria-disabled={isHeaderDisabled}
        data-accordion-id={state.id}
        data-testid={dataTestid && `${dataTestid}-header`}
        $disabled={disabled}
        $padding={headerPadding}
        $withDefaults={typeof header !== 'function'}
        ref={headerRef as React.ComponentPropsWithRef<typeof AccordionHeader>['ref']}
      >
        {typeof header === 'function' ? (
          header({ isOpen, disabled: isHeaderDisabled })
        ) : (
          <>
            {header}
            <DefaultIndicator $isOpen={isOpen} $padding={headerPadding} />
          </>
        )}
      </AccordionHeader>
      {!reverseOrder && body}
    </>
  );
};

export default React.forwardRef(WaiAccordionItem);
