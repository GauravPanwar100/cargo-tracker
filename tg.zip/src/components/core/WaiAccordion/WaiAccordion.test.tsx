import FakeTimers from '@sinonjs/fake-timers';
import { fireEvent } from '@testing-library/dom';
import userEvent from '@testing-library/user-event';
import React from 'react';
import { act } from 'react-dom/test-utils';
import { KeyboardEventKeyValue } from '@src/lib/util/dom';
import { RenderResult, render, waitForEventLoopToDrain } from '@src/test-utils';

const mockUseFocusVisible = jest.fn();
jest.mock('@src/lib/hooks/use-focus-visible', () => ({
  __esModule: true,
  default: mockUseFocusVisible,
}));

import { WaiAccordion, WaiAccordionItem } from '@src/components/core/WaiAccordion';
import { WaiAccordionItemRef } from '@src/components/core/WaiAccordion/WaiAccordionItem';

describe('WaiAccordion Components', () => {
  let clock: FakeTimers.InstalledClock;
  let result: RenderResult;
  let waitForTransition: () => Promise<void>;
  beforeEach(() => {
    clock = FakeTimers.install();
    mockUseFocusVisible.mockReturnValue(false);
    waitForTransition = () =>
      act(async () => {
        clock.runToFrame();
        clock.runToFrame();
        await waitForEventLoopToDrain();
        clock.runToFrame();
        clock.runToFrame();
        await clock.tickAsync(250);
        await waitForEventLoopToDrain();
      });
  });

  afterEach(() => {
    clock.uninstall();
  });

  it('should render an accordion item that can be opened/closed with click, ENTER or SPACE', async () => {
    const ref = React.createRef<WaiAccordionItemRef>();
    result = render(
      <WaiAccordion id="accordion-id" data-testid="accordion">
        <WaiAccordionItem header="Header" id="accordion-item-id" data-testid="accordion-item" ref={ref}>
          Content
        </WaiAccordionItem>
      </WaiAccordion>,
    );

    const header = () => result.getByTestId('accordion-item-header');
    expect(header()).toHaveAttribute('id', 'accordion-item-id-header');
    expect(header()).toHaveAttribute('role', 'button');
    expect(header()).toHaveAttribute('tabIndex', '0');
    expect(header()).toHaveAttribute('aria-expanded', 'false');
    expect(header()).toHaveAttribute('aria-controls', 'accordion-item-id');
    expect(header()).toHaveAttribute('aria-disabled', 'false');

    const body = () => result.getByTestId('accordion-item-body');
    expect(body()).toHaveAttribute('id', 'accordion-item-id');
    expect(body()).toHaveAttribute('role', 'region');
    expect(body()).toHaveAttribute('aria-labelledby', 'accordion-item-id-header');
    expect(body()).toHaveAttribute('tabIndex', '-1');
    expect(body()).toHaveAttribute('aria-hidden', 'true');

    expect(body()).toHaveStyle({
      maxHeight: 0,
      overflow: 'hidden',
      transitionProperty: 'max-height',
      transitionDuration: '250ms',
      transitionTimingFunction: 'ease-in-out',
    });
    expect(ref.current!.isOpen).toBe(false);

    const expectOpened = () => {
      expect(ref.current!.isOpen).toBe(true);
      expect(header()).toHaveAttribute('aria-expanded', 'true');
      expect(body()).not.toHaveAttribute('tabIndex');
      expect(body()).toHaveAttribute('aria-hidden', 'false');
      expect(body()).toHaveStyle({ maxHeight: 'none' });
      expect(body()).not.toHaveAttribute('hidden');
    };

    const expectClosed = () => {
      expect(ref.current!.isOpen).toBe(false);
      expect(header()).toHaveAttribute('aria-expanded', 'false');
      expect(body()).toHaveAttribute('tabIndex', '-1');
      expect(body()).toHaveAttribute('aria-hidden', 'true');
      expect(body()).toHaveStyle({ maxHeight: 0 });
      expect(body()).toHaveAttribute('hidden');
    };

    fireEvent.click(result.getByRole('button'));
    await waitForTransition();
    expectOpened();

    fireEvent.click(result.getByRole('button'));
    await waitForTransition();
    expectClosed();

    fireEvent.keyDown(result.getByRole('button'), { key: KeyboardEventKeyValue.ENTER });
    await waitForTransition();
    expectOpened();

    fireEvent.keyDown(result.getByRole('button'), { key: KeyboardEventKeyValue.ENTER });
    await waitForTransition();
    expectClosed();

    fireEvent.keyDown(result.getByRole('button'), { key: KeyboardEventKeyValue.SPACE });
    await waitForTransition();
    expectOpened();

    fireEvent.keyDown(result.getByRole('button'), { key: KeyboardEventKeyValue.SPACE });
    await waitForTransition();
    expectClosed();
  });

  it('should allow accessible navigation between headers', () => {
    result = render(
      <WaiAccordion id="accordion-id" data-testid="accordion">
        <WaiAccordionItem header="Header 1" id="accordion-item-1-id" data-testid="accordion-item-1">
          Content 1
        </WaiAccordionItem>
        <WaiAccordionItem header="Header 2" id="accordion-item-2-id" data-testid="accordion-item-2">
          Content 2
        </WaiAccordionItem>
        <WaiAccordionItem header="Header 3" id="accordion-item-3-id" data-testid="accordion-item-3">
          Content 3
        </WaiAccordionItem>
      </WaiAccordion>,
    );

    const header1 = result.getByText('Header 1');
    const header2 = result.getByText('Header 2');
    const header3 = result.getByText('Header 3');

    header1.focus();
    // END should focus the last header
    userEvent.type(header1, '{end}');
    expect(document.activeElement).toBe(header3);

    // HOME should focus the first header
    userEvent.type(header3, '{home}');
    expect(document.activeElement).toBe(header1);

    // ARROW_DOWN should focus the next header down
    userEvent.type(header1, '{arrowdown}');
    expect(document.activeElement).toBe(header2);

    header3.focus();
    // ARROW_DOWN should loop focus around
    userEvent.type(header3, '{arrowdown}');
    expect(document.activeElement).toBe(header1);

    header2.focus();
    // ARROW_UP should move docus to the previous header
    userEvent.type(header2, '{arrowup}');
    expect(document.activeElement).toBe(header1);

    // ARROW_UP should loop focus around
    userEvent.type(header1, '{arrowup}');
    expect(document.activeElement).toBe(header3);
  });

  it('should keep atLeastOne and atMostOne open', async () => {
    const ref1 = React.createRef<WaiAccordionItemRef>();
    const ref2 = React.createRef<WaiAccordionItemRef>();
    result = render(
      <WaiAccordion atLeastOne={true} atMostOne={true} id="accordion-id" data-testid="accordion">
        <WaiAccordionItem header="Header 1" id="accordion-item-1-id" ref={ref1} data-testid="accordion-item-1">
          Content 1
        </WaiAccordionItem>
        <WaiAccordionItem
          defaultOpen={true}
          header="Header 2"
          id="accordion-item-2-id"
          ref={ref2}
          data-testid="accordion-item-2"
        >
          Content 2
        </WaiAccordionItem>
      </WaiAccordion>,
    );

    // Wait for useLayoutEffect to trigger
    await act(waitForEventLoopToDrain);

    // defaultOpen should have Accordion Item 2 opened by default
    expect(ref1.current!.isOpen).toBe(false);
    expect(ref2.current!.isOpen).toBe(true);

    // Opening Accordion Item 1 should close Accordion Item 2
    act(() => ref1.current!.open(true));
    expect(ref1.current!.isOpen).toBe(true);
    expect(ref2.current!.isOpen).toBe(false);

    // Attempting to close Accordion Item 1 should fail
    act(() => ref1.current!.close(true));
    expect(ref1.current!.isOpen).toBe(true);
    expect(ref2.current!.isOpen).toBe(false);
  });

  it('should disable user-initiated toggling when disabled is set', () => {
    const ref = React.createRef<WaiAccordionItemRef>();
    result = render(
      <WaiAccordion id="accordion-id" data-testid="accordion">
        <WaiAccordionItem
          disabled="default"
          header="Header"
          id="accordion-item-id"
          data-testid="accordion-item"
          ref={ref}
        >
          Content
        </WaiAccordionItem>
      </WaiAccordion>,
    );

    const header = () => result.getByRole('button');
    expect(ref.current!.isOpen).toBe(false);
    expect(header()).toHaveAttribute('aria-disabled', 'true');

    fireEvent.click(header());
    expect(ref.current!.isOpen).toBe(false);
  });
});
