import React from 'react';
import styled, { css } from 'styled-components';
import AccordionContext, { reducer } from '@src/components/core/WaiAccordion/context';
import { focusOutline } from '@src/lib/util/mixins';
import useFocusVisible from '@src/lib/hooks/use-focus-visible';
import useIsomorphicLayoutEffect from '@src/lib/hooks/use-isomorphic-layout-effect';
import { useId } from 'react-id-generator';
import { WaiAccordionItemProps } from '@src/components/core/WaiAccordion/WaiAccordionItem';

interface WaiAccordionRootProps {
  $showFocus: boolean;
}

/**
 * Provides focus ring styles to accordion as per WAI-ARIA Authoring Practices when any header button is focused
 * @see https://www.w3.org/TR/wai-aria-practices-1.1/examples/accordion/accordion.html#:~:text=Accessibility%20Features
 */
const WaiAccordionRoot = styled.div<WaiAccordionRootProps>`
  ${(p) =>
    p.$showFocus &&
    css`
      &:focus-within {
        // Using outline instead of box-shadow due to issues with stacking context
        ${focusOutline()}
      }
    `}
`;

/**
 * Explanation: This type definition allows an `as` prop to be specified to render the WaiAccordion as whilst also
 * inferring the props from that `as` component. As `"div"` is the default, we specify `{ as?: "div" }` as optional.
 * Consumers of the WaiAccordion should not have to supply these type parameters as they should be inferred from use.
 */
type WaiAccordionProps<
  C extends keyof JSX.IntrinsicElements | React.ComponentType<P>,
  P = React.ComponentPropsWithoutRef<C>,
> = (C extends keyof JSX.IntrinsicElements
  ? (C extends 'div' ? { as?: 'div' } : { as: C }) & Omit<JSX.IntrinsicElements[C], 'as'>
  : { as: C } & Omit<P, 'as'>) & {
  children: React.ReactNode;
  id?: string;
  atLeastOne?: boolean;
  atMostOne?: boolean;
  'data-testid'?: string;
};

/**
 * WAI-ARIA Accessible Accordion Component
 *
 * NOTE: This is a mostly functional component and styles should not be directly modified. Instead,
 * use the `as` prop to specify a custom container component such as a `styled.div`.
 *
 * @see https://www.w3.org/TR/wai-aria-practices-1.1/#accordion
 *
 * @param props
 */
const WaiAccordion = <
  C extends keyof JSX.IntrinsicElements | React.ComponentType<P>,
  P = React.ComponentPropsWithoutRef<C>,
>({
  as,
  children,
  id: suppliedId,
  atLeastOne = false,
  atMostOne = false,
  ...props
}: WaiAccordionProps<C, P>) => {
  const [generatedId] = useId(1, 'wai-accordion-');
  const id = suppliedId || generatedId;

  const stateAndDispatch = React.useReducer(reducer, {
    id,
    atLeastOne,
    atMostOne,
    focused: [],
    opened: [],
    immediate: false,
  });
  const [state, dispatch] = stateAndDispatch;
  useIsomorphicLayoutEffect(() => {
    dispatch({ type: 'update', id, atLeastOne, atMostOne });
  }, [dispatch, id, atLeastOne, atMostOne]);

  const focusVisible = useFocusVisible();

  const generatedIds = useId(React.Children.count(children), 'accordion-item-');

  return (
    <WaiAccordionRoot
      // Not ideal, but required to make TS happy
      {...({ as, ...props } as {})}
      id={id}
      $showFocus={focusVisible && !!state.focused.length}
    >
      <AccordionContext.Provider value={stateAndDispatch}>
        {React.Children.map(children, (child, i) => {
          if (!React.isValidElement<WaiAccordionItemProps>(child)) {
            return child;
          }
          return React.cloneElement(child, { id: child.props.id ?? generatedIds[i] });
        })}
      </AccordionContext.Provider>
    </WaiAccordionRoot>
  );
};

export default WaiAccordion;
