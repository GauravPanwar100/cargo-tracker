import { storiesOf } from '@storybook/react';
import React from 'react';
import styled from 'styled-components';
import { WaiAccordion, WaiAccordionItem } from '@src/components/core/WaiAccordion';
import { Sections } from '@src/lib/constants/storybook';

const StyledAccordion = styled.div`
  position: relative;
  overflow: hidden;
  background-color: ${(p) => p.theme.colors.white};
  border-radius: ${(p) => p.theme.sizes.borderRadius}px;
  box-shadow: ${(p) => p.theme.variants.accordionBoxShadow};
`;

const StyledAccordionItemHeader = styled.div`
  padding: 8px 12px;
`;

const content = (
  <>
    <p>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque hendrerit odio elit, et volutpat mi
      fringilla eu. Integer iaculis quam pellentesque libero aliquet cursus. Vivamus dignissim, augue sed condimentum
      placerat, nibh est tristique nisl, quis elementum ligula eros sit amet est. Nam semper tincidunt orci vitae
      posuere. Suspendisse convallis non nulla nec blandit. Duis sed ligula mi. Phasellus urna tellus, pretium nec eros
      sit amet, hendrerit sollicitudin nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames
      ac turpis egestas. Etiam lobortis malesuada nibh, nec fringilla orci tempus a. Morbi in dolor id nibh malesuada
      porta eget nec eros. Nullam aliquam pharetra tellus quis dignissim.
    </p>
    <p>
      Vivamus sit amet fermentum erat. Integer eget risus a leo accumsan suscipit. Vivamus sed mauris scelerisque,
      ornare massa non, aliquet metus. Mauris ut volutpat dui, at vestibulum elit. Class aptent taciti sociosqu ad
      litora torquent per conubia nostra, per inceptos himenaeos. Nulla non metus massa. Cras ac sapien a sapien
      ullamcorper aliquam in vel purus. Phasellus pulvinar orci quis ipsum lobortis, quis blandit lectus scelerisque.
      Nam suscipit maximus consequat. Nullam sit amet vulputate ipsum. Mauris at posuere nulla. Nullam fermentum
      hendrerit urna, in ullamcorper lacus tincidunt id. Quisque hendrerit commodo orci, ac finibus felis bibendum ac.
      Interdum et malesuada fames ac ante ipsum primis in faucibus.
    </p>
    <p>
      Quisque tempus odio in nunc gravida laoreet. Pellentesque lobortis quam dolor, id imperdiet felis gravida semper.
      Aenean sit amet mauris eget sapien cursus iaculis. Integer suscipit et velit quis accumsan. In pretium ac enim non
      volutpat. Praesent ac pellentesque ipsum. Praesent malesuada mauris at libero dictum aliquet. Nullam tempus risus
      sit amet justo rhoncus, et commodo metus rhoncus. Nullam et velit in purus fermentum sollicitudin. Donec dignissim
      mauris eget pellentesque laoreet.
    </p>
  </>
);

storiesOf(`${Sections.CORE}|WaiAccordion`, module)
  .add('Single', () => (
    <WaiAccordion>
      <WaiAccordionItem header="Header">{content}</WaiAccordionItem>
    </WaiAccordion>
  ))
  .add('Default Open', () => (
    <WaiAccordion>
      <WaiAccordionItem defaultOpen={true} header="Header">
        {content}
      </WaiAccordionItem>
    </WaiAccordion>
  ))
  .add('Multiple', () => (
    <WaiAccordion>
      <WaiAccordionItem header="Header 1">{content}</WaiAccordionItem>
      <WaiAccordionItem header="Header 2">{content}</WaiAccordionItem>
      <WaiAccordionItem header="Header 3">{content}</WaiAccordionItem>
    </WaiAccordion>
  ))
  .add('At Least One', () => (
    <WaiAccordion atLeastOne={true}>
      <WaiAccordionItem defaultOpen={true} header="Header 1">
        {content}
      </WaiAccordionItem>
      <WaiAccordionItem header="Header 2">{content}</WaiAccordionItem>
      <WaiAccordionItem header="Header 3">{content}</WaiAccordionItem>
    </WaiAccordion>
  ))
  .add('At Most One', () => (
    <WaiAccordion atMostOne={true}>
      <WaiAccordionItem defaultOpen={true} header="Header 1">
        {content}
      </WaiAccordionItem>
      <WaiAccordionItem header="Header 2">{content}</WaiAccordionItem>
      <WaiAccordionItem header="Header 3">{content}</WaiAccordionItem>
    </WaiAccordion>
  ))
  .add('One And Only One', () => (
    <WaiAccordion atLeastOne={true} atMostOne={true}>
      <WaiAccordionItem defaultOpen={true} header="Header 1">
        {content}
      </WaiAccordionItem>
      <WaiAccordionItem header="Header 2">{content}</WaiAccordionItem>
      <WaiAccordionItem header="Header 3">{content}</WaiAccordionItem>
    </WaiAccordion>
  ))
  .add('Reverse Order', () => (
    <WaiAccordion>
      <WaiAccordionItem header="Header" reverseOrder={true}>
        {content}
      </WaiAccordionItem>
    </WaiAccordion>
  ))
  .add('Styled', () => (
    <WaiAccordion as={StyledAccordion}>
      <WaiAccordionItem
        header={({ isOpen }) => (
          <StyledAccordionItemHeader>Header 1 - isOpen: {isOpen.toString()}</StyledAccordionItemHeader>
        )}
      >
        {content}
      </WaiAccordionItem>
      <WaiAccordionItem
        header={({ isOpen }) => (
          <StyledAccordionItemHeader>Header 2 - isOpen: {isOpen.toString()}</StyledAccordionItemHeader>
        )}
      >
        {content}
      </WaiAccordionItem>
      <WaiAccordionItem
        header={({ isOpen }) => (
          <StyledAccordionItemHeader>Header 3 - isOpen: {isOpen.toString()}</StyledAccordionItemHeader>
        )}
      >
        {content}
      </WaiAccordionItem>
    </WaiAccordion>
  ));
