import { toggle } from '@kablamo/kerosene';
import { omit } from 'lodash';
import React from 'react';
import { assertNever } from '@src/lib/util/typescript';

export interface AccordionState {
  readonly id: string;
  readonly atLeastOne: boolean;
  readonly atMostOne: boolean;
  readonly focused: readonly string[];
  readonly opened: readonly string[];
  readonly immediate: boolean;
}

type AccordionFocusActionType = 'focus' | 'blur';

type AccordionStateActionType = 'open' | 'close' | 'toggle';

export type AccordionAction =
  | {
      [Type in AccordionFocusActionType]: { type: Type; id: string };
    }[AccordionFocusActionType]
  | {
      [Type in AccordionStateActionType]: { type: Type; id: string; immediate: boolean };
    }[AccordionStateActionType]
  | { type: 'update'; id: string; atLeastOne: boolean; atMostOne: boolean };

export const reducer = (state: AccordionState, action: AccordionAction): AccordionState => {
  switch (action.type) {
    case 'focus':
      return { ...state, focused: [...state.focused, action.id] };
    case 'blur':
      return { ...state, focused: state.focused.filter((id) => id !== action.id) };
    case 'open':
      return {
        ...state,
        opened: state.atMostOne ? [action.id] : [...state.opened, action.id],
        immediate: action.immediate,
      };
    case 'close': {
      const opened = state.opened.filter((id) => id !== action.id);
      return {
        ...state,
        opened: state.atLeastOne && opened.length === 0 ? [action.id] : opened,
        immediate: action.immediate,
      };
    }
    case 'toggle': {
      const opened = toggle(action.id, state.opened);
      return {
        ...state,
        opened:
          (state.atLeastOne && opened.length === 0) || (state.atMostOne && opened.length > 1) ? [action.id] : opened,
        immediate: action.immediate,
      };
    }
    case 'update':
      return { ...state, ...omit(action, ['type']) };
    /* istanbul ignore next */
    default:
      return assertNever(action);
  }
};

const wrapError = new Error('Did you forget to wrap your component in a <WaiAccordion />?');

const AccordionContext = React.createContext<readonly [AccordionState, React.Dispatch<AccordionAction>]>([
  {
    focused: [],
    opened: [],
    /* istanbul ignore next */
    get id(): never {
      throw wrapError;
    },
    /* istanbul ignore next */
    get atLeastOne(): never {
      throw wrapError;
    },
    /* istanbul ignore next */
    get atMostOne(): never {
      throw wrapError;
    },
    get immediate(): never {
      throw wrapError;
    },
  },
  /* istanbul ignore next */
  () => {
    throw wrapError;
  },
]);

export default AccordionContext;
