import { MixinProperty, columnGapMixin, focusBoxShadow, marginBottomMixin, paddingMixin } from '@src/lib/util/mixins';
import styled from 'styled-components';

export const CheckMark = styled.div`
  box-sizing: border-box;
  height: 20px;
  width: 20px;
  border: 1px solid #999999;
  border-radius: 3px;
  background-color: ${(p) => p.theme.colors.white};
`;

interface LabelProps {
  padding: MixinProperty;
  columnGap: MixinProperty;
}

export const Label = styled.label<LabelProps>`
  display: grid;
  grid-auto-flow: column;
  grid-template-columns: max-content auto;
  ${(p) => columnGapMixin(p.columnGap)}
  ${(p) => paddingMixin(p.padding)}
  user-select: none;
  cursor: pointer;

  input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
    height: 0;
    width: 0;

    &:checked ~ ${CheckMark} {
      background-color: ${(p) => p.theme.colors.white};
      border: 1px solid rgba(0, 0, 0, 0.2);
    }
  }

  &:hover {
    input ~ ${CheckMark} {
      background-color: ${(p) => p.theme.colors.silver};
    }
  }
`;

interface CheckboxWrapperProps {
  marginBottom: MixinProperty<string>;
}

export const CheckboxWrapper = styled.div<CheckboxWrapperProps>`
  display: block;
  position: relative;
  ${(p) => marginBottomMixin(p.marginBottom)}
  cursor: pointer;

  input:checked ~ ${CheckMark} {
    background-color: ${(p) => p.theme.colors.turquoise};
    &:after {
      display: block;
    }
  }

  input:focus:focus-visible ~ ${CheckMark} {
    ${focusBoxShadow}
  }

  @supports not selector(:focus-visible) {
    input:focus ~ ${CheckMark} {
      ${focusBoxShadow}
    }
  }

  ${CheckMark}:after {
    content: '';
    position: relative;
    display: none;
    left: 6px;
    top: 2px;
    width: 6px;
    height: 11px;
    border: solid ${(p) => p.theme.colors.white};
    border-width: 0 2px 2px 0;
    transform: rotate(45deg);
  }
`;
