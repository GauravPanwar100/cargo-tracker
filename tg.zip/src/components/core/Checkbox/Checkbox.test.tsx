import React from 'react';
import { fireEvent, render } from 'test-utils';
import Checkbox, { CheckboxProps } from './Checkbox';

const defaultProps: CheckboxProps = {
  id: '1234',
  label: 'Checkbox',
  name: 'checkboxName',
  onChange: jest.fn(),
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<Checkbox {...props} />);
  return { utils, props };
};

describe('Checkbox', () => {
  it('renders checkbox', () => {
    const { utils } = setup();
    utils.getByText('Checkbox');
  });

  it('checks input field on click', () => {
    const { utils, props } = setup();
    const label = utils.getByText('Checkbox');
    const input = utils.getByTestId('checkbox-input-checkboxName') as HTMLInputElement;
    expect(input.checked).toEqual(false);
    fireEvent.click(label);
    expect(props.onChange).toBeCalled();
    expect(input.checked).toEqual(true);
  });

  it('renders a checked checkbox if checked is passed in', () => {
    const { utils } = setup({ checked: true });
    const input = utils.getByTestId('checkbox-input-checkboxName') as HTMLInputElement;
    expect(input.checked).toEqual(true);
  });
});
