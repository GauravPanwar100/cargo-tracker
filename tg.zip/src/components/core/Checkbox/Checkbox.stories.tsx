import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import Checkbox from './Checkbox';

storiesOf(`${Sections.CORE}|CheckBox`, module).add('Default', () => (
  <>
    <Checkbox label="checkbox: checked = false" onChange={() => {}} />
    <Checkbox label="Checkbox: checked = true" checked={true} onChange={() => {}} />
    <Checkbox label="Checkbox: checked = true and including name" name="name 1" checked={true} onChange={() => {}} />
  </>
));
