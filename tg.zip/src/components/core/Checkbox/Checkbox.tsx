import RichText from '@src/components/core/RichText';
import { MixinProperty } from '@src/lib/util/mixins';
import React from 'react';
import { CheckMark, CheckboxWrapper, Label } from './Checkbox.styles';

export interface CheckboxProps {
  label?: string;
  name?: string;
  id?: string;
  wrapperMarginBottom?: MixinProperty<string>;
  labelGap?: MixinProperty<string>;
  labelPadding?: MixinProperty<string>;
  errorDesign?: boolean;
  checked?: React.HTMLProps<HTMLInputElement>['checked'];
  onChange?: React.HTMLProps<HTMLInputElement>['onChange'];
}

const Checkbox: React.FC<CheckboxProps> = ({
  label,
  name,
  id,
  wrapperMarginBottom = { xs: '12px' },
  labelGap = { xs: '8px' },
  labelPadding,
  errorDesign,
  checked,
  onChange,
}) => (
  <>
    <CheckboxWrapper key={id} marginBottom={wrapperMarginBottom}>
      <Label data-testid={`checkbox-label-${name}`} htmlFor={id} columnGap={labelGap} padding={labelPadding}>
        <input
          data-testid={`checkbox-input-${name}`}
          name={name}
          type="checkbox"
          id={id}
          onChange={onChange}
          checked={checked}
        />
        <CheckMark style={errorDesign ? { border: '2px solid red' } : {}} />
        <RichText>{label}</RichText>
      </Label>
    </CheckboxWrapper>
  </>
);

export default Checkbox;
