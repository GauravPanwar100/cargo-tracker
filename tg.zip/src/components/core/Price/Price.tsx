import React from 'react';
import { formatCurrency } from '@src/lib/util/number-formatter';
import OriginalPrice from '@src/components/core/Price/OriginalPrice';
import { DeviceEndpoint } from '@src/lib/api/types';
import { Amount, Container, CurrencySymbol, Prefix } from './Price.styles';

interface PriceProps {
  deviceId?: string;
  price?: number;
  prefix?: string;
  label?: string;
  originalPrice?: number;
  deviceType?: string;
}

const Price: React.FC<PriceProps> = ({
  deviceId,
  prefix,
  price,
  label,
  originalPrice,
  deviceType = DeviceEndpoint.PHONE,
}) => (
  <Container>
    {prefix && <Prefix data-testid="prefix">{prefix}</Prefix>}
    {deviceType === DeviceEndpoint.PREPAIDPHONE && (
      <OriginalPrice price={price} originalPrice={originalPrice} deviceId={deviceId} label={label} />
    )}
    <div>
      <CurrencySymbol>$</CurrencySymbol>
      <Amount data-testid={`device-${deviceId}-recurringCharge`}>
        {!originalPrice && !price && '--.--'}
        {price !== undefined && formatCurrency(price)}
        {originalPrice && price === undefined && formatCurrency(originalPrice)}
      </Amount>

      {(deviceType === DeviceEndpoint.PHONE ||
        deviceType === DeviceEndpoint.WEARABLES ||
        deviceType === DeviceEndpoint.MBB_MODEMS) && (
        <OriginalPrice price={price} originalPrice={originalPrice} deviceId={deviceId} label={label} />
      )}
    </div>
  </Container>
);

export default Price;
