import React from 'react';
import { formatCurrency, formatStringPrice } from '@src/lib/util/number-formatter';
import { MixinProperty } from '@src/lib/util/mixins';
import { FontSizeKey } from '@src/lib/theme';
import RichText from '@src/components/core/RichText';
import { useUpliftDataContent } from '@src/lib/context/uplift-data-provider';
import { PromoLabelBlock } from '@src/components/core/DataAllowance/DataAllowance.styles';

import {
  AmountSmall,
  Container,
  CurrencySymbolSmall,
  LabelBlock,
  Prefix,
  StrikethrougCurrencySymbolSmall,
  Strikethrough,
  StrikethroughPriceAmountSmall,
} from './Price.styles';

export interface PriceProps {
  additionalInfo?: React.ReactNode;
  price: string | number;
  originalPrice?: string | number;
  prefix?: string;
  label?: string | JSX.Element;
  prepaidPriceAllowancePos?: boolean;
  noLabel?: boolean;
  currencySymbolSize?: MixinProperty<FontSizeKey | [FontSizeKey, FontSizeKey]>;
  noPadding?: boolean;
  floatRight?: boolean;
  alwaysDisplayDecimal?: boolean;
  displayOnlyOnMobile?: boolean;
  wasPrefix?: string;
  hideWasPrice?: boolean;
  hideWasPrefix?: boolean;
  hideWasPriceInHead?: boolean;
}

const labelValidator = (label: string | JSX.Element | React.ReactNode) => {
  if (!label) return false;
  if (typeof label === 'string' && !label.trim()) return false; // whitespace check
  return true;
};

const PriceSmall: React.FC<PriceProps> = ({
  additionalInfo,
  prefix,
  price,
  originalPrice,
  label = 'per month',
  noLabel,
  currencySymbolSize,
  noPadding,
  floatRight,
  alwaysDisplayDecimal = true,
  displayOnlyOnMobile,
  wasPrefix = 'was',
  hideWasPrice = false,
  hideWasPrefix = false,
  hideWasPriceInHead,
  prepaidPriceAllowancePos = false,

  ...props
}) => {
  const upliftEnabled = useUpliftDataContent();
  return (
    <Container
      displayOnlyOnMobile={displayOnlyOnMobile}
      noPadding={noPadding}
      floatRight={floatRight}
      upliftEnabled={upliftEnabled}
      {...props}
    >
      {prefix && <Prefix>{prefix}</Prefix>}
      {!hideWasPriceInHead && !!originalPrice && originalPrice !== price && (
        <>
          <StrikethrougCurrencySymbolSmall>$</StrikethrougCurrencySymbolSmall>
          <StrikethroughPriceAmountSmall data-testid="strike-price">
            {formatStringPrice(Number(originalPrice))}
          </StrikethroughPriceAmountSmall>
        </>
      )}
      <CurrencySymbolSmall
        displayMarginTop={!hideWasPriceInHead && !!originalPrice}
        size={currencySymbolSize}
        upliftEnabled={upliftEnabled}
      >
        $
      </CurrencySymbolSmall>
      <AmountSmall data-testid="price" as="h5" upliftEnabled={upliftEnabled}>
        {formatCurrency(price)}
      </AmountSmall>
      {prepaidPriceAllowancePos && !hideWasPrice && originalPrice && originalPrice !== price && (
        <PromoLabelBlock>
          <LabelBlock>
            {!hideWasPrefix && wasPrefix}{' '}
            <Strikethrough data-testid="was-price">
              ${alwaysDisplayDecimal ? formatCurrency(originalPrice) : formatStringPrice(originalPrice)}
            </Strikethrough>
          </LabelBlock>
        </PromoLabelBlock>
      )}
      {!noLabel && labelValidator(label) && (
        <LabelBlock>
          <RichText pTagFontLineHeightSize="priceSmallText" pNoMargin={true}>
            {label}
          </RichText>
        </LabelBlock>
      )}
      {additionalInfo && labelValidator(additionalInfo) && <LabelBlock>{additionalInfo}</LabelBlock>}
      {!prepaidPriceAllowancePos && !hideWasPrice && originalPrice && originalPrice !== price && (
        <PromoLabelBlock>
          <LabelBlock>
            {!hideWasPrefix && wasPrefix}{' '}
            <Strikethrough data-testid="was-price">
              ${alwaysDisplayDecimal ? formatCurrency(originalPrice) : formatStringPrice(originalPrice)}
            </Strikethrough>
          </LabelBlock>
        </PromoLabelBlock>
      )}
    </Container>
  );
};

export default PriceSmall;
