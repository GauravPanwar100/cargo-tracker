import React from 'react';
import { formatCurrency } from '@src/lib/util/number-formatter';
import PriceSmall from '@src/components/core/Price/PriceSmall';
import Price from '@src/components/vfe/CartCard/CartCardTitle/Price';
import { LabelBlock, PriceContainer, WasPriceSmallContainer } from './Price.styles';

interface WasPriceSmallProps {
  price: string | number;
  originalPrice?: string | number;
  costLabel?: string | JSX.Element;
  hideOriginalPrice?: boolean;
  hideWasPrefix?: boolean;
}

// TODO we have many variations of price display in this repo, clean up is advised

const WasPriceSmall: React.FC<WasPriceSmallProps> = ({
  price,
  originalPrice,
  hideOriginalPrice,
  costLabel = 'per month',
  hideWasPrefix,
  ...props
}) => (
  <WasPriceSmallContainer {...props}>
    <PriceSmall
      price={formatCurrency(price)}
      originalPrice={originalPrice && formatCurrency(originalPrice)}
      label={costLabel}
      currencySymbolSize={{ m: ['priceXSmall', 'priceXSmall'] }}
      noPadding={true}
      floatRight={true}
      alwaysDisplayDecimal={true}
      displayOnlyOnMobile={true}
      hideWasPrefix={hideWasPrefix}
      hideWasPrice={hideOriginalPrice}
    />
    <PriceContainer>
      <Price
        isTitle={false}
        price={originalPrice ?? price}
        adjustedPrice={price}
        hideOriginalPrice={hideOriginalPrice}
      />
      <LabelBlock>{costLabel}</LabelBlock>
    </PriceContainer>
  </WasPriceSmallContainer>
);

export default WasPriceSmall;
