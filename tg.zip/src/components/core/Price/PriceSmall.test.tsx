import { useUpliftDataContent } from '@src/lib/context/uplift-data-provider';
import React from 'react';
import { render } from 'test-utils';
import { mocked } from 'ts-jest/utils';
import PriceSmall, { PriceProps } from './PriceSmall';

jest.mock('@src/lib/context/uplift-data-provider', () => ({
  useUpliftDataContent: jest.fn().mockReturnValue(false),
}));

const useUpliftDataContentMock = mocked<() => boolean>(useUpliftDataContent, false);

const defaultProps: PriceProps = {
  price: '60',
  originalPrice: '60',
  label: '$60/mth when you already have a phone plan with us',
  wasPrefix: 'was',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<PriceSmall {...props} />);
  return { utils, props };
};

describe('PriceSmall', () => {
  it('should not render strike-thru was price when no promotion', () => {
    const { utils } = setup({ originalPrice: '75' });
    expect(utils.getByTestId('price')).toBeInTheDocument();
    expect(utils.queryByTestId('was-price')).toBeInTheDocument();
  });

  it('should render strike-thru was price when there is promotion', () => {
    const { utils } = setup({ originalPrice: '75' });
    expect(utils.getByTestId('price')).toBeInTheDocument();
    expect(utils.getByTestId('was-price')).toBeInTheDocument();
    expect(utils.getByText('$75')).toBeInTheDocument();
  });

  it('should not render strike-thru was price when there is promotion but hideWasPrice is true', () => {
    const { utils } = setup({ originalPrice: '75', hideWasPrice: true });
    expect(utils.getByTestId('price')).toBeInTheDocument();
    expect(utils.queryByTestId('was-price')).not.toBeInTheDocument();
    expect(utils.queryByText('$75')).not.toBeInTheDocument();
  });

  it('should have pricing in greyDark if uplift is disabled', () => {
    const { utils } = setup({ originalPrice: '75' });
    const priceSection = utils.getAllByText('60');
    expect(priceSection[0]).not.toHaveStyle('color: #E60000');
  });

  it('should have pricing in red if uplift is enabled', () => {
    useUpliftDataContentMock.mockReturnValueOnce(true);
    const { utils } = setup({ originalPrice: '75' });
    const priceSection = utils.getAllByText('60');
    expect(priceSection[0]).toHaveStyle('color: #E60000');
  });
});
