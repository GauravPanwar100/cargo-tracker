import React from 'react';
import { formatCurrency } from '@src/lib/util/number-formatter';
import { Label, LabelBlock, Strikethrough, WasPriceContainer } from '@src/components/core/Price/Price.styles';

interface OriginalPriceProps {
  price?: number;
  originalPrice?: number;
  deviceId?: string;
  label?: string;
}

const OriginalPrice: React.FC<OriginalPriceProps> = ({ price, originalPrice, deviceId, label }) => (
  <WasPriceContainer>
    {originalPrice && price !== undefined && originalPrice !== price && (
      <LabelBlock>
        <Strikethrough data-testid={`device-${deviceId}-was-price`}>
          {`$${formatCurrency(originalPrice)}`}
        </Strikethrough>
      </LabelBlock>
    )}
    <Label>{label}</Label>
  </WasPriceContainer>
);

export default OriginalPrice;
