import styled, { css } from 'styled-components';
import { MixinProperty, fontLineHeightSize, fontSizeLineHeightMixin, maxMedia, media } from '@src/lib/util/mixins';
import { FontSizeKey } from '@src/lib/theme';

// TODO we have many variations of price display using this container in this repo, clean up is advised
export const Container = styled.div<{
  noPadding?: boolean;
  floatRight?: boolean;
  displayOnlyOnMobile?: boolean;
  upliftEnabled?: boolean;
}>`
  display: inline-block;
  font-family: ${(p) => p.theme.fonts.regular};
  line-height: 0px !important;
  ${fontLineHeightSize('base')};
  ${media.xs`
    padding-top: 0;
  `}
  ${media.m`
    padding-top: 10px;
  `}
  ${media.l`
    padding-top: 10px;
  `}
  ${(p) =>
    p.noPadding &&
    css`
      padding: 0 !important;
    `}
  ${(p) =>
    p.floatRight &&
    css`
      text-align: end;
      width: 30%;
    `}
  ${(p) =>
    p.displayOnlyOnMobile &&
    css`
      ${media.m`
        display: none;
        visibility: hidden;
      `}
      ${maxMedia.m`
        width: auto;
      `}
    `}
  ${({ upliftEnabled }) =>
    upliftEnabled &&
    css`
      ${media.m`
        padding-top: 0px;
      `};
      ${media.l`
        padding-top: 0px;
      `}
    `}
`;

export const WasPriceSmallContainer = styled.div`
  ${fontLineHeightSize('base')};
  text-align: end;
`;

export const PriceContainer = styled.div`
  text-align: end;
  ${maxMedia.m`
    display: none;
    visibility: hidden;
  `}
`;

export const Prefix = styled.div`
  ${fontLineHeightSize('baseSmall')};
  line-height: 18px;
`;

export const Label = styled.span`
  display: inline-block;
  ${fontLineHeightSize('baseSmall')};
  line-height: 18px;
  padding: 3px 0 0 2px;
`;

export const LabelBlock = styled.div`
  ${media.xs`
    padding-top: 0;
  `}
  ${media.m`
    padding-top: 3px;
  `}
  ${media.l`
    padding-top: 3px;
  `}
  ${fontLineHeightSize('baseSmall')};
  line-height: 15px;
`;
export const StrikethroughPrice = styled.span`
  ${maxMedia.l`
display: inline;
visibility: auto;
`}
  ${maxMedia.m`
display: none;
visibility: hidden;
`}
`;
export const Strikethrough = styled.span`
  text-decoration: line-through;
`;

export const CurrencySymbol = styled.span`
  font-family: ${(p) => p.theme.fonts.bold};
  display: inline-block;
  vertical-align: top;
  ${fontLineHeightSize('baseLarge')};
  line-height: 36px;
`;

export const Amount = styled.span`
  font-family: ${(p) => p.theme.fonts.bold};
  ${fontLineHeightSize('price')};
  padding-right: 0px;
`;
export const CurrencySymbolSmall = styled.span<{
  size?: MixinProperty<FontSizeKey | [FontSizeKey, FontSizeKey]>;
  displayMarginTop: Boolean;
  upliftEnabled?: Boolean;
}>`
  font-family: ${(p) => p.theme.fonts.bold};
  display: inline-block;
  vertical-align: top;
  ${fontSizeLineHeightMixin({
    xs: ['base', 'baseLarge'],
    m: ['base', 'footnote'],
  })}
  ${(p) => p.size && fontSizeLineHeightMixin(p.size)}
  ${media.xs`
    margin-top: 2px;
  `}
  ${media.m`
    margin-top: 0px;
  `}
  ${({ upliftEnabled }) =>
    upliftEnabled &&
    css`
      color: #e60000;
      ${media.xs`
        margin-top: 3px;
      `}
      ${media.m`
        margin-top: 6px;
      `}
      ${media.l`
        margin-top: 10px;
      `}
    `}
`;

export const AmountSmall = styled.span<{ upliftEnabled?: boolean }>`
  display: inline-block;
  font-family: ${(p) => p.theme.fonts.bold};
  ${fontLineHeightSize('amountSmall')};
  ${({ upliftEnabled }) => upliftEnabled && `color: #E60000;`}
`;

export const StrikethroughPriceAmountSmall = styled.span`
  text-decoration: line-through;
  display: inline-block;
  font-family: ${(p) => p.theme.fonts.bold};
  font-weight: bold;
  font-stretch: normal;
  font-style: normal;
  letter-spacing: normal;
  color: #6d7278;
  margin-right: 10px;
  ${media.xs`
  height: 36px;
  font-size: 21px;
  line-height: 1.71;
  `}
  ${media.m`
  height: 48px;
  font-size: 24px;
  line-height: 1.5;
  `}
  ${media.l`
  height: 48px;
  font-size: 24px;
  line-height: 1.5;
  `}
`;

export const StrikethrougCurrencySymbolSmall = styled(StrikethroughPriceAmountSmall)`
  text-decoration: none;
  vertical-align: top;
  ${media.xs`
  width: 8px;
  height: 22px;
  margin: 6px 0 8px;
  font-size: 14px;
  line-height: 1.57;
  `}
  ${media.m`
  width: 10px;
  height: 28px;
  margin: 6px 0 14px;
  font-size: 18px;
  line-height: 1.56;
  `}
  ${media.l`
  width: 10px;
  height: 28px;
  margin: 6px 0 14px;
  font-size: 18px;
  line-height: 1.56;
  `}
`;

export const WasPriceContainer = styled.div`
  display: inline-block;
  padding-left: 5px;
`;
