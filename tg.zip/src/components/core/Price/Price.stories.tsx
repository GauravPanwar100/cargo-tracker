import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import Price from './Price';
import PriceSmall from './PriceSmall';

storiesOf(`${Sections.CORE}|Price`, module).add('Price', () => (
  <Section>
    <Grid>
      <GridCol>
        <Price originalPrice={1221.23} />
      </GridCol>
      <GridCol>
        <Price price={111.23} />
      </GridCol>
      <GridCol>
        <Price price={1234.5} label="PER MONTH" />
      </GridCol>
      <GridCol>
        <Price price={1234.5} prefix="Phone from" />
      </GridCol>
      <GridCol>
        <Price price={1234.0} prefix="Phone from" />
      </GridCol>
      <GridCol>
        <Price price={1234.0} prefix="Phone from" />
      </GridCol>
      <GridCol>
        <Price price={65.0} originalPrice={75} />
      </GridCol>
      <GridCol>
        <Price price={65.0} originalPrice={75} prefix="Phone from" />
      </GridCol>
      <GridCol>
        <Price prefix="Phone from" />
      </GridCol>
    </Grid>
  </Section>
));

storiesOf(`${Sections.CORE}|Price`, module).add('Price Small', () => (
  <Section>
    <Grid>
      <GridCol>
        <PriceSmall price={79.19} originalPrice={2000} />
      </GridCol>
      <GridCol>
        <PriceSmall price={25} originalPrice={25} label="one-off cost" />
      </GridCol>
    </Grid>
  </Section>
));
