import React, { useCallback } from 'react';
import { noop } from 'lodash';

/**
 * NB: See Select, ChipGroup, OptionButtonGroup for usage examples
 */

export interface RadioButtonGroupProps {
  className?: string;
  disabled?: boolean;
  id: string;
  onChange?: (value: string) => void;
  name?: string;
  value?: string;
}

interface RadioButtonChildProps {
  checked?: React.HTMLProps<HTMLInputElement>['checked'];
  disabled?: boolean;
  name?: React.HTMLProps<HTMLInputElement>['name'];
  onChange?: React.HTMLProps<HTMLInputElement>['onChange'];
  value?: string;
}

const RadioButtonGroup: React.FC<RadioButtonGroupProps> = ({
  children,
  className,
  disabled,
  id,
  name,
  onChange = noop,
  value,
}) => {
  const childOnChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      if (event.currentTarget.checked) {
        onChange(event.currentTarget.value);
      }
    },
    [onChange],
  );

  const enhancedChildren = React.Children.map(children, (child) => {
    if (!React.isValidElement<RadioButtonChildProps>(child)) {
      return child;
    }

    const {
      props: { value: childValue },
    } = child;

    const checked = !!childValue && childValue === value;

    return React.cloneElement(child, {
      checked,
      disabled,
      name,
      onChange: childOnChange,
    });
  });

  return (
    <div className={className} id={id} role="radiogroup">
      {enhancedChildren}
    </div>
  );
};

export default RadioButtonGroup;
