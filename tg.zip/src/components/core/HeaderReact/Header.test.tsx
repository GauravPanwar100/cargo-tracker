import React from 'react';
import { render } from 'test-utils';
import Header, { HeaderProps } from './Header';

const defaultProps: HeaderProps = {};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<Header {...props} />);
  return { utils, props };
};

describe('Header', () => {
  it('should be rendered', () => {
    const { utils } = setup();
    utils.getByText('Personal');
  });
});
