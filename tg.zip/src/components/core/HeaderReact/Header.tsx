import React, { useCallback, useState } from 'react';
import { ThemeProvider } from 'styled-components';
import { ReactComponent as Cart } from '@src/assets/svg/cart.svg';
import { ReactComponent as Close } from '@src/assets/svg/close-red.svg';
import { ReactComponent as Logo } from '@src/assets/svg/logo.svg';
import { ReactComponent as Menu } from '@src/assets/svg/menu.svg';
import { ReactComponent as Search } from '@src/assets/svg/search.svg';
import { ReactComponent as User } from '@src/assets/svg/user.svg';
import { Grid, GridCol } from '@src/components/core/Grid';
import IconWrapper from '@src/components/core/IconWrapper';
import RichText from '@src/components/core/RichText';
import { darkTheme } from '@src/lib/theme';
import NavIconButton from './NavIconButton';
import NavMenu from './NavMenu';
import NavMenuItem from './NavMenuItem';
import OffCanvasNav from './OffCanvasNav';
import { HEADER_LINKS } from './Header.constants';
import {
  ContainerInner,
  ContainerOuter,
  NavIconItem,
  NavIconList,
  NavMenuLink,
  NavMenuList,
  NavMenuListItem,
  NavMenuTitle,
  SecondaryLink,
  SecondaryLinkContainer,
  SecondaryLinkItem,
  SecondaryLinkList,
} from './Header.styles';

export interface HeaderProps {}

const Header: React.FC<HeaderProps> = () => {
  const [isOffCanvasNavOpen, setIsOffCanvasNavOpen] = useState<boolean>(false);
  const onSideMenuButtonClick = useCallback(() => {
    setIsOffCanvasNavOpen((prevState) => !prevState);
  }, []);

  return (
    <>
      <ThemeProvider theme={darkTheme}>
        <SecondaryLinkContainer>
          <Grid>
            <GridCol>
              <SecondaryLinkList>
                <SecondaryLinkItem isActive={true}>
                  <SecondaryLink href="#">Personal</SecondaryLink>
                </SecondaryLinkItem>
                <SecondaryLinkItem>
                  <SecondaryLink href="#">Business</SecondaryLink>
                </SecondaryLinkItem>
                <SecondaryLinkItem>
                  <SecondaryLink href="#">About Vodafone</SecondaryLink>
                </SecondaryLinkItem>
              </SecondaryLinkList>
            </GridCol>
          </Grid>
        </SecondaryLinkContainer>
      </ThemeProvider>
      <ContainerOuter>
        <Grid>
          <GridCol>
            <ContainerInner>
              <IconWrapper
                height={{ xs: '32px', m: '40px', l: '48px' }}
                marginBottom={{ xs: '10px', l: '12px' }}
                marginRight="36px"
                marginTop={{ xs: '10px', l: '12px' }}
                svg={Logo}
                width={{ xs: '32px', m: '40px', l: '48px' }}
              />
              <NavMenu>
                {HEADER_LINKS.map((headerLinkList) => (
                  <NavMenuItem id={headerLinkList.title} key={headerLinkList.title} label={headerLinkList.title}>
                    <Grid>
                      {headerLinkList.items.map((linkList) => (
                        <GridCol gridColSpan={3} key={linkList.title}>
                          <NavMenuTitle>
                            <RichText>{linkList.title}</RichText>
                          </NavMenuTitle>
                          <NavMenuList>
                            {linkList.items.map((link) => (
                              <NavMenuListItem key={link.label}>
                                <NavMenuLink href={link.href}>
                                  <RichText>{link.label}</RichText>
                                </NavMenuLink>
                              </NavMenuListItem>
                            ))}
                          </NavMenuList>
                        </GridCol>
                      ))}
                    </Grid>
                  </NavMenuItem>
                ))}
              </NavMenu>
              <NavIconList>
                <NavIconItem>
                  <NavIconButton svg={Cart} />
                </NavIconItem>
                <NavIconItem>
                  <NavIconButton svg={Search} />
                </NavIconItem>
                <NavIconItem>
                  <NavIconButton svg={User} />
                </NavIconItem>
                <NavIconItem display={{ xs: 'block', l: 'none' }}>
                  <NavIconButton onClick={onSideMenuButtonClick} svg={isOffCanvasNavOpen ? Close : Menu} />
                  <OffCanvasNav isOpen={isOffCanvasNavOpen} onScrimClick={onSideMenuButtonClick} />
                </NavIconItem>
              </NavIconList>
            </ContainerInner>
          </GridCol>
        </Grid>
      </ContainerOuter>
    </>
  );
};

export default Header;
