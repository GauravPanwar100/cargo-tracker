import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import Header from './Header';

storiesOf(`${Sections.CORE}|Header (React)`, module).add('Default', () => <Header />);
