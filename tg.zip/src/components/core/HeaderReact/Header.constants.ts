import { TRADEMARK } from '@src/lib/constants/html-entities';

export interface HeaderLinkList {
  title: string;
  items: LinkList[];
}

export interface LinkList {
  title: string;
  items: Link[];
}

export interface Link {
  href: string;
  label: string;
}

export const HEADER_LINKS: HeaderLinkList[] = [
  {
    title: 'Mobile',
    items: [
      {
        title: 'Devices',
        items: [
          {
            label: 'All Phones',
            href: '#',
          },
          {
            label: 'iPhone',
            href: '#',
          },
          {
            label: 'Smart Watches',
            href: '#',
          },
          {
            label: 'Android',
            href: '#',
          },
          {
            label: 'Tablets',
            href: '#',
          },
          {
            label: 'Upgrade Your Device',
            href: '#',
          },
        ],
      },
      {
        title: 'Plans',
        items: [
          {
            label: 'Plans with Phones',
            href: '#',
          },
          {
            label: 'SIM Only Plans',
            href: '#',
          },
          {
            label: 'Plans With Modems',
            href: '#',
          },
          {
            label: 'Change my Plan',
            href: '#',
          },
        ],
      },
      {
        title: 'Prepaid',
        items: [
          {
            label: 'Recharge Now',
            href: '#',
          },
          {
            label: 'Prepaid Plans',
            href: '#',
          },
          {
            label: 'Mobile Broadband Prepaid',
            href: '#',
          },
          {
            label: 'Prepaid Phones',
            href: '#',
          },
          {
            label: 'Prepaid Roaming Add-ons',
            href: '#',
          },
          {
            label: 'Add-ons',
            href: '#',
          },
        ],
      },
      {
        title: 'Services',
        items: [
          {
            label: 'International Roaming',
            href: '#',
          },
          {
            label: 'International Calls',
            href: '#',
          },
          {
            label: 'Insurance',
            href: '#',
          },
          {
            label: 'Entertainment and Pay with Vodafone',
            href: '#',
          },
        ],
      },
    ],
  },
  {
    title: 'iPad & Tablets',
    items: [
      {
        title: 'Tablets With Plans',
        items: [
          {
            label: 'All Tablets',
            href: '#',
          },
          {
            label: 'iPad',
            href: '#',
          },
          {
            label: 'Insurance',
            href: '#',
          },
          {
            label: 'Upgrade',
            href: '#',
          },
        ],
      },
      {
        title: 'Plans',
        items: [
          {
            label: 'SIM Only Plans',
            href: '#',
          },
          {
            label: 'Prepaid Plans',
            href: '#',
          },
          {
            label: 'Change my Plan',
            href: '#',
          },
        ],
      },
    ],
  },
  {
    title: `nbn${TRADEMARK} & Internet`,
    items: [
      {
        title: `nbn${TRADEMARK} Home Internet`,
        items: [
          {
            label: `nbn${TRADEMARK} Plans`,
            href: '#',
          },
          {
            label: 'Plans with 4G Modem',
            href: '#',
          },
        ],
      },
      {
        title: 'Mobile Broadband',
        items: [
          {
            label: 'Plans With Pocket Wifi',
            href: '#',
          },
          {
            label: 'SIM Only Plans',
            href: '#',
          },
          {
            label: 'Prepaid Plans',
            href: '#',
          },
        ],
      },
    ],
  },
  {
    title: 'My Vodafone',
    items: [
      {
        title: 'My Vodafone',
        items: [
          {
            label: 'Login',
            href: '#',
          },
          {
            label: 'Download',
            href: '#',
          },
          {
            label: 'Register',
            href: '#',
          },
          {
            label: 'Get Help',
            href: '#',
          },
        ],
      },
      {
        title: 'My Vodafone Services',
        items: [
          {
            label: 'Recharge Your Prepaid Service',
            href: '#',
          },
          {
            label: 'Activate Your SIM',
            href: '#',
          },
          {
            label: 'Swap Your SIM',
            href: '#',
          },
          {
            label: 'Pay Your Bill',
            href: '#',
          },
          {
            label: 'Upgrade Your Device',
            href: '#',
          },
          {
            label: 'Change Your Plan',
            href: '#',
          },
        ],
      },
    ],
  },
  {
    title: 'Support',
    items: [
      {
        title: 'Support',
        items: [
          {
            label: 'Get Help Online',
            href: '#',
          },
          {
            label: 'Contact Our Team',
            href: '#',
          },
          {
            label: 'Find a Store',
            href: '#',
          },
          {
            label: 'Compliments and Complaints',
            href: '#',
          },
          {
            label: 'Track Your Order',
            href: '#',
          },
          {
            label: 'Critical Information Summaries',
            href: '#',
          },
          {
            label: 'Fraud',
            href: '#',
          },
          {
            label: 'Scams',
            href: '#',
          },
        ],
      },
      {
        title: 'Devices',
        items: [
          {
            label: 'Device Guide',
            href: '#',
          },
          {
            label: 'Service a Repair',
            href: '#',
          },
          {
            label: 'Software Updates',
            href: '#',
          },
          {
            label: 'Accessibility',
            href: '#',
          },
          {
            label: 'Manage Your eSIM',
            href: '#',
          },
        ],
      },
      {
        title: 'Network',
        items: [
          {
            label: 'Our Network',
            href: '#',
          },
          {
            label: '5G',
            href: '#',
          },
          {
            label: 'Check Your Coverage',
            href: '#',
          },
          {
            label: 'Scheduled Network Updates',
            href: '#',
          },
        ],
      },
    ],
  },
];
