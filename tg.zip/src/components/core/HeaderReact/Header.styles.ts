import styled, { css } from 'styled-components';
import {
  MixinProperty,
  displayMixin,
  fontLineHeightSize,
  listReset,
  media,
  variantThemeColors,
  variantThemeLinkColors,
} from '@src/lib/util/mixins';

export const ContainerOuter = styled.div`
  position: relative;
  background-color: ${(p) => p.theme.colors.white};
  border-bottom: 1px solid ${(p) => p.theme.colors.silver};
`;

export const ContainerInner = styled.nav`
  display: flex;
  padding: 0 16px;

  @media (min-width: 1180px) {
    padding: 0;
  }
`;

export const NavMenuTitle = styled.h3`
  padding: 0 0 8px;
  font-family: ${(p) => p.theme.fonts.regular};
  ${fontLineHeightSize('heading5Tablet')}
  border-bottom: 1px solid ${(p) => p.theme.variants.greyBorderColor};
  color: ${(p) => p.theme.colors.anthracite};

  ${media.xl`
    font-family: ${(p) => p.theme.fonts.light};
    ${fontLineHeightSize('heading4')}
  `}
`;

export const NavMenuList = styled.ul`
  ${listReset}
  padding: 8px 0 0;
  ${variantThemeLinkColors}
`;

export const NavMenuListItem = styled.li`
  padding: 6px 0;
`;

export const NavMenuLink = styled.a`
  ${fontLineHeightSize('baseLarge')}
  text-decoration: none;

  &:hover {
    text-decoration: underline;
  }
`;

export const NavIconList = styled.ul`
  ${listReset}
  display: flex;
  margin-left: auto;
`;

interface NavIconItemProps {
  display?: MixinProperty;
}
export const NavIconItem = styled.li<NavIconItemProps>`
  margin: 0;
  padding: 0;
  ${(p) => displayMixin(p.display)}
`;

export const SecondaryLinkContainer = styled.div`
  display: none;
  ${variantThemeColors}
  ${variantThemeLinkColors}

  ${media.l`
    display: block;
  `}
`;

export const SecondaryLinkList = styled.ul`
  ${listReset}
  display: flex;
  padding-left: 60px;
`;

interface SecondaryLinkItemProps {
  isActive?: boolean;
}
export const SecondaryLinkItem = styled.li<SecondaryLinkItemProps>`
  width: 150px;
  padding: 4px 0;
  text-align: center;
  ${(p) =>
    p.isActive &&
    css`
      background-color: ${p.theme.colors.white};

      a,
      a:focus,
      a:hover,
      a:active,
      a:visited {
        color: ${p.theme.variants.backgroundColor};
      }
    `}
`;

export const SecondaryLink = styled.a`
  ${fontLineHeightSize('base')}
  text-decoration: none;

  &:hover {
    text-decoration: underline;
  }
`;
