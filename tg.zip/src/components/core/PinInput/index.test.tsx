import React from 'react';
import { render } from 'test-utils';
import { InputProps, PinInput } from './index';
import '@testing-library/jest-dom';

const defaultProps: InputProps = {
  invalid: false,
  helpText:
    "This is the PIN you created when you signed up to your service. If your service sits under one account, you'll need the PIN of the account owner to log in.",
  label: undefined,
  name: '',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<PinInput {...props} />);
  return { utils, props };
};

describe('PinInput', () => {
  it('should render InfoCircleWrapper when helpText is there', () => {
    defaultProps.invalid = true;
    const { utils } = setup();
    const PinInputIcon = utils.getByTestId('info-icon');
    const PinInputToolTip = utils.getByTestId('help-text-tooltip');
    expect(PinInputIcon).toBeTruthy();
    expect(PinInputToolTip).toBeTruthy();
  });
});
