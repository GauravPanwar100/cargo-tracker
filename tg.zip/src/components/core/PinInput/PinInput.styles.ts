/* eslint-disable @typescript-eslint/no-explicit-any */
import styled from 'styled-components';
import DiscCompatEot from '../../../assets/fonts/text-security-disc-compat.eot';
import DiscWoff from '../../../assets/fonts/text-security-disc.woff2';

const Wrapper = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  max-width: '100%';
  width: 100%;
`;

/**
 * input type search is used for `PinInput` component
 * since disabling autofills is an issue across different browsers.
 * `-moz` does not support `text-security`
 * hence disc style masking font is added to the input.
 * caveat: browsers offer security features for password fields,
 * using type="search" for `PinPinput` will get rid of browser protections.
 */
const InputElement = styled.input<{
  hasError: boolean;
  hasReset: boolean;
  maxWidth: any;
  invalid: any;
  mask: boolean;
}>`
  color: #333333;
  font-family: "VodafoneRegular", Arial, sans-serif;
  font-size: 18px;
  letter-spacing: 0;
  line-height: 24px;
  max-width: ${({ maxWidth }) => maxWidth || '100%'};
  box-sizing: border-box;
  height: 50px;

  @media (max-width: 500px) {
    height: 44px;
  }
  width: 100%;
  border: ${({ invalid }) => (invalid ? `2px solid #E60000` : `1px solid #999999`)};
  border-radius: 6px;
  background-color: #ffffff;
  padding: ${({ hasReset }) => (hasReset ? `13px 26px 13px 16px` : `13px 16px`)};
  background-clip: padding-box !important;
  outline-color: transparent

  &:focus {
    outline-color: #00b0ca;
  }
  &[aria-invalid='true'] {
    padding: 11px 15px;
    border-width: 2px;
    border-color: ${(p) => p.theme.colors.red};
  }
  &[type="search"] {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    ${({ mask }) =>
      mask &&
      `
      @font-face {
        font-family: 'text-security-disc';
        src: url(${DiscCompatEot}),
            url(${DiscWoff}) format('woff2');
      }
      font-family: 'text-security-disc';
      text-security: disc;
      -webkit-text-security: disc;
    `}
  }


  &[type="search"]::-webkit-search-cancel-button {
    -webkit-appearance: none;
    appearance: none;
  }

  &[autocomplete="off"]::-webkit-contacts-auto-fill-button {
    visibility: hidden;
    display: none;
    pointer-events: none;
    height: 0;
    width: 0;
    margin: 0;
  }

  &[autocomplete="off"]::-webkit-credentials-auto-fill-button {
    visibility: hidden;
    display: none;
    pointer-events: none;
    height: 0;
    width: 0;
    margin: 0;
  }
`;

const Label = styled.label`
  height: 22px;
  width: 100%;
  color: #333333;
  font-family: 'VodafoneRegular', Arial, sans-serif;
  font-size: 16px;
  letter-spacing: 0;
  line-height: 22px;
  margin-bottom: 8px;
`;

const InfoCircleWrapper = styled.div<{ maxWidth: any; ref: any }>`
  position: absolute;
  left: ${({ maxWidth }) => `calc(${maxWidth || '100%'} - 34px)`};
  bottom: 11px;
  @media (max-width: 500px) {
    bottom: 8px;
  }
`;

const arrowWidth = '10px';

const Tooltip = styled.div<{ show: any; maxWidth: any }>`
  border-radius: 6px;
  background-color: #666666;
  box-shadow: 0 -1px 4px 0 rgba(0, 0, 0, 0.35);

  content: attr(data-tooltip-text);
  color: white;
  font-family: 'VodafoneRegular', Arial, sans-serif;
  font-size: 18px;
  letter-spacing: 0;
  line-height: 22px;
  top: 110%;
  left: 0;
  padding: 18px 24px;
  position: absolute;
  width: 100%;
  min-width: 50px;

  z-index: 9999;

  opacity: ${({ show }) => (show ? 1 : 0)};
  display: ${({ show }) => (show ? 'block' : 'none')};

  @media (max-width: 500px) {
    width: 100%;
    padding: 18px 24px;
  }

  &:before {
    content: '';
    position: absolute;
    height: 0;
    width: 0;
    top: -15px;
    left: ${({ maxWidth }) => `calc(${maxWidth || '100%'} - ${arrowWidth} - 22px)`};
    border-width: 0 ${arrowWidth} 15px;
    border-style: solid;
    border-color: transparent transparent #666;
  }
`;

const ResetButton = styled.button`
  border: 0;
  background-color: transparent;
  outline: 0;
  cursor: pointer;
  position: absolute;
  padding: 0;
  margin: 0 14px 0 5px;
  vertical-align: middle;
  right: 0;
  top: 60%;
  transform: translateY(-50%);
  @media (max-width: 500px) {
    top: 53%;
  }
`;

export { Wrapper, Label, Tooltip, InputElement, InfoCircleWrapper, ResetButton };
