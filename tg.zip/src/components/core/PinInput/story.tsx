import React from 'react';
import { Meta, Story } from '@storybook/react';
// eslint-disable-next-line import/named
import { Input, InputProps, PinInput } from './index';

export default {
  title: 'Shared UI/Atom/Input',
  component: Input,
} as Meta;

const Template: Story<InputProps> = (args) => <Input {...args} />;
export const Default = Template.bind({});
Default.args = {
  label: 'input label',
  name: 'input name',
  hasError: false,
};

export const Error = Template.bind({});
Error.args = {
  label: 'input label',
  name: 'input name',
  hasError: true,
};

export const Help = Template.bind({});
Help.args = {
  label: 'input label',
  name: 'input name',
  hasError: false,
  helpText: 'help text',
};

export const WithCancel = Template.bind({});
WithCancel.args = {
  label: 'input label',
  name: 'input name',
  hasError: false,
};

const Template2: Story<InputProps> = (args) => <PinInput {...args} />;
export const PinInputCP = Template2.bind({});
PinInputCP.args = {
  label: 'input label',
  name: 'input name',
  hasError: false,
  helpText: 'help text',
};
