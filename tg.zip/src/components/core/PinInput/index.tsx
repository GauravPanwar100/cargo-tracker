/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useRef, useState } from 'react';
import styled from 'styled-components';

import IconCrossOutline from '../Icons/IconCrossOutline';
import { InfoCircleWrapper, InputElement, Label, ResetButton, Tooltip, Wrapper } from './PinInput.styles';

import { InfoCircle } from '../InfoCircle/index';

function useHover() {
  const [value, setValue] = useState(false);

  const ref = useRef<null | HTMLElement>(null);

  const handleMouseOver = () => setValue(true);
  const handleMouseOut = () => setValue(false);

  useEffect(
    // eslint-disable-next-line consistent-return
    () => {
      const node = ref.current;
      if (node) {
        node.addEventListener('mouseover', handleMouseOver);
        node.addEventListener('mouseout', handleMouseOut);

        return () => {
          node.removeEventListener('mouseover', handleMouseOver);
          node.removeEventListener('mouseout', handleMouseOut);
        };
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [ref.current], // Recall only if ref changes
  );

  return [ref, value];
}

interface InputProps {
  label: any;
  name: string;
  dataTestId?: string;
  type?: string;
  value?: any;
  maxWidth?: string;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  hasReset?: boolean;
  onReset?: any;
  hasError?: boolean;
  helpText?: any;
  invalid?: boolean;
  mask?: boolean;
  onChange?: any;
}

const Input = ({
  label,
  name,
  dataTestId,
  type,
  value,
  maxWidth,
  minLength,
  maxLength,
  pattern,
  hasReset = false,
  onReset,
  hasError = false,
  helpText,
  invalid,
  mask = false,
  onChange,
  children,
  ...props
}: React.ComponentPropsWithoutRef<typeof Wrapper> & InputProps) => {
  const [hoverRef, isHovered] = useHover();
  const [inputValue, setInputValue] = useState(value);

  useEffect(() => {
    setInputValue(value);
  }, [value]);

  const { 'data-test-id': testId, ...rest } = props;

  const onHandleReset = () => {
    setInputValue('');
    onReset();
  };

  const onHandleChange = (e: any) => {
    onChange(e);
    setInputValue(value);
  };

  return (
    <Wrapper {...rest}>
      {label && <Label>{label}</Label>}
      <InputElement
        aria-label={name}
        name={name}
        data-test-id={testId}
        type={type}
        autoComplete="off"
        value={inputValue}
        inputMode="numeric"
        maxWidth={maxWidth}
        minLength={minLength}
        maxLength={maxLength}
        pattern={pattern}
        hasError={hasError}
        hasReset={hasReset}
        invalid={invalid}
        mask={mask}
        onChange={onHandleChange}
      />
      {children}
      {helpText && (
        <InfoCircleWrapper data-testid="info-icon" maxWidth={maxWidth} ref={hoverRef}>
          <InfoCircle />
        </InfoCircleWrapper>
      )}
      {helpText && (
        <Tooltip data-testid="help-text-tooltip" maxWidth={maxWidth} show={isHovered}>
          {helpText}
        </Tooltip>
      )}
      {hasReset && inputValue && (
        <ResetButton onClick={onHandleReset} type="button">
          <IconCrossOutline width="18" height="18" />
        </ResetButton>
      )}
    </Wrapper>
  );
};

const PinInput = styled(Input)`
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }
`;

export { Input, PinInput };
export type { InputProps };
