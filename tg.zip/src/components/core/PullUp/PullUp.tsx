import React from 'react';
import { PullUp as StyledPullUp } from './PullUp.styles';

interface PullUpProps {}

const PullUp: React.FC<PullUpProps> = ({ children }) => (
  <StyledPullUp data-testid="pullup-component">{children}</StyledPullUp>
);

export default PullUp;
