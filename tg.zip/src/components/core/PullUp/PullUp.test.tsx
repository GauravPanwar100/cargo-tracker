import React from 'react';
import PullUp from '@src/components/core/PullUp';
import { render } from '@src/test-utils';

const setup = () => {
  const utils = render(
    <PullUp>
      <div data-testid="pullup-child" />
    </PullUp>,
  );

  return { utils };
};

describe('PullUp', () => {
  it('should render component with children', () => {
    const { utils } = setup();
    expect(utils.getByTestId('pullup-child')).toBeDefined();
    expect(utils.getByTestId('pullup-component')).toBeDefined();
  });
});
