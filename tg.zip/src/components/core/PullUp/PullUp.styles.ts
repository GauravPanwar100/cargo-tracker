import styled from 'styled-components';
import { media } from '@src/lib/util/mixins';

export const PullUp = styled.div`
  position: relative;
  margin-top: -24px;
  z-index: 1;

  ${media.m`
    margin-top: -64px;
  `}
`;
