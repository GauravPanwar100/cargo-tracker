import styled, { StyledProps, css } from 'styled-components';
import { ColorKey } from '@src/lib/theme';
import {
  MixinProperty,
  borderRadiusMixin,
  focusBoxShadow,
  fontLineHeightSize,
  heightMixin,
  media,
  widthMixin,
} from '@src/lib/util/mixins';

export type ButtonSize = 's' | 'm' | 'l';
export type ButtonVariant = 'primary' | 'secondary' | 'tertiary' | 'tertiaryInverse' | 'selected' | 'lightGrey';

type ColorMap = Record<ButtonVariant, VariantStyle>;
type ThemeColor = Partial<ColorKey>;

interface VariantStyle {
  background: ThemeColor;
  border: ThemeColor;
  hover: {
    background: ThemeColor;
    border: ThemeColor;
  };
  text: ThemeColor;
}

export const ButtonColorMap: ColorMap = {
  primary: {
    background: 'red',
    border: 'red',
    hover: {
      background: 'redDark',
      border: 'redDark',
    },
    text: 'white',
  },
  secondary: {
    background: 'greyDark',
    border: 'greyDark',
    hover: {
      background: 'anthracite',
      border: 'anthracite',
    },
    text: 'white',
  },
  tertiary: {
    background: 'white',
    border: 'midGrey',
    hover: {
      background: 'lightGrey',
      border: 'black',
    },
    text: 'black',
  },
  tertiaryInverse: {
    background: 'transparent',
    border: 'white',
    hover: {
      background: 'transparent',
      border: 'lightGrey',
    },
    text: 'white',
  },
  selected: {
    background: 'uiGreen',
    border: 'uiGreen',
    hover: {
      background: 'uiGreen',
      border: 'uiGreen',
    },
    text: 'white',
  },
  lightGrey: {
    background: 'anthracite',
    border: 'anthracite',
    hover: {
      background: 'black',
      border: 'black',
    },
    text: 'white',
  },
};

const variantStyles = (p: StyledProps<ButtonProps>) => {
  const styles = ButtonColorMap[p.variant];

  return css`
    background: ${p.theme.colors[styles.background]};
    color: ${p.theme.colors[styles.text]};
    border: 1px solid ${p.theme.colors[styles.border]};

    &:not(:disabled):hover {
      background: ${p.theme.colors[styles.hover.background]};
      border-color: ${p.theme.colors[styles.hover.border]};
    }
  `;
};

const sizeStyles = (p: StyledProps<ButtonProps>) => {
  const baseSize = css`
    padding: 10px 14px;
    ${fontLineHeightSize('buttonMobile')};
  `;

  switch (p.size) {
    case 's':
      return baseSize;
    case 'm':
    default:
      return css`
        ${baseSize}
        ${media.m`
          padding: 10px 18px;
          ${fontLineHeightSize('button')}
        `}
      `;
  }
};

interface ButtonProps {
  fullWidth?: boolean;
  isLoading?: boolean;
  size: ButtonSize;
  variant: ButtonVariant;
  visuallyDisabled?: boolean;
  fixedHeight?: MixinProperty;
  fixedWidth?: MixinProperty;
  borderRadius?: MixinProperty;
}

export const Button = styled.button<ButtonProps>`
  display: block;
  width: 100%;

  font-family: ${(p) => p.theme.fonts.regular};
  text-align: center;
  text-decoration: none;
  border-radius: 6px;
  transition: background-color ${(p) => p.theme.durations.transition} ease-out;
  cursor: pointer;
  ${sizeStyles}
  ${variantStyles}
  ${(p) => p.fixedHeight && heightMixin(p.fixedHeight)}
  ${(p) => p.fixedWidth && widthMixin(p.fixedWidth)}
  ${(p) => p.borderRadius && borderRadiusMixin(p.borderRadius)}

  &:active {
    ${focusBoxShadow}
    transform: translateY(1px);
  }

  &:focus {
    ${focusBoxShadow}
  }

  ${(p) =>
    p.visuallyDisabled &&
    !p.isLoading &&
    css`
      color: ${p.theme.colors.white} !important;
      background-color: ${p.theme.colors.silver} !important;
      border-color: ${p.theme.colors.silver} !important;
    `}

  &:disabled {
    cursor: not-allowed;
    ${(p) =>
      !p.isLoading &&
      css`
        color: ${p.theme.colors.white};
        background-color: ${p.theme.colors.silver};
        border-color: ${p.theme.colors.silver};
      `}
  }

  ${media.m<ButtonProps>`
    ${(p) =>
      !p.fullWidth &&
      css`
        display: inline-block;
        width: auto;
        min-width: 150px;
      `}
  `}
`;

export const CircularTick = styled.div`
  display: inline-block;
  position: relative;
  top: 2px;
  height: 18px;
  width: 18px;
  margin-right: 10px;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M12 24C5.373 24 0 18.627 0 12S5.373 0 12 0s12 5.373 12 12-5.373 12-12 12zm5.782-17.175h-.001l-8.68 9.403L5.55 12.38a.75.75 0 00-1.1 1.018l4.101 4.444a.75.75 0 001.103 0l9.23-10a.75.75 0 00-1.102-1.017z' fill='%23FFF' fill-rule='nonzero'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
`;

export const CheckedBox = styled.div`
  display: inline-block;
  position: relative;
  top: 3px;
  height: 18px;
  width: 18px;
  margin-right: 12px;
  border: solid ${(p) => p.theme.colors.white};
  border-width: 1px;
  border-radius: 3px;
  background-color: ${(p) => p.theme.colors.white};
`;

export const UnCheckedBox = styled.div`
  display: inline-block;
  position: relative;
  top: 3px;
  height: 18px;
  width: 18px;
  margin-right: 12px;
  border: solid ${(p) => p.theme.colors.black};
  border-width: 1px;
  border-radius: 3px;
  background-color: ${(p) => p.theme.colors.white};
`;

export const CheckMark = styled.div`
  margin-top: 2px;
  margin-left: 5px;
  width: 6px;
  height: 11px;
  border: solid ${(p) => p.theme.colors.uiGreen};
  border-width: 0 2px 2px 0;
  transform: rotate(45deg);
`;
