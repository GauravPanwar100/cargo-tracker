import React from 'react';
import { fireEvent, render } from 'test-utils';
import Button, { ButtonProps } from './Button';

const defaultProps: ButtonProps = {
  children: 'Button text',
  variant: 'primary',
  onClick: jest.fn(),
};

const setup = (extraProps: Partial<ButtonProps> = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<Button {...props} />);
  return { utils, props };
};

describe('Button', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  it('should be clickable', () => {
    const { utils, props } = setup();
    const button = utils.getByText('Button text');
    fireEvent.click(button);
    expect(props.onClick).toBeCalled();
  });

  it('should be disabled with disabled prop', () => {
    const { utils, props } = setup({ disabled: true });
    const button = utils.getByText('Button text');
    fireEvent.click(button);
    expect(props.onClick).not.toBeCalled();
  });

  it('should be visually disabled with visuallyDisabled prop', () => {
    const { utils, props } = setup({ visuallyDisabled: true });
    const button = utils.getByText('Button text');
    fireEvent.click(button);
    expect(props.onClick).toBeCalled();
  });
});
