import React from 'react';
import { ThemeProvider } from 'styled-components';
import { storiesOf } from '@storybook/react';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import Text from '@src/components/core/Text';
import { Sections } from '@src/lib/constants/storybook';
import { darkTheme } from '@src/lib/theme';
import Button from './Button';

storiesOf(`${Sections.CORE}|Button`, module).add('Default', () => (
  <>
    <Section>
      <Grid>
        <GridCol>
          <Text as="h5" marginBottom="12px">
            Primary
          </Text>
          <Button variant="primary">Label</Button>
        </GridCol>
        <GridCol>
          <Text as="h5" marginBottom="12px">
            Secondary
          </Text>
          <Button variant="secondary">Label</Button>
        </GridCol>
        <GridCol gridColSpan={{ xs: 12, m: 6 }}>
          <Text as="h5" marginBottom="12px">
            Tertiary
          </Text>
          <Button variant="tertiary">Label</Button>
        </GridCol>
      </Grid>
    </Section>
    <ThemeProvider theme={darkTheme}>
      <Section>
        <Grid>
          <GridCol>
            <Text as="h5" marginBottom="12px">
              Tertiary Inverse
            </Text>
            <Button variant="tertiaryInverse">Label</Button>
          </GridCol>
        </Grid>
      </Section>
    </ThemeProvider>
    <Section>
      <Grid>
        <GridCol>
          <Text as="h5" marginBottom="12px">
            Selected
          </Text>
          <Button variant="selected">Label</Button>
        </GridCol>
        <GridCol>
          <Text as="h5" marginBottom="12px">
            Disabled
          </Text>
          <Button disabled={true} variant="primary">
            Label
          </Button>
        </GridCol>
      </Grid>
    </Section>
  </>
));
