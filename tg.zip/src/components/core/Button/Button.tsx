import React, { forwardRef } from 'react';
import { ReactComponent as LoadingSpinner } from '@src/assets/svg/loading-spinner.svg';
import { ReactComponent as LoadingSpinnerWhite } from '@src/assets/svg/loading-spinner-white.svg';
import IconWrapper from '@src/components/core/IconWrapper';
import { MixinProperty } from '@src/lib/util/mixins';
import {
  ButtonVariant,
  CheckMark,
  CheckedBox,
  CircularTick,
  Button as StyledButton,
  UnCheckedBox,
} from './Button.styles';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  disabled?: boolean;
  /**
   * In some cases, we may only want to 'visually' disable a button, such as when relying on browser
   * autocomplete. This is because although a field may be filled visually to a user when
   * autofilled, React does not become aware of the value until the form is attempted to be
   * submitted (due to browser security), and for this reason we don't want to disable the button
   * for a user.
   */
  visuallyDisabled?: boolean;
  fullWidth?: boolean;
  isLoading?: boolean;
  onClick?: React.MouseEventHandler;
  size?: 's' | 'm' | 'l';
  type?: 'submit' | 'reset' | 'button';
  variant?: ButtonVariant;
  tickType?: 'circular' | 'checkbox' | 'none';
  fixedHeight?: MixinProperty;
  fixedWidth?: MixinProperty;
  borderRadius?: MixinProperty;
}

const Button: React.ForwardRefRenderFunction<HTMLButtonElement, ButtonProps> = (
  {
    children,
    disabled,
    visuallyDisabled,
    fullWidth,
    isLoading,
    onClick,
    size = 'm',
    type = 'button',
    variant = 'primary',
    tickType,
    fixedHeight,
    fixedWidth,
    borderRadius,
    ...props
  }: ButtonProps,
  ref,
) => (
  <StyledButton
    disabled={disabled || isLoading}
    visuallyDisabled={visuallyDisabled}
    fullWidth={fullWidth}
    isLoading={isLoading}
    onClick={onClick}
    ref={ref}
    size={size}
    type={type}
    variant={variant}
    fixedHeight={fixedHeight}
    fixedWidth={fixedWidth}
    borderRadius={borderRadius}
    {...props}
  >
    {!isLoading && variant === 'selected' && (tickType === 'circular' || !tickType) && <CircularTick />}
    {!isLoading && variant === 'selected' && tickType === 'checkbox' && (
      <CheckedBox>
        <CheckMark />
      </CheckedBox>
    )}
    {!isLoading && variant === 'secondary' && tickType === 'checkbox' && <UnCheckedBox />}
    {isLoading && (
      <IconWrapper
        animateRotate={true}
        display="inline-block"
        height="18px"
        marginRight="10px"
        svg={variant === 'tertiary' ? LoadingSpinner : LoadingSpinnerWhite}
        top="2px"
        width="18px"
      />
    )}
    {children}
  </StyledButton>
);

export default forwardRef(Button);
