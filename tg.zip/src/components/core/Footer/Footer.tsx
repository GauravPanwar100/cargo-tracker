import React from 'react';
import sanitize from 'sanitize-html';
import { Footer as StyledFooter } from './Footer.styles';

export interface FooterProps {
  footerLinks: string;
}

const Footer: React.FC<FooterProps> = ({ footerLinks }) => {
  const footerHtml = footerLinks || '';
  const sanitized = sanitize(footerHtml, {
    allowedTags: false,
    allowedAttributes: false,
  });
  return (
    // eslint-disable-next-line react/no-danger
    <StyledFooter dangerouslySetInnerHTML={{ __html: sanitized }} />
  );
};

export default Footer;
