import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import { NAVIGATION } from '@src/lib/constants/navigation';
import Footer from './Footer';

storiesOf(`${Sections.CORE}|Footer`, module).add('default', () => <Footer footerLinks={NAVIGATION.footer} />);
