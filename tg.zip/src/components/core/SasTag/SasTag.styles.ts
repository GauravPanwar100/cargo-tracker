import styled from 'styled-components';

export const CI360CustomEvent = styled.div`
  display: none;
  visibility: hidden;
`;
