import React, { forwardRef } from 'react';
import { CI360CustomEvent } from './SasTag.styles';

export interface SasTagProps {
  prop?: string;
}

/**
 * SAS script updates the style
 * and innerHTML of the divs with ids
 */
type Ref = HTMLDivElement;

const SasTag = forwardRef<Ref, SasTagProps>((_, ref) => {
  const displayTags = { display: 'none' };
  return (
    <div ref={ref}>
      <div id="eu-attr-1" style={displayTags} />
      <div id="eu-attr-2" style={displayTags} />
      <div id="eu-attr-3" style={displayTags} />
      <div id="eu-attr-4" style={displayTags} />

      {/* A/B tests/personalization DOM*/}

      <div id="eu-ab-test-1" style={displayTags} />
      <div id="eu-ab-test-2" style={displayTags} />
      <div id="eu-ab-test-3" style={displayTags} />
      <div id="eu-ab-test-4" style={displayTags} />
      <CI360CustomEvent id="ci360_customEvent" />
    </div>
  );
});

export default SasTag;
