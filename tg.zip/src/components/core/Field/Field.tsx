import React from 'react';
import { Theme } from '@src/lib/theme';
import { ControlContainer, Feedback, HelpText, Label, LabelContainer, Required } from './Field.styles';

/**
 * NB: See Select, ChipGroup, OptionButtonGroup for usage examples
 */

export interface FieldProps {
  className?: string;
  /**
   * Applies a 16px top and bottom margin to the control container. This is used for
   * things like a chip group, colour picker, or button options group
   */
  hasControlMargins?: boolean;
  error?: React.ReactNode;
  helpText?: React.ReactNode;
  /**
   * ID is mandatory for all fields in order to link the Label htmlFor prop to the ID of the
   * wrapped control. This is necessary for accessibility and clicking on the Label to focus
   * the control
   */
  id: string;
  label: string | React.ReactNode;
  labelSpacing?: keyof Theme['sizes'];
  required?: boolean;
  /**
   * Small fields use default font sizes for labels (no overrides of browser styling)
   * Medium fields have baseLarge sizing for mobile and desktop
   * Large fields have baseLarge sizing on mobile and go to h5 on desktop
   */
  size?: 'small' | 'medium' | 'large';
}

const Field: React.FC<FieldProps> = ({
  className,
  children,
  hasControlMargins,
  error,
  helpText,
  id,
  label,
  labelSpacing = 'modulePaddingSmall',
  required,
  size = 'small',
}) => (
  <div className={className}>
    <LabelContainer spacing={labelSpacing}>
      <Label htmlFor={id} size={size}>
        {label}
      </Label>
      {required && <Required aria-hidden="true"> *</Required>}
    </LabelContainer>
    <ControlContainer hasControlMargins={hasControlMargins}>{children}</ControlContainer>
    {/* `role="alert"` will announce the error to screen readers when it appears */}
    {error && <Feedback role="alert">{error}</Feedback>}
    {helpText && <HelpText>{helpText}</HelpText>}
  </div>
);

export default Field;
