import styled from 'styled-components';
import { Theme } from '@src/lib/theme';
import { fontLineHeightSize, media } from '@src/lib/util/mixins';

interface LabelContainerProps {
  spacing: keyof Theme['sizes'];
}

export const LabelContainer = styled.div<LabelContainerProps>`
  margin-bottom: ${(p) => p.theme.sizes[p.spacing]}px;
`;

interface LabelProps {
  size?: 'small' | 'medium' | 'large';
}

// Small fields use default font sizes for labels (no overrides of browser styling)
// Medium fields have baseLarge sizing for mobile and desktop
// Large fields have baseLarge sizing on mobile and go to h5 on desktop
export const Label = styled.label<LabelProps>`
  color: ${(p) => p.theme.colors.darkGrey};
  ${(p) => (p.size === 'large' || p.size === 'medium') && fontLineHeightSize('baseLarge')}

  ${media.l<LabelProps>`
    ${(p) => p.size === 'large' && fontLineHeightSize('heading5')}
  `}
`;

export const Required = styled.span`
  color: ${(p) => p.theme.colors.darkRed};
`;

interface ControlContainerProps {
  hasControlMargins?: boolean;
}
export const ControlContainer = styled.div<ControlContainerProps>`
  ${(p) =>
    p.hasControlMargins &&
    `
    margin: ${p.theme.sizes.modulePaddingSmall}px 0 0;
  `}
`;

// Text that shows up underneath the rendered control
// Used for both Feedback (an error message), and HelpText (persistent explainer for the field)
const HelpTextBase = styled.div`
  margin-top: ${(p) => p.theme.sizes.modulePaddingSmallSmall}px;
  display: block;
  ${fontLineHeightSize('baseSmall')}

  p {
    ${fontLineHeightSize('baseSmall')}
  }
`;

export const Feedback = styled(HelpTextBase)`
  color: ${(p) => p.theme.colors.darkRed};
`;

export const HelpText = styled(HelpTextBase)`
  color: ${(p) => p.theme.colors.darkGrey};
`;
