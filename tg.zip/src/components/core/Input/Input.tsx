import React, { ForwardRefRenderFunction, forwardRef } from 'react';
import { MixinProperty } from '@src/lib/util/mixins';
import { Input as StyledInput } from './Input.styles';

// Strip the `as` and `ref` props to maintain compatibility with the styled-component
// versions of those props
type HTMLInputProps = Omit<React.HTMLProps<HTMLInputElement>, 'as' | 'ref'>;

export interface InputProps extends HTMLInputProps {
  invalid?: boolean;
  borderRadiusValue?: MixinProperty;
}

const Input: ForwardRefRenderFunction<HTMLInputElement, InputProps> = (
  { invalid = false, type = 'text', borderRadiusValue, ...props },
  ref: React.Ref<HTMLInputElement>,
) => (
  <StyledInput
    data-testid="input"
    aria-invalid={invalid}
    ref={ref}
    type={type}
    borderRadiusValue={borderRadiusValue}
    {...props}
  />
);

export default forwardRef(Input);
