import styled from 'styled-components';
import { MixinProperty, borderRadiusMixin, fontLineHeightSize, media } from '@src/lib/util/mixins';

interface InputProps {
  invalid?: boolean;
  borderRadiusValue?: MixinProperty;
}
export const Input = styled.input<InputProps>`
  display: block;
  width: 100%;
  max-width: 100%;
  padding: 12px 16px;
  color: ${(p) => p.theme.colors.mainColor};
  font-family: ${(p) => p.theme.fonts.regular};
  border: 1px solid ${(p) => p.theme.colors.midGrey};
  border-radius: ${(p) => p.theme.sizes.borderRadius}px;
  background: ${(p) => p.theme.colors.white};
  appearance: none;
  box-shadow: none;
  ${(p) => p.borderRadiusValue && borderRadiusMixin(p.borderRadiusValue)}

  ${fontLineHeightSize('base')};

  &::-webkit-calendar-picker-indicator {
    display: none;
  }

  &:focus {
    padding: 11px 15px;
    border-color: ${(p) => p.theme.colors.aquaBlue};
    border-width: 2px;
    outline: none;
  }

  &:disabled {
    background-color: ${(p) => p.theme.colors.aluminium};
    opacity: 0.6;
    cursor: not-allowed;
  }

  &[aria-invalid='true'] {
    padding: 11px 15px;
    border-width: 2px;
    border-color: ${(p) => p.theme.colors.red};
  }

  ${media.m`
    width: 100%;
    padding: 14px 16px;
    ${fontLineHeightSize('baseLarge')};

    &:focus,
    &:disabled,
    &[aria-invalid="true"]{
      padding: 13px 15px;
    }
  `}
`;
