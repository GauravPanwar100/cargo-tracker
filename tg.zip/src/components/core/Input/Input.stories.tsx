import React from 'react';
import { storiesOf } from '@storybook/react';
import Field from '@src/components/core/Field';
import { Sections } from '@src/lib/constants/storybook';
import Input from './Input';

storiesOf(`${Sections.CORE}|Input`, module).add('default', () => (
  <Field id="input" label="Text input with label">
    <Input id="input" />
  </Field>
));
