import React from 'react';
import IframeResizer from 'iframe-resizer-react';
import { Container } from './IframeContainer.styles';

export interface IframeContainerProps {
  srcUrl: string;
  isCentered?: boolean;
}

const IframeContainer: React.FC<IframeContainerProps> = ({ srcUrl, isCentered = false }) => {
  return (
    <Container isCentered={isCentered}>
      <IframeResizer
        log={false}
        src={srcUrl}
        style={{
          width: '1px',
          minWidth: '100%',
          borderWidth: '0px',
          borderRadius: '6px',
        }}
      >
        Iframe Wrapper
      </IframeResizer>
    </Container>
  );
};

export default IframeContainer;
