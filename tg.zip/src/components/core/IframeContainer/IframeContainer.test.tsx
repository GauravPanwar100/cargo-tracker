import React from 'react';
import { render } from 'test-utils';
import IframeContainer, { IframeContainerProps } from './IframeContainer';

const defaultProps: IframeContainerProps = {
  srcUrl: '/omniout/index.html',
  isCentered: true,
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<IframeContainer {...props} />);
  return { utils, props };
};

describe('IframeContainer', () => {
  it('should render HeroImageTitle', () => {
    const { utils } = setup();
    utils.getByTitle('iframe');
    utils.getByText('Iframe Wrapper');
  });
});
