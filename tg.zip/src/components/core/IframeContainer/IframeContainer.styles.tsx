import styled, { css } from 'styled-components';
import { borderRadiusMixin, boxShadowMixin } from '@src/lib/util/mixins';

interface StyledIframeContainerProps {
  isCentered: boolean;
}

export const Container = styled.div<StyledIframeContainerProps>`
  ${(p) => `max-width: ${p.theme.sizes.containerMaxWidth}px`};
  ${(p) => borderRadiusMixin({ xs: 'none', m: `${p.theme.sizes.borderRadius}px` })};
  ${(p) => boxShadowMixin({ xs: 'none', m: p.theme.boxShadows.brand })};
  ${(p) =>
    p.isCentered &&
    css`
      margin-left: auto;
      margin-right: auto;
    `}
  ${(p) => css`
    @media (min-width: 768px) and (max-width: ${p.theme.sizes.containerMaxWidth}px) {
      margin-left: ${p.theme.spacing.xxs}px;
      margin-right: ${p.theme.spacing.xxs}px;
    }
  `}
`;
