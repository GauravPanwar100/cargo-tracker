import styled from 'styled-components';
import { media } from '@src/lib/util/mixins';

export const ContainerInner = styled.div`
  padding: 24px 0;

  ${media.m`
    padding: 32px 0;
  `}
`;
