import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import Text from '@src/components/core/Text';
import CheckoutFooter from './CheckoutFooter';

storiesOf(`${Sections.CORE}|CheckoutFooter`, module).add('default', () => (
  <div>
    <Text as="h5" marginBottom="12px">
      Footer with Country Acknowledgement
    </Text>
    <CheckoutFooter />
    <Text as="h5" marginBottom="12px">
      Footer without Country Acknowledgement
    </Text>
    <CheckoutFooter hideCountryAcknowledgement={true} />
  </div>
));
