export { default } from './CheckoutFooter';
