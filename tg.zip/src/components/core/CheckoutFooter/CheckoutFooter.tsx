import React from 'react';
import { ThemeProvider } from 'styled-components';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import Text from '@src/components/core/Text';
import { footerTheme } from '@src/lib/theme';
import Divider from '@src/components/core/Divider';
import { ContainerInner } from './CheckoutFooter.styles';

interface CheckoutFooterProps {
  hideCountryAcknowledgement?: boolean;
}
const CheckoutFooter: React.FC<CheckoutFooterProps> = ({ hideCountryAcknowledgement }) => (
  <ThemeProvider theme={footerTheme}>
    <Section spacingBottom={null} spacingTop={null} data-testid="checkout-footer">
      <Grid>
        <GridCol>
          <ContainerInner>
            <Text $color="white" fontSize={{ xs: 'base', m: 'baseLarge' }} lineHeight={{ xs: 'base', m: 'baseLarge' }}>
              &copy; 2020 TPG Telecom Limited ABN 76 096 304 620
            </Text>
          </ContainerInner>
        </GridCol>
      </Grid>
      {!hideCountryAcknowledgement && (
        <>
          <Grid>
            <GridCol>
              <Divider />
            </GridCol>
          </Grid>
          <Grid>
            <GridCol>
              <ContainerInner data-testid="acknowledgement-of-country-footer">
                <Text
                  $color="white"
                  fontSize={{ xs: 'base', m: 'baseLarge' }}
                  lineHeight={{ xs: 'base', m: 'baseLarge' }}
                >
                  Vodafone acknowledges the Traditional Custodians of the land on which we live, work and connect. We
                  pay respect to Elders, past, present, and emerging.
                </Text>
              </ContainerInner>
            </GridCol>
          </Grid>
        </>
      )}
    </Section>
  </ThemeProvider>
);

export default CheckoutFooter;
