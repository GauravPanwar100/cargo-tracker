import React from 'react';
import { render } from 'test-utils';
import RouterMock from '@src/test/RouterMock';
import CheckoutFooter from './CheckoutFooter';

const setup = (extraProps = {}) => {
  const props = { ...extraProps };
  const utils = render(
    <RouterMock>
      <CheckoutFooter {...props} />
    </RouterMock>,
  );
  return { utils, props };
};

describe('CheckoutFooter', () => {
  it('should render CheckoutFooter', () => {
    const { utils } = setup();
    utils.getByText('© 2020 TPG Telecom Limited ABN 76 096 304 620');
    utils.getByText(
      'Vodafone acknowledges the Traditional Custodians of the land on which we live, work and connect. We pay respect to Elders, past, present, and emerging.',
    );
  });
  it('should render footer for make payment screen', () => {
    const { utils } = setup({ hideCountryAcknowledgement: true });
    utils.getByText('© 2020 TPG Telecom Limited ABN 76 096 304 620');
    const subText = utils.queryByText('Vodafone acknowledges the Traditional Custodians');
    expect(subText).toBe(null);
  });
});
