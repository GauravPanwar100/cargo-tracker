import styled from 'styled-components';
import { media } from '@src/lib/util/mixins';

const ButtonGroup = styled.div`
  display: grid;
  grid-auto-flow: row;
  gap: 16px;

  ${media.m`
    grid-auto-flow: column;
    justify-content: start;
  `}
`;

export default ButtonGroup;
