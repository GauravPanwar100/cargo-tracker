import styled from 'styled-components';
import { listReset, media } from '@src/lib/util/mixins';

interface FeaturedList {
  isNewDesign?: boolean;
  length?: number;
}

export const List = styled.ul<FeaturedList>`
  ${listReset}
  display: grid;
  row-gap: 20px;
  justify-content: ${(p) => (p.isNewDesign ? 'space-between' : 'center')};

  ${media.m<FeaturedList>` 
    grid-template-columns: ${(p) =>
      // eslint-disable-next-line no-nested-ternary
      p.isNewDesign && p.length
        ? `repeat(${p.length}, 1fr)`
        : p.length
        ? `repeat(${p.length}, minmax(100px, 225px))`
        : `repeat(auto-fit, minmax(100px, 225px))`};
    column-gap: 15px;
  `}
  ${media.l<FeaturedList>` 
    column-gap: 30px;
  `}
`;

export const Title = styled.h2<{
  isNewDesign?: boolean;
}>`
  text-align: ${(p) => (p.isNewDesign ? 'left' : 'center')};
  margin-bottom: ${(p) => (p.isNewDesign ? p.theme.sizes.modulePadding : p.theme.sizes.modulePaddingSmallMedium)}px;
  ${media.m`
    margin-bottom: ${(p) => p.theme.sizes.modulePadding}px;
  `}

  ${media.l<{ isNewDesign?: boolean }>`
    margin-bottom: ${(p) => (p.isNewDesign ? p.theme.sizes.modulePadding : p.theme.sizes.modulePaddingLarge)}px;
  `};
`;

export const SubTitle = styled.h3`
  text-align: center;
  margin-bottom: ${(p) => p.theme.sizes.modulePaddingSmallMedium}px;

  ${media.m`
    margin-bottom: ${(p) => p.theme.sizes.modulePadding}px;
  `}

  ${media.l`
    margin-bottom: ${(p) => p.theme.sizes.modulePaddingLarge}px;
  `};
`;

export const Description = styled.div`
  p {
    max-width: 100%;
  }
`;
