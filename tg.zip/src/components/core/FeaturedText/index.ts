export { default as FeaturedText } from './FeaturedText';
export { default as FeaturedTextItem } from './FeaturedTextItem';
