import React from 'react';
import Text from '@src/components/core/Text';
import RichText from '@src/components/core/RichText';
import { PlanUspItem } from '@src/lib/api/types';
import { Description, List, Title } from './FeaturedText.styles';

export interface FeaturedTextProps {
  isNewDesign?: boolean;
  title?: string;
  description?: string;
  usps?: PlanUspItem[];
}

const FeaturedText: React.FC<FeaturedTextProps> = ({ isNewDesign, title, description, children, usps }) => (
  <div>
    {title && (
      <Title as={isNewDesign ? 'h3' : 'h2'} data-testid="feature-text-title" isNewDesign={isNewDesign}>
        {title}
      </Title>
    )}
    {description && (
      <Text fontSize="baseLarge" textAlign="center">
        <Description>
          <RichText>{description}</RichText>
        </Description>
      </Text>
    )}
    {children && (
      <List isNewDesign={isNewDesign} length={usps?.length}>
        {children}
      </List>
    )}
  </div>
);

export default FeaturedText;
