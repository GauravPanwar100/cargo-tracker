import React from 'react';
import { render } from 'test-utils';
import FeaturedText, { FeaturedTextProps } from './FeaturedText';

const defaultProps: FeaturedTextProps = {
  title: 'title',
  description: 'desc',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<FeaturedText {...props} />);
  return { utils, props };
};

describe('FeaturedText', () => {
  it('should render FeaturedText', () => {
    const { utils, props } = setup();
    if (props.title) {
      utils.getByText(props.title);
    }
    if (props.description) {
      utils.getByText(props.description);
    }
  });
});
