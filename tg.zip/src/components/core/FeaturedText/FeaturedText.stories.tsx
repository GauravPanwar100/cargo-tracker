import React from 'react';
import { ThemeProvider } from 'styled-components';
import { storiesOf } from '@storybook/react';
import { PriceTag, Rewards } from '@src/assets/base64/icons-system';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import { Sections } from '@src/lib/constants/storybook';
import { darkTheme } from '@src/lib/theme';
import FeaturedTextItem from './FeaturedTextItem';
import FeaturedText from './FeaturedText';

storiesOf(`${Sections.CORE}|FeaturedText`, module).add('Default', () => (
  <>
    <Section>
      <Grid>
        <GridCol>
          <FeaturedText title="Lorem ipsum dolor sit amet consectetur adipiscing elit">
            <FeaturedTextItem icon={PriceTag} title="Title">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} title="Very long multi line title">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
          </FeaturedText>
        </GridCol>
      </Grid>
    </Section>
    <Section>
      <Grid>
        <GridCol>
          <FeaturedText title="Lorem ipsum dolor sit amet consectetur adipiscing elit">
            <FeaturedTextItem icon={PriceTag} title="Title">
              Short text.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} title="Title">
              Medium lorem ipsum text.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} title="Title">
              Very very very very very very very very very long lorem ipsum dolor sit amet text spilling over the second
              line.
            </FeaturedTextItem>
          </FeaturedText>
        </GridCol>
      </Grid>
    </Section>
    <Section>
      <Grid>
        <GridCol>
          <FeaturedText title="Lorem ipsum dolor sit amet consectetur adipiscing elit">
            <FeaturedTextItem icon={PriceTag} title="Title">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} title="Title">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} title="Title">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} title="Title">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
          </FeaturedText>
        </GridCol>
      </Grid>
    </Section>
  </>
));

storiesOf(`${Sections.CORE}|FeaturedText`, module).add('Dark Themed', () => (
  <>
    <ThemeProvider theme={darkTheme}>
      <Section>
        <Grid>
          <GridCol>
            <FeaturedText title="Lorem ipsum dolor sit amet consectetur adipiscing elit">
              <FeaturedTextItem icon={Rewards} title="Title">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </FeaturedTextItem>
              <FeaturedTextItem icon={Rewards} title="Title">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </FeaturedTextItem>
            </FeaturedText>
          </GridCol>
        </Grid>
      </Section>
      <Section>
        <Grid>
          <GridCol>
            <FeaturedText title="Lorem ipsum dolor sit amet consectetur adipiscing elit">
              <FeaturedTextItem icon={Rewards} title="Title">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </FeaturedTextItem>
              <FeaturedTextItem icon={Rewards} title="Title">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </FeaturedTextItem>
              <FeaturedTextItem icon={Rewards} title="Title">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </FeaturedTextItem>
            </FeaturedText>
          </GridCol>
        </Grid>
      </Section>
      <Section>
        <Grid>
          <GridCol>
            <FeaturedText title="Lorem ipsum dolor sit amet consectetur adipiscing elit">
              <FeaturedTextItem icon={Rewards} title="Title">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </FeaturedTextItem>
              <FeaturedTextItem icon={Rewards} title="Title">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </FeaturedTextItem>
              <FeaturedTextItem icon={Rewards} title="Title">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </FeaturedTextItem>
              <FeaturedTextItem icon={Rewards} title="Title">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              </FeaturedTextItem>
            </FeaturedText>
          </GridCol>
        </Grid>
      </Section>
    </ThemeProvider>
  </>
));

const link = {
  label: 'Click here',
  url: '# ',
};

storiesOf(`${Sections.CORE}|FeaturedLinks`, module).add('Default', () => (
  <>
    <Section>
      <Grid>
        <GridCol>
          <FeaturedText title="Lorem ipsum dolor sit amet consectetur adipiscing elit">
            <FeaturedTextItem icon={PriceTag} link={link}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} link={link}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
          </FeaturedText>
        </GridCol>
      </Grid>
    </Section>

    <Section>
      <Grid>
        <GridCol>
          <FeaturedText title="Lorem ipsum dolor sit amet consectetur adipiscing elit">
            <FeaturedTextItem icon={PriceTag} link={link}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} link={link}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} link={link}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
          </FeaturedText>
        </GridCol>
      </Grid>
    </Section>

    <Section>
      <Grid>
        <GridCol>
          <FeaturedText title="Lorem ipsum dolor sit amet consectetur adipiscing elit">
            <FeaturedTextItem icon={PriceTag} link={link}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} link={link}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} link={link}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
            <FeaturedTextItem icon={PriceTag} link={link}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </FeaturedTextItem>
          </FeaturedText>
        </GridCol>
      </Grid>
    </Section>
  </>
));
