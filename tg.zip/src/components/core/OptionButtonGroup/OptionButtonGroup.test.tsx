import React from 'react';
import { fireEvent, render } from 'test-utils';
import OptionButtonGroup, { OptionButtonGroupProps } from './OptionButtonGroup';
import OptionButton from './OptionButton';

const defaultProps: OptionButtonGroupProps = {
  id: 'unit-test',
  name: 'unit-test',
  label: 'Choose your phone repayment period',
  onChange: jest.fn(),
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(
    <OptionButtonGroup {...props}>
      <OptionButton id="12months" value="12">
        12 months
      </OptionButton>
      <OptionButton id="24months" value="24">
        24 months
      </OptionButton>
      <OptionButton id="36months" value="36">
        36 months
      </OptionButton>
    </OptionButtonGroup>,
  );
  return { utils, props };
};

describe('OptionButtonGroup', () => {
  it('should render options', () => {
    const { utils } = setup();
    utils.getByText('12 months');
    utils.getByText('24 months');
    utils.getByText('36 months');
  });

  it('should fire onChange on button click', () => {
    const { utils, props } = setup();
    const firstButton = utils.getByText('12 months');
    fireEvent.click(firstButton);
    expect(props.onChange).toBeCalledWith('12');
  });

  it('should render a checked option when value exists', () => {
    const { utils } = setup({ value: '12' });
    const selectedOption = utils.getByTestId('option-button-input-unit-test-checked') as HTMLInputElement;
    expect(selectedOption.value).toBe('12');
  });
});
