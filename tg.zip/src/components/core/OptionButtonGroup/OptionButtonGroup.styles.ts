import styled from 'styled-components';
import RadioButtonGroup from '@src/components/core/RadioButtonGroup';
import { media } from '@src/lib/util/mixins';

export const OptionButtonGroup = styled(RadioButtonGroup)`
  white-space: nowrap;
  overflow: auto;
  margin: 0 ${(p) => -p.theme.sizes.modulePaddingSmall}px;
  padding: 0 ${(p) => p.theme.sizes.modulePaddingSmall}px;

  ${media.m`
    margin: 0;
    padding: 0;
  `}
`;
