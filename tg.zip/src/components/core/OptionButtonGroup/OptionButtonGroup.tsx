import React from 'react';
import Field from '@src/components/core/Field';
import { FieldProps } from '@src/components/core/Field/Field';
import { RadioButtonGroupProps } from '@src/components/core/RadioButtonGroup/RadioButtonGroup';
import { OptionButtonGroup as StyledOptionButtonGroup } from './OptionButtonGroup.styles';

export type OptionButtonGroupProps = FieldProps & RadioButtonGroupProps;

const OptionButtonGroup: React.FC<OptionButtonGroupProps> = ({
  // Radio button group props
  disabled,
  name,
  onChange,
  value,
  // Field props
  className,
  error,
  children,
  id,
  hasControlMargins = true,
  helpText,
  label,
  required,
  size = 'large',
}) => (
  <Field
    className={className}
    error={error}
    hasControlMargins={hasControlMargins}
    helpText={helpText}
    id={id}
    label={label}
    required={required}
    size={size}
  >
    <StyledOptionButtonGroup disabled={disabled} id={id} name={name} onChange={onChange} value={value}>
      {children}
    </StyledOptionButtonGroup>
  </Field>
);

export default OptionButtonGroup;
