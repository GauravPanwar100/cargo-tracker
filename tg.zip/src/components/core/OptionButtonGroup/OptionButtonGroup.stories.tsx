import React, { useCallback, useState } from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import OptionButton from './OptionButton';
import OptionButtonGroup from './OptionButtonGroup';

export const OptionButtonGroupDemo = () => {
  const [value, setValue] = useState<string>('');
  const onChange = useCallback((v: string) => {
    setValue(v);
  }, []);

  return (
    <OptionButtonGroup
      id="storybook"
      label="Choose your phone repayment period"
      onChange={onChange}
      name="storybook"
      value={value}
    >
      <OptionButton id="12months" value="12">
        12 months
      </OptionButton>
      <OptionButton id="24months" value="24">
        24 months
      </OptionButton>
      <OptionButton id="36months" value="36">
        36 months
      </OptionButton>
    </OptionButtonGroup>
  );
};

storiesOf(`${Sections.CORE}|OptionButtonGroup`, module).add('Default', () => <OptionButtonGroupDemo />);
