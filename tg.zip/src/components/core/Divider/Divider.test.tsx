import React from 'react';
import { render } from 'test-utils';
import RouterMock from '@src/test/RouterMock';
import Divider, { DividerProps } from './Divider';

const defaultProps: DividerProps = {};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(
    <RouterMock>
      <Divider {...props} />
    </RouterMock>,
  );
  return { utils, props };
};

describe('Divider', () => {
  it('should render the divider', () => {
    const { utils } = setup();
    utils.getByTestId('divider');
  });
});
