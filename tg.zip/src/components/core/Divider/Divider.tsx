import React from 'react';
import { Divider as StyledDivider } from './Divider.styles';

export interface DividerProps {
  prop?: string;
}

const Divider: React.FC<DividerProps> = () => <StyledDivider data-testid="divider" />;

export default Divider;
