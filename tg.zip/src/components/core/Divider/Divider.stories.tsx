import React from 'react';
import { storiesOf } from '@storybook/react';
import Section from '@src/components/core/Section';
import { Sections } from '@src/lib/constants/storybook';
import Divider from './Divider';

storiesOf(`${Sections.CORE}|Divider`, module).add('default', () => (
  <Section>
    <Divider />
  </Section>
));
