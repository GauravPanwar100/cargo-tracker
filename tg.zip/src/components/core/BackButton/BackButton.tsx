import { kebabCase } from 'lodash';
import React, { useCallback } from 'react';
import Link from 'next/link';
import Router from 'next/router';
import { BackCaret } from '@src/assets/base64/icons-system';
import { Grid, GridCol } from '@src/components/core/Grid';
import { trackEvent } from '@src/lib/tracking';
import IconWrapper from '@src/components/core/IconWrapper';
import { ReactComponent as UpliftedBackIcon } from '@src/assets/svg/chevron-left.svg';
import { useUpliftDataContent } from '@src/lib/context/uplift-data-provider';
import { Button, ContainerInner, ContainerOuter, Icon, UpliftedBackButton } from './BackButton.styles';

export interface BackButtonProps {
  as?: string;
  href?: string;
  onClick?: React.MouseEventHandler;
}

const BackButton: React.FC<BackButtonProps> = ({ as, children, href, onClick: externalOnClick, ...props }) => {
  const upliftEnabled = useUpliftDataContent();
  const onClick: React.MouseEventHandler<HTMLElement> = useCallback(
    (e) => {
      if (externalOnClick) {
        externalOnClick(e);
      } else if (!href) {
        Router.back();
      }
      trackEvent({
        pageEventAttributeOne: kebabCase(e.currentTarget.innerText),
        pageEventType: 'breadcrumb',
        pageEventValue: 'back',
      });
    },
    [externalOnClick, href],
  );

  let content = (
    <Button onClick={onClick} {...props}>
      <Icon role="presentation" src={BackCaret} />
      {children}
    </Button>
  );

  if (href) {
    content = (
      <Link as={as} href={href} passHref={true} replace={true}>
        {upliftEnabled ? (
          <UpliftedBackButton as="a" data-testid="back-button-a" onClick={onClick} {...props}>
            <IconWrapper color="white" svg={UpliftedBackIcon} width="32px" height="32px" marginRight={{ xs: '5px' }} />
            {children}
          </UpliftedBackButton>
        ) : (
          <Button as="a" data-testid="back-button-a" onClick={onClick} {...props}>
            <Icon role="presentation" src={BackCaret} />
            {children}
          </Button>
        )}
      </Link>
    );
  }

  return (
    <ContainerOuter upliftEnabled={upliftEnabled}>
      <Grid>
        <GridCol>
          <ContainerInner upliftEnabled={upliftEnabled}>{content}</ContainerInner>
        </GridCol>
      </Grid>
    </ContainerOuter>
  );
};

export default BackButton;
