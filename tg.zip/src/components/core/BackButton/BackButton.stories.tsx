import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import BackButton from './BackButton';

const Demo = () => <BackButton>Back to home</BackButton>;

storiesOf(`${Sections.CORE}|BackButton`, module).add('Default', () => <Demo />);
