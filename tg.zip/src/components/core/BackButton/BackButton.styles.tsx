import styled, { css } from 'styled-components';
import { buttonReset, focusOutline, fontLineHeightSize, media } from '@src/lib/util/mixins';

export const ContainerOuter = styled.div<{ upliftEnabled?: boolean }>`
  background-color: ${(p) => p.theme.colors.lightGrey};
  ${({ upliftEnabled }) =>
    upliftEnabled
      ? css`
          padding-top: 32px;
        `
      : css`
          border-top: 1px solid ${(p) => p.theme.colors.silver};
          border-bottom: 1px solid ${(p) => p.theme.colors.silver};
        `}
`;

export const ContainerInner = styled.div<{ upliftEnabled?: boolean }>`
  display: flex;
  align-items: center;
  height: 52px;

  ${media.m`
    height: 64px;
  `}

  ${({ upliftEnabled }) =>
    upliftEnabled &&
    css`
      height: 32px;
      ${media.m`
        height: 32px;
      `}
    `}
`;

export const Button = styled.button`
  ${buttonReset}
  height: 100%;
  display: flex;
  align-items: center;
  padding: 0 6px;
  ${fontLineHeightSize('base')}
  font-family: ${(p) => p.theme.fonts.regular};
  color: ${(p) => p.theme.colors.mainColor};
  cursor: pointer;
  text-decoration: none;

  &:hover {
    color: ${(p) => p.theme.colors.red};
    text-decoration: underline;
  }

  &:focus {
    ${focusOutline()}
  }

  ${media.m`
    ${fontLineHeightSize('baseLarge')}
  `}
`;

export const UpliftedBackButton = styled(Button)`
  color: ${(p) => p.theme.colors.aluminium};

  &:hover {
    color: ${(p) => p.theme.colors.aluminium};
  }
`;

export const Icon = styled.img`
  width: 32px;
  height: 32px;
  color: ${(p) => p.theme.colors.darkGrey};
  margin-right: 5px;
`;
