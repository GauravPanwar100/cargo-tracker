import React from 'react';
import { render } from 'test-utils';
import BackButton, { BackButtonProps } from './BackButton';

const defaultProps: BackButtonProps = {};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<BackButton {...props}>Button text</BackButton>);
  return { utils, props };
};

describe('BackButton', () => {
  it('should be rendered', () => {
    const { utils } = setup();
    utils.getByText('Button text');
  });

  it('should render a link when href is passed', () => {
    const { utils } = setup({ href: '/phones' });
    const anchorButton = utils.getByTestId('back-button-a') as HTMLAnchorElement;
    expect(anchorButton.href.split('/').pop()).toBe('phones');
  });
});
