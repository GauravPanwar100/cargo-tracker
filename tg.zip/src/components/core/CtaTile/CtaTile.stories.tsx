import React from 'react';
import { storiesOf } from '@storybook/react';
import { ThemeProvider } from 'styled-components';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import { CtaItem } from '@src/lib/api/types';
import { Sections } from '@src/lib/constants/storybook';
import { midTheme } from '@src/lib/theme';
import CtaTile from './CtaTile';

const tiles: CtaItem[] = [
  {
    ctaLabel: 'Upgrade your phone',
    ctaUrl: '#',
    description: 'Get a new phone online today with an interest-free repayment period of 12, 24 or 36 months.',
    imageUrl: '',
    title: 'Get a new phone',
  },
  {
    ctaLabel: 'Upgrade your plan',
    ctaUrl: '#',
    description: 'Our SIM Only Plans are perfect to use with a phone that you love.',
    imageUrl: '',
    title: 'Get a new SIM Only Plan',
  },
];

storiesOf(`${Sections.CORE}|CtaTile`, module).add('default', () => (
  <ThemeProvider theme={midTheme}>
    <Section>
      <Grid>
        {tiles.map((tile) => (
          <GridCol key={tile.title} gridColSpan={{ xs: 12, m: 6 }}>
            <CtaTile content={tile} />
          </GridCol>
        ))}
      </Grid>
    </Section>
  </ThemeProvider>
));
