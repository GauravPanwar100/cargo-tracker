export { default } from './CtaTile';
