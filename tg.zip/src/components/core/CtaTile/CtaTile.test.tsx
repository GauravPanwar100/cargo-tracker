import React from 'react';
import { render } from 'test-utils';
import RouterMock from '@src/test/RouterMock';
import { CtaItem } from '@src/lib/api/types';
import CtaTile, { CtaTileProps } from './CtaTile';

const content: CtaItem = {
  ctaLabel: 'label',
  ctaUrl: 'url',
  description: 'description',
  imageUrl: 'image',
  title: 'title',
};

const defaultProps: CtaTileProps = {
  content,
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(
    <RouterMock>
      <CtaTile {...props} />
    </RouterMock>,
  );
  return { utils, props };
};

describe('CtaTile', () => {
  it('Should render all the elements of the CtaTile', () => {
    const { utils } = setup();
    utils.getByTestId('quick-link-image');
    utils.getByTestId('cta-tile-title');
    utils.getByTestId('cta-tile-description');
    utils.getByTestId('cta-tile-button');
  });
});
