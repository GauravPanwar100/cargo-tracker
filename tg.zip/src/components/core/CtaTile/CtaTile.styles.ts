import styled from 'styled-components';
import { cardFoundation, media } from '@src/lib/util/mixins';

export const Container = styled.div`
  ${cardFoundation}
  display: grid;
  height: 100%;
  padding: 20px 16px;
  grid-template-areas:
    'icon content'
    'action action';
  grid-template-columns: auto 1fr;

  ${media.m`
    padding: 20px 40px 28px 20px;
    grid-template-areas: 
      "icon content"
      ". action"
    ;
  `}
`;

export const IconContainer = styled.div`
  grid-area: icon;
  margin-right: 16px;

  ${media.m`
    margin-right: 20px;
  `}
`;

export const ContentContainer = styled.div`
  grid-area: content;
`;

export const ActionContainer = styled.div`
  grid-area: action;
  margin-top: 20px;
  align-self: end;
`;
