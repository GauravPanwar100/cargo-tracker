import React from 'react';
import Image from '@src/components/core/Image';
import Text from '@src/components/core/Text';
import { CtaItem } from '@src/lib/api/types';
import RichText from '@src/components/core/RichText/RichText';
import { ActionContainer, Container, ContentContainer, IconContainer } from './CtaTile.styles';
import { LinkButton } from '../Button';

export interface CtaTileProps {
  content: CtaItem;
  onClickLink?: React.MouseEventHandler<HTMLAnchorElement>;
}

const CtaTile: React.FC<CtaTileProps> = ({ content, onClickLink }) => (
  <Container>
    <IconContainer>
      <Image
        alt=""
        data-testid="quick-link-image"
        desktopImageUrl={content.imageUrl}
        height="60px"
        role="presentation"
        width="60px"
      />
    </IconContainer>
    <ContentContainer>
      <Text
        as="h5"
        fontFamily="bold"
        marginBottom={content.description ? { xs: '4px', m: '8px' } : null}
        data-testid="cta-tile-title"
      >
        {content.title}
      </Text>
      {content.description && (
        <Text
          fontSize={{ xs: 'base', m: 'baseLarge' }}
          lineHeight={{ xs: 'base', m: 'baseLarge' }}
          data-testid="cta-tile-description"
        >
          <RichText>{content.description}</RichText>
        </Text>
      )}
    </ContentContainer>
    <ActionContainer>
      <LinkButton href={content.ctaUrl} onClick={onClickLink} data-testid="cta-tile-button">
        {content.ctaLabel}
      </LinkButton>
    </ActionContainer>
  </Container>
);

export default CtaTile;
