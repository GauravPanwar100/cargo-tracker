/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-param-reassign */
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';

const withIcon = (Component: any) => {
  Component.DataUri = ({ width = 24, height = 24, color = 'currentColor', ...props }) =>
    encodeURIComponent(renderToStaticMarkup(<Component width={width} height={height} color={color} {...props} />));
  Component.CssBackground = (props: any) => `data:image/svg+xml;charset=utf8,${Component.DataUri(props)}`;
  return Component;
};
export default withIcon;
