export interface IconProps {
  width?: number;
  heights?: number;
  disabled?: boolean;
  strokeWidth?: number;
  viewBox?: string;
  opacity?: number;
  onClickHandler?: Function;
}
