import React from 'react';
import styled from 'styled-components';

import { IconProps } from './type';
import withIcon from './withIcon';

export const SVG = styled.svg`
  enable-background: new 0 0 129.2 129.2;
`;

export const Path = styled.path`
  fill: #999999;
`;

const IconCrossOutline = (props: IconProps) => (
  <SVG
    version="1.1"
    id="Layer_3"
    xmlns="http://www.w3.org/2000/svg"
    x="0px"
    y="0px"
    viewBox="0 0 129.2 129.2"
    {...props}
  >
    <Path
      d="M64.6,2.4C30.3,2.4,2.4,30.3,2.4,64.6s27.8,62.2,62.2,62.2s62.2-27.8,62.2-62.2S98.9,2.4,64.6,2.4z M97.4,93.8
	c1,1,1,2.7,0,3.7c-0.5,0.5-1.2,0.8-1.8,0.8s-1.3-0.2-1.8-0.8L64.6,68.3L35.4,97.4c-0.5,0.5-1.2,0.8-1.8,0.8s-1.3-0.2-1.8-0.8
	c-1-1-1-2.7,0-3.7l29.2-29.2L31.8,35.4c-1-1-1-2.7,0-3.7c1-1,2.7-1,3.7,0l29.2,29.2l29.2-29.2c1-1,2.7-1,3.7,0c1,1,1,2.7,0,3.7
	L68.3,64.6L97.4,93.8z"
    />
  </SVG>
);

export default withIcon(IconCrossOutline);
