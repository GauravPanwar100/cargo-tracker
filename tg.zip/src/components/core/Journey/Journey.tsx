import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ParsedQuery } from 'query-string';
import { useRouteMeta } from '@src/lib/context/route-meta';
import { useStickyCart } from '@src/lib/context/sticky-cart';
import { QueryKey } from '@src/lib/util/query';
import { RouterMethod, safeWindowLocationReplace, useNextQuery, useUpdateQuery } from '@src/lib/util/router';
import { BasketRequestItem } from '@src/lib/api/types';
import usePrevious from '@src/lib/hooks/use-previous';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import NewRelic from '@src/lib/tracking/newRelic';
import { ERROR_PAGE_URL } from '@src/lib/util/error';
import { useCustomerData } from '@src/lib/context/customer-data';
import useBnsOffer from '@src/lib/hooks/use-bns-offer';
import JourneyStep from './JourneyStep';
import { JourneyStepCompletionParams, JourneyStepProps } from './JourneyStep/JourneyStep';

interface JourneyProps {
  children: React.ReactNode[];
}

type JourneyStepElement = React.ReactElement<JourneyStepProps>;

function assertIsValidJourneyStep(node: React.ReactNode): asserts node is JourneyStepElement {
  if (!React.isValidElement<JourneyStepProps>(node) || node.type !== JourneyStep) {
    throw new Error('Journey must have JourneyStep components as children');
  }
}

const mapSteps = (children: React.ReactNode[]): JourneyStepElement[] =>
  React.Children.toArray(children).map((child) => {
    assertIsValidJourneyStep(child);
    return child;
  });

const getValidSteps = (steps: JourneyStepElement[], query: ParsedQuery): JourneyStepElement[] => {
  const firstInvalidStep = steps.findIndex((step) => {
    const { validateQuery } = step.props;
    if (!validateQuery) {
      return false;
    }

    return validateQuery.some((queryKey) => !query[queryKey]);
  });

  // No invalid steps were found, return all steps
  if (firstInvalidStep === -1) {
    return [...steps];
  }

  // If even the first step is invalid, just return the first step as the only item so we can reset the journey
  if (firstInvalidStep === 0) {
    return steps.slice(0, 1);
  }

  // Array.slice extracts up to but not including `end` -- so we get everything before the first invalid step
  return steps.slice(0, firstInvalidStep);
};

const Journey: React.FC<JourneyProps> = ({ children }) => {
  const query = useNextQuery();
  const updateQuery = useUpdateQuery();

  const [{ stickyCart }, stickyCartDispatch] = useStickyCart();
  const stickyCartRef = useRef<BasketRequestItem[]>(stickyCart);
  stickyCartRef.current = stickyCart;

  const { setJourneyUpdating, routeChangeInProgress } = useRouteMeta();

  const steps: JourneyStepElement[] = mapSteps(children);
  if (!steps.length) {
    throw new Error('Journey must have at least one JourneyStep component as children');
  }

  const [currentStep, setCurrentStep] = useState<JourneyStepProps>(steps[0].props);

  const { customerBundleAndSaveCount } = useCustomerData();

  const bnsOffer = useBnsOffer();

  const updateStepQuery = useCallback(
    (step: number, routerMethod: RouterMethod) =>
      updateQuery({ [QueryKey.JOURNEY_STEP]: step ? `${step}` : undefined }, routerMethod),
    [updateQuery],
  );

  const goToNextStep = useCallback(
    async (params?: JourneyStepCompletionParams) => {
      const { onBeforeGoToNextStep, step, updateQueryOnNextStep } = currentStep;

      let nextStep = step + 1;

      if (onBeforeGoToNextStep && params) {
        const nextStepResult = await onBeforeGoToNextStep(params, customerBundleAndSaveCount);
        if (typeof nextStepResult === 'boolean' && !nextStepResult) {
          return false;
        }
        if (typeof nextStepResult === 'number') {
          new Array(nextStepResult - nextStep).fill(0).forEach((_, i) => {
            const stepBeingSkipped = step + (i + 1);
            stickyCartDispatch({
              type: 'COMMIT_TO_HISTORY',
              payload: {
                items: params?.items,
                historyType: 'original',
                step: stepBeingSkipped,
              },
            });

            stickyCartDispatch({
              type: 'COMMIT_TO_HISTORY',
              payload: {
                items: params?.items,
                historyType: 'configured',
                step: stepBeingSkipped,
              },
            });
          });
          nextStep = nextStepResult;
        }
      }

      if (updateQueryOnNextStep) {
        const newQuery = updateQueryOnNextStep(params?.items);
        await updateQuery(newQuery, 'replace');
      }
      return updateStepQuery(nextStep, 'push');
    },
    [currentStep, customerBundleAndSaveCount, stickyCartDispatch, updateQuery, updateStepQuery],
  );

  const goToPreviousStep = useCallback(async () => {
    const { onBeforeGoToPreviousStep, step } = currentStep;
    let originalStep = step - 1;

    if (onBeforeGoToPreviousStep) {
      const previousStepResult = onBeforeGoToPreviousStep();
      if (typeof previousStepResult === 'boolean' && !previousStepResult) {
        return;
      }
      if (typeof previousStepResult === 'number') {
        originalStep = previousStepResult;
      }
    }
    updateStepQuery(originalStep, 'replace');
  }, [currentStep, updateStepQuery]);

  const [hasInitialised, setHasInitialised] = useState<boolean>(false);
  const [isLoadingStep, setIsLoadingStep] = useState<boolean>(false);
  const [isBuildingCartFromQuery, setIsBuildingCartFromQuery] = useState<boolean>(false);
  const [isBnsOfferApplied, setIsBnsOfferApplied] = useState<boolean>(false);

  useEffect(() => {
    setJourneyUpdating(isLoadingStep);
  }, [isLoadingStep, setJourneyUpdating]);

  const buildStepCartFromQuery = useCallback(
    async (stepProps: JourneyStepProps, baseCart?: BasketRequestItem[] | undefined) => {
      const { buildCartFromQuery } = stepProps;

      if (!buildCartFromQuery) return baseCart;

      const cart = await buildCartFromQuery(baseCart, bnsOffer);

      const { isInterimStep, step } = stepProps;

      // Set the configured cart for the previous step
      if (step > 0) {
        stickyCartDispatch({
          type: 'SET_STICKY_CART',
          payload: {
            items: cart,
            history: {
              historyType: 'configured',
              step: step - 1,
            },
          },
        });
      }

      // Set the original cart for the current step
      stickyCartDispatch({
        type: 'SET_STICKY_CART',
        payload: {
          items: cart,
          history: {
            historyType: 'original',
            step,
          },
        },
      });

      // Set the configured cart for the current step if it is an interim step (device listing in planled)
      if (isInterimStep) {
        stickyCartDispatch({
          type: 'COMMIT_TO_HISTORY',
          payload: {
            items: cart,
            historyType: 'configured',
            step,
          },
        });
      }

      return cart;
    },
    [bnsOffer, stickyCartDispatch],
  );

  const stepQuery = query?.[QueryKey.JOURNEY_STEP];
  useEffect(() => {
    const updateCurrentStep = async () => {
      if (query === null) return;

      const stepString = (query[QueryKey.JOURNEY_STEP] ?? '0') as string;
      const stepNumber = Number(stepString);

      if (Number.isNaN(stepNumber)) {
        await updateStepQuery(0, 'replace');
        return;
      }

      // Extract everything up to the current step number from our array of total steps
      const currentAndPreviousSteps = steps.slice(0, stepNumber + 1);
      // Extract up to the furthest valid step, based on whether all of the required query params for each
      // step are present in the query
      const validSteps = getValidSteps(currentAndPreviousSteps, query);
      // If there are less valid steps than the step we're trying to navigate to, navigate to the furthest
      // possible valid step. i.e. if there is a ?step=2 in the URL, but the furthest step with all of its
      // required query params in the URL is step 1, then force a navigation to step 1
      if (validSteps.length < currentAndPreviousSteps.length) {
        const furthestValidStep = validSteps[validSteps.length - 1];
        await updateStepQuery(furthestValidStep.props.step, 'replace');
        return;
      }

      if (!hasInitialised || !isBnsOfferApplied) {
        let items: BasketRequestItem[] | undefined;
        // eslint-disable-next-line no-restricted-syntax -- for..of syntax is only way to await in a loop
        for (const element of validSteps) {
          setIsBuildingCartFromQuery(true);
          // eslint-disable-next-line no-await-in-loop -- each call to buildCartFromQuery is dependent on the previous so we want to run in series
          items = await buildStepCartFromQuery(element.props, items);
        }
      }

      if (bnsOffer.plans.length > 0) {
        setIsBnsOfferApplied(true);
      }

      if (stepNumber < currentStep.step) {
        const { queryKeysToClearOnPreviousStep } = currentStep;
        if (queryKeysToClearOnPreviousStep?.length) {
          const clearedQuery: Partial<Record<QueryKey, undefined>> = Object.fromEntries(
            queryKeysToClearOnPreviousStep.map((key) => [key, undefined]),
          );
          updateQuery(clearedQuery, 'replace');
        }
      }

      const stepElement = validSteps[stepNumber];
      if (!stepElement) {
        return;
      }

      const { getInitialProps } = stepElement.props;

      if (!getInitialProps) {
        setCurrentStep(stepElement.props);
        setHasInitialised(true);
        setIsBuildingCartFromQuery(false);
        return;
      }

      setIsLoadingStep(true);
      const initialProps = await getInitialProps(stickyCartRef.current);
      setIsLoadingStep(false);

      setCurrentStep({
        ...stepElement.props,
        initialProps,
      });
      setHasInitialised(true);
      setIsBuildingCartFromQuery(false);
    };

    const runUpdate = async () => {
      try {
        await updateCurrentStep();
      } catch (error) {
        safeWindowLocationReplace(ERROR_PAGE_URL);
      }
    };

    runUpdate();

    // eslint-disable-next-line react-hooks/exhaustive-deps -- Only want to run when the step query param changes
  }, [stepQuery, bnsOffer.plans.length]);

  const previousStep = usePrevious(currentStep.step);
  useEffect(() => {
    NewRelic.setCurrentRouteName(window.location.href);
    if (typeof previousStep !== 'undefined' && previousStep > currentStep.step) {
      return;
    }
    routeChangeInProgress.current = true;
    window.scrollTo(0, 0);
    setTimeout(() => {
      routeChangeInProgress.current = false;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps -- Only want to run when step changes
  }, [currentStep.step]);

  const currentStepElement = steps[currentStep.step];

  if (!currentStepElement) {
    return null;
  }

  const enhancedCurrentStepElement = React.cloneElement(currentStepElement, {
    ...currentStep,
    goToNextStep,
    goToPreviousStep,
    hasInitialised,
    isLoadingStep,
    stickyCart,
    bnsOffer,
  });

  return isBuildingCartFromQuery ? <SpinnerSection /> : enhancedCurrentStepElement;
};

export default Journey;
