import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import CheckoutHeaderEU from './CheckoutHeaderEU';

storiesOf(`${Sections.CORE}|CheckoutHeaderEU`, module).add('default', () => <CheckoutHeaderEU headerEU="upgrade" />);
