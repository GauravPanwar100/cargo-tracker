import React from 'react';
import { render } from 'test-utils';
import RouterMock from '@src/test/RouterMock';
import CheckoutHeaderEU from './CheckoutHeaderEU';

const setup = (extraProps = { headerEU: 'upgrade' }) => {
  const props = { ...extraProps };
  const utils = render(
    <RouterMock>
      <CheckoutHeaderEU {...props} />
    </RouterMock>,
  );
  return { utils, props };
};

describe('CheckoutHeaderEU', () => {
  it('should render CheckoutHeaderEU', () => {
    const { utils } = setup();
    utils.getByText('Secure upgrade');
    utils.getByText('Secure page');
  });
});
