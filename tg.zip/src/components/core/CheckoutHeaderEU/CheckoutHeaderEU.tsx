import React from 'react';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import IconWrapper from '@src/components/core/IconWrapper';
import { ReactComponent as LogoIcon } from '@src/assets/svg/logo.svg';
import {
  ContainerInner,
  ContainerOuter,
  LeftContainer,
  PadlockIcon,
  PadlockText,
  RightContainer,
  Title,
} from '@src/components/core/CheckoutHeader/CheckoutHeader.styles';

type props = {
  headerEU: string;
  hidePresetHeaderBefore?: boolean;
};
const CheckoutHeaderEU = ({ headerEU, hidePresetHeaderBefore }: props) => (
  <ContainerOuter>
    <Section spacingBottom={null} spacingTop={null}>
      <Grid>
        <GridCol>
          <ContainerInner>
            <LeftContainer data-testid="logo-icon">
              <IconWrapper
                svg={LogoIcon}
                height={{ xs: '32px', l: '48px' }}
                width={{ xs: '32px', l: '48px' }}
                marginRight={{ xs: '20px', l: '32px' }}
              />
              <Title data-testid="upgrade-header-eu">{hidePresetHeaderBefore ? headerEU : `Secure ${headerEU}`}</Title>
            </LeftContainer>
            <RightContainer>
              <PadlockIcon data-testid="padlock-icon" />
              <PadlockText data-testid="secure-page-header">Secure page</PadlockText>
            </RightContainer>
          </ContainerInner>
        </GridCol>
      </Grid>
    </Section>
  </ContainerOuter>
);

export default CheckoutHeaderEU;
