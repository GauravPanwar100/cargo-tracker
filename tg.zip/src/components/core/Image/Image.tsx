import React from 'react';
import { breakpoints } from '@src/lib/theme';
import { MixinProperty } from '@src/lib/util/mixins';
import { Image as StyledImage } from './Image.styles';

type ImageProps = {
  alt: string;
  desktopImageUrl: string;
  height?: MixinProperty;
  loading?: 'eager' | 'lazy';
  marginBottom?: MixinProperty;
  marginLeft?: MixinProperty;
  marginRight?: MixinProperty;
  marginTop?: MixinProperty;
  mobileImageUrl?: string;
  objectFit?: MixinProperty;
  width?: MixinProperty;
} & Omit<JSX.IntrinsicElements['img'], 'height' | 'ref' | 'width'>;

const Image: React.FC<ImageProps> = ({
  alt,
  desktopImageUrl,
  height,
  loading = 'lazy',
  marginBottom,
  marginLeft,
  marginRight,
  marginTop,
  mobileImageUrl,
  objectFit,
  width,
  ...props
}) => (
  <picture>
    {mobileImageUrl && (
      <>
        <source srcSet={`${mobileImageUrl} ${breakpoints.s}w, ${desktopImageUrl}`} />
      </>
    )}
    <StyledImage
      alt={alt}
      data-testid="image"
      h={height}
      loading={loading}
      marginBottom={marginBottom}
      marginLeft={marginLeft}
      marginRight={marginRight}
      marginTop={marginTop}
      objectFit={objectFit}
      src={desktopImageUrl}
      w={width}
      {...props}
    />
  </picture>
);

export default Image;
