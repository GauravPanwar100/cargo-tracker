import styled from 'styled-components';
import {
  MixinProperty,
  heightMixin,
  marginBottomMixin,
  marginLeftMixin,
  marginRightMixin,
  marginTopMixin,
  objectFitMixin,
  widthMixin,
} from '@src/lib/util/mixins';

interface ImageProps {
  h?: MixinProperty;
  marginBottom?: MixinProperty;
  marginLeft?: MixinProperty;
  marginRight?: MixinProperty;
  marginTop?: MixinProperty;
  objectFit?: MixinProperty;
  w?: MixinProperty;
}
export const Image = styled.img<ImageProps>`
  display: block;
  max-width: 100%;
  ${(p) => heightMixin(p.h)}
  ${(p) => widthMixin(p.w)}
  ${(p) => marginBottomMixin(p.marginBottom)}
  ${(p) => marginLeftMixin(p.marginLeft)}
  ${(p) => marginRightMixin(p.marginRight)}
  ${(p) => marginTopMixin(p.marginTop)}
  ${(p) => objectFitMixin(p.objectFit)}
`;
