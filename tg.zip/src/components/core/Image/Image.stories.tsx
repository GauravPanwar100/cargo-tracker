import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import Image from './Image';

storiesOf(`${Sections.CORE}|Image`, module).add('Responsive desktop & mobile images', () => (
  <Image
    mobileImageUrl="https://webkit.org/demos/srcset/image-1x.png"
    desktopImageUrl="https://webkit.org/demos/srcset/image-2x.png"
    alt="example"
  />
));

storiesOf(`${Sections.CORE}|Image`, module).add('Responsive with specified height + width', () => (
  <Image
    mobileImageUrl="https://webkit.org/demos/srcset/image-1x.png"
    desktopImageUrl="https://webkit.org/demos/srcset/image-2x.png"
    alt="example"
    height="400px"
    width="auto"
  />
));

storiesOf(`${Sections.CORE}|Image`, module).add('No mobile image supplied', () => (
  <Image desktopImageUrl="https://webkit.org/demos/srcset/image-2x.png" alt="example" />
));
