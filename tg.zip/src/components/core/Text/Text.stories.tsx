import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import Text from './Text';

storiesOf(`${Sections.CORE}|Text`, module).add('default', () => (
  <>
    <Text fontSize="baseSmall" marginBottom="8px">
      This is some baseSmall text
    </Text>
    <Text marginBottom="8px">This is some base text without any arguments</Text>
    <Text fontFamily="bold" fontSize="baseLarge" marginBottom="8px">
      This is some baseLarge text with a bold fontFamily
    </Text>
    <Text fontSize={{ xs: 'base', m: 'baseLarge' }} marginBottom="8px">
      This text is base size on mobile and baseLarge on medium screens
    </Text>
  </>
));
