import styled from 'styled-components';
import { ColorKey, FontKey, FontSizeKey, LineHeightKey } from '@src/lib/theme';
import {
  MixinProperty,
  alignItemsMixin,
  backgroundColorMixin,
  colorMixin,
  displayMixin,
  flexDirectionMixin,
  fontFamilyMixin,
  fontSizeMixin,
  justifyContentMixin,
  lineHeightMixin,
  marginBottomMixin,
  marginLeftMixin,
  marginRightMixin,
  marginTopMixin,
  textAlignMixin,
  variantThemeLinkColors,
} from '@src/lib/util/mixins';

export interface StyledTextProps {
  $color?: MixinProperty<ColorKey>;
  display?: MixinProperty;
  fontFamily?: MixinProperty<FontKey>;
  fontSize?: MixinProperty<FontSizeKey>;
  lineHeight?: MixinProperty<LineHeightKey>;
  marginBottom?: MixinProperty;
  marginLeft?: MixinProperty;
  marginRight?: MixinProperty;
  marginTop?: MixinProperty;
  textAlign?: MixinProperty;
  alignItems?: MixinProperty;
  justifyContent?: MixinProperty;
  flexDirection?: MixinProperty;
  backgroundColorValue?: MixinProperty<ColorKey>;
  gridArea?: React.CSSProperties['gridArea'];
  verticalAlign?: React.CSSProperties['verticalAlign'];
  fontWeight?: React.CSSProperties['fontWeight'];
}

export const StyledText = styled.div<StyledTextProps>`
  ${(p) => displayMixin(p.display)}
  ${(p) => colorMixin(p.$color)}
  ${variantThemeLinkColors}
  ${(p) => fontSizeMixin(p.fontSize)}
  ${(p) => lineHeightMixin(p.lineHeight)}
  ${(p) => fontFamilyMixin(p.fontFamily)}
  ${(p) => marginBottomMixin(p.marginBottom)}
  ${(p) => marginLeftMixin(p.marginLeft)}
  ${(p) => marginRightMixin(p.marginRight)}
  ${(p) => marginTopMixin(p.marginTop)}
  ${(p) => textAlignMixin(p.textAlign)}
  ${(p) => alignItemsMixin(p.alignItems)}
  ${(p) => justifyContentMixin(p.justifyContent)}
  ${(p) => flexDirectionMixin(p.flexDirection)}
  ${(p) => backgroundColorMixin(p.backgroundColorValue)}
  grid-area: ${(p) => p.gridArea};
  vertical-align: ${(p) => p.verticalAlign};
  font-weight: ${(p) => p.fontWeight};

  a {
    text-decoration: underline;
  }
`;
