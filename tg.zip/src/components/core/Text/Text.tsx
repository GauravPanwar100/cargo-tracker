export { StyledText as default } from './Text.styles';
