import React, { useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import tinydate from 'tinydate';
import { fontLineHeightSize, media } from '@src/lib/util/mixins';
import { useRouter } from 'next/router';
import DayPickerInput from 'react-day-picker/DayPickerInput';
import { previewGetOptionalDate } from '@src/lib/util/preview';
import { getApiClient } from '@src/lib/api';
import { safeRouterPush } from '@src/lib/util/router';
import Button from '../Button';
import Select from '../Select';
import Field from '../Field';
import { Accordion, AccordionItem } from '../Accordion';

const PreviewMode = () => {
  const router = useRouter();
  const [previewDate, setPreviewDate] = useState<string | undefined>(undefined);
  const [buttonText, setButtonText] = useState<string>('Copy link');
  const [disableUpdate, setDisableUpdate] = useState<boolean>(true);

  const [date, setDate] = useState<Date>(new Date());
  const onDayChange = useCallback((day: Date) => {
    setDate(day);
    setDisableUpdate(false);
  }, []);

  const [time, setTime] = useState<string>(timeMatch());
  const onChangeTime = useCallback((event: React.ChangeEvent<HTMLSelectElement>) => {
    setTime(event.currentTarget.value);
    setDisableUpdate(false);
  }, []);

  const [timezone, setTimezone] = useState<string>(timezoneMatch());
  const onChangeTimezone = useCallback((event: React.ChangeEvent<HTMLSelectElement>) => {
    setTimezone(event.currentTarget.value);
    setDisableUpdate(false);
  }, []);

  useEffect(() => {
    const timezoneOffset = timezones.find(({ name }) => name === timezone)?.offset;
    if (timezoneOffset) {
      const encodedPreviewDate = encodeURIComponent(`${formatISODate(date)}T${time}${timezoneOffset}`);
      setPreviewDate(encodedPreviewDate);
    }
  }, [date, time, timezone]);

  // Use previewDate query parameter on page load
  useEffect(() => {
    const queryDate = previewGetOptionalDate(router.query); // Get the preview date from the query
    if (queryDate !== undefined) {
      setPreviewDate(queryDate);
      getApiClient().setPreviewDate(queryDate);

      const decodedPreviewDate = decodeURIComponent(queryDate);
      setDate(new Date(decodedPreviewDate));
      setTime(decodedPreviewDate.substring(11, 16));
      const timezoneOffset = decodedPreviewDate.substring(16);
      const timezoneName = timezones.find(({ offset }) => offset === timezoneOffset)?.name;
      if (timezoneName) {
        setTimezone(timezoneName);
      }
    }
  }, [router.query]);

  const handleOnClickCopy = () => {
    const baseUrl = window.location.host + router.asPath;
    const previewUrl = getPreviewUrl({ baseUrl, previewDate });

    navigator.clipboard.writeText(previewUrl);

    setButtonText('Copied!');
    setTimeout(() => {
      setButtonText('Copy link');
    }, 1500);
  };

  const handleOnClickUpdate = () => {
    const baseUrl = window.location.host + router.asPath;
    const previewUrlWithoutHost = getPreviewUrl({ baseUrl, previewDate }).replace(window.location.host, '');

    safeRouterPush(previewUrlWithoutHost).then(() => {
      setDisableUpdate(true);
      router.reload(); // not all pages show correctly without reload, ex: device details announcement phase
    });
  };

  return (
    <Root>
      <Accordion allowOverflow={true}>
        <AccordionItem hasContentPadding={false} defaultIsOpen={true} title="Preview">
          <Label>
            <Field id="date" label="Date">
              <DayPickerInputWrapper>
                <DayPickerInput
                  formatDate={formatDate}
                  onDayChange={onDayChange}
                  parseDate={parseDate}
                  placeholder="DD/MM/YYYY"
                  value={date}
                />
              </DayPickerInputWrapper>
            </Field>
            <Select
              id="time"
              label="Time"
              showDefaultOption={false}
              onChange={onChangeTime}
              value={time}
              fullWidth={true}
            >
              {times.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </Select>
            <Select
              id="timezone"
              label="Timezone"
              showDefaultOption={false}
              onChange={onChangeTimezone}
              value={timezone}
              fullWidth={true}
            >
              {timezones.map(({ name }) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </Select>
            <ButtonContainer>
              <Button onClick={handleOnClickCopy} fullWidth={true}>
                {buttonText}
              </Button>
              <Button onClick={handleOnClickUpdate} disabled={disableUpdate} fullWidth={true}>
                Update
              </Button>
            </ButtonContainer>
          </Label>
        </AccordionItem>
      </Accordion>
    </Root>
  );
};

/*
 * Get a sharable full url, including preview date query parameter
 */
function getPreviewUrl({ baseUrl, previewDate }: { baseUrl: string; previewDate?: string }) {
  const [path, query] = baseUrl.split('?');
  if (!query) return `${path}?date=${previewDate}`;

  const queryWithoutDateParam = query
    .split('&')
    .filter((param) => !param.includes('date'))
    .join('&');

  return queryWithoutDateParam ? `${path}?${queryWithoutDateParam}&date=${previewDate}` : `${path}?date=${previewDate}`;
}

/*
 * List of Australian timezones + UTC
 */
const timezones = [
  { offset: '+00:00', offsetInt: 0, name: '+00:00 UTC Coordinated Universal Time' },
  { offset: '+08:00', offsetInt: -480, name: '+08:00 AWST Australian Western' },
  { offset: '+08:45', offsetInt: -525, name: '+08:45 ACWST Australian Central Western' },
  { offset: '+09:30', offsetInt: -570, name: '+09:30 ACST Australian Central Standard' },
  { offset: '+10:00', offsetInt: -600, name: '+10:00 AEST Australian Eastern Standard' },
  { offset: '+10:30', offsetInt: -630, name: '+10:30 ACDT Australian Central Daylight' },
  { offset: '+10:30', offsetInt: -630, name: '+10:30 LHDT Lord Howe Standard' },
  { offset: '+11:00', offsetInt: -660, name: '+11:00 AEDT Australian Eastern Daylight' },
  { offset: '+11:00', offsetInt: -660, name: '+11:00 LHDT Lord Howe Daylight' },
];

/*
 * Get the user's current time to the latest 15 minute interval, as a string with format HH:MM
 */
function timeMatch() {
  const userTime = new Date();
  const userHours = userTime.getHours().toString().padStart(2, '0');
  const userMinutes = (Math.floor(userTime.getMinutes() / 15) * 15).toString().padStart(2, '0');
  return `${userHours}:${userMinutes}`;
}

/*
 * Get the user's current timezone
 * Defaults to UTC if timezone is not in timezone list
 */
function timezoneMatch() {
  const userTimezoneOffset = new Date().getTimezoneOffset();
  const match = timezones.find((tz) => tz.offsetInt === userTimezoneOffset);
  if (!match) return '+00:00 UTC Coordinated Universal Time';
  return match.name;
}

/*
 * Get a list of times for every 15 min in the format HH:MM
 */
const times = [...Array(24 * 4)].map(
  (_, i) =>
    `${Math.floor(i / 4)
      .toString()
      .padStart(2, '0')}:${((i % 4) * 15).toString().padStart(2, '0')}`,
);

/*
 * Formats a Date object to a string like: YYYY-MM-DD
 */
const formatISODate = tinydate('{YYYY}-{MM}-{DD}');

/*
 * Formats a Date object to a string like: DD/MM/YYYY
 */
const formatDate = tinydate('{DD}/{MM}/{YYYY}');

/*
 * Parses a date string like DD/MM/YYYY to a Date object
 */
function parseDate(date: string) {
  if (date.length !== 10) return undefined;

  const [day, month, year] = date.split('/');
  if (day?.length !== 2 || month?.length !== 2 || year?.length !== 4) return undefined;

  const parsedDate = new Date(`${year}-${month}-${day}`);
  if (Number.isNaN(parsedDate.getTime())) return undefined; // check that Date is valid

  return parsedDate;
}

const Label = styled.div`
  ${fontLineHeightSize('button')}
  background: white;
  display: flex;
  flex-direction: column;
  padding: 20px;

  > div {
    margin-bottom: 32px;
  }

  > div:last-of-type {
    margin-bottom: 0;
  }
`;

const Root = styled.div`
  display: flex;
  flex-direction: column;
  position: fixed;
  bottom: 0;
  right: 0;
  padding: 8px;
  z-index: 10;
`;

const ButtonContainer = styled.div`
  display: flex;
  flex-grow: 2;

  > button {
    margin-right: 20px;
  }

  > button:last-of-type {
    margin-right: 0;
  }
`;

const DayPickerInputWrapper = styled.div`
  .DayPickerInput {
    width: 100%;
  }

  .DayPickerInput > input {
    border-radius: ${(p) => p.theme.sizes.borderRadius}px;
    border: 1px solid ${(p) => p.theme.colors.midGrey};
    color: ${(p) => p.theme.colors.greyDark};
    font-family: ${(p) => p.theme.fonts.regular};
    font-size: ${(p) => p.theme.fontSizes.base}px;
    line-height: ${(p) => p.theme.lineHeights.base}px;
    padding: 10px 50px 10px 12px;
    width: 100%;

    &:focus {
      background-position: calc(100% - 5px) calc(100% - 5px);
      border-color: ${(p) => p.theme.colors.focusColor};
      border-width: 2px;
      outline: none;
      padding: 9px 50px 9px 11px;
    }

    ${media.m`
      ${fontLineHeightSize('baseLarge')};
    `}
  }

  .DayPicker-Day--selected:not(.DayPicker-Day--disabled):not(.DayPicker-Day--outside) {
    background-color: ${(p) => p.theme.colors.red};
    color: ${(p) => p.theme.colors.white};

    &:hover {
      background-color: ${(p) => p.theme.colors.darkRed};
    }
  }

  .DayPicker:not(.DayPicker--interactionDisabled)
  .DayPicker-Day:not(.DayPicker-Day--disabled):not(.DayPicker-Day--selected):not(.DayPicker-Day--outside):hover {
    background-color: ${(p) => p.theme.colors.greyLight};
  } 

  .DayPicker-Day {
    border-radius: ${(p) => p.theme.sizes.borderRadius}px;
    padding: 4px 10px;
  }

  .DayPicker-Day--today {
    color: ${(p) => p.theme.colors.red};
  }

  .DayPickerInput-Overlay {
    border-radius: ${(p) => p.theme.sizes.borderRadius}px;
    box-shadow: ${(p) => p.theme.boxShadows.brand};
  }
}
`;

export default PreviewMode;
