import React, { useCallback, useEffect, useState } from 'react';

/**
 * NB: See Select, ChipGroup, OptionButtonGroup for usage examples
 */

export interface CheckboxGroupProps {
  className?: string;
  id: string;
  onChange: (values: string[]) => void;
  name: string;
  value: string[];
}

interface CheckboxChildProps {
  checked?: React.HTMLProps<HTMLInputElement>['checked'];
  name?: React.HTMLProps<HTMLInputElement>['name'];
  onChange?: React.HTMLProps<HTMLInputElement>['onChange'];
  value?: string;
}

export const SELECT_ALL = 'selectAll';

const CheckboxGroup: React.FC<CheckboxGroupProps> = ({ children, className, id, name, onChange, value }) => {
  const [allChildValues, setAllChildValues] = useState<string[]>([]);

  // When the children have been rendered, collect all of the child values in case
  // we want to use a "Select all" button to check all of them
  useEffect(() => {
    const values: string[] = [];

    React.Children.forEach(children, (child) => {
      // Checking that each child has the expected props interface
      if (!React.isValidElement<CheckboxChildProps>(child)) {
        return;
      }

      const {
        props: { value: childValue },
      } = child;

      // Collect all of the child values in a list
      if (childValue && childValue !== SELECT_ALL) {
        values.push(childValue);
      }
    });

    // Save them in state
    setAllChildValues(values);
  }, [children]);

  // This handler is applied onto all checkbox child elements
  const childOnChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      // If the child is being checked, add it to the list of checked values. Otherwise
      // filter it out
      const newValue = event.currentTarget.checked
        ? value.concat(event.currentTarget.value)
        : value.filter((v) => v !== event.currentTarget.value);

      // Notify the parent of the new list of checked values
      onChange(newValue);
    },
    [onChange, value],
  );

  // Sometimes we want to offer a "select all" option in the UI. If this component detects
  // a child with a value matching the SELECT_ALL constant, it will use this change handler
  // instead of the standard one
  const selectAllChildOnChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      // If SELECT_ALL is being checked, add all of the child values to the checked list, else
      // clear them all
      const newValue = event.currentTarget.checked ? [...allChildValues] : [];

      onChange(newValue);
    },
    [allChildValues, onChange],
  );

  const enhancedChildren = React.Children.map(children, (child) => {
    if (!React.isValidElement<CheckboxChildProps>(child)) {
      return child;
    }

    const {
      props: { value: childValue },
    } = child;

    let checked = false;

    if (childValue === SELECT_ALL) {
      checked = allChildValues.every((v) => value.includes(v));
    } else if (childValue && value.includes(childValue)) {
      checked = true;
    }

    return React.cloneElement(child, {
      checked,
      name,
      onChange: childValue === SELECT_ALL ? selectAllChildOnChange : childOnChange,
    });
  });

  return (
    <div className={className} id={id} role="group">
      {enhancedChildren}
    </div>
  );
};

export default CheckboxGroup;
