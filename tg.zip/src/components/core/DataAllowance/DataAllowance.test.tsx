import React from 'react';
import { render } from 'test-utils';
import DataAllowance, { DataAllowanceProps } from './DataAllowance';

jest.mock('@src/lib/context/uplift-data-provider', () => ({
  useUpliftDataContent: jest.fn().mockReturnValue(true),
}));

const defaultProps: DataAllowanceProps = {
  amount: '45',
  label: 'Data Allowance Label',
};

const setup = (extraProps = {}) => {
  const props = { ...defaultProps, ...extraProps };
  const utils = render(<DataAllowance {...props} />);
  return { utils, props };
};

describe('DataAllowance', () => {
  it('should display the amount', () => {
    const { utils } = setup();
    utils.getByText('45');
  });

  it('should display the default unit', () => {
    const { utils } = setup();
    utils.getByText('GB');
  });

  it('should be display the label', () => {
    const { utils } = setup();
    utils.getByText('Data Allowance Label');
  });

  it('should override the default unit', () => {
    const { utils } = setup({ unit: 'MB' });
    utils.getByText('MB');
  });

  it('should present the validity', () => {
    const { utils } = setup({ validity: '25 days' });
    utils.getAllByText('25');
  });

  it('should display dark grey font if uplift is enabled', () => {
    const { utils } = setup();
    const amount = utils.getByText('45');
    const unit = utils.getByText('GB');
    expect(amount).toHaveStyle('color: #333333');
    expect(unit).toHaveStyle('color: #333333');
  });
});
