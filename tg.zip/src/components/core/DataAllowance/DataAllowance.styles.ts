import styled, { css } from 'styled-components';
import {
  fontFamilyMixin,
  fontLineHeightSize,
  fontSizeLineHeightMixin,
  fontSizeMixin,
  lineHeightMixin,
  media,
} from '@src/lib/util/mixins';

export const Container = styled.div`
  display: flex;
  flex-direction: column;
`;
interface AmountSectionProps {
  theme: object;
  isUnlimited: boolean;
  upliftEnabled?: boolean;
}

interface PromoLabelBlockProps {
  upliftEnabled?: boolean;
}

type AmountProps = {
  isUnlimited?: boolean;
  upliftEnabled?: boolean;
};

export const AmountSection = styled.div<AmountSectionProps>`
  ${fontFamilyMixin('bold')};
  padding-right: ${(p) => {
    const { isUnlimited, theme } = p;
    return isUnlimited ? '0px' : `${theme.sizes.modulePaddingSmallMedium}px`;
  }};
`;

export const Amount = styled.span<AmountProps>`
  padding-right: 3px;
  ${(p) =>
    p.isUnlimited
      ? fontSizeMixin({ xs: 'heading3Mobile', m: 'heading2Mobile', l: 'heading1Mobile' })
      : fontSizeMixin({ xs: 'heading2Mobile', m: 'heading2Tablet' })}
  ${(p) => p.upliftEnabled && fontSizeMixin({ xs: 'priceRegular', m: 'priceRegular', l: 'priceLarge' })}
  ${(p) => p.upliftEnabled && lineHeightMixin({ xs: 'heading3Mobile', m: 'heading3Mobile', l: 'heading3Tablet' })}
  ${({ upliftEnabled, theme }) => upliftEnabled && `color: ${theme.colors.greyDark};`}
`;

export const Unit = styled.span<{ upliftEnabled?: boolean }>`
  ${fontSizeMixin('base')};
  vertical-align: text-bottom;
  position: absolute;
  padding-top: 11px; // hack to align data unit with data amount
  ${({ upliftEnabled, theme }) => upliftEnabled && `color: ${theme.colors.greyDark};`}

  ${media.m`
    padding-top: 18px;
    ${fontSizeMixin('heading4Mobile')};
  `}
`;

export const Label = styled.div`
  ${fontSizeLineHeightMixin(['baseSmall', 'footnote'])};
`;

export const PromoLabelBlock = styled.div<PromoLabelBlockProps>`
  ${media.xs`
    padding-top: 0;
  `}
  ${media.m`
    padding-top: 3px;
  `}
  ${media.l`
    padding-top: 3px;
  `}
  ${fontLineHeightSize('baseSmall')};
  line-height: 18px;
  ${({ upliftEnabled, theme }) =>
    upliftEnabled &&
    css`
      ${lineHeightMixin('priceSmallText')};
      color: ${theme.colors.greyDark};
      ${media.m`
        padding-top: 0px;
      `}
    `}
`;

export const Strikethrough = styled.span`
  text-decoration: line-through;
`;
