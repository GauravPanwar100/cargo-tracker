import React from 'react';
import { storiesOf } from '@storybook/react';
import { Sections } from '@src/lib/constants/storybook';
import DataAllowance from './DataAllowance';

storiesOf(`${Sections.CORE}|DataAllowance`, module).add('default', () => (
  <DataAllowance
    amount="45"
    label={
      <div>
        <div>data in Oz</div>
        <div>
          was <del>30GB</del>
        </div>
      </div>
    }
  />
));
