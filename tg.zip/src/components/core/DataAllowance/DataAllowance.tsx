import React from 'react';
import RichText from '@src/components/core/RichText';
import { isUnlimitedPlan } from '@src/components/vfe/PlanSelectorCard/utils';
import { useUpliftDataContent } from '@src/lib/context/uplift-data-provider';

import { Amount, AmountSection, Container, Label, PromoLabelBlock, Strikethrough, Unit } from './DataAllowance.styles';

export interface DataAllowanceProps {
  amount: string;
  originalAmount?: string;
  label?: string | React.ReactNode;
  unit?: string;
  validity?: string;
  prepaidDataAllowancePos?: boolean;
}

const labelValidator = (label: string | React.ReactNode) => {
  if (!label) return false;
  if (typeof label === 'string' && !label.trim()) return false; // whitespace check
  return true;
};

const DataAllowance: React.FC<DataAllowanceProps> = ({
  amount,
  originalAmount,
  unit = 'GB',
  label,
  validity,
  prepaidDataAllowancePos = false,
}) => {
  const amountStr = amount.replace('GB', ''); // Workaround for poorly authored content.
  const validityStr = validity?.replace('days', 'day').split(' ');
  const upliftEnabled = useUpliftDataContent();

  return (
    <Container>
      <AmountSection
        isUnlimited={isUnlimitedPlan(amount)}
        upliftEnabled={upliftEnabled}
        data-testid="data-allowance-amount-section"
      >
        {validityStr && !!validityStr.length && (
          <>
            <Amount upliftEnabled={upliftEnabled}>{validityStr[0]}</Amount>
            <Unit>{validityStr[1]}</Unit>
          </>
        )}

        {!validityStr && (
          <>
            <Amount upliftEnabled={upliftEnabled} isUnlimited={isUnlimitedPlan(amount)} data-testid="data">
              {amountStr}
            </Amount>
            {!isUnlimitedPlan(amount) && <Unit upliftEnabled={upliftEnabled}>{unit}</Unit>}
          </>
        )}
      </AmountSection>
      {prepaidDataAllowancePos && originalAmount && originalAmount !== amount && (
        <PromoLabelBlock>
          was <Strikethrough data-testid="was-data">{originalAmount}</Strikethrough>
        </PromoLabelBlock>
      )}
      {labelValidator(label) && (
        <Label>
          <RichText color="white">{label}</RichText>
        </Label>
      )}

      {!prepaidDataAllowancePos && originalAmount && originalAmount !== amount && (
        <PromoLabelBlock upliftEnabled={upliftEnabled}>
          was <Strikethrough data-testid="was-data">{originalAmount}</Strikethrough>
        </PromoLabelBlock>
      )}
    </Container>
  );
};

export default DataAllowance;
