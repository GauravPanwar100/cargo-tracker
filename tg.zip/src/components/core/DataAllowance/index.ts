export { default } from './DataAllowance';
