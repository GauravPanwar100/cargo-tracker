export const isAcnCookie = (cookie?: string) => {
  return (
    (typeof document !== 'undefined' || cookie !== undefined) &&
    (cookie ?? document.cookie).includes('dealer=') &&
    (cookie ?? document.cookie).includes('agent=')
  );
};
