import { isAcnCookie } from './acnCookie';

describe('isAcnCookie', () => {
  it('should return true when cookie values are present', () => {
    expect(
      isAcnCookie(
        'dealer={"dealerCode":"WEB0002","id":1625799745771}; agent={"agentID":"Agent008"} _gid=GA1.1.1331083945.1624234440; vfe.servicetype=New',
      ),
    ).toBe(true);
  });
  it('should return false when cookie values are not present', () => {
    expect(
      isAcnCookie(
        'dealer={"dealerCode":"WEB0002","id":1625799745771}; _gid=GA1.1.1331083945.1624234440; vfe.servicetype=New',
      ),
    ).toBe(false);
  });
});
