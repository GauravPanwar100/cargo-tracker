/* eslint-disable no-plusplus */
import { SamsungCookie } from '@src/lib/storage/types';
import Cookies from 'universal-cookie';
import { PATRNER_COOKIE_NAME, SAMSUNG } from '@src/templates/Samsung/Samsung.constants';

export const isSamsungCookie = () => {
  if (typeof document !== 'undefined') {
    const cookieValue = getSamsungCookie();
    return !!cookieValue && cookieValue.partnerCode.toLowerCase() === SAMSUNG;
  }
  return false;
};

// retrieves the value of the portion of the cookie specified by the cName param
// eg. partnerCode=Samsung;
export function getSamsungCookie(): SamsungCookie {
  return new Cookies().get(PATRNER_COOKIE_NAME);
}

// Function to set the samsung cookie values
export const setSamsungCookie = (cookieValue: SamsungCookie) => {
  new Cookies().set(PATRNER_COOKIE_NAME, cookieValue, { path: '/', secure: true });
};
