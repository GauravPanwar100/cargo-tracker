import cuid from 'cuid';
/**
 * this is to test to see if the e2eSessionId cookie exists
 * - if not generate a 19 character string
 */
export const sessionCookie = () => {
  if (typeof document !== 'undefined' && !document.cookie.includes('e2eSessionId=')) {
    const e2eSessionId = cuid();
    document.cookie = `e2eSessionId=${e2eSessionId}; path=/`;
  }
};
sessionCookie();
