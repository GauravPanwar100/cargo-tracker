import { sleep } from './sleep';

jest.useFakeTimers();

describe('sleep', () => {
  it('should resolve after the specified time', async () => {
    const timeoutDuration = 100;
    const promise = sleep(timeoutDuration);
    jest.advanceTimersByTime(timeoutDuration);
    await expect(promise).resolves.toBeUndefined();
  });
});
