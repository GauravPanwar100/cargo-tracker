import { isSamsungCookie, setSamsungCookie } from './samsungCookie';

describe('isSamsungCookie', () => {
  it('should return true when  Samsung cookie is present', () => {
    Object.defineProperty(window.document, 'cookie', {
      writable: true,
      value:
        'partnerTransactionDetails=%7B%22partnerCode%22%3A%22samsung%22%2C%22planId%22%3A%22AU1234%22%2C%22deviceSKU%22%3A%22devicesku%22%2C%22callbackUrl%22%3A%22callbackUrl%22%2C%22resumeUrl%22%3A%22resumeUrl%22%2C%22cartUID%22%3A%22cartUID%22%7D; expires=Thu, 26 Sept 2021 12:00:00 UTC; path=/',
    });
    expect(isSamsungCookie()).toBe(true);
  });
  it('should return true when partnerCode samsung(lowercase) cookie is present', () => {
    Object.defineProperty(window.document, 'cookie', {
      writable: true,
      value:
        'partnerTransactionDetails=%7B%22partnerCode%22%3A%22samsung%22%2C%22planId%22%3A%22AU1234%22%2C%22deviceSKU%22%3A%22devicesku%22%2C%22callbackUrl%22%3A%22callbackUrl%22%2C%22resumeUrl%22%3A%22resumeUrl%22%2C%22cartUID%22%3A%22cartUID%22%7D; expires=Thu, 26 Sept 2021 12:00:00 UTC; path=/',
    });
    expect(isSamsungCookie()).toBe(true);
  });
  it('should return false when cookie value Samsung not present', () => {
    Object.defineProperty(window.document, 'cookie', {
      writable: true,
      value: 'partnerCode=Apple; expires=Thu, 26 Sept 2021 12:00:00 UTC; path=/',
    });
    expect(isSamsungCookie()).toBe(false);
  });
  it('should return false when cookie value is empty', () => {
    expect(isSamsungCookie()).toBe(false);
  });
  it('should return false when cookie values does not include partnerCode param', () => {
    Object.defineProperty(window.document, 'cookie', {
      writable: true,
      value: 'vendor=Apple; expires=Thu, 26 Sept 2021 12:00:00 UTC; path=/',
    });
    expect(isSamsungCookie()).toBe(false);
  });
});

describe('setSamsungCookie', () => {
  it('should be able to set the cookie value', () => {
    setSamsungCookie({
      partnerCode: 'samsung',
      planId: 'AU80801',
      deviceSku: 'devicesku',
      callbackUrl: 'callbackUrl',
      resumeUrl: 'resumeUrl',
      cartId: 'cartUID',
    });
    expect(isSamsungCookie()).toBe(true);
  });
});
