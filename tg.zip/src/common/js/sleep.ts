/**
 * Simple helper function to trigger a blocking wait with returned promise
 */
export const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
