import { sessionCookie } from './sessionCookie';

describe('sessionCookie', () => {
  it('should populate cookie with e2eSessionId when not defined', () => {
    document.cookie = '';
    sessionCookie();
    expect(document.cookie).toContain('e2eSessionId=');
  });
  it('should not update e2eSessionId when defined', () => {
    document.cookie = 'e2eSessionId=1234; path=/';
    sessionCookie();
    expect(document.cookie).toContain('e2eSessionId=1234');
  });
});
