import { RenderOptions, act, render } from '@testing-library/react';
import React from 'react';
import { ThemeProvider } from 'styled-components';
import timers from 'timers';
import { lightTheme } from '@src/lib/theme';

import Global = NodeJS.Global;

interface CustomGlobal extends Global {
  innerWidth?: number;
  innerHeight?: number;
}

export const customGlobal: CustomGlobal = global;

const customRender = (ui: React.ReactElement, options?: RenderOptions) => {
  const Providers: React.FC = ({ children }) => (
    <ThemeProvider theme={lightTheme}>{children as React.ReactChild}</ThemeProvider>
  );

  return render(ui, { wrapper: Providers, ...options });
};

const wait = async (ms: number) => act(() => new Promise<void>((resolve) => setTimeout(resolve, ms)));

export { wait as timeout };

export { customRender as render };

// NOTE: This needs to be destructed rather than imported as `import { setImmediate } from 'timers';`
// to avoid live bindings of ES modules that could be overriden by FakeTimers (`@sinonjs/fake-timers`)
const { setImmediate } = timers;
export function waitForEventLoopToDrain(): Promise<void> {
  return new Promise((resolve) => setImmediate(resolve));
}

export * from '@testing-library/react';
