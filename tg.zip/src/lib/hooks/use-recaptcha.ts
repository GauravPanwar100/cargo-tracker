/* eslint-disable max-classes-per-file */
import { noop } from 'lodash';
import React from 'react';
import scripts from '@src/lib/util/scripts';
import { Flag, useFeatureFlag } from '@src/lib/context/feature-flags';
import { isPromiseLike } from '@src/lib/types';
import { ExtendableError } from '@src/lib/util/error';
import { TimeoutError, promiseRaceTimeout } from '@src/lib/util/promise';

export class RecaptchaError extends ExtendableError {
  constructor(message: string, public error?: unknown) {
    super(message);
  }
}

export class RecaptchaScriptLoadFailedError extends RecaptchaError {}

export class RecaptchaExecutionFailedError extends RecaptchaError {}

export class RecaptchaExecutionTimeoutError extends RecaptchaError {}

const RECAPTCHA_ENTERPRISE_SCRIPT_SRC = 'https://recaptcha.net/recaptcha/enterprise.js?render=explicit';

const RECAPTCHA_SITE_KEY = process.env.RECAPTCHA_SITE_KEY || '6Ld3b8kcAAAAAElUPmqiuZqRv7DPb2q2pSOUjWp8';

/**
 * This function allows us to create a Promise and be able to resolve/reject outside the scope of the
 * `new Promise(executor)` constructor.
 *
 * For the majority of the time when you're creating a promise, inside the `executor` works fine, but in this case
 * because of the way rendering the Recaptcha widget is separate from executing and the Recaptcha callback, this
 * separation was necessary.
 */
function createPromise<T>() {
  let resolve: (value: T) => void;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let reject: (reason?: any) => void;
  const promise = new Promise<T>((_resolve, _reject) => {
    resolve = _resolve;
    reject = _reject;
  });
  // @ts-ignore Promise constructor executor happens synchronously, so these values will always be defined
  return { promise, resolve, reject };
}

/**
 * Injects the Recaptcha Enterprise script if required and returns a promise when `window.grecaptcha.enterprise.ready`
 */
async function onReady(): Promise<void> {
  try {
    await scripts.inject(RECAPTCHA_ENTERPRISE_SCRIPT_SRC);
  } catch (error) {
    throw new RecaptchaScriptLoadFailedError('Recaptcha script failed to load', error);
  }

  // NOTE: Using a timeout here due to flakiness on the VHA VPN where the intial Recaptcha script loads but the
  // subsequent callback is never called as a secondary script loaded internally by Recaptcha fails to load
  return promiseRaceTimeout(() => new Promise((resolve) => window.grecaptcha.enterprise.ready(resolve)));
}

/**
 * Custom React hook that injects an "invisible" Recaptcha widget and provides a method to execute and return the token
 * @param options
 */
export default function useRecaptcha({ id = 'grecaptcha-el' }: { id?: string } = {}) {
  const { data: disabled, isInitialised, isLoading } = useFeatureFlag(Flag.DISABLE_RECAPTCHA);

  const onRender = React.useMemo(() => {
    // Using id here to ensure a new promise is created whenever the id changes
    noop(id);
    return createPromise<number | null>();
  }, [id]);
  const onCallback = React.useRef(createPromise<string>());

  React.useEffect(() => {
    if (!isInitialised || isLoading) return noop;

    if (disabled) {
      onRender.resolve(null);
      return noop;
    }

    const controller = new AbortController();

    onReady().then(() => {
      if (controller.signal.aborted) return;

      const el = document.createElement('div');
      el.className = 'g-recaptcha';
      el.id = id;
      document.body.appendChild(el);

      const instance = window.grecaptcha.enterprise.render(el, {
        sitekey: RECAPTCHA_SITE_KEY,
        size: 'invisible',
        'error-callback': () =>
          onCallback.current.reject(new RecaptchaExecutionFailedError('Recaptcha execution failed')),
        callback: (token) => onCallback.current.resolve(token),
      });
      onRender.resolve(instance);
    }, onRender.reject);

    // NOTE: Errors will still be surfaced in executeAndReturnToken, but this will suppress the Unhandled Error warning
    // because we have at least once catch on the promise to handle the cases where the Promise rejects without calling
    // executeAndReturnToken
    onRender.promise.catch(noop);

    return () => {
      controller.abort();
      document.querySelector(`#${id}`)?.remove();
      onRender.reject(new Error('Aborted'));
    };
  }, [disabled, id, isInitialised, isLoading, onCallback, onRender]);

  const alreadyExecuted = React.useRef(false);

  const executeAndReturnToken = React.useCallback(async () => {
    try {
      // Wait for Recaptcha to be rendered (or disabled)
      const instance = await onRender.promise;

      if (instance === null) {
        // When Recaptcha is disabled, just return an empty string
        return '';
      }

      if (alreadyExecuted.current) {
        // We want a fresh token each time we call this method, so create a new promise if we've already called execute.
        // For the first run though, we want to keep the original promise as Recaptcha may call the error-callback before
        // we call execute.
        onCallback.current = createPromise<string>();
      }

      // NOTE: Recaptcha typings specify that this function returns `void`, but testing shows that it actually returns a
      // `PromiseLike<string>` object
      const maybePromiseLike = window.grecaptcha.enterprise.execute(instance);
      alreadyExecuted.current = true;

      // If the return result of `execute()` returns a `PromiseLike<string>` object, await on it instead of the callback
      // Promise as it seems to be more reliable than waiting for the callback which seems to time out some of the time
      const tokenPromise = isPromiseLike<string>(maybePromiseLike)
        ? Promise.resolve(maybePromiseLike)
        : onCallback.current.promise;

      // Using a timeout here of 10 seconds which has been chosen arbitrarily. Was seeing some flakiness in DEV/SIT
      // on the VPN where Recaptcha was not responding at all and we were stuck with a spinner indefinitely instead
      // of displaying some sort of error. By timing out, we can at least encourage the user to try again (refresh)
      const token = await promiseRaceTimeout(() => tokenPromise);
      return token;
    } catch (error) {
      if (error instanceof TimeoutError) {
        throw new RecaptchaExecutionTimeoutError('Recaptcha execution timed out', error);
      }

      if (!(error instanceof RecaptchaError)) {
        throw new RecaptchaExecutionFailedError('Recaptcha execution failed', error);
      }

      throw error;
    }
  }, [onRender.promise]);

  return { executeAndReturnToken };
}
