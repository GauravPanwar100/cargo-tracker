import React from 'react';
import { getApiClient } from '@src/lib/api';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import { PaymentConfiguration, PaymentConfigurationKey } from '@src/lib/api/types';

const usePaymentConfiguration = <K extends PaymentConfigurationKey>(configKey: K) => {
  const ApiClient = getApiClient();
  const [paymentConfiguration, getPaymentConfiguration] = useImperativeData<K, PaymentConfiguration[K]>(
    ApiClient.getPaymentConfiguration,
  );

  React.useEffect(() => {
    getPaymentConfiguration(configKey);
  }, [configKey, getPaymentConfiguration]);

  return paymentConfiguration;
};

export default usePaymentConfiguration;
