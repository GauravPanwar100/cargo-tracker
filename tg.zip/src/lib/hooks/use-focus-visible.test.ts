import {
  ADD_EVENT_LISTENER_CAPTURE_PASSIVE_OPTIONS,
  REMOVE_EVENT_LISTENER_CAPTURE_PASSIVE_OPTIONS,
} from '@kablamo/kerosene-ui';
import useFocusVisible from '@src/lib/hooks/use-focus-visible';
import { renderHook } from '@testing-library/react-hooks';
import { when } from 'jest-when';
import { act } from 'react-test-renderer';

describe('useFocusVisible', () => {
  let addEventListener: jest.SpyInstance<void, Parameters<typeof window.addEventListener>>;
  let removeEventListener: jest.SpyInstance<void, Parameters<typeof window.removeEventListener>>;
  let querySelector: jest.SpyInstance<Element | null, Parameters<typeof document.querySelector>>;
  let supports: jest.SpyInstance<ReturnType<typeof CSS.supports>, Parameters<typeof CSS.supports>>;
  const FOCUS_EVENTS = ['focus', 'blur', 'keydown'] as const;
  const getUpdate = () => addEventListener.mock.calls.find(([name]) => name === 'focus')![1] as () => void;
  beforeEach(() => {
    addEventListener = jest.spyOn(window, 'addEventListener');
    removeEventListener = jest.spyOn(window, 'removeEventListener');
    querySelector = jest.spyOn(document, 'querySelector').mockImplementation(() => {
      throw new Error('Not stubbed');
    });
    supports = jest.spyOn(CSS, 'supports').mockImplementation(() => {
      throw new Error('Not stubbed');
    });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should return whether :focus:focus-visible is present', () => {
    when(supports).calledWith('selector(:focus-visible)').mockReturnValue(true);
    when(querySelector)
      .calledWith(':focus:focus-visible')
      .mockReturnValueOnce({} as Element);

    const { result, unmount } = renderHook(() => useFocusVisible());

    FOCUS_EVENTS.forEach((name) => {
      expect(addEventListener).toHaveBeenCalledWith(name, getUpdate(), ADD_EVENT_LISTENER_CAPTURE_PASSIVE_OPTIONS);
    });

    expect(result.current).toBe(true);

    when(querySelector).calledWith(':focus:focus-visible').mockReturnValueOnce(null);
    act(getUpdate());

    expect(result.current).toBe(false);

    unmount();
    FOCUS_EVENTS.forEach((name) => {
      expect(removeEventListener).toHaveBeenCalledWith(
        name,
        getUpdate(),
        REMOVE_EVENT_LISTENER_CAPTURE_PASSIVE_OPTIONS,
      );
    });
  });

  it("should return whether :focus is present in a browser which doesn't support :focus-visible", () => {
    when(supports).calledWith('selector(:focus-visible)').mockReturnValue(false);
    when(querySelector)
      .calledWith(':focus')
      .mockReturnValueOnce({} as Element);

    const { result, unmount } = renderHook(() => useFocusVisible());

    FOCUS_EVENTS.forEach((name) => {
      expect(addEventListener).toHaveBeenCalledWith(name, getUpdate(), ADD_EVENT_LISTENER_CAPTURE_PASSIVE_OPTIONS);
    });

    expect(result.current).toBe(true);

    when(querySelector).calledWith(':focus').mockReturnValueOnce(null);
    act(getUpdate());

    expect(result.current).toBe(false);

    unmount();
    FOCUS_EVENTS.forEach((name) => {
      expect(removeEventListener).toHaveBeenCalledWith(
        name,
        getUpdate(),
        REMOVE_EVENT_LISTENER_CAPTURE_PASSIVE_OPTIONS,
      );
    });
  });
});
