import { useEffect } from 'react';

const useAsyncLoadStyleSheet = (src: string) => {
  useEffect(() => {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = src;
    link.media = 'print';
    // eslint-disable-next-line func-names
    link.onload = function () {
      this.onload = null;
      (this as HTMLLinkElement).removeAttribute('media');
    };
    document.head.appendChild(link);

    return () => {
      document.head.removeChild(link);
    };
  }, [src]);
};

export default useAsyncLoadStyleSheet;
