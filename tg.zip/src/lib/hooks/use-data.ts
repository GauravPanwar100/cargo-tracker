import { Dispatch, SetStateAction, useCallback, useEffect, useReducer, useRef, useState } from 'react';
import {
  DataFetchAction,
  DataFetchReducer,
  DataFetchState,
  dataFetchReducer,
  makeFetchData,
} from './data-fetch-reducer';

function useData<P, R>(
  request: (params: P) => Promise<R>,
  initialParams: P | null,
  initialData: R | null,
  delay = 0,
): [DataFetchState<P, R>, Dispatch<SetStateAction<P | null>>, Dispatch<DataFetchAction<P, R>>] {
  const [params, setParams] = useState<P | null>(initialParams);

  // Keep the delay in a static ref so that we don't need to include it as a
  // dependency in the data fetching effect deps array. Changes to the delay
  // param will not re-run the data fetching effect because it only depends on
  // the ref
  const latestDelay = useRef(delay);
  useEffect(() => {
    latestDelay.current = delay;
  }, [delay]);

  const didCancel = useRef<boolean>(false);

  const [state, dispatch] = useReducer<DataFetchReducer<P, R>>(dataFetchReducer, {
    data: initialData,
    error: null,
    isInitialised: false,
    isLoading: false,
    isSuccess: false,
    params,
  });

  // eslint-disable-next-line react-hooks/exhaustive-deps -- unable to lint deps but still works
  const fetchData = useCallback(makeFetchData(request, dispatch, didCancel, latestDelay), [request]);

  useEffect(() => {
    didCancel.current = false;

    if (params) {
      fetchData(params);
    }

    return () => {
      didCancel.current = true;
    };
  }, [fetchData, params, request]);

  return [state, setParams, dispatch];
}

export default useData;
