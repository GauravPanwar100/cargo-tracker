import { useEffect, useState } from 'react';

export interface LoadScriptState {
  loaded: boolean;
  error: boolean;
}

const useLoadExternalScript = (src: string) => {
  const [scriptLoaded, setScriptLoaded] = useState<LoadScriptState>({ loaded: false, error: false });

  useEffect(() => {
    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    document.body.appendChild(script);

    script.onload = () => {
      setScriptLoaded({ loaded: true, error: false });
    };

    script.onerror = () => {
      setScriptLoaded({ loaded: false, error: true });
    };

    return () => {
      document.body.removeChild(script);
    };
  }, [src]);

  return scriptLoaded;
};

export default useLoadExternalScript;
