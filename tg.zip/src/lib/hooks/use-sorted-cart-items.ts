import React from 'react';
import { BasketItem } from '@src/lib/api/types';
import { filterNonVisibleItems, sortCartItems } from '@src/lib/util/cart';

const useSortedCartItems = (cartItems: readonly BasketItem[]) =>
  React.useMemo(() => sortCartItems(filterNonVisibleItems(cartItems)), [cartItems]);

export default useSortedCartItems;
