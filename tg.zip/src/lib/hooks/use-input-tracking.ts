import { trackGtagEvent } from '@src/lib/tracking';
import { useRef } from 'react';

const useInputTracking = (startIndicator: boolean, label: string, category: string) => {
  const timeStartRef = useRef<number | null>(null);
  if (startIndicator) {
    timeStartRef.current = Date.now();
  }

  if (!startIndicator && timeStartRef.current) {
    const timeSinceStart = Date.now() - timeStartRef.current;

    // Event action name to be confirmed, as well as the event_label attribute name
    trackGtagEvent('timetrack - test', {
      event_category: category,
      event_label: label,
      event_value: timeSinceStart.toString(),
    });

    timeStartRef.current = null;
  }
};

export default useInputTracking;
