import React from 'react';

/**
 * At a minimum, one of childList, attributes, and/or characterData
 * must be true when you call observe()
 * otherwise, a `TypeError` exception will be thrown
 */
const DEFAULT_MUTATION_OBSERVER_OPTIONS: MutationObserverInit = {
  attributes: true,
  childList: true,
};

function useMutationObserver(
  ref: React.RefObject<HTMLElement>,
  callback: MutationCallback,
  options: MutationObserverInit = DEFAULT_MUTATION_OBSERVER_OPTIONS,
) {
  const [mutationObserver, setMutationObserver] = React.useState<MutationObserver>();

  React.useEffect(() => {
    if (ref.current) {
      if (mutationObserver) return;
      const observer = new MutationObserver(callback);
      setMutationObserver(observer);
    }
  }, [mutationObserver, ref, callback]);

  React.useEffect(() => {
    if (!mutationObserver) return;
    if (ref.current) {
      mutationObserver.observe(ref.current, options);
      // eslint-disable-next-line consistent-return
      return () => {
        if (mutationObserver) {
          mutationObserver.disconnect();
        }
      };
    }
  }, [mutationObserver, options, ref]);
}

export { DEFAULT_MUTATION_OBSERVER_OPTIONS, useMutationObserver };
