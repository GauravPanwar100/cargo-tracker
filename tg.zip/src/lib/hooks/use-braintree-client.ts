import React from 'react';
import braintree from 'braintree-web';
import { getApiClient } from '@src/lib/api';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import { getAllowedParentOrigin } from '@src/lib/payment/origin';
import Logger from '@src/lib/logger/logger';
import { DeviceDataRequest } from '@src/lib/api/types';
import { usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import { getPaymentIframeHashParams } from '@src/lib/payment/params';

const useBraintreeClient = (clientMetadataId = '', isPayPalTransaction = false) => {
  const ApiClient = getApiClient();
  const [tokenData, getBraintreeToken] = useImperativeData(ApiClient.getBraintreeToken);
  React.useEffect(() => {
    // If we're not inside an iframe, redirect to the home page
    if (window === window.parent) {
      window.location.replace('/');
      return;
    }

    try {
      getAllowedParentOrigin();
      getBraintreeToken();
    } catch (error) {
      Logger.error('Failed when trying to access the allowed parent origin', { error, ucode: '3910b4c' });
    }
  }, [getBraintreeToken]);

  const [client, setClient] = React.useState<braintree.Client>();

  // Used for Braintree Premium Fraud Management
  const [deviceData, setDeviceData] = React.useState<braintree.DataCollector['deviceData']>();

  const postMessage = usePaymentIframePostMessage();

  React.useEffect(() => {
    if (!tokenData.isLoading && tokenData.error) {
      Logger.error('Failed to get Braintree token', { error: tokenData.error, ucode: '11905d4' });
      postMessage({
        source: 'vfe',
        type: 'VFE_IFRAME_FAILED',
      });
    }

    if (!tokenData.data) return;

    braintree.client.create({ authorization: tokenData.data.token }).then(
      (c) => setClient(c),
      (error) => {
        Logger.error('Failed to create Braintree client', { error, ucode: '9f50dc3' });
        postMessage({
          source: 'vfe',
          type: 'VFE_IFRAME_FAILED',
        });
      },
    );
  }, [tokenData.data, tokenData.isLoading, tokenData.error, postMessage]);

  React.useEffect(() => {
    if (!client) return;
    const isPaypalPrepaid = isPayPalTransaction && getPaymentIframeHashParams().FLOW_TYPE === 'CHARGE';
    if (isPaypalPrepaid && !clientMetadataId) return;

    const deviceDataRequest: DeviceDataRequest = {
      client,
    };
    if (clientMetadataId) {
      deviceDataRequest.paypal = true;
      deviceDataRequest.riskCorrelationId = clientMetadataId;
    }
    braintree.dataCollector.create(deviceDataRequest).then(
      (dc) => setDeviceData(dc.deviceData),
      (error) => {
        Logger.error('Failed to create Braintree data collector', { error, ucode: '0948c84' });
        postMessage({
          source: 'vfe',
          type: 'VFE_IFRAME_FAILED',
        });
      },
    );
  }, [client, clientMetadataId, isPayPalTransaction, postMessage]);

  return { client, deviceData };
};

export default useBraintreeClient;
