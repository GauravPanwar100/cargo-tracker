import React from 'react';
import { ServiceTypeContext, useAuthentication } from '@src/lib/context/authentication';
import { useSetModal } from '@src/lib/context/modal';
import { LocalStorageClient } from '@src/lib/storage';
import { ServiceTypeValue } from '@src/lib/storage/types';

const useServiceType = (forceWhenAuthed?: Exclude<ServiceTypeValue, ServiceTypeValue.NewAcquisition>) => {
  const { isAuthenticated, loading } = useAuthentication();
  const [serviceType, setServiceType] = React.useContext(ServiceTypeContext);
  const setModal = useSetModal();

  const hasRun = React.useRef(false);
  React.useEffect(() => {
    if (loading || hasRun.current) return;
    hasRun.current = true;

    if (!isAuthenticated) {
      setServiceType(ServiceTypeValue.NewAcquisition);
    } else if (forceWhenAuthed) {
      const hasItemsInCart = !!LocalStorageClient.getBasketId();
      const existingServiceType = LocalStorageClient.getServiceType();
      if (
        hasItemsInCart &&
        existingServiceType === ServiceTypeValue.AnotherService &&
        forceWhenAuthed === ServiceTypeValue.Upgrade
      ) {
        setModal({
          id: 'intoupgrades',
          isOpen: true,
          confirmCtaAction: () => {
            LocalStorageClient.removeBasketId();
            setServiceType(ServiceTypeValue.Upgrade);
            setModal('');
          },
          cancelCtaAction: '/another-service',
          onClose: null,
        });
        return;
      }
      if (existingServiceType === ServiceTypeValue.Upgrade && forceWhenAuthed === ServiceTypeValue.AnotherService) {
        setModal({
          id: 'outofupgrades',
          isOpen: true,
          confirmCtaAction: '/upgrade',
          cancelCtaAction: () => {
            LocalStorageClient.removeBasketId();
            setServiceType(ServiceTypeValue.AnotherService);
            setModal('');
          },
          onClose: null,
        });
        return;
      }
      setServiceType(forceWhenAuthed);
    }
  }, [forceWhenAuthed, isAuthenticated, loading, setModal, setServiceType]);

  return [serviceType, setServiceType] as const;
};

export default useServiceType;
