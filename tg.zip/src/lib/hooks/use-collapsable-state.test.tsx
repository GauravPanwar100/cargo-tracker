import { Mutable } from '@kablamo/kerosene';
import FakeTimers from '@sinonjs/fake-timers';
import { RenderHookResult, renderHook } from '@testing-library/react-hooks';
import { act } from 'react-test-renderer';
import { when } from 'jest-when';
import { waitForEventLoopToDrain } from '@src/test-utils';

const mockUseMediaQuery: jest.MockedFunction<typeof import('@src/lib/hooks/use-media-query')['default']> = jest.fn();
jest.mock('@src/lib/hooks/use-media-query', () => ({
  __esModule: true,
  default: mockUseMediaQuery,
}));

import useCollapsableState from '@src/lib/hooks/use-collapsable-state';

type HookTestProps = Parameters<typeof useCollapsableState>[1] & { open: boolean };

describe('useCollapsableState', () => {
  let clock: FakeTimers.InstalledClock;
  let repaint: () => Promise<void>;
  let tick: (ms: number) => Promise<void>;
  let setup: (initialProps: HookTestProps) => RenderHookResult<HookTestProps, ReturnType<typeof useCollapsableState>>;
  let el: HTMLElement;
  beforeEach(() => {
    clock = FakeTimers.install();
    repaint = () =>
      act(async () => {
        clock.runToFrame();
        clock.runToFrame();
        await waitForEventLoopToDrain();
      });
    tick = (ms) =>
      act(async () => {
        await clock.tickAsync(ms);
        await waitForEventLoopToDrain();
      });
    el = {
      scrollHeight: 500,
    } as Partial<HTMLElement> as HTMLElement;

    setup = (initialProps: HookTestProps) =>
      renderHook(
        ({ open, ...options }) => {
          const result = useCollapsableState(open, options);
          (result.ref as Mutable<typeof result.ref>).current = el;
          return result;
        },
        { initialProps },
      );
  });

  it.each([
    { immediate: true, prefersReducedMotion: false },
    { immediate: false, prefersReducedMotion: true },
  ])(
    'should perform actions immediately when immediate=$immediate,prefersReducedMotion=$prefersReducedMotion',
    ({ immediate, prefersReducedMotion }) => {
      when(mockUseMediaQuery).calledWith('(prefers-reduced-motion: reduce)').mockReturnValue(prefersReducedMotion);

      const { result, rerender } = setup({ open: false, immediate });
      expect(result.current.render).toBe(false);
      expect(result.current.style).toEqual({
        maxHeight: 0,
        overflow: 'hidden',
        transitionProperty: 'max-height',
        transitionDuration: '0ms',
        transitionTimingFunction: 'ease-in-out',
      });

      rerender({ open: true, immediate });
      expect(result.current.render).toBe(true);
      expect(result.current.style).toEqual({
        maxHeight: 'none',
        overflow: 'hidden',
        transitionProperty: 'max-height',
        transitionDuration: '0ms',
        transitionTimingFunction: 'ease-in-out',
      });

      rerender({ open: false, immediate });
      expect(result.current.render).toBe(false);
      expect(result.current.style).toEqual({
        maxHeight: 0,
        overflow: 'hidden',
        transitionProperty: 'max-height',
        transitionDuration: '0ms',
        transitionTimingFunction: 'ease-in-out',
      });
    },
  );

  it('should orchestrate transitions appropriately', async () => {
    when(mockUseMediaQuery).calledWith('(prefers-reduced-motion: reduce)').mockReturnValue(false);
    const { result, rerender } = setup({ open: false });
    expect(result.current.render).toBe(false);
    expect(result.current.style).toEqual({
      maxHeight: 0,
      overflow: 'hidden',
      transitionProperty: 'max-height',
      transitionDuration: '250ms',
      transitionTimingFunction: 'ease-in-out',
    });

    rerender({ open: true });
    // transition-duration: 0ms
    expect(result.current.style).toEqual({
      maxHeight: 0,
      overflow: 'hidden',
      transitionProperty: 'max-height',
      transitionDuration: '0ms',
      transitionTimingFunction: 'ease-in-out',
    });

    await repaint();
    // transition-duration: 250ms, max-height: 0, render: true
    expect(result.current.render).toBe(true);
    expect(result.current.style).toEqual({
      maxHeight: 0,
      overflow: 'hidden',
      transitionProperty: 'max-height',
      transitionDuration: '250ms',
      transitionTimingFunction: 'ease-in-out',
    });

    await repaint();
    // max-height: 500
    expect(result.current.render).toBe(true);
    expect(result.current.style).toEqual({
      maxHeight: 500,
      overflow: 'hidden',
      transitionProperty: 'max-height',
      transitionDuration: '250ms',
      transitionTimingFunction: 'ease-in-out',
    });

    await tick(250);
    // max-height: none
    expect(result.current.render).toBe(true);
    expect(result.current.style).toEqual({
      maxHeight: 'none',
      overflow: 'hidden',
      transitionProperty: 'max-height',
      transitionDuration: '250ms',
      transitionTimingFunction: 'ease-in-out',
    });

    rerender({ open: false });
    // max-height: 500, transition-duration: 250ms
    expect(result.current.render).toBe(true);
    expect(result.current.style).toEqual({
      maxHeight: 500,
      overflow: 'hidden',
      transitionProperty: 'max-height',
      transitionDuration: '250ms',
      transitionTimingFunction: 'ease-in-out',
    });

    await repaint();
    // max-height: 0
    expect(result.current.render).toBe(true);
    expect(result.current.style).toEqual({
      maxHeight: 0,
      overflow: 'hidden',
      transitionProperty: 'max-height',
      transitionDuration: '250ms',
      transitionTimingFunction: 'ease-in-out',
    });

    await tick(250);
    // render: false
    expect(result.current.render).toBe(false);
    expect(result.current.style).toEqual({
      maxHeight: 0,
      overflow: 'hidden',
      transitionProperty: 'max-height',
      transitionDuration: '250ms',
      transitionTimingFunction: 'ease-in-out',
    });
  });
});
