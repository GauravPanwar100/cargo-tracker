import React from 'react';
import { useBasketState } from '@src/lib/context/basket';
import { useCustomerData } from '@src/lib/context/customer-data';
import { getApiClient } from '@src/lib/api';
import { LocalStorageClient } from '@src/lib/storage';
import { BnsOffer } from '@src/lib/api/types';

const useBnsOffer = () => {
  const { getBasketState } = useBasketState();

  const { customerBundleAndSaveCount } = useCustomerData();

  const [serviceCount, setServiceCount] = React.useState<number>(0);
  const [basketExist, setBasketExist] = React.useState<boolean>(false);
  const prevServiceCountRef = React.useRef<number>();

  const [state, setState] = React.useState<BnsOffer>({
    plans: [],
    promotion: null,
  });

  React.useEffect(() => {
    setBasketExist(!!LocalStorageClient.getBasketId());
  }, []);

  React.useEffect(() => {
    const getBnsOffer = async () => {
      const data = await getApiClient().getBnsOffer({
        serviceCount: 1 + serviceCount,
      });
      setState(() => ({
        plans: data?.plans ? data.plans : [],
        promotion: data?.promotion ? data.promotion : null,
      }));
    };

    if (serviceCount > 0 && prevServiceCountRef.current !== serviceCount) {
      getBnsOffer();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serviceCount]);

  React.useEffect(() => {
    prevServiceCountRef.current = serviceCount;

    if (basketExist) {
      if (getBasketState.data?.packages) {
        let totalSrc = 0;
        totalSrc = getBasketState.data.packages.filter((pkg) =>
          pkg.items.some((item) => item.isBundleAndSaveEligible),
        ).length;
        if (getBasketState.params?.additionalBnsCount) {
          totalSrc = +totalSrc + getBasketState.params.additionalBnsCount;
        }

        setServiceCount(totalSrc);
      }
    } else if (customerBundleAndSaveCount !== 0) {
      setServiceCount(customerBundleAndSaveCount);
    }
  }, [serviceCount, basketExist, customerBundleAndSaveCount, getBasketState]);

  return {
    ...state,
  };
};

export default useBnsOffer;
