import { BasketPackage, CatalogCode, CustomerServiceDetails, ProductServiceType } from '@src/lib/api/types';
import { User, useAuthentication } from '@src/lib/context/authentication';
import { useBasketState } from '@src/lib/context/basket';
import { useCustomerData } from '@src/lib/context/customer-data';
import { isCartPage, isCheckoutPage, isInternetPage, isVoicePage } from '@src/lib/util/pages';
import { isNbnService, isPostpayUser } from '@src/lib/util/customer';
import { stripQueryFromPath } from '@src/lib/util/url';
import { useRouter } from 'next/router';
import { useMemo } from 'react';

const calculateASDEligibility = (
  asPath: string,
  isAuthenticated: boolean,
  user: User | undefined,
  customerServiceDetails: readonly CustomerServiceDetails[] | undefined,
  packages: BasketPackage[] | undefined,
): boolean => {
  let hasVoiceBasketItem = false;
  let hasInternetBasketItem = false;
  if (packages) {
    packages.forEach((pkg) => {
      hasVoiceBasketItem ||= pkg.items.some((item) =>
        [CatalogCode.POSTPAID_HANDSET_PLANS, CatalogCode.POSTPAID_SIMO_PLANS].includes(item.catalogCode),
      );
      hasInternetBasketItem ||= pkg.items.some((item) =>
        [CatalogCode.NBN_PLANS, CatalogCode.FHW_4G_PLANS, CatalogCode.FHW_5G_PLANS].includes(item.catalogCode),
      );
    });
  }

  let hasVoiceService = false;
  let hasInternetService = false;

  if (isAuthenticated && user && isPostpayUser(user) && customerServiceDetails) {
    customerServiceDetails.forEach((service) => {
      if (service.serviceType === ProductServiceType.VOICE) {
        hasVoiceService = true;
      } else if (isNbnService(service)) {
        hasInternetService = true;
      }
    });
  }

  const path = stripQueryFromPath(asPath);

  if (isInternetPage(path)) {
    return hasVoiceBasketItem || hasVoiceService;
  }
  if (isVoicePage(asPath)) {
    return hasInternetBasketItem || hasInternetService;
  }
  if (isCartPage(path) || isCheckoutPage(path)) {
    return (hasVoiceBasketItem || hasVoiceService) && (hasInternetBasketItem || hasInternetService);
  }
  return false;
};

const useASDEligibility = () => {
  const { asPath } = useRouter();
  const { isAuthenticated, user } = useAuthentication();
  const {
    customerDetails: [customerDetailsState],
  } = useCustomerData();
  const { getBasketState } = useBasketState();

  return useMemo(
    () =>
      calculateASDEligibility(
        asPath,
        isAuthenticated,
        user,
        customerDetailsState.data?.services,
        getBasketState.data?.packages,
      ),
    [asPath, isAuthenticated, user, customerDetailsState.data?.services, getBasketState.data?.packages],
  );
};

export default useASDEligibility;
