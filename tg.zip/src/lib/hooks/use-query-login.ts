import { useEffect, useMemo } from 'react';
import { QueryKey } from '@src/lib/util/query';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { getDefaultLoginParams } from '@src/lib/util/customer';
import { useClientQuery } from '@src/lib/util/router';
import useAuthentication from './use-authentication';

const useQueryLogin = () => {
  const { login, isAuthenticated, loading } = useAuthentication();
  const query = useClientQuery();
  const authQueryMap = useMemo(
    () =>
      new Map<string, ServiceTypeValue.AnotherService | ServiceTypeValue.Upgrade>([
        ['additional-services', ServiceTypeValue.AnotherService],
        ['upgrade', ServiceTypeValue.Upgrade],
      ]),
    [],
  );

  useEffect(() => {
    const authValue = query?.[QueryKey.AUTH] as string | undefined;
    if (!authValue) return;

    const authType = authQueryMap.get(authValue);
    if (!authType) return;

    if (!isAuthenticated && !loading)
      login(
        authType,
        getDefaultLoginParams(),
        authType === ServiceTypeValue.Upgrade
          ? `/upgrade${window.location.pathname}${window.location.search}`
          : undefined,
      );
  }, [authQueryMap, isAuthenticated, loading, login, query]);
};

export default useQueryLogin;
