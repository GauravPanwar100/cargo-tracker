// Usage
// const {
//     isAuthenticated,
//     login,
//     logout,
//     user,
//   } = useAuthentication();
import { useAuthentication } from '@src/lib/context/authentication';

export default useAuthentication;
