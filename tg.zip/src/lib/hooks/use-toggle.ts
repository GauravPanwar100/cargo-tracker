import React from 'react';

/**
 * Custom hook for boolean toggles
 * @param initialValue
 */
export default function useToggle(
  initialValue = false,
): readonly [value: boolean, toggle: () => void, setValue: React.Dispatch<React.SetStateAction<boolean>>] {
  const [value, setValue] = React.useState(initialValue);
  const toggle = React.useCallback(() => setValue((previous) => !previous), []);
  return [value, toggle, setValue];
}
