import { timeout } from '@kablamo/kerosene';
import { waitForRepaint } from '@kablamo/kerosene-ui';
import useIsomorphicLayoutEffect from '@src/lib/hooks/use-isomorphic-layout-effect';
import useMediaQuery from '@src/lib/hooks/use-media-query';
import { noop } from 'lodash';
import React from 'react';
import ReactDOM from 'react-dom';

export default function useCollapsableState(
  open: boolean,
  {
    immediate = false,
    transitionDuration: animatedTransitionDuration = 250,
    transitionTimingFunction = 'ease-in-out',
  }: {
    immediate?: boolean;
    transitionDuration?: number;
    transitionTimingFunction?: React.CSSProperties['transitionTimingFunction'];
  } = {},
) {
  const [render, setRender] = React.useState(open);
  const [transitionDuration, setTransitionDuration] = React.useState(animatedTransitionDuration);
  const [maxHeight, setMaxHeight] = React.useState<number | 'none'>(open ? 'none' : 0);

  const ref = React.useRef<HTMLElement>(null);

  const hasRun = React.useRef(false);
  const prefersReducedMotion = useMediaQuery('(prefers-reduced-motion: reduce)');
  const immediateRef = React.useRef(immediate || prefersReducedMotion);
  immediateRef.current = immediate || prefersReducedMotion;
  const transitionDurationRef = React.useRef(animatedTransitionDuration);
  transitionDurationRef.current = animatedTransitionDuration;
  useIsomorphicLayoutEffect(() => {
    const controller = new AbortController();

    if (immediateRef.current || !hasRun.current) {
      hasRun.current = true;
      if (open) {
        setRender(true);
        setMaxHeight('none');
      } else {
        setRender(false);
        setMaxHeight(0);
      }
    } else if (open) {
      setTransitionDuration(0);

      waitForRepaint({ signal: controller.signal })
        .then(() =>
          // NOTE: `ReactDOM.unstable_batchedUpdates(callback)` is required here to ensure async updates are flushed at
          // the same time as part of the same update
          ReactDOM.unstable_batchedUpdates(() => {
            setTransitionDuration(transitionDurationRef.current);
            setMaxHeight(0);
            setRender(true);
          }),
        )
        .then(() => waitForRepaint({ signal: controller.signal }))
        .then(() => {
          setMaxHeight(ref.current!.scrollHeight);
        })
        .then(() => timeout(transitionDurationRef.current, { signal: controller.signal }))
        .then(() => {
          setMaxHeight('none');
        })
        .catch(noop);
    } else {
      setMaxHeight(ref.current!.scrollHeight);
      setTransitionDuration(transitionDurationRef.current);

      waitForRepaint({ signal: controller.signal })
        .then(() => {
          setMaxHeight(0);
        })
        .then(() => timeout(transitionDurationRef.current, { signal: controller.signal }))
        .then(() => {
          setRender(false);
        })
        .catch(noop);
    }

    return controller.abort.bind(controller);
  }, [open]);

  const style = React.useMemo(
    () => ({
      maxHeight,
      overflow: 'hidden',
      transitionProperty: 'max-height',
      transitionDuration: `${immediate || prefersReducedMotion ? 0 : transitionDuration}ms`,
      transitionTimingFunction,
    }),
    [immediate, maxHeight, prefersReducedMotion, transitionDuration, transitionTimingFunction],
  );

  return { ref, render, style };
}
