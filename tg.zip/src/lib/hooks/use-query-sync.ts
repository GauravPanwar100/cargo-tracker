import { isEqual, pick } from 'lodash';
import { useRouter } from 'next/router';
import { useEffect, useRef } from 'react';
import queryString, { ParsedQuery } from 'query-string';
import { useRouteMeta } from '@src/lib/context/route-meta';
import { RouterMethod, useUpdateQuery } from '@src/lib/util/router';

interface QuerySyncOptions {
  isInvalid?: boolean;
  routerMethod?: RouterMethod;
}

/**
 * Watches an array of values in a useEffect. Any time one of these values updates, update the query
 * params with the new value, or remove the query param if the value is empty
 * @param params A list of key/value tuples corresponding to query params e.g. [color, 'White']
 */
const useQuerySync = (params: [string, string?][], { isInvalid, routerMethod = 'replace' }: QuerySyncOptions = {}) => {
  const router = useRouter();
  const routeMeta = useRouteMeta();
  const updateQuery = useUpdateQuery();
  const keys = params.map(([key]) => key);
  const values = params.map(([, value]) => value);
  const isInitialised = useRef<boolean>(false);
  useEffect(() => {
    if (isInvalid) {
      return;
    }
    const currentQuery = pick(queryString.parse(window.location.search), keys);
    // For each of the params in our list, if the value has changed compared to what is currently
    // in router.query, update that param in our new query
    const query = params.reduce<ParsedQuery>(
      (acc, [key, value]) => {
        // Only do something if the value we are syncing is different to the value currently in the
        // URL query params
        if (value !== router.query[key]) {
          // We don't want an empty param to show up in the URL if there is no value
          const syncedQuery = value ? { [key]: value } : {};

          // eslint-disable-next-line no-param-reassign
          acc = {
            ...acc,
            ...syncedQuery,
          };
        }

        return acc;
      },
      { ...currentQuery },
    );

    const previousPath = routeMeta.previousPath.current;
    const currentPath = routeMeta.currentPath.current;

    if (
      // Compare the current params to the new ones and only replace the route if there have been
      // changes
      !isEqual(currentQuery, query) &&
      (!isInitialised.current || previousPath === currentPath)
    ) {
      isInitialised.current = true;

      updateQuery(query, routerMethod);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...values]);
};

export default useQuerySync;
