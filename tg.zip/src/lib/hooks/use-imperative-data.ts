import { Dispatch, useCallback, useEffect, useMemo, useReducer, useRef } from 'react';
import {
  DataFetchAction,
  DataFetchReducer,
  DataFetchState,
  dataFetchReducer,
  makeFetchData,
} from './data-fetch-reducer';

export type ImperativeDataReturnType<P, R> = [
  DataFetchState<P, R>,
  undefined extends P ? () => Promise<R | undefined> : (params: P) => Promise<R | undefined>,
  Dispatch<DataFetchAction<P, R>>,
];

// Specifying overloads here to allow calls without params where required
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function useImperativeData<P, R>(
  request: (params?: undefined) => Promise<R>,
  delay?: number,
): ImperativeDataReturnType<undefined, R>;

function useImperativeData<P, R>(request: (params: P) => Promise<R>, delay?: number): ImperativeDataReturnType<P, R>;

function useImperativeData<P, R>(request: (params: P) => Promise<R>, delay = 0): ImperativeDataReturnType<P, R> {
  const [state, dispatch] = useReducer<DataFetchReducer<P, R>>(dataFetchReducer, {
    data: null,
    error: null,
    isInitialised: false,
    isLoading: false,
    isSuccess: false,
    params: null,
  });

  const didCancel = useRef<boolean>(false);

  useEffect(() => {
    didCancel.current = false;

    return () => {
      didCancel.current = true;
    };
  }, []);

  // Keep the delay in a static ref so that we don't need to include it as a
  // dependency in the data fetching effect deps array. Changes to the delay
  // param will not re-run the data fetching effect because it only depends on
  // the ref
  const latestDelay = useRef(delay);
  useEffect(() => {
    latestDelay.current = delay;
  }, [delay]);

  // eslint-disable-next-line react-hooks/exhaustive-deps -- unable to lint deps but still works
  const fetchData = useCallback(makeFetchData(request, dispatch, didCancel, latestDelay), [request]);

  return useMemo(() => [state, fetchData, dispatch] as ImperativeDataReturnType<P, R>, [dispatch, fetchData, state]);
}

export default useImperativeData;
