import React, { useCallback } from 'react';
import braintree from 'braintree-web';
import Logger from '@src/lib/logger/logger';
import { getApiClient } from '@src/lib/api';
import useImperativeData from '@src/lib/hooks/use-imperative-data';

const usePayInFourMessaging = () => {
  const ApiClient = getApiClient();
  const [paypalCheckout, setPaypalCheckout] = React.useState<braintree.PayPalCheckout>();
  const [tokenData, getBraintreeToken] = useImperativeData(ApiClient.getBraintreeToken);
  const [client, setClient] = React.useState<braintree.Client>();

  React.useEffect(() => {
    try {
      getBraintreeToken();
    } catch (error) {
      Logger.error('Error retrieving Braintree token');
    }
  }, [getBraintreeToken]);

  React.useEffect(() => {
    if (!tokenData.data) return;

    braintree.client.create({ authorization: tokenData.data.token }).then(
      (c) => setClient(c),
      (error) => {
        Logger.error('Failed to create Braintree client', error);
      },
    );
  }, [tokenData.data]);

  const setCheckout = useCallback(
    (paypalCheckoutInstance) => {
      if (!paypalCheckout) {
        setPaypalCheckout(paypalCheckoutInstance);
      }
    },
    [paypalCheckout],
  );

  React.useEffect(() => {
    if (!client) return;

    braintree.paypalCheckout
      .create({
        client,
      })
      .then(
        (paypalCheckoutInstance) => setCheckout(paypalCheckoutInstance),
        (error) => {
          Logger.error('Failed to create Braintree PayPal Checkout component', { error, ucode: '094b283' });
        },
      );
  }, [client, setCheckout]);

  React.useEffect(() => {
    if (paypalCheckout) {
      paypalCheckout!
        .loadPayPalSDK({
          currency: 'AUD',
          components: 'messages',
        })
        .catch((error) => {
          Logger.error('Failed to load Braintree Paypal SDK', { error, ucode: 'c201602' });
        });
    }
  }, [paypalCheckout]);
};

export default usePayInFourMessaging;
