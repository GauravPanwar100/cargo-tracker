import {
  ADD_EVENT_LISTENER_CAPTURE_PASSIVE_OPTIONS,
  REMOVE_EVENT_LISTENER_CAPTURE_PASSIVE_OPTIONS,
} from '@kablamo/kerosene-ui';
import React from 'react';

const FOCUS_EVENTS = ['blur', 'focus', 'keydown'] as const;

/**
 * Custom hook which returns whether the browser's focus ring is currently visible anywhere in the page.
 *
 * Where possible, just use `:focus:focus-visible` instead of this hook, however, this hook may be required when a focus
 * ring is required on an ancestor of the actually focused element, as browsers do not currently support the `:has()`
 * selector used within `:focus-within:has(:focus:focus-visible)`.
 */
export default function useFocusVisible() {
  const [focusVisible, setFocusVisible] = React.useState(false);

  React.useEffect(() => {
    const isSelectorSupported = CSS.supports('selector(:focus-visible)');

    const update = () => {
      setFocusVisible(
        // If the browser doesn't support the `:focus-visible` selector, just test with `:focus` for accessibility
        !!document.querySelector(isSelectorSupported ? ':focus:focus-visible' : ':focus'),
      );
    };

    FOCUS_EVENTS.forEach((name) => window.addEventListener(name, update, ADD_EVENT_LISTENER_CAPTURE_PASSIVE_OPTIONS));

    update();

    return () =>
      FOCUS_EVENTS.forEach((name) =>
        window.removeEventListener(name, update, REMOVE_EVENT_LISTENER_CAPTURE_PASSIVE_OPTIONS),
      );
  }, []);

  return focusVisible;
}
