import React from 'react';

/**
 * Custom hook which returns a ref that is kept up-to-date with the latest `value`.
 *
 * This hook can be useful when accessing a value inside an effect that you don't want to re-trigger
 * the effect when its object identity changes. This is particularly useful as it allows us to avoid
 * disabling the lint rules for the rules of hooks which can often help catch potential issues.
 *
 * NOTE: Ideally you should seek to fix the changing identity of the value first, but if that is
 * unavoidable then this hook can be used.
 *
 * @param value
 */
export default function useUpdatingRef<T>(value: T): React.MutableRefObject<T> {
  const ref = React.useRef(value);
  ref.current = value;
  return ref;
}
