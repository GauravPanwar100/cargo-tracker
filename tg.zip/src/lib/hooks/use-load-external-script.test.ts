import { act, renderHook } from '@testing-library/react-hooks';
import useLoadExternalScript, { LoadScriptState } from '@src/lib/hooks/use-load-external-script';
import { fireEvent } from '@testing-library/react';

describe('useLoadExternalScript', () => {
  beforeEach(() => {
    const html = document.querySelector('html');
    if (html) {
      html.innerHTML = '';
    }
  });

  it('should append a script tag ', () => {
    expect(document.querySelectorAll('script').length).toBe(0);

    renderHook(() => useLoadExternalScript('http://scriptsrc/'));
    const scriptElement = document.querySelector('script');

    expect(scriptElement).not.toBeNull();
    if (scriptElement) {
      expect(scriptElement.getAttribute('src')).toEqual('http://scriptsrc/');
    }
  });

  it('should return { loaded: true, error: false } when loaded', () => {
    const { result } = renderHook(() => useLoadExternalScript('http://scriptsrc/'));
    const scriptElement = document.querySelector('script');

    act(() => {
      fireEvent.load(scriptElement!);
    });

    const { loaded, error }: LoadScriptState = result.current;

    expect(loaded).toBe(true);
    expect(error).toBe(false);
  });

  it('should return { loaded: false, error: true } when error', () => {
    const { result } = renderHook(() => useLoadExternalScript('http://scriptsrc/'));
    const scriptElement = document.querySelector('script');

    act(() => {
      fireEvent.error(scriptElement!);
    });

    const { loaded, error }: LoadScriptState = result.current;

    expect(loaded).toBe(false);
    expect(error).toBe(true);
  });
});
