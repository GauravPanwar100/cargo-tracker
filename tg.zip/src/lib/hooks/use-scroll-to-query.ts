import { ElementType } from '@kablamo/kerosene';
import { noop } from 'lodash';
import { useEffect } from 'react';
import { isElementInViewport, scrollElementIntoView } from '@src/lib/util/dom';
import { QueryKey } from '@src/lib/util/query';
import { useClientQuery } from '@src/lib/util/router';

/**
 * This defines precedence if multiple query keys are present, so only the first present value will be used
 */
const SCROLLABLE_QUERY_KEY_PRIORITIES = [QueryKey.HERO, QueryKey.ACCORDION, QueryKey.TAB] as const;

interface UseScrollToQueryParams {
  queryKey: ElementType<typeof SCROLLABLE_QUERY_KEY_PRIORITIES>;
  doNotScrollIfVisible?: boolean;
  queryValueToQuerySelector?: (queryValue: string) => string | undefined;
  rootRef?: React.RefObject<Pick<Element, 'querySelector' | 'querySelectorAll'>>;
}

const useScrollToQuery = ({
  queryKey,
  doNotScrollIfVisible,
  queryValueToQuerySelector,
  rootRef,
}: UseScrollToQueryParams) => {
  const query = useClientQuery();

  // In the order of priority, check which `QueryKey`s have values. If `queryKey` refer to the highest priority with a value present it will be ignored.
  const isHighestPriorityForScrolling = SCROLLABLE_QUERY_KEY_PRIORITIES.find((key) => !!query?.[key]) === queryKey;

  let queryValue = isHighestPriorityForScrolling ? (query?.[queryKey] as string | undefined) : undefined;
  if (queryValue && queryValueToQuerySelector) {
    queryValue = queryValueToQuerySelector(queryValue);
  } else if (queryValue) {
    queryValue = `#${queryValue}`;
  }

  const scrollToQueryElement = () => {
    const root = rootRef?.current ?? document;
    // Find the first matching visible element
    const element = Array.from(root.querySelectorAll(`${queryValue}`) as NodeListOf<HTMLElement>).find(
      // `element.offsetParent` will be null if it or an ancestor is `display: none`
      (el) => el?.offsetParent !== null,
    ) as HTMLElement | undefined;

    if (element && doNotScrollIfVisible && !isElementInViewport(element)) scrollElementIntoView(element, -24);
  };

  useEffect(() => {
    if (!queryValue) return noop;
    const handle = setTimeout(scrollToQueryElement, 1500);
    return () => clearTimeout(handle);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- only run for queryValue changes
  }, [queryValue]);
};

export default useScrollToQuery;
