import React from 'react';
import { useDebounce } from '@react-hook/debounce';

interface WindowState {
  height: number | undefined;
  width: number | undefined;
}

const getHeight = () => (typeof window !== 'undefined' ? window.innerHeight : undefined);
const getWidth = () => (typeof window !== 'undefined' ? window.innerWidth : undefined);

const useWindowSize = () => {
  // NOTE: We get initial values on first render here so that we can use the information immediately
  // if the component was rendered for the first time client side, to minimise jank. We also split
  // values out into primitives here instead of an object containing both height and width so that
  // we avoid unnecessary re-renders due to different object identity
  const [height, setDebouncedHeight] = useDebounce(getHeight);
  const [width, setDebouncedWidth] = useDebounce(getWidth);

  React.useEffect(() => {
    const handleResize = () => {
      setDebouncedHeight(getHeight());
      setDebouncedWidth(getWidth());
    };

    handleResize();

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [setDebouncedHeight, setDebouncedWidth]);

  return React.useMemo<WindowState>(() => ({ height, width }), [height, width]);
};

export default useWindowSize;
