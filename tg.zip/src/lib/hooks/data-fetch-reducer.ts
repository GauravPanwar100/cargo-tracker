/* eslint-disable indent */
import { timeout } from '@kablamo/kerosene';
import { Dispatch, MutableRefObject, Reducer, RefObject } from 'react';
import Logger, { LoggerExtras } from '@src/lib/logger/logger';

export type DataFetchState<P, R> = {
  data: R | null;
  error: Error | null;
  isInitialised: boolean;
  isLoading: boolean;
  isSuccess: boolean;
  params: P | null;
};

export type DataFetchAction<P, R> =
  | { type: 'FETCH_INIT'; payload: P }
  | { type: 'FETCH_SUCCESS'; payload: R | null }
  | { type: 'FETCH_FAILURE'; payload?: Error }
  | { type: 'CLEAR_DATA' }
  | { type: 'CLEAR_ERROR' };

export type DataFetchReducer<P, R> = Reducer<DataFetchState<P, R>, DataFetchAction<P, R>>;

export const dataFetchReducer = <P, R>(
  state: DataFetchState<P, R>,
  action: DataFetchAction<P, R>,
): DataFetchState<P, R> => {
  switch (action.type) {
    case 'FETCH_INIT':
      return {
        ...state,
        error: null,
        isInitialised: true,
        isLoading: true,
        isSuccess: false,
        params: action.payload,
      };
    case 'FETCH_SUCCESS':
      return {
        ...state,
        error: null,
        isLoading: false,
        isSuccess: true,
        data: action.payload,
      };
    case 'FETCH_FAILURE':
      return {
        ...state,
        error: action.payload || null,
        isLoading: false,
        isSuccess: false,
      };
    case 'CLEAR_DATA':
      return {
        ...state,
        data: null,
      };
    case 'CLEAR_ERROR':
      return {
        ...state,
        error: null,
      };
    default:
      throw new Error();
  }
};

export const makeFetchData =
  <P, R>(
    request: (params: P) => Promise<R>,
    dispatch: Dispatch<DataFetchAction<P, R>>,
    didCancel: RefObject<boolean>,
    delay: MutableRefObject<number>,
  ) =>
  async (params: P): Promise<R | void | undefined> => {
    dispatch({ type: 'FETCH_INIT', payload: params });

    try {
      const payload = await request(params);

      if (delay.current) await timeout(delay.current);

      if (!didCancel.current) {
        dispatch({ type: 'FETCH_SUCCESS', payload });
      }

      return payload;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      const payload = error.message ? error : new Error('request error');

      if (delay.current) await timeout(delay.current);

      const extras: LoggerExtras = {
        ucode: 'b20aa04',
        error: payload,
      };
      Logger.error(`Data fetch error (${payload.message})`, extras);
      if (!didCancel.current) {
        dispatch({ type: 'FETCH_FAILURE', payload });
      }
      return undefined;
    }
  };
