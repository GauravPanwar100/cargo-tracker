export const DEVICE_LISTING =
  "Unfortunately we can't display our devices at the moment. Please refresh this page or try again later.";
export const ADD_ITEM_TO_CART =
  'Unfortunately, due to a technical issue we were unable to add this item. Please try again.';
export const ADD_NON_SAMSUNG_ITEM_TO_CART =
  'To checkout with your Vodafone Samsung plan, remove all other items from your cart.';
export const REMOVE_ITEM_FROM_CART =
  "Unfortunately, due to a technical issue we haven't removed an item from your cart. Please try again.";
export const REMOVE_ITEMS_FROM_CART =
  "Unfortunately, due to a technical issue we haven't removed items from your cart. Please try again.";
export const DELIVERY_DATE_UNAVAILABLE =
  '&lt;p&gt;Unfortunately, due to a technical issue, we can&rsquo;t display the estimated delivery date. However, once we&rsquo;ve processed your order, you&rsquo;ll be sent a confirmation email with a tracking number so you can check your delivery details.&nbsp;&nbsp;&lt;/p&gt;';
export const AEM_UNAVAILABLE_ERROR_TITLE = 'Something didn’t go as planned';
export const AEM_UNAVAILABLE_ERROR_DESCRIPTION =
  'Unfortunately, due to a technical issue, this page is currently unavailable. Please refresh this page or try again later.';
export const DELIVERY_UPDATES_OPTION_UNAVAILABLE =
  '&lt;p&gt;Please select a delivery update option to continue.&nbsp;&lt;/p&gt;';
export const COMMON_ERROR_HEADER = 'Page not available';
export const COMMON_ERROR_DESCRIPTION =
  '&lt;p&gt;Unfortunately due to a technical issue, this page is currently unavailable. Please refresh this page or try again later.&nbsp;&lt;/p&gt;';
export const COMMON_ERROR_BTN_TEXT = 'Go to Home';
