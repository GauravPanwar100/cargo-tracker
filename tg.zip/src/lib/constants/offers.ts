export const OfferTypeIdentifier = {
  STUDENT: 'student',
};
