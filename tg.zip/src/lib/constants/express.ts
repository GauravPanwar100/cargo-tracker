export enum ExpressJourneySlug {
  /**
   * a.k.a. Phone & Plan, Handset, or Upgrade Device
   */
  PHONE_AND_PLAN = 'upgrade-device',
  /**
   * a.k.a. SIM Only, or Upgrade Plan
   */
  SIMO = 'upgrade-plan',
  /**
   * a.k.a. Rate-Plan-Change, or Change Plan
   */
  RPC = 'change-plan',
}

export const EXPRESS_JOURNEY_SLUGS = Object.values(ExpressJourneySlug);

// [SHOP-7068] If we get the below message as data_err_reas we treat it as offer expiry
export const OFFER_EXPIRY_MSG = 'Offer recommendation for the subscription expired';

// This HID is used to return the mock data for EU
export const mockHashID = 'EUVALIDORDER';

export enum MorePlanInfoIdentifier {
  TWO_MBPS = 'EU-2Mbps',
  TEN_MBPS = 'EU-10Mbps',
  TWENTY_FIVE_MBPS = 'EU-25Mbps',
  EU_UNLIMITED = 'EU-Unlimited',
  EU_SPEED = 'EU-speed',
  CAMPAIGN_EXPIRY_BAU = 'EU-CAMPAIGN-EXPIRY-BAU',
  CAMPAIGN_EXPIRY_CARE = 'EU-CAMPAIGN-EXPIRY-CARE',
  PHONE_PLANS_PRIVACY_POLICY = 'EU-PHONEPLANS-PRIVACY-POLICY',
  SIMO_PRIVACY_POLICY = 'EU-SIMO-PRIVACY-POLICY',
  RPC_PRIVACY_POLICY = 'EU-RPC-PRIVACY-POLICY',
  UNLIMITED = 'unlimited',
}

export const DATA_CALLOUT_PREFIX = '-data-callout';
