export const TRADEMARK = '&trade;';
