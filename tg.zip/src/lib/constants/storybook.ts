export const Sections = {
  CORE: 'Core',
  VFE: 'VFE',
  SAS: 'SAS',
  TEMPLATES: 'Templates',
};
