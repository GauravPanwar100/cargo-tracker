import { CatalogCode } from '@src/lib/api/types';

export const PlansRefreshCatalogs = [
  CatalogCode.POSTPAID_HANDSET_PLANS,
  CatalogCode.POSTPAID_SIMO_PLANS,
  CatalogCode.POSTPAID_SIMO_TPG_SM,
];
