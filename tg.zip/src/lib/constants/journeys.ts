export enum PostpaidPlanAndMobilePhone {
  PLAN = 0,
  MOBILE_PHONES = 1,
  MOBILE_PHONE = 2,
  EXTRAS = 3,
}

export enum PostpaidMobilePhoneAndPlan {
  MOBILE_PHONE = 0,
  PLAN = 1,
  EXTRAS = 2,
}

export enum PostpaidSIMOPlan {
  PLAN = 0,
  EXTRAS = 1,
}

export enum PostpaidTabletSIMOPlan {
  PLAN = 0,
  EXTRAS = 1,
}

export enum PostpaidTabletAndPlan {
  TABLET = 0,
  PLAN = 1,
  EXTRAS = 2,
}

export enum PostpaidModemAndPlan {
  MODEM = 0,
  PLAN = 1,
  EXTRAS = 2,
}

export enum SmartWatchDetails {
  WATCH = 0,
  EXTRAS = 1,
}

export enum PrepaidDevices {
  MOBILE_PHONE = 0,
  EXTRAS = 1,
}
