export const PLANS_PAGE = '/plans';
export const SIMO_PLANS_PAGE = '/mobile/sim-only-phone-plans';
export const SIMO_MBB_PLANS_PAGE = '/tablets/plans';
export const PREPAID_PLANS_PAGE = '/prepaid/plans';
export const PAY_AND_GO_PLANS_PAGE = '/prepaid/pay-and-go';

export const NBN_PAGE = '/home-internet/nbn';
export const FHW_4G_PAGE = '/home-internet/4g';
export const FHW_5G_PAGE = '/home-internet/5g';

export const MOBILE_LISTING_PAGE = '/mobile/mobile-phones';
export const TABLET_LISTING_PAGE = '/mobile/tablets';

export const CART_PAGE = '/cart';
export const CHECKOUT_PAGE = '/checkout';

export const DOWN_PAGE = '/down';

export const ANOTHER_SERVICE_PAGE = '/another-service';
export const UPGRADE_PAGE = '/upgrade';

export const LOGIN_PAGE = '/login';
export const LOGOUT_PAGE = '/logout';
