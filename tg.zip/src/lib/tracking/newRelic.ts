import { LocalStorageClient } from '@src/lib/storage/';

class NewRelic {
  public constructor() {
    window.newrelic = window.newrelic || [];
  }

  static setCurrentRouteName(path: string | undefined) {
    if (window.newrelic !== []) {
      window.newrelic?.setCurrentRouteName(path);
      this.saveServiceType();
      this.saveInteraction();
    }
  }

  static saveInteraction() {
    if (window.newrelic !== []) {
      window.newrelic?.interaction().save();
    }
  }

  static saveServiceType() {
    if (window.newrelic !== []) {
      window.newrelic?.interaction().setAttribute('serviceType', LocalStorageClient.getServiceType());
    }
  }
}

export default NewRelic;
