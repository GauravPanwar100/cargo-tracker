import { SasProductDevice, SasProductPlan } from '@src/lib/ci360/use-sas-product-list';
import { MergedUnion } from '@src/lib/types';

export type TrackingBoolean = 'true' | 'false';
export type OptionalTrackingBoolean = TrackingBoolean | '';

interface DeviceProductInfo {
  deviceBrand?: string;
  deviceCapacity?: string;
  deviceCatalog?: string;
  deviceColor?: string;
  deviceImageUrl?: string;
  deviceMinCost?: number;
  deviceName?: string;
  deviceRRP?: number;
  deviceSku?: string;
  deviceSubType?: string;
  /**
   * e.g. `"36"`
   */
  deviceTerm?: string;
  deviceType?: string;
  deviceBandColor?: string;
  deviceBandSize?: string;
  deviceCaseSize?: string;
  deviceBandName?: string;
}

interface PlanProductInfo {
  planCatalog?: string;
  planData?: string;
  planName?: string;
  planPrice?: number;
  planSku?: string;
  planSubType?: string;
  /**
   * e.g. `"1"`
   */
  planTerm?: string;
  planType?: string;
}

export interface ExtraInfo {
  extraName?: string;
  extraPrice?: number;
  extraSku?: string;
  extraTerm?: string;
}

export interface PackageInfo {
  productInfo: PlanProductInfo &
    DeviceProductInfo & {
      extras?: readonly ExtraInfo[];
    };
}

export interface DeviceDetails {
  catalogue?: string;
  deviceCode?: string;
  deviceType?: string;
  deviceSubType?: string;
  deviceName?: string;
  deviceColor?: string;
  deviceCapacity?: string;
  deviceSku?: string;
  deviceBrand?: string;
  deviceTerm?: string;
  deviceMinCost?: number;
  deviceImageUrl?: string;
  deviceCaseSize?: string;
  deviceBandName?: string;
  deviceBandSize?: string;
  deviceBandColor?: string;
}

export interface EventResponse {
  /**
   * This field should be `vca/${window.location.pathname}`
   */
  pageEventName: string;
  pageEventType: string;
  pageEventValue: string;
  /**
   * This field generally will be the kebab-case of the CTA/label that triggered the event
   */
  pageEventAttributeOne?: string;
  pageEventAttributeTwo?: string;
  pageEventAttributeThree?: string;
  /**
   * This field should be `${window.location.pathname}${window.location.search}${window.location.hash}`
   */
  path: string;
  basketSize?: number;
  catalogueNames?: string[];
  transactionAmount?: number;
  product?: readonly PackageInfo[];
  stickyCart?: readonly PackageInfo[];
  order?: ExpressUpgradesOrder;
  device?: SasProductDevice;
  plan?: SasProductPlan;
  totalCost?: number;
  totalMonthlyCost?: number;
}

export interface TrackedServiceDetails {
  msisdn: string;
  serviceType: string;
  upgradeEligible: TrackingBoolean;
  /**
   * Should be specified _if_ and _only if_ `upgradeEligible` is false
   */
  upgradeEligibleReason?: string;
  /**
   * Should be specified _if_ and _only if_ `upgradeEligible` is false
   */
  upgradeEligibleDescription?: string;
  planChangeEligible: TrackingBoolean;
  addServiceEligible: TrackingBoolean;
}

export interface PlainPageResponse {
  pageTitle: string;
  path: string;
  nudgeReferrer: string;
  product?: readonly PackageInfo[];
  stickyCart?: readonly PackageInfo[];
}

export interface ExpressUpgrades {
  order?: ExpressUpgradesOrder;
  hashedId: string | null;
}

export interface ExpressUpgradesOrder {
  orderType: string;
  orderID: string;
  orderDateTime: string;
  msisdn: string;
  dealerCode: string;
  channel: string;
}

export type AutomaticPageTrackFields = {
  deviceId: string;
  customerAccountId: string;
  activeMsisdn: string;
  accountType: string;
  /**
   * Even though this will be present in the `services[]` array for the `activeMsisdn`, Zed has requested that this also
   * be provided at a top-level for consistency with OmniOut tracking (which only tracks the active service).
   * @see VFE-1839
   */
  serviceType: string;
  loginStatus: TrackingBoolean;
  services?: readonly TrackedServiceDetails[];
  intlPassportHolder: OptionalTrackingBoolean;
  overdue: OptionalTrackingBoolean;
} & MergedUnion<
  // Upgrade-specific fields
  | {
      mppGppTotalCost?: string;
      planTerm?: string;
      planInformation?: string;
      propositionIdentifier?: string;
      planMonthsRemaining?: string;
      planMonthlyCost?: string;
      mppGppMonthlyAmount?: string;
      totalMonthlyCost?: string;
      mppGppTerms?: string;
      mppGppStartDate?: string;
      mppGppEndDate?: string;
      monthsRemaining?: string;
      mppGppRemaining?: string;
      equipmentLimitRemaining?: string;
      equipmentLimitUsed?: string;
      approvedConnections?: string;
      maximumConnections?: string;
      liveConnections?: string;
    }
  | {}
> &
  MergedUnion<
    // Additional services specific fields
    | {
        bundleAndSaveEligibleCount?: string;
        bundleAndSaveIneligibleCount?: string;
      }
    | {}
  >;

export type PageResponse = PlainPageResponse & AutomaticPageTrackFields;

export type PlainDeviceDetailsPage = PlainPageResponse & DeviceDetails;

export type PlainExpressUpgradesPage = PlainPageResponse & ExpressUpgrades;

export type DeviceDetailsPage = PlainDeviceDetailsPage & AutomaticPageTrackFields;

export enum TrackingEvents {
  page = 'pageTrack',
  event = 'eventTrack',
}

export interface TrackingData {
  event: TrackingEvents.page | TrackingEvents.event;
  path?: string;
  response: EventResponse | PageResponse;
}
