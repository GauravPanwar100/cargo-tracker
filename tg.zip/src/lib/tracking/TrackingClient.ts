import { TrackingData } from './types';

class TrackingClient {
  public constructor() {
    window.aepData = window.aepData || [];
    window.gtmData = window.gtmData || [];
  }

  public pushEvent = (data: TrackingData) => {
    window.aepData.push(data);
    window.gtmData.push(data);
  };
}

export default TrackingClient;
