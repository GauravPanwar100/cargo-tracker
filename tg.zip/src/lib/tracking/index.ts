import { useRouter } from 'next/router';
import { useCallback, useContext, useEffect, useRef, useState } from 'react';
import Cookies from 'universal-cookie';
import { sleep } from '@src/common/js/sleep';
import {
  Basket,
  BasketItem,
  BasketPackage,
  BasketParams,
  BasketRequestItem,
  CartItemType,
  CurrentServiceData,
  CustomerDetails,
  CustomerProductsEligibility,
  ModemBasketItem,
  ModemChildBasketRequestItem,
} from '@src/lib/api/types';
import { User, useAuthentication } from '@src/lib/context/authentication';
import { BASKET_STATE_FOR_EVENT_TRACKING, useBasketState } from '@src/lib/context/basket';
import { useCustomerData } from '@src/lib/context/customer-data';
import { STICKY_CART_FOR_EVENT_TRACKING, StickyCartStateContext } from '@src/lib/context/sticky-cart';
import { DataFetchState } from '@src/lib/hooks/data-fetch-reducer';
import useServiceType from '@src/lib/hooks/use-service-type';
import useUpdatingRef from '@src/lib/hooks/use-updating-ref';
import { LocalStorageClient } from '@src/lib/storage';
import { ServiceTypeValue } from '@src/lib/storage/types';
import TrackingClient from '@src/lib/tracking/TrackingClient';
import {
  DeviceDetailsPage,
  EventResponse,
  ExtraInfo,
  OptionalTrackingBoolean,
  PackageInfo,
  PageResponse,
  PlainDeviceDetailsPage,
  PlainExpressUpgradesPage,
  PlainPageResponse,
  TrackingEvents,
} from '@src/lib/tracking/types';
import { MergedUnion } from '@src/lib/types';
import {
  isDeviceBasketItem,
  isModemBasketItem,
  isPlanBasketItem,
  isWearableDeviceBasketItem,
} from '@src/lib/util/cart';
import { isServiceOfType, useCustomerEligibilityLoading } from '@src/lib/util/customer';
import { isAnchorSameTarget, isNormalClick } from '@src/lib/util/dom';

let client: TrackingClient;

const pushEvent = (
  response: PageResponse | DeviceDetailsPage | EventResponse,
  eventType: TrackingEvents.page | TrackingEvents.event,
) => {
  (client = client ?? new TrackingClient()).pushEvent({
    event: eventType,
    response,
  });
};

const toOptionalTrackingBoolean = (value?: boolean): OptionalTrackingBoolean => {
  if (typeof value !== 'boolean') return '';
  return value ? 'true' : 'false';
};

const NON_DIGIT_REGEX = /\D/g;
export const formatBundleForTracking = (items: readonly (BasketRequestItem | BasketItem)[]) => {
  const plan = items.find(isPlanBasketItem);
  const device = items.find(isDeviceBasketItem) || items.find(isWearableDeviceBasketItem);
  const modem: ModemBasketItem | ModemChildBasketRequestItem | undefined =
    items.find(isModemBasketItem) ??
    (plan as MergedUnion<Exclude<typeof plan, undefined>> | undefined)?.childProducts?.find(
      (child): child is ModemChildBasketRequestItem => isModemBasketItem(child),
    );
  const deviceTerm = (device ?? modem)?.productConfig?.contractTerm?.replace(NON_DIGIT_REGEX, '');
  const recurringCharge = (device ?? modem)?.priceInfo.recurringCharge;
  const deviceMinCost = deviceTerm && recurringCharge ? parseInt(deviceTerm, 10) * recurringCharge : undefined;
  const extras: readonly ExtraInfo[] = [
    ...items,
    ...((plan as MergedUnion<Exclude<typeof plan, undefined>> | undefined)?.childProducts ?? []),
    ...((device as MergedUnion<Exclude<typeof device, undefined>> | undefined)?.childProducts ?? []),
  ]
    .filter((item) => [CartItemType.ADDON, CartItemType.EXTRA].includes(item.itemType))
    .map((item) => ({
      extraSku: item.productCode,
      extraName: item.productName,
      extraPrice: item.priceInfo.recurringCharge || item.priceInfo.oneTimeCharge,
    }));
  const productInformation = {
    productInfo: {
      planCatalog: plan?.catalogCode,
      planData: plan?.relatedContent?.planData,
      planName: plan?.productName,
      planPrice: plan?.priceInfo.recurringCharge || plan?.priceInfo.oneTimeCharge,
      planSku: plan?.productCode,
      planSubType: plan?.productSubType,
      planTerm: plan?.productConfig?.contractTerm,
      planType: plan?.productType,
      deviceBrand: device?.manufacturer ?? modem?.relatedContent?.modemName,
      deviceCapacity: device?.productConfig?.capacity,
      deviceCatalog: (device ?? modem)?.catalogCode,
      deviceColor: device?.productConfig?.color,
      deviceImageUrl: (device ?? modem)?.productConfig?.imageUrl,
      deviceMinCost,
      deviceName: (device ?? modem)?.productName,
      deviceRRP: deviceMinCost ? Math.ceil(deviceMinCost) : undefined,
      deviceSku: (device ?? modem)?.productConfig?.deviceSku,
      deviceSubType: device?.productSubType ?? modem?.productSubType,
      deviceTerm,
      deviceType: (device ?? modem)?.productType,
      extras: extras.length > 0 ? extras : undefined,
      deviceBandColor: device?.productConfig?.bandColor,
      deviceBandName: device?.productConfig?.bandName,
      deviceCaseSize: device?.productConfig?.caseSize,
      deviceBandSize: device?.productConfig?.bandSize,
    },
  };
  return productInformation;
};

export const formatBundles = (bundles?: readonly BasketPackage[]): readonly PackageInfo[] | undefined => {
  if (!bundles?.length) return undefined;
  return bundles.map(({ items }) => formatBundleForTracking(items));
};

export const shouldTrackUpgradeDetails = (asPath: string, serviceType: ServiceTypeValue | undefined): boolean => {
  if (asPath.startsWith('/upgrade')) return true;
  if (serviceType === ServiceTypeValue.Upgrade && asPath.startsWith('/cart')) return true;
  return false;
};

/**
 * NOTE: This conditional was originally inlined in `useImperativeTrackPage`, but has been pulled out into its own
 * function due to `eslint-plugin-react-hooks` tripping on a false-positive for conditionally calling hooks due to some
 * sort of bug in the ESLint parser which seems to be triggered by heavy use of certain syntax features like optional
 * chaining, nullish coalescing, ternaries and object-rest-spread. If you see `react-hooks/rules-of-hooks` tripping
 * unexpectedly, this may be why.
 */
const isReadyToTrack = ({
  loading,
  isAuthenticated,
  user,
  serviceType,
  trackUpgradeDetails,
  currentServiceDataState,
  customerDetailsState,
  upgradePlanEligibilityState,
  waitingForBasket,
  getBasketState,
}: {
  loading: boolean;
  isAuthenticated: boolean;
  user: User | undefined;
  serviceType: ServiceTypeValue | undefined;
  trackUpgradeDetails: boolean;
  currentServiceDataState: DataFetchState<{ activeMsisdn: string }, CurrentServiceData>;
  customerDetailsState: DataFetchState<undefined, CustomerDetails>;
  upgradePlanEligibilityState: DataFetchState<{ activeMsisdn: string }, CustomerProductsEligibility>;
  waitingForBasket: boolean;
  getBasketState: DataFetchState<BasketParams, Basket>;
}) =>
  !waitingForBasket &&
  !getBasketState.isLoading &&
  !loading &&
  (!isAuthenticated ||
    (!!user &&
      !!serviceType &&
      (!trackUpgradeDetails || currentServiceDataState.isSuccess || !!currentServiceDataState.error) &&
      (customerDetailsState.isSuccess || !!customerDetailsState.error) &&
      (upgradePlanEligibilityState.isSuccess || !!upgradePlanEligibilityState.error)));

export const useImperativeTrackPage = () => {
  const { loading, isAuthenticated, user } = useAuthentication();
  const {
    activeMsisdn,
    activeService,
    // This data is fetched automatically when authenticated in the CustomerDataProvider
    customerDetails: [customerDetailsState],
    currentServiceData: [currentServiceDataState],
    upgradePlanEligibility: [upgradePlanEligibilityState],
  } = useCustomerData();
  const { asPath } = useRouter();
  const [serviceType] = useServiceType();

  const isReadyToLoadBasket = !useCustomerEligibilityLoading();
  const stickyCartState = useContext(StickyCartStateContext);
  const { getBasketState, getBasket } = useBasketState();
  const [waitingForBasket, setWaitingForBasket] = useState(true);
  useEffect(() => {
    if (getBasketState.isSuccess || getBasketState.error) {
      setWaitingForBasket(false);
    }
  }, [getBasketState.error, getBasketState.isSuccess]);
  useEffect(() => {
    if (!isReadyToLoadBasket || !waitingForBasket || getBasketState.isInitialised) return;
    const basketId = LocalStorageClient.getBasketId();
    if (!basketId) {
      setWaitingForBasket(false);
      return;
    }
    getBasket({ basketId });
  }, [getBasket, getBasketState.isInitialised, isReadyToLoadBasket, waitingForBasket]);

  const trackUpgradeDetails = shouldTrackUpgradeDetails(asPath, serviceType);
  const trackAdditionalServiceDetails = isServiceOfType(serviceType, ServiceTypeValue.AnotherService);
  const readyToTrack = isReadyToTrack({
    loading,
    isAuthenticated,
    user,
    serviceType,
    trackUpgradeDetails,
    currentServiceDataState,
    customerDetailsState,
    upgradePlanEligibilityState,
    waitingForBasket,
    getBasketState,
  });
  const readyToTrackRef = useUpdatingRef(readyToTrack);

  const automaticFields = useUpdatingRef({
    stickyCart: stickyCartState?.stickyCart.length
      ? ([formatBundleForTracking(stickyCartState.stickyCart)] as ReturnType<typeof formatBundles>)
      : undefined,
    product: formatBundles(getBasketState.data?.packages),
    path: asPath,
    deviceId: new Cookies().get('v_deviceid') ?? '',
    customerAccountId: customerDetailsState.data?.customerAccountId ?? '',
    activeMsisdn: activeMsisdn ?? '',
    accountType: user?.['https://auth.vodafone.com.au/accounttype'] ?? '',
    serviceType: activeService?.serviceType ?? '',
    loginStatus: isAuthenticated ? 'true' : 'false',
    services:
      isAuthenticated && user
        ? customerDetailsState.data?.services.map(
            (service) =>
              ({
                msisdn: service.msisdn,
                serviceType: service.serviceType ?? '',
                upgradeEligible: service.eligibilityIndicator ? 'true' : 'false',
                reasonCode: service.eligibilityIndicator === false ? service.eligibility?.reasonCode : undefined,
                reasonDescription:
                  service.eligibilityIndicator === false ? service.eligibility?.reasonDescription : undefined,
                planChangeEligible: service.permitPlanChangeIndicator ? 'true' : 'false',
                addServiceEligible: service.additionalServiceEligibility ? 'true' : 'false',
              } as const),
          )
        : undefined,
    intlPassportHolder: toOptionalTrackingBoolean(upgradePlanEligibilityState.data?.internationalPassport),
    overdue: toOptionalTrackingBoolean(upgradePlanEligibilityState.data?.internationalPassport),
    ...(trackUpgradeDetails && {
      mppGppTotalCost: currentServiceDataState.data?.phone?.contractAmount?.toString() ?? '',
      planTerm: currentServiceDataState.data?.plan?.contractTerm?.toString() ?? '',
      planInformation: upgradePlanEligibilityState.data?.planProductName ?? '',
      propositionIdentifier: upgradePlanEligibilityState.data?.propositionIdentifier ?? '',
      planMonthsRemaining: upgradePlanEligibilityState.data?.monthsRemaining ?? '',
      planMonthlyCost: currentServiceDataState.data?.plan?.monthlyCharge.toString() ?? '',
      mppGppMonthlyAmount: currentServiceDataState.data?.phone?.monthlyCharge.toString() ?? '',
      totalMonthlyCost: currentServiceDataState.data?.totalCost?.toString() ?? '',
      mppGppTerms: currentServiceDataState.data?.phone?.contractTerm?.toString() ?? '',
      mppGppStartDate: currentServiceDataState.data?.phone?.startDate ?? '',
      mppGppEndDate: currentServiceDataState.data?.phone?.endDate ?? '',
      monthsRemaining: currentServiceDataState.data?.phone?.monthlyRemaining?.toString() ?? '',
      mppGppRemaining: currentServiceDataState.data?.phone?.balanceAmount?.toString() ?? '',
      equipmentLimitRemaining: customerDetailsState.data?.equipmentLimitRemaining ?? '',
      equipmentLimitUsed: customerDetailsState.data?.equipmentLimitUsed ?? '',
      approvedConnections: customerDetailsState.data?.approvedConnections ?? '',
      maximumConnections: customerDetailsState.data?.maximumConnections ?? '',
      liveConnections: customerDetailsState.data?.liveConnections ?? '',
    }),
    ...(trackAdditionalServiceDetails && {
      bundleAndSaveEligibleCount:
        customerDetailsState.data?.services.filter((service) => service.bundleAndSaveEligible).length.toString() ?? '',
      bundleAndSaveIneligibleCount:
        customerDetailsState.data?.services.filter((service) => !service.bundleAndSaveEligible).length.toString() ?? '',
    }),
  } as const);

  const queue = useRef<(PlainPageResponse | PlainDeviceDetailsPage | PlainExpressUpgradesPage)[]>([]);
  const trackPage = useCallback(
    (response: PlainPageResponse | PlainDeviceDetailsPage | PlainExpressUpgradesPage) => {
      if (readyToTrackRef.current) {
        // Push the event immediately
        pushEvent({ ...response, ...automaticFields.current }, TrackingEvents.page);
      } else {
        // Push the response to a queue to be pulled from once eligibility info is ready
        queue.current.push(response);
      }
    },
    [automaticFields, readyToTrackRef],
  );
  useEffect(() => {
    if (!readyToTrack) return;

    while (queue.current.length) {
      pushEvent({ ...queue.current.shift()!, ...automaticFields.current }, TrackingEvents.page);
    }
  }, [automaticFields, readyToTrack]);

  return trackPage;
};

export const useTrackPage: ReturnType<typeof useImperativeTrackPage> = (response) => {
  const trackPage = useImperativeTrackPage();

  const hasTracked = useRef(false);
  useEffect(() => {
    if (hasTracked.current) return;

    trackPage(response);

    hasTracked.current = true;
  }, [response, trackPage]);
};

/**
 * These fields are automatically included with every event track with consistent rules.
 * They can still be overriden if required.
 */
const captureAutomaticEventFields = () => ({
  pageEventName: `vca${window.location.pathname}`,
  path: `${window.location.pathname}${window.location.search}${window.location.hash}`,
  // NOTE: Even though this might still be loading at the time we track the event, we don't want to wait like we do for
  // page tracking as this may be for an 'outbound link' where we only have a very limited time before navigating away
  // from the current page and not tracking the event entirely.
  product: formatBundles(BASKET_STATE_FOR_EVENT_TRACKING.basket?.packages),
  stickyCart: STICKY_CART_FOR_EVENT_TRACKING.stickyCart.length
    ? ([formatBundleForTracking(STICKY_CART_FOR_EVENT_TRACKING.stickyCart)] as ReturnType<typeof formatBundles>)
    : undefined,
});

export const trackEvent = (
  response: Omit<EventResponse, keyof ReturnType<typeof captureAutomaticEventFields>> &
    Partial<ReturnType<typeof captureAutomaticEventFields>>,
) =>
  pushEvent(
    {
      ...captureAutomaticEventFields(),
      ...response,
    },
    TrackingEvents.event,
  );

interface GtagProperties
  extends Omit<
    EventResponse,
    keyof ReturnType<typeof captureAutomaticEventFields> | 'pageEventValue' | 'pageEventType' | 'pageEventName'
  > {
  event_category: string;
  event_label: string;
  event_value?: string;
}

export const trackGtagEvent = (action: string, properties: GtagProperties, appendPageInfo = true) => {
  trackEvent({
    pageEventValue: action,
    pageEventType: properties.event_category,
    pageEventName: `${properties.event_label}${
      appendPageInfo ? ` | ${window.location.origin}${window.location.pathname} | ${window.document.title}` : ''
    }`,
    ...properties,
  });
};
/**
 * Providing the tracking `response` for a link click, this function returns a
 * `React.MouseEventHandler<HTMLAnchorElement>` which handles the complexities of tracking links that trigger a hard
 * page load when opening in the same tab. When opening a link in the same tab, `e.preventDefault()` is called to
 * prevent immediate navigation, and instead we wait for the tracking to complete before navigating (capped at 250ms).
 * This duration is capped to handle cases where tracking fails, or is taking an excessively long time to complete and
 * we don't want to block the user from navigating.
 *
 * @params response
 */
export const createOutboundLinkTracker =
  (response: Parameters<typeof trackEvent>[0]): React.MouseEventHandler<HTMLAnchorElement> =>
  (e) => {
    const { href } = e.currentTarget;

    // When opening a new page in the same tab, we need to wait for the track to complete before navigating or we may miss
    // actually tracking. Importantly, we also have a 250ms timer and whichever happens first will trigger the navigation
    if (isAnchorSameTarget(e.currentTarget) && isNormalClick(e)) {
      e.preventDefault();

      const trackComplete = new Promise<void>(() => {
        // TODO: Figure out if Adobe Launch Data Layer actually has a way to add a callback for when tracking is complete,
        // and resolve the Promise accordingly. With Google Analytics, this is simple with a field called `hitCallback`.
        // For now, this Promise will never resolve, and the `sleep(250)` will resolve first.
        trackEvent(response);
      });

      // Try to wait for the tracking to complete, but only wait for a maxium of 250ms
      Promise.race([sleep(250), trackComplete]).then(() => {
        window.location.href = href;
      });
    } else {
      trackEvent(response);
    }
  };
