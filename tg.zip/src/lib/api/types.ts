import { ExpressJourneySlug } from '@src/lib/constants/express';
import { SimTypeCompatibility } from '@src/lib/util/sim-selection';
import { MergedUnion } from '@src/lib/types';
import { PaymentIframeHashParams } from '@src/lib/payment/params';
import { BraintreePayload, PaymentMethod } from '@src/lib/payment/braintree';
import { ReceivedMessageType } from '@src/lib/payment/postMessage';
import { HomeInternetType } from '@src/templates/HomeWireless/HomeWireless.constants';

/**
 * Error
 */

export interface IntegrationError {
  code: string;
  message: string;
  category: string;
}

export interface IntegrationErrors {
  errors: IntegrationError[];
}

/**
 * Devices Page
 */

export enum DeviceEndpoint {
  PHONE = 'postpaid',
  PHONE_UPGRADES = 'postpaid-upgrades',
  TABLET = 'tablet',
  PREPAIDPHONE = 'prepaid',
  WEARABLES = 'wearables',
  MBB_MODEMS = 'mbb-modems',
}

export enum DeviceType {
  PHONE = 'phone',
  TABLET = 'tablet',
  HANDSET = 'handset',
  WEARABLE = 'wearable',
}

export interface DevicesPageParams {
  date?: string; // Preview use only
  deviceEndpoint: DeviceEndpoint;
  delay?: number; // optional argument only used for CPT to simulate API response time
}

export interface DevicesPageResponse {
  error?: IntegrationError[];
  deviceListing: {
    devices: DeviceItem[];
    promos: PromoItem[];
  };
  faqs: FaqContent;
  pageHeaderData: PageHeaderContent;
  uspItems: UspContent;
  termsAndConditions: TermsAndConditionsContent;
  experienceFragments: ExperienceFragment[];
}

export interface PromoItem {
  promoProductCode: string;
  promoTitle: string;
  promoDescription: string;
  promoContractText: string;
  promoURL: string;
  promoCTALabel: string;
  promoImage: string;
  promoTexture: string;
  variant: TileVariant;
  order: number;
  // id is for the sake of type sanity check
  id?: string;
}

export type TileVariant =
  | 'solid-dark-grey'
  | 'solid-red'
  | 'solid-purple'
  | 'solid-turquoise'
  | 'textured-light'
  | 'textured-dark';

export interface DeviceItem {
  // Alert not in scope
  // alert?: string;
  contractText: string;
  contractLength: number;
  id: string;
  imageUrl: string;
  eligibleBrands: string[];
  manufacturer: string;
  name: string;
  order?: number;
  recurringCharge: number;
  releaseDate: Date;
  heroOffer: string;
  slug: string;
  discountedRecurringCharge?: number;
  promotions: Promotion[];
  networkCapability?: string;
  simTypeCompatibility?: string;
  oneTimeCharge: number;
  prepaidPlanId?: string;
}

export interface OrderItem {
  orderedItem: DeviceItem[] | PromoItem[];
}

export interface Promotion {
  promotionCode: string;
  title: string;
  description: string;
  iconUrl: string;
  productAdjustment?: ProductAdjustment[];
  promotionExpired?: boolean;
  priceAdjustmentValue?: string;
  endDate?: string;
  subType?: PromoSubtype;
  tradeInAndSave?: boolean;
  adjustmentValue?: number | null;
  isASD?: boolean;
  bonusTradeInCredit?: string;
}
export interface OffersList {
  code: string;
  description: string;
  iconUrl: string;
  title: string;
  termsConditionsDesc: string;
}
export interface MorePlanInfo {
  title: string;
  description: string;
  icon: string;
  identifier: string;
}
export interface Offers {
  numberOfOffers: number;
  offersList: OffersList[];
}

export interface ProductAdjustment {
  productCode: string;
  priceAdjustment: PriceAdjustment[];
  dataAllowanceAdjustment: DataAllowanceAdjustment[];
}

export interface PriceAdjustment {
  chargeType: string;
  baseAmount: number;
  chargeAmount: number;
}

export interface DataAllowanceAdjustment {
  withBonusAllowance?: string;
}

export interface UspContent {
  heading: string;
  uspItems: UspItem[];
}

export interface UspItem {
  description: string;
  iconUrl: string;
  title: string;
}

export interface QuickLinkContent {
  analyticsAttribute: string;
  disableAnalytics: boolean;
  linkTarget: string;
  quickLinks: QuickLinkItem[];
  sectionTitle: string;
}

export interface QuickLinkItem {
  description: string;
  iconUrl: string;
  targetUrl: string;
  title: string;
  modalId: string;
}

/**
 * Device Page
 */

export interface DevicePageParams {
  date?: string; // Preview use only
  deviceEndpoint: DeviceEndpoint;
  deviceId: string;
  delay?: number; // optional argument only used for CPT to simulate API response time
}

export interface PrepaidStarterPageParam {
  planEndpoint: PlanEndpoint;
  planId: string;
}

export interface CompareField {
  brandIdentifier: string;
  compareUrl: string;
  compareLabel: string;
  openInNewBrowser: boolean;
}

export interface DeviceDetails {
  announcementPhase: boolean;
  capacities: DeviceCapacity[];
  catalogCode: CatalogCode;
  colors: DeviceColor[];
  contractTerm: DeviceContractTerm[];
  dataCapable: DeviceDataCapable[];
  defaultCapacity: string;
  defaultColor: string;
  defaultContractTerm: string;
  defaultImageUrl: string;
  deviceSku?: string;
  deviceSubType: string;
  deviceType: string;
  features: DeviceFeatures;
  heroOffer?: string;
  id: string;
  is5gCapable: boolean;
  manufacturer: string;
  metaTags?: string;
  minimumCharge: number;
  name: string;
  recurringCharge: number;
  relatedProducts?: DeviceRelatedProduct[];
  seoData?: string[];
  seoTitle?: string;
  specification: DeviceSpecContent[];
  simTypeCompatibility: SimTypeCompatibility;
  deviceDataCapability: string;
  networkCapability?: string;
  customStockAlertID?: string;
  hideStockMessaging?: boolean;
}

export interface DeviceConfigPricingMatrix {
  [color: string]: { [capacity: string]: DeviceConfigPricingEntry[] };
}

export interface ModemConfigPricingMatrix {
  [color: string]: DeviceConfigPricingEntry[];
}

export interface DeviceConfigPricingEntry {
  ContractTerm: string;
  ContractTermMonthlyInt: number;
  Discount?: number;
  FinalMRC?: number;
  FinalRCC: number;
  MatrixRowKey: string;
  MRC: number;
  NRC: number;
  OrderType: string;
  OutOfStockConnectLater?: string;
  OutOfStockConnectNow?: string;
  ProductCode: string;
  ProductName: string;
  RCC: number;
  RRP: number;
  SKU: string;
  FinalNRC?: number;
}
/**
 * DeviceStockStatus declares the possible status values for a response from DevicePageResponse.
 * The values are used as a key to lookup the relevant alert for a device.
 * Note: not all statuses will have a specialised authored an alert (i.e. Available).
 */
export enum DeviceStockStatus {
  AVAILABLE = 'Available',
  NON_ORDERABLE = 'Non-Orderable',
  UNAVAILABLE = 'Unavailable',
  BACK_ORDER = 'Back Order',
  LOW_STOCK = 'Low Stock',
  PREPAIDUNAVAILABLE = 'prepaid-non-orderable',
  WEARABLE_BAND_UNAVAILABLE = 'watch-band-non-orderable',
  WEARABLE_CASE_UNAVAILABLE = 'watch-case-non-orderable',
  /**
   * Stock API failure means we can't determine Available/Non-orderable etc and the business decided to let orders continue regardless and a team will call the customer if the device isn't available
   */
  STOCK_API_FAILURE = 'Stock API Failure',
}

export const DeepLinkableDeviceStockStatuses: DeviceStockStatus[] = [
  DeviceStockStatus.AVAILABLE,
  DeviceStockStatus.BACK_ORDER,
  DeviceStockStatus.LOW_STOCK,
  DeviceStockStatus.STOCK_API_FAILURE,
];

export interface DeliveryAvailabilityContent {
  deliveryInformation?: string;
  disclaimer?: string;
  heading?: string;
  icons?: Array<{
    iconUrl: string | null;
    description: string;
  }>;
  placeholderText?: string;
  submitLabel?: string;
  submitDescription?: string;
  tabTitle?: string;
  tabIcon?: string;
  error?: IntegrationError[];
}

export interface Alert {
  alertIcon?: string;
  alertId: string;
  alertTitle?: string;
  alertText: string;
  alertType: string;
}

export interface DeviceDataCapable {
  value: string;
  disabled: boolean;
  label: string;
}

export interface VlocityAttribute {
  defaultSelected: boolean;
  disabled: boolean;
  label: string;
  readonly: boolean;
  value: string;
}

export type DeviceCapacity = VlocityAttribute;

export interface DeviceColor extends VlocityAttribute {
  caseSize?: string | undefined;
  bandName?: string | undefined;
  bandColor?: string | undefined;
  hexCode: string;
  images: DeviceImage[];
}

export type DeviceContractTerm = VlocityAttribute;

export interface ImageAttributes {
  url: string;
  height?: number;
  width?: number;
}

export interface DeviceFeatures {
  description: string;
  descriptionItems?: Array<{
    description: string;
  }>;
  desktopImageUrls: Array<ImageAttributes>;
  mobileImageUrls: Array<ImageAttributes>;
  youtubeVideo: string;
}

export interface DeviceImage {
  id?: string;
  imageUrl: string;
  altText: string;
  useInCart?: boolean;
}

export interface DeviceRelatedProduct {
  code: string;
  name: string;
  slug: string;
}

export interface DeviceSpecContent {
  iconUrl: string;
  specs: DeviceSpecItem[];
  title: string;
}

export interface DeviceSpecItem {
  description: string;
  subTitle: string;
}

export interface DeliveryDatesParams {
  orderChannel: string;
  orderFunction: 'Acquisition' | 'Upgrade';
  accessories: DeliveryDatesParamItem[];
  devices: DeliveryDatesParamItem[];
}

export interface DeliveryDatesParamItem {
  sku: string;
  postcode: string;
}

export interface DeliveryDatesResponse {
  accessories: DeliveryDatesResponseItem[];
  devices: DeliveryDatesResponseItem[];
}

export interface DeliveryDatesResponseItem {
  stockAvailability: DeviceStockStatus;
  id: string;
  orderChannel: string;
  orderFunction: string;
  sku: string;
  postcode: string;
  estimatedDeliveryDate: string;
  estimatedShipmentDate?: string;
}

export interface AvailableDeliveryStoresParams {
  orderFunction: 'Acquisition' | 'Upgrade';
  latitude: string;
  longitude: string;
  postcode: string;
  sku: string;
  range: string;
}

export interface AvailableDeliveryStoreResponse {
  stores: AvailableDeliveryStoresItem[];
  params?: AvailableDeliveryStoresParams | null;
}
export type statusTypes = 'Available' | 'Unavailable' | 'Back Order';
export interface AvailableDeliveryStoresItem {
  storeName: string;
  distance: string;
  deliveryAvailabilityStatus: statusTypes;
  estimatedDeliveryDate?: string;
}

/**
 * Plans Page
 */

export interface PlansPageDataParams {
  date?: string; // Preview use only
  planEndpoint?: PlanEndpoint;
  delay?: number; // optional argument only used for CPT to simulate API response time
  extraOffer?: string;
  planId?: string;
}
export interface PlanDetailsPageDataParams {
  date?: string; // Preview use only
  planEndpoint?: PlanEndpoint;
  delay?: number; // optional argument only used for CPT to simulate API response time
  slug: string;
}
export interface PromoAvailibilityParams {
  subType: PromoSubtype;
  planEndpoint: PlanEndpoint;
}

export enum PromoSubtype {
  OnlineBTL = 'OnlineBTL',
  Student = 'student',
}

export enum PlanEndpoint {
  POSTPAID = 'postpaid',
  POSTPAID_SIMO = 'postpaid-simo',
  POSTPAID_PLAN = 'postpaid-plan',
  POSTPAID_SIMO_TPG_SM = 'postpaid-simo-tpg-sm',
  POSTPAID_UPGRADES = 'postpaid-upgrades',
  PREPAID_COMBO_PLUS = 'prepaid-combo-plus',
  PREPAID_PAY_AND_GO = 'prepaid-pay-and-go',
  TABLET = 'tablet',
  TABLET_SIMO = 'mbb-postpaid-simo-tablet',
  NBN = 'nbn',
  HOME_INTERNET_4G = 'fhw-4g',
  HOME_INTERNET_5G = 'fhw-5g',
  POSTPAID_MBB_MODEM = 'mbb-postpaid-modem',
  POSTPAID_MBB_MODEM_SIMO = 'mbb-postpaid-simo-modem',
  POSTPAID_SIMO_PLAN_DETAILS = 'postpaid-simo-plan-details',
}

export enum ChargeType {
  RECURRING = 'Recurring',
  ONE_TIME = 'One-time',
}

export interface PlansPageResponse {
  catalogCode: CatalogCode;
  errors?: IntegrationError[];
  faqs: FaqContent;
  offers: OffersContent;
  pageHeaderData: PageHeaderContent;
  planListing: PlansContent;
  quickLinks?: QuickLinkContent;
  // TODO: Investigate why the API sometimes returns an empty object here and just make it return undefined
  secondaryPlanListing?: MergedUnion<PlansContent | {}>;
  termsAndConditions: TermsAndConditionsContent;
}

export interface RefreshPlansPageResponse extends Omit<PlansPageResponse, 'planListing' | 'offers'> {
  discountedOneTimeCharge?: number;
  discountedRecurringCharge?: number;
  plan: PostpaidPlan | PrepaidPlan;
  showPayIn4PromoContent?: boolean;
  payIn4PromoContentThreshold?: number;
  usps?: PlanUspItem[];
  iconTilesVariant?: 'biggie' | 'smalls';
  iconTilesBgColor?: string;
  oneTimeCharge?: number;
  offers?: OffersContent;
  planListingTheme?: 'light' | 'dark';
  planListingBackgroundColor?: string;
}

export interface ExperienceFragmentsResponse {
  errors?: IntegrationError[];
  experienceFragments?: ExperienceFragment[];
}

export type RefreshPlansPageAndExperienceFragmentsResponse = RefreshPlansPageResponse & ExperienceFragmentsResponse;

export interface PromoAvailibilityResponse {
  availability: boolean;
}

export interface PlansContent {
  usps: PlanUspItem[];
  plans: PostpaidPlan[] | PrepaidPlan[];
  title: string;
  description?: string;
  iconTilesVariant?: 'biggie' | 'smalls';
  iconTilesBgColor?: string;
  showPayIn4PromoContent: boolean;
  payIn4PromoContentThreshold: number;
  experienceFragments?: ExperienceFragment[];
  inlineBanners?: InlineBannerType[];
  planListingTheme?: 'light' | 'dark';
  planListingBackgroundColor?: string;
}

export interface PostpaidPlan extends BasePlan {
  planCategory: string;
  ratesLabel: string;
  ratesUrl: string;
}

export interface PrepaidPlan extends BasePlan {
  id?: string;
  customPlanName?: string;
  isPlanEsimSimo?: boolean;
  expandPlanOnMobile?: boolean;
  bannerTitle?: string;
  bannerImage?: string;
  priceLabel?: string;
  planCategory: string;
  ratesLabel: string;
  ratesUrl: string;
  oneTimeCharge: number;
  discountedOneTimeCharge: number;
}

export interface PlanUspItem {
  title: string;
  description: string;
  imageUrl: string;
  isNewConnect?: boolean;
  isUpgrade?: boolean;
}

/**
 * Extras Page
 */

interface ExtrasParams {
  catalogCode: string;
  productCode: string;
}

export interface ExtrasPageDataParams {
  date?: string; // Preview use only
  delay?: number; // optional argument only used for CPT to simulate API response time
  params: ExtrasParams[];
}

export interface ExtrasPageResponse {
  addOn: AddOnsContent;
  insurance: InsurancesContent;
  swapAndGo: SwapAndGoContent;
  pageHeaderData: ExtrasPageHeaderContent;
  termsAndConditions: TermsAndConditionsContent;
}

export interface ExperienceFragment {
  fragmentId?: string;
  fragmentHtml?: string;
}

interface SimSelectionTimelineItem {
  icon: string | null;
  heading: string;
  rtecontent: string;
}

export interface SimSelectionContent {
  sectionFooter: string;
  altSectionSubTitle: string;
  altSimIcon: string;
  altSimSelectionDescription: string;
  sectionTitle: string;
  sectionSubTitle: string;
  simIcon: string;
  simSelectionDescription: string;
  simExplanation: string;
  timelineSectionTitle: string;
  timeLineData: SimSelectionTimelineItem[];
  psimCta: string;
  esimCta: string;
}

export interface ExtrasPageHeaderContent {
  breadcrumb: string;
  description: string;
  title: string;
  esimDeviceTitleOverride?: string;
  esimDeviceDescriptionOverride?: string;
  simOnlyTitleOverride?: string;
  simOnlyDescriptionOverride?: string;
  seoTitle?: string;
  metaTags?: string;
  seoData?: string[];
  alerts?: Alert[];
  simSelectionDevice: SimSelectionContent;
  simSelectionSIMO: SimSelectionContent;
  simSelectionUpgrades: SimSelectionContent;
}

export interface ExtrasContent {
  ctaAlternateLabel: string;
  ctaLabel: string;
  description: string;
  extras: Extra[];
  extraType?: string;
  heading: string;
}

export interface Extra {
  cisUrl: string;
  description: string;
  imageUrl: string;
  inclusions: ExtrasInclusion[];
  name: string;
  order: string;
  pdsLinkUrl: string;
  productCode: string;
  recurringCharge: number;
  oneTimeCharge?: number;
  chargeType: string;
  contractTerm?: string;
  parentProductCode: string;
  parentCatalogCode: string;
  productSubType: ExtraType;
  productType: ExtraType;
  parentHierarchyPath: string;
  productGroupId?: string;
}

export enum ExtraType {
  ADDON = 'Add-On',
  INSURANCE = 'Insurance',
  SWAP_AND_GO = 'SwapAndGo',
}

export interface ExtrasInclusion {
  description: string;
  iconUrl: string;
  eligibleBrands?: string[];
  forMobile?: boolean;
  forTablet?: boolean;
  title?: string;
  forWatch?: boolean;
}

export interface AddOnsContent extends ExtrasContent {
  cisLabel: string;
  extras: AddOnExtra[];
}

export interface SwapAndGoContent extends ExtrasContent {
  pdsLinkLabel: string;
  extras: SwapAndGoExtra[];
}

export interface InsurancesContent extends ExtrasContent {
  pdsLinkLabel: string;
  extras: InsuranceExtra[];
}

export interface InsuranceExtra extends Extra {
  productType: ExtraType.INSURANCE;
}

export interface AddOnExtra extends Extra {
  productType: ExtraType.ADDON;
}

export interface SwapAndGoExtra extends Extra {
  productType: ExtraType.SWAP_AND_GO;
}

/**
 * Cart Summary Page
 */

export interface CartPageResponse extends PageMetaContent {
  alerts: Alert[];
  cartSummary: CartSummaryContent;
  persistentCart: PersistentCartContent;
  additionalServices?: AdditionalServicesPageResponse;
  checkoutSplitterGroups: CheckoutSplitterGroup[];
  checkoutSplitterLogo: string;
  rafCartLabels?: ReferAFriendContent;
}

export interface ReferAFriendContent {
  icon: string;
  title: string;
  description: string;
  placeholderText: string;
  primaryCtaLabel: string;
  cartLabel: string;
  rafOfferData?: AemOffer;
}
export interface CheckoutSplitterGroup {
  id: string;
  content: CheckoutSplitterContent[];
}

export interface AemOffer {
  code: string;
  description: string;
  title: string;
  iconPath?: string;
  channels?: string[];
  tradeInAndSave?: boolean;
  bonusTradeInCredit?: string;
}
export interface CheckoutSplitterContent {
  title: string;
  body: string;
  primaryCtaRole: CheckoutSplitterCtaRole;
  primaryCtaStyle: CheckoutSplitterCtaStyle;
  primaryCtaLabel: string;
  secondaryCtaRole: CheckoutSplitterCtaRole;
  secondaryCtaStyle: CheckoutSplitterCtaStyle;
  secondaryCtaLabel: string | undefined;
}

export type CheckoutSplitterCtaRole =
  | 'new'
  | 'additional-service'
  | 'upgrade'
  | 'change-plan'
  | 'new-simo'
  | 'new-plan-handset'
  | 'one-service-upgrade';

export type LogInAction = Extract<CheckoutSplitterCtaRole, 'change-plan' | 'additional-service' | 'upgrade'>;

export type CheckoutSplitterCtaStyle = 'primary' | 'secondary' | 'tertiary';

export type GetContentParams = {
  cart: Basket | null;
  checkoutSplitterGroups: CheckoutSplitterGroup[] | undefined;
};

export interface CartSummaryContent {
  appliedCta: string;
  bundleCartLabel: string;
  title: string;
  checkoutCta: string;
  remainingBalanceLabel: string;
  emptyCartMessage: string;
  continueCtaUrl: string;
  totalCostLabelAddService: string;
  totalCostLabelUpgrades: string;
  continueCta: string;
  promoCodeTitle: string;
  totalCostLabel: string;
  promoCodeCta: string;
  disclaimer: string;
  remainingBalanceModal: string;
  includedLabel: string;
  repairWarranty: string;
  repairWarrantyTitle: string;
}

export interface PersistentCartContent {
  collapseCta: string;
  expandCta: string;
  label: string;
}

/**
 * Checkout Page
 */

export interface OmniEventMessage {
  'OmniScript-Messaging': {
    Type: string;
    orderId: string;
    creditCheckDecisionCode: OmniCreditCheckCode | undefined;
    serviceType: OmniServiceType;
    journey: OmniJourney;
  };
}

export enum OmniCreditCheckCode {
  APPROVED = 'APPROVE',
  CONDITIONALLY_APPROVED = 'CONDAPPRVE',
  REFER = 'REFER',
  WITHDRAWN = 'WITHDRAW',
  RTCC_OFF = 'RTCC Downtime',
  RTCC_DOWNTIME = 'RTCC Downtime',
}

export enum OmniServiceType {
  NEW = 'New',
  UPGRADE = 'Upgrade',
  ADDITIONAL_SERVICES = 'Additional Services',
}

export enum OmniJourney {
  PREPAID = 'Prepaid',
  POSTPAID = 'Postpaid',
}

/**
 * NBN Page
 */

export interface NbnPageResponse {
  nbnFaqContent: FaqContent;
  nbnInfoContent: NbnInfoContent;
  nbnModemsContent: NbnModemsContent;
  nbnStepsContent: NbnStepsContent;
  nbnTitleContent: PageHeaderContent;
  nbnTncsContent: TermsAndConditionsContent;
}

export interface HomeWirelessPageResponse {
  fhwFaqContent: FaqContent;
  fhwInfoContent: NbnInfoContent;
  fhwModemsContent: NbnModemsContent;
  fhwStepsContent: NbnStepsContent;
  fhwTitleContent: PageHeaderContent;
  fhwTncsContent: TermsAndConditionsContent;
  quickLinks?: QuickLinkContent;
}

export interface PrepaidPlansResponse {
  planListing: PrepaidPlan[];
}

export interface NbnPlansResponse {
  planListing: {
    plans: NbnPlan[];
    inlineBanners: InlineBannerType[] | null;
    usps: PlanUspItem[];
    title?: string;
    description: string;
    iconTilesVariant?: 'biggie' | 'smalls';
    iconTilesBgColor?: string;
    experienceFragments?: ExperienceFragment[];
    hideOnPlanCardCIS: boolean;
    hideOnPlanCardKFS: boolean;
    showPayIn4PromoContent: boolean;
    payIn4PromoContentThreshold: number;
  };
  modemPriceInfo: {
    recurringCharge: number;
    oneTimeCharge: number;
    loyaltyMRCAmount: number;
    contractTerm: string;
  };
}

export interface HomeWirelessPlansResponse {
  planListing: {
    plans: HomeWirelessPlan[];
    inlineBanners: InlineBannerType[] | null;
    usps: PlanUspItem[];
    title?: string;
    description: string;
    iconTilesVariant?: 'biggie' | 'smalls';
    iconTilesBgColor?: string;
    experienceFragments?: ExperienceFragment[];
    showPayIn4PromoContent: boolean;
    payIn4PromoContentThreshold: number;
  };
  modemPriceInfo: {
    recurringCharge: number;
    oneTimeCharge: number;
    loyaltyMRCAmount: number;
    contractTerm: string;
  };
}

export interface NbnPlan extends BasePlan {
  customPlanName: string;
  connectionSpeed: string;
  factSheetLabel: string;
  factSheetUrl: string;
  withModem: boolean;
}

export interface HomeWirelessPlan extends BasePlan {
  customPlanName: string;
  planData: string;
  factSheetLabel: string;
  factSheetUrl: string;
}

export interface NbnModemsContent {
  modemPlans: HomeInternetModemItem[];
}

export interface HomeInternetModemItem {
  altText: string;
  productDisplayName: string;
  productId?: string;
  tabName: string;
  textBlock: string;
  thumbnailUrl: string;
  subHeading: string;
  inclusions?: {
    image: string;
    description: string;
  }[];
}

export interface NbnInfoContent {
  altText: string;
  logo: string;
  textBlock: string;
}

export interface NbnStepsContent {
  steps: NbnStepItem[];
}

export interface NbnStepItem {
  description: string;
  title: string;
  heading: string;
  ctaLabel: string;
}

export interface AddressCheckerResponse {
  addressCoverage: AddressCheckerContent;
  alerts: Alert[];
  coverageStatus: AddressCheckerCoverageStatusContent;
}

export interface AddressCheckerContent {
  cancelCta: string;
  cta: string;
  fields: AddressCheckerField[];
}

export interface AddressCheckerField {
  fieldLabel: string;
  fieldName: string;
  fieldPlaceholder: string;
  fieldType: string;
  isRequired: boolean;
  order?: number;
  validationMessage: string;
}

export interface AddressCheckerCoverageStatusContent {
  nbnTechnology: AddressCheckerCoverageService[];
  exceptions: AddressCheckerCoverageStatus[];
  installation: AddressCheckerCoverageService[];
  mobileCoverage: AddressCheckerCoverageStatus[];
}

export interface AddressCheckerCoverageStatus {
  type: string;
  message: string;
}

export interface AddressCheckerCoverageService extends AddressCheckerCoverageStatus {
  serviceClasses: string[];
}

// Basket Types

export interface AddToBasketParams {
  items: BasketRequestItem[] | StrippedBasketRequestItem[];
  additionalBnsCount: number;
  extraOffer?: string;
  raf?: RafRequestParams;
}

export interface BaseBasketRequestItem {
  catalogCode: CatalogCode;
  matrixRowKey?: string;
  packageId: string;
  productCode: string;
  isBundleAndSaveEligible?: boolean;
}

export interface StrippedBasketRequestItem extends BaseBasketRequestItem {
  childProducts: string[];
  tradeInDeviceName?: string;
}

export interface BasketRequestItem extends BaseBasketRequestItem {
  childProducts: ChildBasketRequestItem[];
  manufacturer?: string;
  priceInfo: BasketRequestItemPriceInfo;
  productConfig: {
    capacity?: string;
    color?: string;
    contractTerm?: string;
    deviceSku?: string;
    imageUrl?: string;
    orderType?: string;
    caseSize?: string;
    bandName?: string;
    bandSize?: string;
    bandColor?: string;
  };
  productName: string;
  productSubType?: CartProductSubType;
  productType: CartProductType;
  itemType: CartItemType;
  hideWasLabel?: boolean;
  asdSubCopy?: string;
  promoSubType?: string;
}

export type ChildBasketRequestItem = Omit<BasketRequestItem, 'childProducts'>;

export interface BasketRequestItemPriceInfo {
  oneTimeCharge?: number;
  recurringCharge: number;
  originalRecurringCharge?: number;
  adjustedNRCAmount?: number;
  adjustedMRCAmount?: number;
  loyaltyMRCAmount?: number;
  discount?: number;
  nonRecurringCharge?: number;
  originalNonRecurringCharge?: number;
}

export interface DeviceBasketRequestItem extends BasketRequestItem {
  matrixRowKey: string;
  productConfig: {
    color: string;
    capacity: string;
    contractTerm: string;
    deviceSku: string;
    imageUrl?: string;
    orderType: string;
    bandColor?: string;
    bandName?: string;
    bandSize?: string;
    caseSize?: string;
  };
  simTypeCompatibility: SimTypeCompatibility;
  manufacturer: string;
  itemType: CartItemType.DEVICE;
}
export interface WearableDeviceBasketRequestItem extends BasketRequestItem {
  matrixRowKey: string;
  productConfig: {
    color: string;
    contractTerm: string;
    deviceSku: string;
    imageUrl?: string;
    orderType: string;
    bandColor: string;
    bandName: string;
    bandSize: string;
    caseSize: string;
    capacity?: string;
  };
  simTypeCompatibility: SimTypeCompatibility;
  manufacturer: string;
  itemType: CartItemType.SMARTWATCH;
}
export interface ModemBasketRequestItem extends BasketRequestItem {
  matrixRowKey: string;
  productConfig: {
    color: string;
    contractTerm: string;
    deviceSku: string;
    imageUrl?: string;
    orderType: string;
    bandColor?: string;
    bandName?: string;
    bandSize?: string;
    caseSize?: string;
  };
  simTypeCompatibility: SimTypeCompatibility;
  manufacturer: string;
  itemType: CartItemType.MODEM;
}
export interface PlanBasketRequestItem extends BasketRequestItem {
  relatedContent: {
    planData: string;
  };
  itemType: CartItemType.PLAN;
}

export interface PrepaidComboPlusPlanBasketRequestItem extends BasketRequestItem {
  catalogCode: CatalogCode.PREPAID_COMBO_PLUS_PLANS;
  itemType: CartItemType.PLAN;
}

export interface PrepaidPayAndGoPlanBasketRequestItem extends BasketRequestItem {
  catalogCode: CatalogCode.PREPAID_PAY_AND_GO_PLANS;
  itemType: CartItemType.PLAN;
}

export interface PostpaidSimoPlanBasketRequestItem extends BasketRequestItem {
  catalogCode: CatalogCode.POSTPAID_SIMO_PLANS | CatalogCode.POSTPAID_TABLET_SIMO_PLANS;
  itemType: CartItemType.PLAN;
  productConfig: {
    contractTerm: string;
  };
}

export interface NbnPlanBasketRequestItem extends BasketRequestItem {
  catalogCode: CatalogCode.NBN_PLANS;
  itemType: CartItemType.PLAN;
  productConfig: {
    contractTerm: string;
  };
}

export interface ModemChildBasketRequestItem extends Omit<ChildBasketRequestItem, 'itemType'> {
  itemType: CartItemType.MODEM;
  relatedContent: {
    modemName: string;
  };
}

export interface BaseBasket {
  basketId: string;
  errors?: IntegrationError[];
  totalPrice: BasketTotalPrice;
  bundleAndSaveApplied: boolean;
}

export interface BasketTotalPrice {
  oneTimeCharge: number;
  recurringCharge: number;
}

export interface BNSOfferParams {
  serviceCount: number;
}

export interface BnsPlan {
  bnsDiscount: number;
  planCode: string;
}

export interface BnsPromotion {
  promotionCode: string;
  description: string;
  title: string;
  iconUrl: string;
  endDate?: string;
}
export interface BnsOffer {
  plans: BnsPlan[];
  promotion: BnsPromotion | null;
}
export interface BasketParams {
  basketId: string;
  additionalBnsCount?: number;
  extraOffer?: string;
}

export interface BasketResponse extends BaseBasket {
  packages: BasketPackageDictionary;
  raf?: BasketRafDataResponse;
}

export interface Basket extends BaseBasket {
  packages: BasketPackage[];
  onlinePromotionAvailability?: boolean;
  raf?: BasketRafDataResponse;
}

export interface BasketRafDataResponse {
  discountAmount?: number;
  appliedCatalogCode?: CatalogCode;
  rafCode: string;
  isValid: boolean;
}

export interface BasketPackage {
  items: BasketItem[];
  packageId: string;
}

export interface BasketPackageDictionary {
  [packageId: string]: { [productType: string]: BasketItem };
}

export interface BasketItem {
  catalogCode: CatalogCode;
  cisUrl?: string;
  itemType: CartItemType;
  packageId: string;
  pdsLinkUrl?: string;
  factSheetUrl?: string;
  priceInfo: BasketItemPriceInfo;
  productCode: string;
  productConfig?: BasketItemProductConfig;
  productConfigChanged: boolean;
  productExpired: boolean;
  productName: string;
  productSubType?: CartProductSubType;
  productType: CartProductType;
  promotions?: Promotion[];
  tradeInDeviceDetails?: CartTradeInDeviceType;
  relatedContent?: BasketItemRelatedContent;
  isBundleAndSaveEligible?: boolean;
}

export interface CartTradeInDeviceType {
  tradeInDeviceName: string;
  tradeInValue: number;
}

export interface DeviceBasketItem extends BasketItem {
  itemType: CartItemType.DEVICE;
  simTypeCompatibility: SimTypeCompatibility;
  manufacturer?: string;
}

export interface PlanBasketItem extends BasketItem {
  itemType: CartItemType.PLAN;
  isBundleAndSaveEligible?: boolean;
}

export interface PrepaidComboPlusPlanBasketItem extends BasketItem {
  catalogCode: CatalogCode.PREPAID_COMBO_PLUS_PLANS;
  itemType: CartItemType.PLAN;
  isBundleAndSaveEligible?: boolean;
}

export interface PrepaidPayAndGoPlanBasketItem extends BasketItem {
  catalogCode: CatalogCode.PREPAID_PAY_AND_GO_PLANS;
  itemType: CartItemType.PLAN;
}

export interface PostpaidSimoPlanBasketItem extends BasketItem {
  catalogCode: CatalogCode.POSTPAID_SIMO_PLANS | CatalogCode.POSTPAID_TABLET_SIMO_PLANS;
  itemType: CartItemType.PLAN;
}

export interface NbnPlanBasketItem extends BasketItem {
  catalogCode: CatalogCode.NBN_PLANS;
  itemType: CartItemType.PLAN;
  isBundleAndSaveEligible?: boolean;
}

export interface ModemBasketItem extends BasketItem {
  itemType: CartItemType.MODEM;
}

export interface BasketItemPriceInfo {
  adjustedMRCAmount: number; // is the final recurringCharge amount after promotions were applied for that product
  adjustedNRCAmount: number; // is the final oneTimeCharge amount after promotions were applied for that product
  Discount?: number;
  loyaltyMRCAmount?: number; // is the value we are using to handle NBN Modem loyalty discount
  MRC?: number;
  nrcPercentDiscount: number;
  nrcPriceAdjustment: number;
  oneTimeCharge: number;
  recurringCharge: number;
  strategicDeviceDiscount?: number; // is the final total Strategic Device Discount (SDD)
}

export interface BasketItemProductConfig {
  color?: string;
  capacity?: string;
  contractTerm?: string;
  dataSharing?: string;
  dataLimit?: DataLimit;
  deviceSku?: string;
  imageUrl?: string;
  orderType?: string;
  packageId?: string;
  validity?: string;
  bandName?: string;
  bandColor?: string;
  bandSize?: string;
  caseSize?: string;
}

export interface BasketItemRelatedContent {
  cisLabel?: string;
  connectionSpeed?: string;
  hasDataOverride?: boolean;
  heroOfferId?: string;
  heroLabel?: string;
  image?: DeviceImage;
  inclusions?: (PlanInclusion | ExtrasInclusion)[];
  modemName?: string;
  offers?: OffersContent;
  pdsLinkLabel?: string;
  planData?: string;
  planDescription?: string;
  planExtraInfo?: string;
  planName?: string;
  planTenure?: string;
  planSpeedLabel?: string;
  planTitle?: string;
  subHeadingPrimary?: string;
  subHeadingSecondary?: string;
  withModem?: boolean;
}

export interface RemovePackageFromBasketParams {
  basketId: string;
  packageId: string;
  additionalBnsCount: number;
  raf?: {
    action: RafAction;
    rafCatalogCodes: Array<CatalogCode>;
  };
}

export interface RafAppliedItem {
  packageId: string;
  catalogCode: CatalogCode;
  discountAmount: number;
  rafCode: string;
}

export enum CartAemEvents {
  RESET_ABANDONED_CART = 'abandoned_cart_updated',
}

export interface CartProductConfig {
  color?: string;
  capacity?: string;
  contractTerm?: string;
  packageId?: string;
  orderType?: string;
  deviceSku?: string;
  imageUrl?: string;
  caseSize?: string;
  bandSize?: string;
  bandName?: string;
  bandColor?: string;
}

export interface BaseCartItem {
  catalogCode: CatalogCode;
  itemType: CartItemType;
  name: string;
  priceInfo: CartPriceInfo;
  productCode: string;
  productConfig: CartProductConfig;
  productSubType: CartProductSubType;
  productType: CartProductType;
  quantity: number;
  actions: {
    delete: CartAction;
    update: CartAction;
  };
  cisUrl?: string;
  pdsLinkUrl?: string;
  relatedContent?: CartItemRelatedContent;
  defaultSimType?: SimTypeCompatibility;
  simTypeCompatibilitySelection?: SimTypeCompatibility[];
}

export interface CartItemRelatedContent {
  pdsLinkLabel?: string;
  cisLabel?: string;
  connectionSpeed?: string;
  image?: {
    altText: string;
    imageUrl: string;
  };
  inclusions?: (PlanInclusion | ExtrasInclusion)[];
  modemName?: string;
  planName?: string;
  planDescription?: string;
  planExtraInfo?: string;
  planTenure?: string;
  planTitle?: string;
  planData?: string;
  offers?: OffersContent;
  subHeadingPrimary?: string;
  subHeadingSecondary?: string;
  withModem?: boolean;
  deviceStockStatus?: DeviceStockStatus;
  validity?: string;
}

export interface CartItem extends BaseCartItem {
  childProducts?: ExtraCartItem[];
}

export interface DeviceCartItem extends CartItem {
  itemType: CartItemType.DEVICE;
}

export interface PlanCartItem extends CartItem {
  itemType: CartItemType.PLAN;
}

export interface NbnPlanCartItem extends CartItem {
  itemType: CartItemType.PLAN;
  catalogCode: CatalogCode.NBN_PLANS;
}

export interface PostpaidSimoPlanCartItem extends CartItem {
  itemType: CartItemType.PLAN;
  catalogCode: CatalogCode.POSTPAID_SIMO_PLANS;
}

export interface PrepaidComboPlusPlanCartItem extends CartItem {
  itemType: CartItemType.PLAN;
  catalogCode: CatalogCode.PREPAID_COMBO_PLUS_PLANS;
}

export interface PrepaidPayAndGoPlanCartItem extends CartItem {
  itemType: CartItemType.PLAN;
  catalogCode: CatalogCode.PREPAID_PAY_AND_GO_PLANS;
}

export interface ModemCartItem extends CartItem {
  itemType: CartItemType.MODEM;
}

export interface AddonCartItem extends CartItem {
  itemType: CartItemType.ADDON;
}

export interface ExtraCartItem extends BaseCartItem {
  parentProductCode?: string;
  itemType: CartItemType.EXTRA;
}

/**
 * Additional Services Bundle
 */

export interface AdditionalServicesBundleResponse {
  header: AdditionalServicePageHeaderContent;
  bundle: AdditionalServiceBundleDetails;
}

export interface AdditionalServicePageHeaderContent extends PageMetaContent {
  title: string;
  subTitle: string;
  imageUrl: string;
  journeyTitle: string;
  imageMobile: string;
  imageTablet: string;
  theme: string;
  alerts: Alert[];
  twoWaySmsMessage?: string;
  twoWaySmsIconUrl?: string;
  twoWaySmsInvalidMessage?: string;
}

export interface AdditionalServiceBundleDetails {
  title: string;
  sectionTitle: string;
  sectionInformation: {
    description: string;
    href: string;
    title: string;
  };
  termsAndConditions: {
    description: string;
    label: string;
  };
  iconUrl: string;
  phoneIconUrl: string;
  planIconUrl: string;
  tabletIconUrl: string;
  nbnIconUrl: string;
  savingsTitle: string;
  savingsImageUrl: string;
}

/**
 * Additional Services Page
 */

export interface AdditionalServicesPageResponse {
  header: AdditionalServicePageHeaderContent;
  bundle: AdditionalServiceBundleDetails;
  quickLinks: QuickLinkContent;
  faqs: FaqContent;
  termsAndConditions: TermsAndConditionsContent;
}

/**
 * Upgrades Page
 */

export interface UpgradesPageResponse {
  pageHeaderData: UpgradesPageHeaderContent;
  ctaItems: CtaItemContent;
  quickLinks: QuickLinkContent;
  faqs: FaqContent;
}

export interface UpgradesHeaderResponse {
  pageHeaderData: UpgradesPageHeaderContent;
}

export interface UpgradesPageHeaderContent extends PageMetaContent {
  alerts: Alert[];
  altText: string;
  cancelCtaLabel: string;
  confirmCtaLabel: string;
  ctaHomeLabel: string;
  homepageUrl: string;
  imageUrl: string;
  onlineUpgradeError: string;
  otherServicesLabel: string;
  phoneIconUrl: string;
  planIconUrl: string;
  tabletIcon: string;
  serviceCardMessage: string;
  serviceCardMessageSIMO: string;
  subtitle: string;
  title: string;
  journeyTitle: string;
  imageMobile: string;
  imageTablet: string;
  theme: string;
  twoWaySmsMessage?: string;
  twoWaySmsIconUrl?: string;
  twoWaySmsInvalidMessage?: string;
  customText?: string;
}

export interface CurrentServiceDataWithoutContent {
  msisdn: string;
  formattedMSISDN: string;
  formattedTotalCost: string;
  plan?: ServiceItem;
  phone?: ServiceItem;
  extras: ServiceItem[];
  totalCost: number;
}

export interface CurrentServiceData extends CurrentServiceDataWithoutContent {
  serviceCardMessageSIMO: string;
  serviceCardMessage: string;
  phoneIconUrl?: string;
  tabletIcon?: string;
  planIconUrl?: string;
  otherServicesLabel?: string;
  twoWaySmsMessage?: string;
  twoWaySmsIconUrl?: string;
  twoWaySmsInvalidMessage?: string;
}

export interface ServiceItem {
  balanceAmount: number;
  paid: boolean;
  monthlyCharge: number;
  contractAmount?: number;
  contractTerm?: number;
  displayName?: string;
  displayProductType?: string;
  formattedContractTerm?: string;
  formattedMonthlyCharge?: string;
  itemName?: string;
  monthlyRemaining?: number;
  startDate?: string;
  endDate?: string;
  sharingStatus?: boolean;
  sharingCompatibility?: string;
}

interface EarlyUpgradeChargeAmount {
  inclusiveOfGst: string;
  exclusiveOfGst: string;
  gst: string;
}

interface UpgradeOptions {
  upgradeNewPlanIndicator: boolean;
  earlyUpgradeIndicator: boolean;
  loyaltyUpgradeIndicator: boolean;
  resignToCurrentPlanIndicator: boolean;
  earlyResignIndicator: boolean;
  loyaltyResignIndicator: boolean;
  upgradeOutrightIndicator: boolean;
  earlyUpgradeChargeAmount: EarlyUpgradeChargeAmount;
}

export enum AccountType {
  POSTPAY = 'Postpay',
  PREPAY = 'Prepay',
}

/**
 * `ProductServiceType` a.k.a `serviceType`, not to be confused with `serviceType` a.k.a `ServiceTypeValue` a.k.a. "shop intent".
 * Confused?
 */
export enum ProductServiceType {
  NBN_ONLY = 'NBN Only',
  NBN_WITH_MBB = 'NBN with MBB',
  /**
   * e.g. Tablet, mobile broadband
   */
  MBB = 'MBB',
  /**
   * e.g. Phone and plan, Voice SIMO
   */
  VOICE = 'Voice',
}

export interface CustomerServiceDetails {
  msisdn: string;
  /**
   * NOTE: This will always be present, except for certain hardstop scenarios where we can't actually access the data
   */
  serviceType?: ProductServiceType;
  /**
   * This is the `msisdn` but encrypted
   *
   * NOTE: This will always be present except for certain hardstop scenarios
   */
  customerID?: string;
  eligibilityIndicator: boolean;
  additionalServiceEligibility: boolean;
  permitPlanChangeIndicator: boolean;
  eligibility?: {
    type?: string;
    reasonCode?: string;
    reasonDescription?: string;
  };
  forceLogoutForUpgrade?: boolean;
  forceLogoutForAdditionalService?: boolean;
  ineligibleStatusForUpgrade?: string;
  ineligibleStatusForAdditionalService?: string;
  bundleAndSaveEligible: boolean;
  bundleAndSaveEligibleText: string;
  /**
   * Bundle and Save CTA (e.g. Change plan to be eligible for bundle and save)
   */
  serviceCta: string;
}

/**
 * TODO: Error scenarios
 */
export interface CustomerDetails {
  /**
   * NOTE: This will always be present, except for certain hardstop scenarios where we can't actually access the data
   */
  customerAccountId?: string;
  /**
   * NOTE: This will always be present, except for certain hardstop scenarios where we can't actually access the data
   */
  equipmentLimitRemaining?: string;
  /**
   * NOTE: This will always be present, except for certain hardstop scenarios where we can't actually access the data
   */
  equipmentLimitUsed?: string;
  /**
   * NOTE: This will always be present, except for certain hardstop scenarios where we can't actually access the data
   */
  approvedConnections?: string;
  /**
   * NOTE: This will always be present, except for certain hardstop scenarios where we can't actually access the data
   */
  maximumConnections?: string;
  /**
   * NOTE: This will always be present, except for certain hardstop scenarios where we can't actually access the data
   */
  liveConnections?: string;
  services: readonly CustomerServiceDetails[];
  primaryMobilePhone?: string;
}

export interface CustomerProductsEligibility {
  internationalPassport?: boolean;
  overdueAccount?: boolean;
  monthsIntoContract?: string;
  monthsRemaining: string;
  planProductName: string;
  propositionIdentifier: string;
  upgradeEligibilityIndicator?: boolean;
  upgradeOptions?: UpgradeOptions;
  upgradeEligiblePlans?: string[];
  errors?: IntegrationError[];
}

/**
 * Cart
 */

export enum CatalogCode {
  NBN_MODEMS = 'CATNBNMODEMS',
  NBN_PLANS = 'CATNBNPLANS',
  FHW_4G_PLANS = 'CATFHWPLANS',
  FHW_5G_PLANS = 'CAT5GFHWPLANS',
  POSTPAID_HANDSET_INSURANCE_PLANS = 'CATPOSTPAIDINSURANCEPLANS',
  POSTPAID_HANDSET_PLANS = 'CATPOSTPAIDHANDSETPLANS',
  POSTPAID_HANDSETS = 'CATPOSTPAIDHANDSETS',
  POSTPAID_SIMO_PLANS = 'CATPOSTPAIDSIMOPLANS',
  POSTPAID_SIMO_TPG_SM = 'CATPOSTPAIDSIMOPLANSTPGSM',
  POSTPAID_TABLET = 'CATMBBPOSTPAIDTABLETS',
  POSTPAID_TABLET_PLANS = 'CATMBBTABLETPOSTPAIDPLANS',
  POSTPAID_TABLET_SIMO_PLANS = 'CATMBBTABLETPOSTPAIDSIMOPLANS',
  POSTPAID_MBB_MODEMS = 'CATMBBPOSTPAIDMODEMS',
  POSTPAID_MBB_MODEM_PLANS = 'CATMBBMODEMPOSTPAIDPLANS',
  POSTPAID_MBB_MODEM_SIMO_PLANS = 'CATMBBMODEMPOSTPAIDSIMOPLANS',
  PREPAID_COMBO_PLUS_PLANS = 'CATPREPAIDCOMBOPLUSPLANS',
  PREPAID_PAY_AND_GO_PLANS = 'CATPREPAIDPAYANDGOPLANS',
  EXTRAS = '', // Child products dont need a catalogcode and wont be managed separate from the parent
  CART_PROMO_OFFER = 'CARTPROMOOFFER', // It is a fake identifier for Promotoolkit purpose
  PREPAID_HANDSETS = 'CATPREPAIDHANDSETS',
  PREPAID = 'CATPREPAIDHANDSETPLANS',
  POSTPAID_WEARABLES = 'CATPOSTPAIDWEARABLES',
}

export const RafEligibleCatalogCodes = [
  CatalogCode.POSTPAID_HANDSET_PLANS,
  CatalogCode.POSTPAID_SIMO_PLANS,
  CatalogCode.POSTPAID_TABLET_PLANS,
  CatalogCode.POSTPAID_TABLET_SIMO_PLANS,
  CatalogCode.FHW_4G_PLANS,
  CatalogCode.FHW_5G_PLANS,
  CatalogCode.NBN_PLANS,
  CatalogCode.POSTPAID_MBB_MODEM_PLANS,
  CatalogCode.POSTPAID_MBB_MODEM_SIMO_PLANS,
];

export enum PageContentSections {
  TITLE_DESC = 'TITLEDESCRIPTION',
  USPS = 'USPS',
  DEFAULT_DESC = 'DEFAULTDESCRIPTION',
  PLAN = 'PLAN',
  BREADCRUMB = 'BREADCRUMB',
}

// if adding any prepaid catalog code please also add to this list
export const PrepaidCatalogCodes = [
  CatalogCode.PREPAID_COMBO_PLUS_PLANS,
  CatalogCode.PREPAID_PAY_AND_GO_PLANS,
  CatalogCode.PREPAID_HANDSETS,
];

export const PostpaidCatalogCodes = [
  CatalogCode.POSTPAID_HANDSETS,
  CatalogCode.POSTPAID_HANDSET_INSURANCE_PLANS,
  CatalogCode.POSTPAID_HANDSET_PLANS,
  CatalogCode.POSTPAID_SIMO_PLANS,
  CatalogCode.POSTPAID_TABLET,
  CatalogCode.POSTPAID_TABLET_PLANS,
  CatalogCode.POSTPAID_TABLET_SIMO_PLANS,
  CatalogCode.POSTPAID_WEARABLES,
  CatalogCode.POSTPAID_MBB_MODEM_PLANS,
];
export const PostpaidSimoCatalogCodes = [
  CatalogCode.POSTPAID_SIMO_PLANS,
  CatalogCode.POSTPAID_TABLET_SIMO_PLANS,
  CatalogCode.POSTPAID_SIMO_TPG_SM,
  CatalogCode.POSTPAID_MBB_MODEM_SIMO_PLANS,
];

export enum CartItemType {
  ADDON = 'ADDON',
  DEVICE = 'DEVICE',
  EXTRA = 'EXTRA',
  MODEM = 'MODEM',
  MBB_MODEM = 'MBB_MODEM',
  OFFER = 'OFFER', // fallback item type
  PLAN = 'PLAN',
  HARDWARE = 'HARDWARE', // sim card
  TABLET = 'TABLET',
  SMARTWATCH = 'WEARABLE',
}

enum ProductType {
  DEVICE = 'Device',
  HARDWARE = 'Hardware',
  NONE = 'None',
  PLAN_FIXED = 'Plan - Fixed',
  PLAN_VOICE = 'Plan - Voice',
  PLAN_MBB = 'Plan - MBB',
  SMARTWATCH = 'Wearable',
}

export const CartProductType = { ...ProductType, ...ExtraType };
export type CartProductType = ProductType | ExtraType;

export enum ProductSubType {
  HANDSET = 'Handset',
  HANDSET_M2M = 'Handset M2M',
  HANDSET_M2M_PLUS = 'Handset M2M Plus',
  NBN_MODEM = 'NBN Modem',
  NBN_MODEM_M2M = 'NBN Modem M2M',
  NBN_BYO_M2M = 'NBN BYO M2M',
  FHW_4G_M2M = 'FWA 4G Modem M2M',
  FHW_5G_M2M = 'FWA 5G Modem M2M',
  TABLET = 'Tablet',
  SIM = 'SIM',
  ESIM = 'eSIM',
  MBB_MODEM = 'MBB Modem',
  MBB_M2M_PLUS = 'MBB M2M Plus',
  PREPAID = 'Prepaid',
  PREPAID_HANDSET = 'Prepaid Handset',
  WEARABLES = 'Wearable',
}

export enum ProductManufacturer {
  APPLE = 'Apple',
  SAMSUNG = 'Samsung',
}

export const CartProductSubType = { ...ProductSubType, ...ExtraType };
export type CartProductSubType = ProductSubType | ExtraType;

export interface CartAction {
  lineItemKey: string;
  bundleContextKey: string;
}

export interface CartPriceInfo {
  oneTimeCharge: number;
  recurringCharge: number;
  oneTimeLoyalty: number;
  recurringLoyalty: number;
}

/**
 * Common
 */

export interface PageHeaderContent extends PageMetaContent {
  altBreadcrumb: string;
  altDescription: string;
  altTitle: string;
  defaultBreadcrumb: string;
  defaultDescription: string;
  defaultTitle: string;
  experienceFragments: ExperienceFragment[][];
}

export interface PageMetaContent {
  metaTags: string;
  seoData: string[];
  seoTitle: string;
}

export interface OffersContent {
  analyticsAttribute: string;
  disableAnalytics: boolean;
  offersList: OfferItem[];
  numberOfOffers: number;
}

export interface OfferItem {
  code: string;
  description: string;
  iconUrl: string;
  title: string;
}

export interface FaqContent {
  faqItems: FaqItem[];
  identifier: string;
  sectionTitle: string;
}

export interface FaqItem {
  description: string;
  title: string;
}

export interface ModalItem {
  id: string;
  templateId: string;
  title: string;
  subTitle: string;
  content: string;
  cancelCtaLabel: string;
  confirmCtaLabel: string;
  triggerLabel?: string;
}

export interface TermsAndConditionsContent {
  termsConditionsDesc: string;
}

export interface TimelineItem {
  imageUrl: string;
  description: string;
  title: string;
}

export interface TimelineContent {
  title: string;
  items: TimelineItem[];
}

export interface BasePlan {
  discountedOneTimeCharge?: number;
  discountedRecurringCharge: number;
  planId: string;
  order: number;
  planName: string;
  planDescription: string;
  planData: string;
  planTenure: string;
  contractTerm: number;
  planTitle: string;
  subHeadingPrimary: string;
  subHeadingSecondary: string;
  ctaLabel: string;
  heroLabel: string;
  heroOfferId: string;
  cisLabel: string;
  ctaDisabledLabel: string;
  ctaSelectedLabel: string;
  cisUrl: string;
  planExtraInfo: string;
  planImage: {
    imageUrl: string;
    altText: string;
  };
  inclusions: PlanInclusion[];
  recurringCharge: number;
  planProductName: string;
  planSubType: string;
  oneTimeCharge?: number;
  validity?: string;
  promotions: Promotion[];
  isBundleAndSaveEligible: boolean;
  isTrialPlan: boolean;
  includePromotionPlanData?: string;
  footnote?: string;
  hideWasLabel?: boolean;
  expandPlanByDefault?: boolean;
  expandPlanOnMobile?: boolean;
  homeInternetType?: HomeInternetType;
}

export enum DataLimit {
  LIMITED = 'Limited',
  UNLIMITED = 'Unlimited',
}

export interface PlanInclusion {
  description: string;
  iconUrl: string;
  planId: string;
  title: string;
  hideFromCart?: boolean;
  forMobile?: boolean;
  forTablet?: boolean;
  name?: string;
  forWatch?: boolean;
  simpleDescription?: string;
  eligibleBrands?: null;
}

export interface HeaderFooter {
  header: string;
  footer: string;
  includes: Include[];
}

export interface NavigationResponse {
  main: HeaderFooter;
  upgrades: HeaderFooter;
}

export interface AbandonedCartData {
  ctaAriaLabel: string;
  ctaLabel: string;
  ctaUrl: string;
  linkLabel: string;
  planIcon: string;
  title: string;
}

export interface AcnBanner {
  heroImage: string;
  icon: string;
  bgColor: string;
  description: string;
  textColor: string;
}

export interface InlineBannerType {
  customBgColor: string;
  callbackQueueName: string;
  bannerId: string;
  description?: string;
  theme: string;
  heroImage?: string;
  title?: string;
  ctaLink?: string;
  ctaLabel?: string;
  termsAndConditions?: string;
}

export interface Include {
  name: string;
  type: string;
  source: string;
}

export interface ModalResponse {
  modals: ModalItem[];
}

export interface CtaItemContent {
  sectionTitle: string;
  ctaItems: CtaItem[];
}

export interface CtaItem {
  ctaLabel: string;
  ctaUrl: string;
  description: string;
  imageUrl: string;
  title: string;
}

export type GlobalModal =
  | string
  | {
      id: string;
      isOpen: boolean;
      /**
       * This may be `null` if the modal may not be dismissed
       */
      onClose: (() => void) | null;
      cancelCtaAction: (() => void) | string;
      confirmCtaAction: (() => void) | string;
    };

export interface ExpressUpgradeBaseContent {
  headerContent: PageHeaderContent;
  promotions?: Promotion[];
  quickLinksContent: QuickLinkContent;
  offers?: Offers;
  morePlanInfoContent: {
    morePlanInfoList: readonly MorePlanInfo[];
  };
  faqContent: FaqContent;
  tncsContent: TermsAndConditionsContent;
}

export interface FormFields {
  fieldName: string;
  fieldLabel: string;
}

export interface SectionFields {
  sectionTitleKey: string;
  sectionTitleLabel: string;
  sectionDescription: string;
  formFields: FormFields[];
}

export interface ReviewOrderContent {
  infoText: string;
  legalText: string;
  ctaLabel: string;
  sectionFields: SectionFields[];
}

export interface ExpressLandingPageQuery {
  hid?: string;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
}

export interface ExpressCheckoutPageResponse extends ExpressUpgradeBaseContent {
  reviewOrderContent: ReviewOrderContent;
  alertsContent?: Alert[];
}

export interface ExpressConfirmationPageResponse extends ExpressUpgradeBaseContent {
  alertsContent: Alert[];
  reviewOrderContent: ReviewOrderContent;
}

export interface ExpressUpgradePlanPageResponse extends ExpressUpgradeBaseContent {
  alertsContent?: Alert[];
}

export interface ExpressUpgradeDevicePageResponse extends ExpressUpgradeBaseContent {
  alertsContent?: Alert[];
}

export interface ExpressChangePlanPageResponse extends ExpressUpgradeBaseContent {
  alertsContent?: Alert[];
}

export interface ExpressJourneySlugToLandingPageTypeMap {
  [ExpressJourneySlug.PHONE_AND_PLAN]: ExpressUpgradeDevicePageResponse;
  [ExpressJourneySlug.SIMO]: ExpressUpgradePlanPageResponse;
  [ExpressJourneySlug.RPC]: ExpressChangePlanPageResponse;
}

export interface ExpressSubmitOrderResponse {
  payload: {
    Order: {
      orderType: 'Upgrade' | 'SIMO' | 'RPC';
      orderID: string;
      orderDateTime: string;
      msisdn: string;
      dealerCode: string;
      channel: string;
    };
    Plan: {
      targetPropositionSAMID: string;
      targetPlanID: string;
      targetPlanTerm: string;
    };
    Device?: {
      deviceSKU: string;
      deviceName: string;
      estimatedMonthlyDeviceRepayment: string;
      devicePaymentPlanTerm: string;
      devicePriceIncGST: string;
    };
    Offer: {
      promoCode: string;
    };
    Addon?: ReadonlyArray<{
      SAMId: string;
    }>;
    ShipmentAddress: {
      addressId: string;
      validated: string;
      type: string;
      streetNumber: string;
      streetName: string;
      streetType: string;
      city: string;
      state: string;
      country: string;
      postalCode: string;
      deliveryPointCode: string;
      lineOne: string;
      floorType: string;
      floor: string;
    };
    DeliveryNotification?: {
      notificationMethod: 'Email' | 'TXT' | 'Email and TXT' | 'None';
      notificationMSISDN: boolean;
      notificationEmail: string;
    };
    OfferEmailContent: ReadonlyArray<{
      title: string;
      description: string;
      iconPath?: string;
    }>;
  };
}
export interface DeviceDetailsResponse {
  model: string;
  color: string;
  largeImageGalleryUrls?: string[];
  capacity: string;
  externalSkuId: string;
}

export interface VFECustomPageTrackResponse {
  pageTitle: string;
  path: string | null;
  activeMsisdn: string | null;
  accountType: string | null;
  serviceType: string | null;
}

export interface VFECustomEventTrackResponse {
  pageEventName: string | null;
  pageEventType: string;
  pageEventValue: string;
  pageEventAttributeOne: string | null;
  pageEventAttributeTwo: string | null;
  pageEventAttributeThree: string | null;
  pageEventAttributeFour: string | null;
  errorAttribute: string | null;
}

export interface EmailValidationResponse {
  isValid: boolean;
  result: string;
  description: string;
}

export type RafAction = 'New' | 'Delete' | 'Update' | 'Upsert';

export interface RafValidateAndFetchRequest {
  basketId: string;
  raf: RafRequestParams;
}

export interface RafRequestParams {
  rafCode: string;
  rafCatalogCodes: Array<CatalogCode>;
  action: RafAction;
  toBeValidated: boolean;
}

export interface DeleteRafRequest {
  basketId: string;
  raf: {
    action: RafAction;
  };
}

export interface TradeInJsonResponse {
  DeviceMake: string;
  DeviceModel: string;
  DeviceCapacity?: number | string;
  FromDate: string;
  ToDate: string;
  GwoPrice: number;
  NgwoPrice?: number;
}
export interface OtpPageResponse {
  pageHeaderData: PageHeaderContent;
  alerts: readonly Alert[];
  content: {
    backTextLink: string;
    description: string;
    enterOtpCodeLabelText: string;
    otpCtaLabel: string;
    otpAlternateCtaLabel: string;
    newCodeCtaLabel: string;
  };
}

export interface PinPageResponse {
  headerContent: PageHeaderContent;
  alertsContent: readonly Alert[];
  accountPinInfo: {
    backTextLinkLabel: string;
    forgotYourPinDescription: string;
    forgotYourPinLinkLabel: string;
    accountPinLabelText: string;
    pinCtaLabel: string;
    pinAlternateCtaLabel: string;
    newCodeCtaLabel: string;
    mobileNumberLabelText: string;
    mobileNumberHelpText: string;
  };
}

export interface RequestOtpResponse extends RequestBriefCustomerDetailsResponse {}
export interface RequestBriefCustomerDetailsResponse {
  isComplexAccount: boolean;
  msisdnContact: string;
}

export interface ShipmentAddress {
  addressId: string;
  validated: string;
  type: string;
  streetNumber: string;
  streetName: string;
  streetType: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  deliveryPointCode: string;
  lineOne?: string;
  floorType: string;
  floor: string;
}

export interface EUCustomerData {
  msisdnContact: string;
  customerName: string;
  maskedContactPhoneNumber: string;
  maskedEmail: string;
  address: ShipmentAddress;
}

export interface EUReviewCustomerData extends EUCustomerData {
  deliveryDate: string;
}

export interface VerifyOtpResponse {
  access_token: string;
  expires_in: number;
  id_token: string;
  scope: string;
  token_type: string;
}

export interface VerifyPinResponse {
  isPinValid: boolean;
  errorCode?: string;
}

export interface PreviouslyViewedResponse {
  title: string;
  products: PreviouslyViewedItem[];
}

interface PreviouslyViewedItem {
  aemIdentifier: string;
  productDisplayName: string;
  iconPath: string;
}

export interface HomeInternetPlanCardCtaParam {
  plan: HomeWirelessPlan;
  withModem: boolean;
  ctaLabel: string;
  discountedCost: number | null;
}

export interface BraintreeToken {
  token: string;
}

export interface CreateTransactionResult {
  response: string;
  hmac: string;
  tokenizedCardholderName?: string;
}

export type CustomerContactDetails = Pick<
  Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload'],
  'email' | 'phone'
>;

export interface CreateTransactionRequest {
  payload: BraintreePayload;
  details: CustomerContactDetails;
  deviceData: braintree.DataCollector['deviceData'];
  params: PaymentIframeHashParams;
  paymentType: PaymentMethod;
  paymentId?: string;
}

export type PaymentConfigurationKey = 'threeDS' | 'googlePay' | 'aliPay';

export type PaymentConfiguration = {
  threeDS: {
    amountThresholdPrepaid: number;
    amountThresholdPostpaid: number;
  };
  googlePay: {
    merchantId: string;
  };
  aliPay: {
    merchantAccountId: string;
  };
};

export interface CardTransactionResponse {
  orderId: string;
  creditCard: {
    amount: number;
    currency: string;
    expiry: string;
    firstSixDigits: string;
    lastFourDigits: string;
    name?: string;
    token: string;
    type: string;
    transactionId?: string; // for CHARGE
  };
  receiptNumber?: string; // for CHARGE
  response: {
    businessIdentifier: string;
    description: string;
    reasonCode: string;
  };
}

// TODO: this needs to be revised
export interface APMTransactionResult {
  response: string;
  hmac: string;
}

export enum OptimizeContentKey {
  PLAN_ONLINE_OFFER = 'planOnlineOffer',
  CART = 'cartOnline',
  POSTPAID = 'postpaidOnline',
}

export interface PromotionalCampaignsContent extends PromotionalCampaignsBaseContent {
  availability: boolean;
}

export interface StudentValidationContentResponse {
  offerLabel: string;
  fieldLabel: string;
  errorMessage: string;
  title: string;
  ctaLabel: string;
}

export interface TradeInAndSaveContentResponse {
  findOutUrl: string;
  findOutLinkLabel: string;
  deviceModelLabel: string;
  description: string;
  deviceBrandLabel: string;
  creditNotification: string;
  sectionHeading: string;
  tradeInInformation: string;
  customSectionHeading: CustomSectionHeading[];
}

export interface TradeInDetailsContentResponse {
  bonusTradeInChin: string;
  bonusTradeInInformation: string;
  description: string;
  deviceLabel: string;
  deviceNotEligibleMessage: string;
  noBonusTradeInChin: string;
  noBonusTradeInInformation: string;
  sectionHeading: string;
}
export interface CustomSectionHeading {
  productCode: string;
  customSectionHeading: string;
}
export interface tradeInDeviceDetails {
  tradeInDeviceName: string;
}
export interface PromotionalCampaignsBaseContent {
  identifier?: string;
  title?: string;
  subTitle?: string;
  description?: string;
  heroLabel?: string;
  ctaLabel?: string;
  ctaUrl?: string;
  imageUrl?: string;
  offerUrl?: string;
}

export interface PromotionalCampaignsContentResponse {
  promotionalCampaigns: PromotionalCampaignsBaseContent[];
}

export interface PaypalSTCRequest {
  msisdn: string;
  orderId: string;
}

export interface PaypalSTCResult {
  clientMetadataId: string;
}

export interface DeviceDataRequest {
  client: braintree.Client;
  paypal?: boolean;
  riskCorrelationId?: string;
}

export interface CommonErrorContentResponse {
  alertTitle?: string;
  alertText?: string;
  alertIcon?: string;
  primaryCtaLabel?: string;
  btnUrl?: string;
}

export type OnlinePromoContentParams = {
  catalogCode: CatalogCode;
  promoAvailability: boolean;
  optimizeContentKey: OptimizeContentKey;
};
export interface HomeInternetUIMessages {
  continue4gFhwJourney: boolean;
  continue5gFhwJourney: boolean;
  continueNbnJourney: boolean;
  exceptions: { message: string };
  installation: { message: string }[];
  mobileCoverage: { message: string };
  internetTechnology: { message: string; type: string };
  status: string;
}

export interface HomeInternetUIMessages1SQ {
  continue4gFhwJourney: boolean;
  continue5gFhwJourney: boolean;
  continueNbnJourney: boolean;
  exceptions: {
    nbn: { message: string };
    fhw4g: { message: string };
    fhw5g: { message: string };
  };
  installation: { message: string }[];
  mobileCoverage: { message: string };
  internetTechnology: {
    nbn: { message: string };
    fhw4g: { message: string };
    fhw5g: { message: string };
  };
  status: string;
}

export interface ContentReOrderingPosition {
  catalogCode: CatalogCode;
  approvedPositions: PageContentSections[];
}

export interface SubmitAPMPaymentRequest {
  deviceData: braintree.DataCollector['deviceData'];
  params: PaymentIframeHashParams;
  paymentId: string;
  msisdn: string;
}

export interface SubmitAPMPaymentResult {
  response: Object;
  reasonCode?: string;
  description?: string;
  businessIdentifier: string;
  errorMessage?: string;
  fusionResultCode?: string;
}

export interface PartnerSamsungContent {
  identifier: string;
  desktopBannerImage: string;
  mobileBannerImage: string;
  bannerCTAUrl: string;
}

// if adding any postpaid Mobile SIMO catalog code please also add to this list
export const PostpaidMobileSIMOCatalogCodes = [CatalogCode.POSTPAID_SIMO_PLANS];

/**
 * Smart Watch Page
 */

export interface SmartWatchPageParams {
  deviceEndpoint?: DeviceEndpoint;
  watchId: string;
  date?: string; // Preview use only
  delay?: number; // optional argument only used for CPT to simulate API response time
}
/** Smart Watch Details page mock response
 *  will be replaced once real API endpoint is integrated */
export interface WatchConfigPricingMatrix {
  [color: string]: {
    [caseSize: string]: {
      [bandName: string]: {
        [bandColor: string]: {
          [bandSize: string]: DeviceConfigPricingEntry[];
        };
      };
    };
  };
}
export interface BaseDeviceDetailsPageResponse {
  alerts: Alert[];
  deviceStockStatus: DeviceStockStatus;
  errors?: IntegrationError[];
  expressDelivery: DeliveryAvailabilityContent;
  clickAndCollect: DeliveryAvailabilityContent;
  labels: {
    upgradeHeadingLabel: string;
    compareFields?: CompareField[];
    breadcrumbLabel: string;
    colourLabel: string;
    phoneCostLabel: string;
    ctaLabel: string;
    altCtaLabel: string;
    repaymentPeriodLabel: string;
    deviceInformationLabel: string;
    similarDevicesLabel: string;
    esimDeviceNotificationLabel?: string;
    esimOnlyDeviceNotificationLabel?: string;
    upgradeCTALabel: string;
    upgradeDescriptionLabel: string;
    capacityLabel?: string;
    caseSizeLabel?: string;
    bandSizeLabel?: string;
    bandColourLabel?: string;
    bandLabel?: string;
  };
  promotions?: Promotion[];
  invalidEnrichmentPromotions?: Promotion[];
}
export interface DevicePageResponse extends BaseDeviceDetailsPageResponse {
  deviceDetails: DeviceDetails;
  deviceConfig: DeviceConfigPricingMatrix;
  planDetails?: PrepaidPlan;
  experienceFragments: ExperienceFragment[][];
}

export interface ModemPageParams {
  deviceEndpoint?: DeviceEndpoint;
  modemId: string;
  date?: string; // Preview use only
  delay?: number; // optional argument only used for CPT to simulate API response time
}

export interface ModemPageResponse extends BaseDeviceDetailsPageResponse {
  deviceDetails: DeviceDetails;
  deviceConfig: ModemConfigPricingMatrix;
}
export interface SmartWatchPageResponse extends BaseDeviceDetailsPageResponse {
  deviceDetails: WatchDeviceDetails;
  deviceConfig: WatchConfigPricingMatrix;
  experienceFragments: ExperienceFragment[][];
}
export interface WatchDeviceDetails {
  deviceTermsConditions: string;
  connectionType: string;
  announcementPhase: boolean;
  caseSizes: DeviceCaseSize[];
  catalogCode: CatalogCode;
  colors: DeviceColor[];
  bandColors: DeviceBandColor[];
  bandNames: DeviceBandName[];
  bandSizes: DeviceBandSize[];
  contractTerm: DeviceContractTerm[];
  defaultCaseSize: string;
  defaultColor: string;
  defaultContractTerm: string;
  defaultBandName: string;
  defaultBandSize: string;
  defaultBandColor: string;
  deviceSku?: string;
  deviceSubType: string;
  deviceType: string;
  features: DeviceFeatures;
  heroOffer?: string;
  id: string;
  is5gCapable: boolean;
  manufacturer: string;
  metaTags?: string;
  minimumCharge: number;
  name: string;
  recurringCharge: number;
  relatedProducts?: DeviceRelatedProduct[];
  seoData?: string[];
  seoTitle?: string;
  specification: DeviceSpecContent[];
  simTypeCompatibility: SimTypeCompatibility;
  deviceDataCapability: string;
  networkCapability?: string;
  customStockAlertID?: string;
  hideStockMessaging?: boolean;
}
export type DeviceCaseSize = VlocityAttribute;
export type DeviceBandSize = VlocityAttribute;
export type DeviceBandName = VlocityAttribute;
export interface DeviceBandColor extends VlocityAttribute {
  hexCode: string;
}

export interface WatchDeviceBasketRequestItem extends BasketRequestItem {
  matrixRowKey: string;
  productConfig: {
    color: string;
    contractTerm: string;
    deviceSku: string;
    imageUrl?: string;
    orderType: string;
    caseSize: string;
    bandName: string;
    bandSize: string;
    bandColor: string;
  };
  manufacturer: string;
  itemType: CartItemType.SMARTWATCH;
}
export interface Locality {
  category: string;
  id: number;
  latitude: string;
  location: string;
  longitude: string;
  postcode: number;
  state: string;
}

export interface LocalityResponse {
  localities: Locality[];
}
