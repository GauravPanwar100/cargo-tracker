/* eslint-disable no-console */
import { Agent, ServerResponse } from 'http';
import { DeepPartial } from '@kablamo/kerosene';
import axios, { AxiosInstance } from 'axios';
import HttpsProxyAgent from 'https-proxy-agent/dist/agent';
import { NextPageContext } from 'next';
import { sleep } from '@src/common/js/sleep';
import {
  deviceExtrasPageMock,
  devicePageDataMock,
  devicesPostpaidMock,
  plansPrepaidPageMock,
  refreshPlanPageMock,
  smartWatchListingMock,
} from '@src/lib/api/mocks';
import {
  AcnBanner,
  AddToBasketParams,
  AdditionalServicesBundleResponse,
  AdditionalServicesPageResponse,
  AddressCheckerResponse,
  AvailableDeliveryStoreResponse,
  AvailableDeliveryStoresParams,
  BNSOfferParams,
  Basket,
  BasketParams,
  BasketRequestItem,
  BasketResponse,
  BnsOffer,
  BraintreeToken,
  CartPageResponse,
  CatalogCode,
  ChildBasketRequestItem,
  CreateTransactionRequest,
  CreateTransactionResult,
  CurrentServiceData,
  CurrentServiceDataWithoutContent,
  CustomerDetails,
  CustomerProductsEligibility,
  DeleteRafRequest,
  DeliveryDatesParams,
  DeliveryDatesResponse,
  DeliveryDatesResponseItem,
  DeviceDetailsResponse,
  DeviceEndpoint,
  DevicePageParams,
  DevicePageResponse,
  DeviceStockStatus,
  DevicesPageParams,
  DevicesPageResponse,
  EUCustomerData,
  EmailValidationResponse,
  ExperienceFragmentsResponse,
  ExpressJourneySlugToLandingPageTypeMap,
  ExpressSubmitOrderResponse,
  ExtrasPageDataParams,
  ExtrasPageResponse,
  HomeWirelessPageResponse,
  HomeWirelessPlansResponse,
  ModalResponse,
  ModemPageParams,
  ModemPageResponse,
  NavigationResponse,
  NbnPageResponse,
  NbnPlansResponse,
  OtpPageResponse,
  PartnerSamsungContent,
  PaymentConfiguration,
  PaymentConfigurationKey,
  PaypalSTCRequest,
  PaypalSTCResult,
  PinPageResponse,
  PlanDetailsPageDataParams,
  PlansPageDataParams,
  PlansPageResponse,
  PreviouslyViewedResponse,
  PromoAvailibilityParams,
  PromoAvailibilityResponse,
  PromoSubtype,
  PromotionalCampaignsContentResponse,
  RafValidateAndFetchRequest,
  RefreshPlansPageAndExperienceFragmentsResponse,
  RefreshPlansPageResponse,
  RemovePackageFromBasketParams,
  RequestBriefCustomerDetailsResponse,
  RequestOtpResponse,
  SmartWatchPageParams,
  SmartWatchPageResponse,
  StrippedBasketRequestItem,
  StudentValidationContentResponse,
  SubmitAPMPaymentRequest,
  SubmitAPMPaymentResult,
  TradeInAndSaveContentResponse,
  TradeInDetailsContentResponse,
  TradeInJsonResponse,
  UpgradesHeaderResponse,
  UpgradesPageResponse,
  VerifyOtpResponse,
  VerifyPinResponse,
  tradeInDeviceDetails,
} from '@src/lib/api/types';
import { ExpressJourneySlug } from '@src/lib/constants/express';
import Logger, { LoggerExtras } from '@src/lib/logger/logger';
import { LocalStorageClient, SessionStorageClient } from '@src/lib/storage';
import { ServiceTypeValue } from '@src/lib/storage/types';
import AppStore from '@src/lib/util/app-store';
import { basketResponseToBasket } from '@src/lib/util/cart';
import { preview } from '@src/lib/util/preview';

export const tradeInEndpoint = process.env.S3_URI || 'https://www-dev.test.cms.df.services.vodafone.com.au';

export const apiEndpoint =
  process.env.VFE_INTEGRATION_API || 'https://dev01-integrationapi.test.cms.df.services.vodafone.com.au';

export const integrationStage = process.env.VFE_INTEGRATION_STAGE || '';
const updateCartExpiryOnModification = process.env.VHA_CART_EXPIRY_WITH_MODIFICATION === 'true';

export const formatLocalityEndpointUrl = (searchCriteria: string) =>
  `${apiEndpoint}/locality/${searchCriteria.replace(' ', '-')}`;

export const formatAddressSearchEndpointUrl = (searchCriteria: string) =>
  `${apiEndpoint}/locality/internet/addresses/search?query=${searchCriteria}`;

/**
 * For client-side rendering, we need the ApiClient to be a singleton so that we
 * can store the Auth-token (which is required by some APIs). By returning the
 * same ApiClient object, we preserve the object's id, which is important
 * when React is determining whether to re-run a render function containing this object.
 *
 * BUT, for server-side rendering (which is not reliant on the Auth token), we
 * require the context object so that we can write a response header when an
 * API returns a non-200 response.
 *
 * @param context
 */
export function getApiClient(context?: NextPageContext) {
  if (!context) {
    return clientSideApiClient; // This is created once - a singleton
  }
  return new ApiClient(context);
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function handleErrorLogging(error: any, extras: LoggerExtras) {
  Logger.error(error.message, {
    ...extras,
    error,
  });
}

class ApiClient {
  private axiosClient: AxiosInstance;

  private previewDate: string | undefined;

  /**
   * Function that resolves with the VHA Auth0 access token. This returns a `Promise` as it may
   * need to make an async call to refresh the access token if it has expired.
   */
  public getAccessToken?: () => Promise<string>;

  /**
   * If we are SSR, we may need to write a header based on an API response.
   * So the constructor now passes the Next context object, which has this response
   * object, which has a setHeader() method which we can use.
   * @private
   */
  private readonly serverResponse: ServerResponse | undefined;

  public constructor(context?: NextPageContext) {
    this.serverResponse = context?.res;

    let agent: Agent | undefined;
    const proxy = process.env.HTTP_PROXY;
    if (proxy) {
      agent = new HttpsProxyAgent(proxy);
    }

    this.axiosClient = axios.create({ httpsAgent: agent });
    this.axiosClient.interceptors.request.use((request) => {
      request.headers.common['X-SessionID'] = AppStore.getE2eSessionId();
      request.headers.common['X-InitialSystem'] = AppStore.getXInitialSystem();
      request.headers.common['X-InitialComponent'] = AppStore.getXInitialComponent();

      // Clear errors (CE) from the API response by default.
      // If window.$$VFE_HEADER === false, don't send the header.
      if (typeof window !== 'undefined' && window.$$VFE_HEADER !== false) {
        request.headers.common['x-vfe'] = 'CE';
      }

      const extras: LoggerExtras = {
        ucode: '4306a44',
        request,
      };
      Logger.debug('axios request', extras);
      return request;
    });

    this.axiosClient.interceptors.response.use(
      (response) => {
        const { sourceip } = response.headers;

        // If we have a non-200 API response, we are going to send a cache-control header to CloudFront, telling
        // Cloudfront how long to cache the response for. We have to use the s-maxage directive for Cloudfront,
        // but also send the max-age directive to zero to prevent browser caching returning stale data.
        // See https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/Expiration.html
        if ((response.status !== 200 || this.serverResponse?.statusCode !== 200) && this.serverResponse) {
          // Write a header to indicate that we should not cache this page for long
          // Note: This doesn't work in dev-mode! Need to run server in production mode
          Logger.info('Cache-control override', { ...this.serverResponse, ...response, ucode: '0f20b2e' });
          this.serverResponse.setHeader('cache-control', 's-maxage=120, max-age=120'); // 120 seconds, 2 minutes
        }

        if (sourceip) {
          LocalStorageClient.setSourceIP(sourceip);
        }

        const extras: LoggerExtras = {
          ucode: '6736971',
          response,
        };
        Logger.debug('axios response', extras);
        return response;
      },
      (error) => {
        Logger.debug('axios error', error);
        if (this.serverResponse) {
          Logger.info('Cache-control override', { ...this.serverResponse, ucode: '5c29014' });
          this.serverResponse.setHeader('cache-control', 's-maxage=120, max-age=120'); // 120 seconds, 2 minutes
        }
        return Promise.reject(error);
      },
    );
  }

  public setPreviewDate = (date: string | undefined) => {
    this.previewDate = date;
  };

  public getPreviewDate = () => {
    return this.previewDate;
  };

  public setGetAccessToken = (getAccessToken?: () => Promise<string>) => {
    this.getAccessToken = getAccessToken;
  };

  private async getAuthHeaders() {
    const accessToken = await this.getAccessToken?.();

    if (!accessToken) throw new Error('No accessToken was available when attempting to call an authenticated endpoint');

    return {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    };
  }

  // Get json file for asurion  for trade In
  public fetchDeviceAndPriceInfo = async () => {
    try {
      const url = `${tradeInEndpoint}/content/trade-in/asurionpricelist.json`;
      const response = await this.axiosClient.get<TradeInJsonResponse[]>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '3f76834',
      });
      return Promise.reject(err);
    }
  };
  /**
   * Fetching Header and Footer
   */

  public fetchNavigation = async () => {
    try {
      const url = `${apiEndpoint}/content/navigation`;
      const response = await this.axiosClient.get<NavigationResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'e8c8652',
      });
      return Promise.reject(err);
    }
  };

  /**
   * previously viewed component content
   */
  public fetchPreviouslyViewedContent = async () => {
    try {
      const url = `${apiEndpoint}/content/previously-viewed`;
      const response = await this.axiosClient.get<PreviouslyViewedResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '5983a23',
      });
      return Promise.reject(err);
    }
  };

  /**
   * ACN Banner
   */

  public fetchAcnBanner = async () => {
    try {
      const url = `${apiEndpoint}/content/acn-banner`;
      const response = await this.axiosClient.get<AcnBanner>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'f5c5583',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Partner Samsung Banner
   */

  public fetchPartnerSamsungContent = async () => {
    try {
      const url = `${apiEndpoint}/content/partner-samsung`;
      const response = await this.axiosClient.get<PartnerSamsungContent>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '789484e',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Devices Page
   */

  public fetchDevicesPageData = async ({
    date,
    deviceEndpoint,
    delay,
  }: DevicesPageParams): Promise<DevicesPageResponse> => {
    try {
      if (this.triggerMockResponse(delay)) {
        return await this.fetchMockedDevicesPageData(delay as number, deviceEndpoint);
      }

      const url = `${apiEndpoint}/device/${deviceEndpoint}`;

      // Add optional date parameter for preview mode
      const dateString = this.getPreviewDateString(date);
      const serviceType = LocalStorageClient.getServiceType() ?? ServiceTypeValue.NewAcquisition;

      const response = await this.axiosClient.get<DevicesPageResponse>(url, {
        params: { date: dateString, serviceType },
      });
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '97cb16d',
      });
      return Promise.reject(err);
    }
  };

  /**
   * CPT requires us to load just the VFE lambda, which we achieve through this condition allowing us to
   * inject artificial controllable latency into the 'API' call.
   */
  private fetchMockedDevicesPageData = async (delay: number, deviceEndpoint: DeviceEndpoint) => {
    handleErrorLogging(`artificially delaying for ${delay} ms and returning mock`, {
      ucode: '74d96b7',
    });
    await sleep(delay).then(() => {
      handleErrorLogging(`finished artificial delay of ${delay} ms`, {
        ucode: '9ead6e6',
      });
    });

    return deviceEndpoint === DeviceEndpoint.WEARABLES
      ? (smartWatchListingMock as DeepPartial<DevicesPageResponse> as DevicesPageResponse)
      : (devicesPostpaidMock as DeepPartial<DevicesPageResponse> as DevicesPageResponse);
  };

  /**
   * Mobile Phone Page
   */
  public fetchDevicePageData = async ({
    date,
    deviceEndpoint,
    deviceId,
    delay,
  }: DevicePageParams): Promise<DevicePageResponse> => {
    try {
      if (this.triggerMockResponse(delay)) {
        return await this.fetchDevicePageDataMock(delay as number);
      }

      const url = `${apiEndpoint}/device/${deviceEndpoint}/${deviceId}`;

      // Add optional date query parameter for preview mode
      const dateString = this.getPreviewDateString(date);
      const serviceType = LocalStorageClient.getServiceType() ?? ServiceTypeValue.NewAcquisition;

      const response = await this.axiosClient.get<DevicePageResponse>(url, {
        params: { date: dateString, serviceType },
      });

      if (response.data.errors && !response.data.deviceDetails) {
        throw new Error(response.data.errors.toString());
      }

      let defaultColorConfigurationIsAvailable = false;
      const { deviceDetails } = response.data;
      const { defaultColor } = deviceDetails;
      deviceDetails.colors.forEach((color) => {
        // TODO this should be validated in the BE and filtered appropriately
        if ('error' in color) {
          throw Error('Unable to display product (malformed device colors)');
        }

        if (defaultColor === color.value) {
          defaultColorConfigurationIsAvailable = true;
        }
      });

      // TODO this logic should live in the BE
      // Remove images that should only be used as a cart image. They are not hi res enough to
      // show on the device details page
      deviceDetails.colors = deviceDetails.colors.map((color) => ({
        ...color,
        images: color.images.filter((image) => !image.useInCart),
      }));

      if (!defaultColorConfigurationIsAvailable) {
        throw Error('Unable to display product (default color is not configured)');
      }
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'b4a514b',
      });
      return Promise.reject(err);
    }
  };

  public fetchDeviceStockStatus = async ({ deviceSku }: { deviceSku: string }) => {
    try {
      const url = `${apiEndpoint}/inventory/availability/${encodeURIComponent(deviceSku)}`;
      const response = await this.axiosClient.get<{ stockStatus: DeviceStockStatus }>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'c37bded',
      });
      return Promise.reject(err);
    }
  };

  /**
   * CPT requires us to load just the VFE lambda, which we achieve through this condition allowing us to
   * inject artificial controllable latency into the 'API' call.
   */
  private fetchDevicePageDataMock = async (delay: number) => {
    handleErrorLogging(`artificially delaying for ${delay} ms and returning mock`, {
      ucode: '5b977a3',
    });
    await sleep(delay).then(() => {
      handleErrorLogging(`finished artificial delay of ${delay} ms`, {
        ucode: '15c4e17',
      });
    });

    return devicePageDataMock as DeepPartial<DevicePageResponse> as DevicePageResponse;
  };

  /**
   * For triggering the return of a mocked response we used for lambda performance testing
   * we want to ensure we are in dev and that the delay has been set
   */
  private triggerMockResponse = (delay: number | undefined) =>
    (integrationStage.toUpperCase() === 'DEV' || integrationStage.toUpperCase() === 'DIT') &&
    typeof delay !== 'undefined' &&
    !Number.isNaN(delay);

  public fetchDeliveryDates = async (params: DeliveryDatesParams): Promise<DeliveryDatesResponseItem> => {
    try {
      const url = `${apiEndpoint}/inventory/delivery`;
      const response = await this.axiosClient.post<DeliveryDatesResponse>(url, params);

      // we only want the first item as this is used for a single device presently
      const data = response.data.devices[0];

      // item may be undefined if the array is empty
      if (!data) {
        throw new Error();
      }

      return data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '8fb578d',
      });
      return Promise.reject(err);
    }
  };

  public fetchAvailableDeliveryStores = async (
    params: AvailableDeliveryStoresParams,
  ): Promise<AvailableDeliveryStoreResponse> => {
    try {
      const url = `${apiEndpoint}/inventory/stores/delivery`;
      const response = await this.axiosClient.post<AvailableDeliveryStoreResponse>(url, params);

      // we only want the first item as this is used for a single device presently
      const { data } = response;

      // item may be undefined if the array is empty
      if (!data) {
        throw new Error();
      }

      return data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '8fb578d',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Plans Page
   */

  public fetchPlansPageData = async ({
    date,
    planEndpoint,
    delay,
    extraOffer,
    planId,
  }: PlansPageDataParams): Promise<PlansPageResponse> => {
    try {
      if (this.triggerMockResponse(delay)) {
        return await this.fetchMockedPlansPageData(delay as number);
      }

      const url = `${apiEndpoint}/plan/${planEndpoint}`;

      // Add optional date query parameter for preview mode
      const dateString = this.getPreviewDateString(date);
      const serviceType = LocalStorageClient.getServiceType() ?? ServiceTypeValue.NewAcquisition;

      const encodedExtraOffer = extraOffer ? encodeURIComponent(extraOffer) : null;
      const encodedPlanId = planId ? encodeURIComponent(planId) : null;
      const response = await this.axiosClient.get<PlansPageResponse>(url, {
        params: { date: dateString, serviceType, extraOffer: encodedExtraOffer, planId: encodedPlanId },
      });

      if (response.data.errors && !response.data.planListing.plans) {
        throw new Error(response.data.errors.toString());
      }

      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '8a80d6f',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Plan Details page for Always-on pages
   */
  public fetchPlanDetailsBySlug = async ({
    date,
    planEndpoint,
    delay,
    slug,
  }: PlanDetailsPageDataParams): Promise<RefreshPlansPageAndExperienceFragmentsResponse> => {
    try {
      if (this.triggerMockResponse(delay)) {
        return await this.fetchMockedRefreshPlansPageData(delay as number);
      }

      const url = `${apiEndpoint}/plan/${planEndpoint}/${slug}?serviceType=New`;
      const experienceFragmentUrl = `${apiEndpoint}/content/additional-plan-details/${CatalogCode.POSTPAID_SIMO_PLANS}/${slug}`;

      // Add optional date query parameter for preview mode
      const dateString = this.getPreviewDateString(date);
      const serviceType = LocalStorageClient.getServiceType() ?? ServiceTypeValue.NewAcquisition;

      const response = await this.axiosClient.get<RefreshPlansPageResponse>(url, {
        params: { date: dateString, serviceType, extraOffer: null },
      });

      const experienceFragmentsResponse = await this.axiosClient.get<ExperienceFragmentsResponse>(
        experienceFragmentUrl,
      );

      if (response.data.errors && !response.data.plan) {
        throw new Error(response.data.errors.toString());
      }

      if (experienceFragmentsResponse.data.errors && !experienceFragmentsResponse.data.experienceFragments) {
        throw new Error(experienceFragmentsResponse.data.errors.toString());
      }

      return {
        ...response.data,
        ...experienceFragmentsResponse.data,
      };
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '0af8eee',
      });
      return Promise.reject(err);
    }
  };

  /**
   * CPT requires us to load just the VFE lambda, which we achieve through this condition allowing us to
   * inject artificial controllable latency into the 'API' call.
   */
  private fetchMockedPlansPageData = async (delay: number) => {
    handleErrorLogging(`artificially delaying for ${delay} ms and returning mock`, {
      ucode: '3802aaa',
    });
    await sleep(delay).then(() => {
      handleErrorLogging(`finished artificial delay of ${delay} ms`, {
        ucode: 'ddd44f1',
      });
    });
    return plansPrepaidPageMock as PlansPageResponse;
  };

  private fetchMockedRefreshPlansPageData = async (delay: number) => {
    handleErrorLogging(`artificially delaying for ${delay} ms and returning mock`, {
      ucode: '91c5g6d',
    });
    await sleep(delay).then(() => {
      handleErrorLogging(`finished artificial delay of ${delay} ms`, {
        ucode: '8xz1g7q',
      });
    });
    return refreshPlanPageMock as RefreshPlansPageResponse;
  };

  public fetchCustomerDetails = async () => {
    try {
      const url = `${apiEndpoint}/customer/details`;
      const response = await this.axiosClient.get<CustomerDetails>(url, await this.getAuthHeaders());

      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: '6ffec0e' });
      throw err;
    }
  };

  public fetchUpgradePlanEligibility = async ({ activeMsisdn }: { activeMsisdn: string }) => {
    try {
      const url = `${apiEndpoint}/customer/products-eligibility?activeMsisdn=${activeMsisdn}`;
      const response = await this.axiosClient.get<CustomerProductsEligibility>(url, await this.getAuthHeaders());

      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '8c38d01',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Extras Page
   */

  public fetchExtrasPageData = async ({ date, delay, params }: ExtrasPageDataParams) => {
    try {
      if (this.triggerMockResponse(delay)) {
        return await this.fetchExtrasPageDataMock(delay as number);
      }

      const url = `${apiEndpoint}/extras/postpaid`;

      // Add optional date query parameter for preview mode
      const dateString = this.getPreviewDateString(date);

      // Convert the Extras Params into a "|" and "," separated string. Axios will URL-encode this for us.
      const products = params.map(({ catalogCode, productCode }) => `${catalogCode}|${productCode}`).join(',');

      const response = await this.axiosClient.get<ExtrasPageResponse>(url, { params: { date: dateString, products } });
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '07b3a57',
      });
      return Promise.reject(err);
    }
  };

  /**
   * CPT requires us to load just the VFE lambda, which we achieve through this condition allowing us to
   * inject artificial controllable latency into the 'API' call.
   */
  private fetchExtrasPageDataMock = async (delay: number) => {
    handleErrorLogging(`artificially delaying for ${delay} ms and returning mock`, {
      ucode: '4f8cbb0',
    });
    await sleep(delay).then(() => {
      handleErrorLogging(`finished artificial delay of ${delay} ms`, {
        ucode: '7e6f620',
      });
    });

    return deviceExtrasPageMock as DeepPartial<ExtrasPageResponse> as ExtrasPageResponse;
  };

  /**
   * Address Checker data
   */

  public fetchAddressCheckerData = async (path: string) => {
    try {
      const url = `${apiEndpoint}/content/${path}`;
      const response = await this.axiosClient.get<AddressCheckerResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'a533405',
      });
      return Promise.reject(err);
    }
  };

  /**
   * NBN Page
   */

  public fetchNbnPageData = async (extraOffer: string) => {
    try {
      const url = `${apiEndpoint}/content/nbn-base${extraOffer ? '-ptk' : ''}`;
      const response = await this.axiosClient.get<NbnPageResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '316bdd0',
      });
      return Promise.reject(err);
    }
  };

  public fetchNbnPlansData = async ({ date, extraOffer }: PlansPageDataParams): Promise<NbnPlansResponse> => {
    try {
      const url = `${apiEndpoint}/plan/nbn`;

      // Add optional date query parameter for preview mode
      const dateString = this.getPreviewDateString(date);
      const serviceType = LocalStorageClient.getServiceType() ?? ServiceTypeValue.NewAcquisition;

      const encodedExtraOffer = extraOffer ? encodeURIComponent(extraOffer) : null;
      const response = await this.axiosClient.get<NbnPlansResponse>(url, {
        params: { date: dateString, serviceType, extraOffer: encodedExtraOffer },
      });

      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '55a5e6d',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Home Wireless Page
   */

  public fetchHomeWirelessPageData = async (path: string) => {
    try {
      const url = `${apiEndpoint}/content/${path}`;
      const response = await this.axiosClient.get<HomeWirelessPageResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '5006248',
      });
      return Promise.reject(err);
    }
  };

  public fetchHomeWirelessPlansData = async ({
    planEndpoint,
    date,
    extraOffer,
  }: PlansPageDataParams): Promise<HomeWirelessPlansResponse> => {
    try {
      const url = `${apiEndpoint}/plan/${planEndpoint}`;

      // Add optional date query parameter for preview mode
      const dateString = this.getPreviewDateString(date);
      const serviceType = LocalStorageClient.getServiceType() ?? ServiceTypeValue.NewAcquisition;
      const encodedExtraOffer = extraOffer ? encodeURIComponent(extraOffer) : null;
      const response = await this.axiosClient.get<HomeWirelessPlansResponse>(url, {
        params: { date: dateString, serviceType, extraOffer: encodedExtraOffer },
      });
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '7206432',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Fetching Additional Services Common Bundle
   */

  public fetchAdditionalServicesBundleData = async () => {
    try {
      const url = `${apiEndpoint}/content/additional-services-bundle`;
      const response = await this.axiosClient.get<AdditionalServicesBundleResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '8c61a78',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Additional Services Page
   */

  public async fetchAdditionalServicesPageData(): Promise<AdditionalServicesPageResponse> {
    try {
      const url = `${apiEndpoint}/content/additional-services-base`;
      const response = await this.axiosClient.get<AdditionalServicesPageResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '7189c7b',
      });
      return Promise.reject(err);
    }
  }

  /**
   * Upgrades page
   */

  public fetchUpgradesPageData = async () => {
    try {
      const url = `${apiEndpoint}/content/upgrades-base`;
      const response = await this.axiosClient.get<UpgradesPageResponse>(url);

      // Hack to re-write the link for "upgrade your phone" to something relative:
      response.data.ctaItems.ctaItems = response.data.ctaItems.ctaItems.map((item) => ({
        ...item,
        ctaUrl: item.ctaLabel === 'Upgrade your phone' ? '/upgrade/mobile/mobile-phones' : item.ctaUrl,
      }));

      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '6a6e412',
      });
      return Promise.reject(err);
    }
  };

  public fetchCurrentServiceData = async ({ activeMsisdn }: { activeMsisdn: string }) => {
    try {
      // Q. Why are we making 2 API calls here?
      // A. To improve cacheability of the application. The content API is
      //    very cacheable. The customer-data is not. For a small client-side
      //    cost (making 2 API calls), we get a big system benefit.
      const [services, content] = await Promise.all([
        this.axiosClient.get<CurrentServiceDataWithoutContent>(
          `${apiEndpoint}/customer/upgrade-services?activeMsisdn=${activeMsisdn}`,
          await this.getAuthHeaders(),
        ),
        this.axiosClient.get<UpgradesHeaderResponse>(`${apiEndpoint}/content/upgrades-header`),
      ]);

      // Change the service-response to include the content data
      const {
        phoneIconUrl,
        planIconUrl,
        tabletIcon,
        serviceCardMessage,
        serviceCardMessageSIMO,
        otherServicesLabel,
        twoWaySmsMessage,
        twoWaySmsIconUrl,
        twoWaySmsInvalidMessage,
      } = content.data.pageHeaderData;
      const servicesAndContent: CurrentServiceData = {
        ...services.data,
        phoneIconUrl,
        planIconUrl,
        tabletIcon,
        serviceCardMessage,
        serviceCardMessageSIMO,
        otherServicesLabel,
        twoWaySmsMessage,
        twoWaySmsIconUrl,
        twoWaySmsInvalidMessage,
      };

      return servicesAndContent;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '475bf20',
      });

      return Promise.reject(err);
    }
  };

  /**
   * Cart Page
   */

  public fetchCartPageData = async () => {
    try {
      const url = `${apiEndpoint}/content/cart-summary`;

      const response = await this.axiosClient.get<CartPageResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'cf21aa4',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Basket Interactions
   */

  public addToBasket = async (params: AddToBasketParams): Promise<Basket> => {
    // eslint-disable-next-line prefer-destructuring -- need to explicitly specify type for subsequent items.map to be callable
    const items: (BasketRequestItem | StrippedBasketRequestItem)[] = params.items;
    const additionalBnsCount = params?.additionalBnsCount || 0;
    // We are going to be adding the items from the sticky cart to any existing cart in local storage
    const basketId = LocalStorageClient.getBasketId() as string;
    // NOTE: We are using the number of milliseconds elapsed since the start of today as the basket's `nextPackageId`.
    // We are doing this instead of an incrementing counter because there is an edge case whereby one tab adds a package
    // to the cart, and before that request completes, another tab also adds to the same basket using the same packageId
    // resulting in a Frankenstein's monster package with multiple plans.
    // The millisecond timestamp is unique enough between tabs, but unfortunately the Vlocity API only accepts signed
    // 32-bit integers as the packageId, which are vastly smaller than `Date.now()` for example. So to avoid integer
    // overflow issues, we clip this down to the number of milliseconds elapsed since the start of the day. This will
    // mean that packages added within the same day will correctly display in the order they were added, but will mean
    // packages added over multiple days may not appear in the order they were added.
    // @see https://vodafoneaus.atlassian.net/browse/VFE-3089
    const now = new Date();
    const msSinceStartOfToday = now.getTime() - new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const nextPackageId = msSinceStartOfToday.toString();

    const basketItemsWithPackageId: (BasketRequestItem | StrippedBasketRequestItem)[] = items.map((item) => ({
      ...item,
      packageId: nextPackageId,
    }));

    const getTradeInDeviceDetails: tradeInDeviceDetails | null = SessionStorageClient.getTradeInDeviceDetails();
    const deviceData = getTradeInDeviceDetails?.tradeInDeviceName;
    const strippedItems: StrippedBasketRequestItem[] = basketItemsWithPackageId.map((item) => ({
      catalogCode: item.catalogCode,
      productCode: item.productCode,
      packageId: item.packageId,
      matrixRowKey: item.matrixRowKey,
      tradeInDeviceName: [
        CatalogCode.POSTPAID_HANDSETS,
        CatalogCode.POSTPAID_WEARABLES,
        CatalogCode.POSTPAID_TABLET,
      ].includes(item.catalogCode)
        ? deviceData
        : undefined,
      childProducts: (item.childProducts as (ChildBasketRequestItem | string)[]).map((child) =>
        typeof child === 'string' ? child : child.productCode,
      ),
    }));

    const extraOffer = (): string => {
      // OnlineBTL promotion
      if (params.extraOffer) {
        return encodeURIComponent(params?.extraOffer);
      }

      // Student promotion
      return basketItemsWithPackageId.some(
        (item) => item.productCode === LocalStorageClient.getStudentOfferInfo().planId,
      )
        ? encodeURIComponent(PromoSubtype.Student)
        : '';
    };

    const url = `${apiEndpoint}/basket${basketId ? `/${basketId}` : ''}`;

    const request = basketId ? this.axiosClient.put : this.axiosClient.post;
    const serviceType = LocalStorageClient.getServiceType() ?? ServiceTypeValue.NewAcquisition;

    const raf = params.raf && serviceType === ServiceTypeValue.NewAcquisition ? params.raf : undefined;

    try {
      const response = await request<BasketResponse>(
        url,
        { items: strippedItems, serviceCount: additionalBnsCount, raf },
        {
          params: {
            serviceType,
            date: this.getPreviewDateString(),
            extraOffer: extraOffer(),
          },
        }, // for Preview Mode in vfe-apis: filter promotions before basket request
      );

      if (response.status === 200 || response.status === 207) {
        LocalStorageClient.updateCartExpiryDate(updateCartExpiryOnModification);
      }

      return basketResponseToBasket(response.data);
    } catch (error) {
      handleErrorLogging(error, {
        ucode: '2ab6685',
      });
      return Promise.reject(error);
    }
  };

  public getBasket = async ({ basketId, additionalBnsCount = 0, extraOffer }: BasketParams): Promise<Basket> => {
    try {
      const url = `${apiEndpoint}/basket/${basketId}`;
      const serviceType = LocalStorageClient.getServiceType();
      const encodedExtraOfferParam = extraOffer ? encodeURIComponent(extraOffer) : null;
      const response = await this.axiosClient.get<BasketResponse>(url, {
        params: {
          serviceType,
          serviceCount: additionalBnsCount,
          extraOffer: encodedExtraOfferParam,
          date: this.getPreviewDateString(),
        },
      });

      if (!response.data.basketId) {
        throw new Error('Error retrieving cart: no basketId returned');
      }

      // If basketId is different from api end, then set new basketId to localstorage
      if (basketId !== response.data.basketId) {
        LocalStorageClient.setBasketId(response.data.basketId);
      }

      return basketResponseToBasket(response.data);
    } catch (error) {
      handleErrorLogging(error, {
        ucode: 'd407dd7',
      });

      return Promise.reject(error);
    }
  };

  public getBnsOffer = async ({ serviceCount }: BNSOfferParams): Promise<BnsOffer> => {
    try {
      const url = `${apiEndpoint}/offer/bnsoffer`;

      const response = await this.axiosClient.get<BnsOffer>(url, {
        params: { serviceCount },
      });

      if (!response.data.promotion) {
        throw new Error('Error retrieving bundle and save offers');
      }

      return response.data;
    } catch (error) {
      handleErrorLogging(error, {
        ucode: 'a904qq0',
      });

      return Promise.reject(error);
    }
  };

  public removePackageFromBasket = async ({
    basketId,
    packageId,
    additionalBnsCount = 0,
    raf,
  }: RemovePackageFromBasketParams) => {
    try {
      const url = `${apiEndpoint}/basket/${basketId}/${packageId}`;
      const response = await this.axiosClient.delete<BasketResponse>(url, {
        params: { serviceCount: additionalBnsCount, date: this.getPreviewDateString(), raf: JSON.stringify(raf) },
      });

      if (response.status === 200 || response.status === 207) {
        LocalStorageClient.updateCartExpiryDate(updateCartExpiryOnModification);
      }

      return basketResponseToBasket(response.data);
    } catch (error) {
      handleErrorLogging(error, {
        ucode: '7dd2efa',
      });

      return Promise.reject(error);
    }
  };

  /**
   * Modals
   */

  public fetchModals = async () => {
    try {
      const url = `${apiEndpoint}/content/modals`;
      const response = await this.axiosClient.get<ModalResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'b2e27d2',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Appends the optional preview date field to the url, if there is a preview date and preview mode is on.
   * If a new date string is passed, it overrides any previously set preview date in the api client.
   */
  private getPreviewDateString = (date?: string): string | undefined => {
    if (date && preview) {
      this.setPreviewDate(date);
      return date;
    }
    if (this.previewDate && preview) {
      return this.previewDate;
    }
    return undefined;
  };

  // Express Upgrade
  // Review
  public fetchExpressCheckoutPageData = async () => {
    try {
      const url = `${apiEndpoint}/content/eu-review-order`;
      const response = await this.axiosClient.get(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'f212e55',
      });
      throw err;
    }
  };

  // Confirmation
  public fetchExpressConfirmationPageData = async (journeyType: ExpressJourneySlug) => {
    try {
      const url = `${apiEndpoint}/content/eu-confirmation-${journeyType}`;
      const response = await this.axiosClient.get(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'ea1d02a',
      });
      throw err;
    }
  };

  public fetchExpressUpgradeLandingPageData = async <T extends ExpressJourneySlug>(journeyType: T) => {
    try {
      const url = `${apiEndpoint}/content/eu-landing-${journeyType}`;
      const response = await this.axiosClient.get<ExpressJourneySlugToLandingPageTypeMap[T]>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'f212e55',
      });
      throw err;
    }
  };

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  public fetchOtpPageData = async (journeyType: ExpressJourneySlug) => {
    try {
      const url = `${apiEndpoint}/content/otp-base-${journeyType}`;
      const response = await this.axiosClient.get<OtpPageResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'f212e55',
      });
      throw err;
    }
  };

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  public fetchPinPageData = async (journeyType: ExpressJourneySlug) => {
    try {
      const url = `${apiEndpoint}/content/account-pin`;
      const response = await this.axiosClient.get<PinPageResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'f212e55',
      });
      throw err;
    }
  };

  /**
   * @param params.encryptedMsisdn
   * @param params.recaptchaToken
   */
  public requestOtp = async ({
    encryptedMsisdn,
    recaptchaToken,
  }: {
    encryptedMsisdn: string;
    recaptchaToken: string;
  }): Promise<RequestOtpResponse> => {
    const url = `${apiEndpoint}/passwordless/otp-request`;

    try {
      const response = await this.axiosClient.post<RequestOtpResponse>(url, { encryptedMsisdn, recaptchaToken });

      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: 'e2a189c' });
      throw err;
    }
  };

  /**
   * @param params.encryptedMsisdn
   * @param params.recaptchaToken
   * @param params.verificationCode
   */
  public verifyOtp = async ({
    encryptedMsisdn,
    recaptchaToken,
    verificationCode,
  }: {
    encryptedMsisdn: string;
    recaptchaToken: string;
    verificationCode: string;
  }): Promise<VerifyOtpResponse> => {
    try {
      const url = `${apiEndpoint}/passwordless/otp-verify`;
      const response = await this.axiosClient.post<VerifyOtpResponse>(url, {
        encryptedMsisdn,
        recaptchaToken,
        verificationCode,
      });

      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: 'c08df83' });
      throw err;
    }
  };

  public verifyPin = async ({
    msisdn,
    vfNumber,
    pin,
  }: {
    msisdn: string;
    vfNumber: string;
    pin: string;
  }): Promise<VerifyPinResponse> => {
    try {
      const url = `${apiEndpoint}/passwordless/pin-verify`;
      const response = await this.axiosClient.post<VerifyPinResponse>(url, {
        msisdn,
        vfNumber,
        pin,
      });
      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: 'c08df83' });
      throw err;
    }
  };

  /**
   * @param params.encryptedMsisdn
   * @param params.recaptchaToken
   */
  public requestBriefCustomerDetails = async ({
    encryptedMsisdn,
    recaptchaToken,
  }: {
    encryptedMsisdn: string;
    recaptchaToken: string;
  }): Promise<RequestBriefCustomerDetailsResponse> => {
    const url = `${apiEndpoint}/passwordless/brief-customer-details-request`;

    try {
      const response = await this.axiosClient.post<RequestBriefCustomerDetailsResponse>(url, {
        encryptedMsisdn,
        recaptchaToken,
      });

      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: 'b8db574' });
      throw err;
    }
  };

  /**
   * @param params.encryptedMsisdn
   * @param params.token
   */
  public requestEUCustomerDetails = async ({
    encryptedMsisdn,
    token,
  }: {
    encryptedMsisdn: string;
    token: string;
  }): Promise<EUCustomerData> => {
    try {
      const url = `${apiEndpoint}/passwordless/getEUCustomerDetails`;
      const response = await this.axiosClient.post<EUCustomerData>(url, {
        encryptedMsisdn,
        token,
      });
      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: '3763bb3' });
      throw err;
    }
  };

  public submitExpressUpgradeOrder = async ({
    id_token,
    campaignId,
    encryptedMsisdn,
    encryptedPayload,
    sourcePlanName,
    offerEmailPayload,
    deliveryNotification,
    deviceRecurringCharge,
  }: {
    id_token: string;
    encryptedMsisdn: string;
    campaignId: string;
    encryptedPayload: string;
    sourcePlanName: string;
    offerEmailPayload: ExpressSubmitOrderResponse['payload']['OfferEmailContent'];
    deliveryNotification?: NonNullable<ExpressSubmitOrderResponse['payload']>['DeliveryNotification'];
    deviceRecurringCharge?: string;
  }): Promise<ExpressSubmitOrderResponse> => {
    try {
      const response = await this.axiosClient.post<ExpressSubmitOrderResponse>(
        `${apiEndpoint}/passwordless/submit-express-upgrade-order`,
        {
          id_token,
          campaignId,
          encryptedMsisdn,
          encryptedPayload,
          sourcePlanName,
          offerEmailPayload,
          deliveryNotification,
          deviceRecurringCharge,
        },
      );
      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: 'cd4743b' });
      throw err;
    }
  };

  public fetchDeviceDetails = async ({ externalDeviceId }: { externalDeviceId: string }) => {
    try {
      const url = `${apiEndpoint}/device/details/${encodeURIComponent(externalDeviceId)}`;
      const response = await this.axiosClient.get<DeviceDetailsResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'a1af204',
      });
      return Promise.reject(err);
    }
  };

  public validateEmail = async ({ emailAddress }: { emailAddress: string }) => {
    try {
      const url = `${apiEndpoint}/email/validation`;
      const response = await this.axiosClient.post<EmailValidationResponse>(url, { email: emailAddress });
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'b6a35ad',
      });
      return Promise.reject(err);
    }
  };

  // Called when the RAF code needs to be validated and stored in the Salesforce Basket.
  // Validation logic will be handled in seperate card: SHOP-7466
  public validateAndFetchRafCredit = async (rafValidationRequest: RafValidateAndFetchRequest) => {
    console.log('request: ', { rafValidationRequest });
    const { basketId } = rafValidationRequest;

    const url = `${apiEndpoint}/basket/${basketId}`;
    try {
      const response = await this.axiosClient.put<BasketResponse>(url, rafValidationRequest, {
        params: {
          serviceType: ServiceTypeValue.NewAcquisition,
        },
      });
      console.log('Response from API is: ', response.data);
      return response.data;
    } catch (error) {
      handleErrorLogging(error, {
        ucode: 'c665054',
      });
      return Promise.reject(error);
    }
  };

  // Function to Delete RAF details from Salesforce Basket
  public deleteRafCode = async (request: DeleteRafRequest): Promise<Basket> => {
    const { basketId } = request;

    const url = `${apiEndpoint}/basket/${basketId}`;
    try {
      const response = await this.axiosClient.put<BasketResponse>(url, request, {
        params: {
          serviceType: ServiceTypeValue.NewAcquisition,
        },
      });
      return basketResponseToBasket(response.data);
    } catch (error) {
      handleErrorLogging(error, {
        ucode: 'd92162d',
      });
      return Promise.reject(error);
    }
  };

  public getBraintreeToken = async () => {
    try {
      const response = await this.axiosClient.get<BraintreeToken>(`${apiEndpoint}/payment/token`);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: '893d92b' });
      throw err;
    }
  };

  public getCardSurcharge = async ({ bin }: { bin: string }) => {
    try {
      const response = await this.axiosClient.get<{ pct: string }>(
        `${apiEndpoint}/payment/card-surcharge?${new URLSearchParams([['bin', bin]])}`,
      );
      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: '1aaec66' });
      throw err;
    }
  };

  public createTransaction = async ({
    payload,
    details,
    deviceData,
    params,
    paymentType,
    paymentId,
  }: CreateTransactionRequest) => {
    try {
      const response = await this.axiosClient.post<CreateTransactionResult>(`${apiEndpoint}/payment/transaction`, {
        nonce: payload.nonce,
        details,
        deviceData,
        paymentId,
        ...(paymentType === 'CREDITCARD' && 'cardType' in payload.details && { cardType: payload.details.cardType }),
        FLOW_TYPE: params.FLOW_TYPE === 'VAULT' ? 'VAULT' : 'CHARGE',
        ORDER_ID: params.ORDER_ID,
        'X-SESSION_ID': params['X-SESSION_ID'],
        AMOUNT: params.AMOUNT,
        HMAC: params.HMAC,
        paymentMethod: paymentType,
      });

      // Send tokenized cardholder name field in the payload to Omni when present.
      if ('cardholderName' in payload.details && payload.details.cardholderName) {
        response.data.tokenizedCardholderName = payload.details.cardholderName;
      }

      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: 'e7fd7e3' });
      throw err;
    }
  };

  public getPaypalSTCClientMetadataId = async (stcRequest: PaypalSTCRequest) => {
    try {
      const response = await this.axiosClient.post<PaypalSTCResult>(
        `${apiEndpoint}/payment/transaction-context`,
        stcRequest,
      );
      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: '082e9c1' });
      throw err;
    }
  };

  // To be re-visited
  public submitAPMPayment = async ({ deviceData, paymentId, params, msisdn }: SubmitAPMPaymentRequest) => {
    try {
      const response = await this.axiosClient.post<SubmitAPMPaymentResult>(`${apiEndpoint}/payment/details`, {
        deviceData,
        amount: params.AMOUNT,
        paymentId,
        businessIdentifier: params.ORDER_ID,
        msisdn,
      });
      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: 'e9c8c7b' });
      throw err;
    }
  };

  public getPaymentConfiguration = async <K extends PaymentConfigurationKey>(
    configKey: K,
  ): Promise<PaymentConfiguration[K]> => {
    try {
      const response = await this.axiosClient.get<PaymentConfiguration>(`${apiEndpoint}/payment/configuration`);
      return response.data[configKey];
    } catch (err) {
      handleErrorLogging(err, { ucode: '0a3d0f4' });
      throw err;
    }
  };

  public fetchPromoAvailability = async ({ subType, planEndpoint }: PromoAvailibilityParams) => {
    try {
      // when the flag is off (false), the feature is enabled
      // but when the flag is on (true), the feature disabled
      // That means online offer is set to off in feature toggle and no need to call api then
      // if (isOnlineOfferDisabled) {
      //   return { availability: false };
      // }
      const url = `${apiEndpoint}/promotion/${planEndpoint}/availability`;
      const response = await this.axiosClient.get<PromoAvailibilityResponse>(url, {
        params: { date: this.getPreviewDateString(), subType },
      });
      return response.data;
    } catch (err) {
      handleErrorLogging(err, { ucode: '72fe25e' });
      return { availability: false };
    }
  };

  /**
   * Fetching content for Student Email and offer validation
   */

  public fetchStudentOfferContent = async () => {
    try {
      const url = `${apiEndpoint}/content/student-validation`;
      const response = await this.axiosClient.get<StudentValidationContentResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '33116b1',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Fetching PROMOTIONAL_CAMPAIGNS
   */
  public fetchPromotionalCampaigns = async () => {
    try {
      const url = `${apiEndpoint}/content/promotional-campaigns`;
      const response = await this.axiosClient.get<PromotionalCampaignsContentResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: '33116b2',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Fetching content for Trade-In-and-Save
   */
  public fetchTradeInAndSaveContent = async () => {
    try {
      const url = `${apiEndpoint}/content/trade-in-and-save`;
      const response = await this.axiosClient.get<TradeInAndSaveContentResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'b00a3a0',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Fetching content for Trade-In-Details for New TradeIn component
   */
  public fetchTradeInDetailsContent = async () => {
    try {
      const url = `${apiEndpoint}/content/trade-in-details`;
      const response = await this.axiosClient.get<TradeInDetailsContentResponse>(url);
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'b00a3a0',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Smart Watch Page
   */
  public fetchSmartWatchPageData = async ({ date, watchId }: SmartWatchPageParams): Promise<SmartWatchPageResponse> => {
    try {
      const url = `${apiEndpoint}/device/wearables/${watchId}`;
      const dateString = this.getPreviewDateString(date);
      const serviceType = LocalStorageClient.getServiceType() ?? ServiceTypeValue.NewAcquisition;
      const response = await this.axiosClient.get<SmartWatchPageResponse>(url, {
        params: { date: dateString, serviceType },
      });
      if (response.data.errors && !response.data.deviceDetails) {
        throw new Error(response.data.errors.toString());
      }

      let defaultColorConfigurationIsAvailable = false;
      const { deviceDetails } = response.data;
      const { defaultColor } = deviceDetails;
      deviceDetails.colors.forEach((color) => {
        // TODO this should be validated in the BE and filtered appropriately
        if ('error' in color) {
          throw Error('Unable to display product (malformed device colors)');
        }

        if (defaultColor === color.value) {
          defaultColorConfigurationIsAvailable = true;
        }
      });

      // Remove images that should only be used as a cart image. They are not hi res enough to
      // show on the device details page
      deviceDetails.colors = deviceDetails.colors.map((color) => ({
        ...color,
        images: color.images.filter((image) => !image.useInCart),
      }));

      if (!defaultColorConfigurationIsAvailable) {
        throw Error('Unable to display product (default color is not configured)');
      }
      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'baabf04',
      });
      return Promise.reject(err);
    }
  };

  /**
   * Modem Page
   */
  public fetchModemPageData = async ({
    date,
    deviceEndpoint,
    modemId,
  }: ModemPageParams): Promise<ModemPageResponse> => {
    try {
      const url = `${apiEndpoint}/device/${deviceEndpoint}/${modemId}`;

      // Add optional date query parameter for preview mode
      const dateString = this.getPreviewDateString(date);
      const serviceType = LocalStorageClient.getServiceType() ?? ServiceTypeValue.NewAcquisition;

      const response = await this.axiosClient.get<ModemPageResponse>(url, {
        params: { date: dateString, serviceType },
      });

      if (response.data.errors && !response.data.deviceDetails) {
        throw new Error(response.data.errors.toString());
      }

      let defaultColorConfigurationIsAvailable = false;
      const { deviceDetails } = response.data;
      const { defaultColor } = deviceDetails;
      deviceDetails.colors.forEach((color) => {
        // TODO this should be validated in the BE and filtered appropriately
        if ('error' in color) {
          throw Error('Unable to display product (malformed device colors)');
        }

        if (defaultColor === color.value) {
          defaultColorConfigurationIsAvailable = true;
        }
      });

      // TODO this logic should live in the BE
      // Remove images that should only be used as a cart image. They are not hi res enough to
      // show on the device details page
      deviceDetails.colors = deviceDetails.colors.map((color) => ({
        ...color,
        images: color.images.filter((image) => !image.useInCart),
      }));

      if (!defaultColorConfigurationIsAvailable) {
        throw Error('Unable to display product (default color is not configured)');
      }

      return response.data;
    } catch (err) {
      handleErrorLogging(err, {
        ucode: 'b4a514b',
      });
      return Promise.reject(err);
    }
  };
}
const clientSideApiClient = new ApiClient();
