/* eslint-disable no-useless-escape */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* istanbul ignore file */
import { JourneyContext } from '@src/lib/context/sas-provider';
import { findKey, isEmpty } from 'lodash';
import Logger from '@src/lib/logger/logger';
import { formatDate, parseDateString } from '@src/lib/util/formatUtils';
import { LocalStorageClient } from '@src/lib/storage';
// import { sleep } from '@src/common/js/sleep';
import {
  CURRENT_PLAN_DATA,
  EU_SPOT_NAMES,
  FCID_MATCHER,
  HREF_MATCHER,
  MEGA_BYTE_IDENTIFIER,
  SPOT_ID_MATCHER,
  buildSpotJourneyAttribute,
  isExpressJourneySlug,
} from '@src/lib/util/express-upgrades';
import { promiseRaceTimeout } from '@src/lib/util/promise';
import { SECOND } from '@kablamo/kerosene';
import {
  CartItemType,
  ExpressSubmitOrderResponse,
  VFECustomEventTrackResponse,
  VFECustomPageTrackResponse,
} from '@src/lib/api/types';
import { SasProduct, SasProductDevice, SasProductPlan } from '@src/lib/ci360/use-sas-product-list';
import { trackEvent } from '@src/lib/tracking';
import { formatCurrency } from '@src/lib/util/number-formatter';
import { mockHashID } from '@src/lib/constants/express';
import { EUCreativeRegexStrings, FCID_NAME, FCID_TIMEOUT_ERROR, Schema, ci360Schema } from './schema';
import { makeMockedCreatives } from './mockedResponse';
import { SasTimeout } from './SasTimeout';
// this is a journey type as per for express-upgrade for new journeys we can have or not
// meaning it can be extended to include any other possible for future journeys
// This functionality mainly deals with `required`
// to check for mandatory schema item is there
type journeyType = 'simo' | 'rpc' | 'handset' | undefined;

const CREATIVES_API_CALL_LIMIT = 6; // including the first manual api call triggered by the effect hook
const SPOT_IDS = process.env.EU_SPOT_IDS?.split(',');

enum TEMPLATE_WITH_TYPE {
  DOLLAR_SIGN = '<span class="dollar">$</span>',
  GB = '<span class="gb">GB</span>',
  MB = '<span class="gb">MB</span>',
}

enum CREATIVES_API_CALL_STATUS {
  INITIAL = 'inital',
  IN_PROGRESS = 'in-progress',
  SUCCESS = 'success',
  FAIL = 'failed',
}

export interface SasSpots {
  [key: string]: {
    key: string;
    value: {
      attributes: string[];
      id: string;
      selector: string;
    };
  };
}

export type SpotName = string;
export type CI360JourneyAttribute = {
  url_path: string; // only pass the journey from the url path
};

export type CI360SpotAttributes = Record<SpotName, CI360JourneyAttribute>;

export interface Ci360Parameters {
  domain: string;
  path: string;
  params: { hid: string };
  attributes: CI360SpotAttributes;
  names: Array<SpotName>;
}

export interface SasCreatives {
  content: string;
  creativeId: string;
  taskId: string;
}

export type SasCreativesMap = Map<string, SasCreatives>;

export interface JourneyTemplates {
  id: string;
  content: string;
  value: string;
}

interface PurchaseItems {
  id: string;
  name: string;
  quantity: '1';
  sku: string;
  unitPrice: string;
  group: string;
}

declare global {
  function ci360(
    operation: 'attachIdentity',
    parameters: {
      loginId: string;
      loginEventType: string;
    },
  ): void;

  function ci360(
    operation: 'getCreatives',
    parameters: Ci360Parameters,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    callback: (err: any, data: Map<string, SasCreatives>) => void,
  ): void;

  function ci360(
    operation: 'getSpotDefinitions',
    parameters: Ci360Parameters,
    // TODO: Give more specific types
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    callback: (err: any, data: unknown) => void,
  ): void;

  function ci360(
    operation: 'send',
    parameters: {
      eventName: string;
      action: string;
      apiEventKey: string;
      id: string;
      name: string;
      orderId: string;
      paymentType: string;
      totalCartValue: number;
      items: [PurchaseItems];
    },
  ): void;

  function ci360(
    operation: 'send',
    parameters: {
      eventName: string;
      apiEventKey: string;
      trackingCode: string;
      placementId: string;
      name: string;
      recordType: string;
      type: string;
    },
  ): void;

  function ci360(
    operation: 'send',
    parameters: {
      eventName: string;
      apiEventKey: string;
      customName: string;
      customGroupName: string;
      pageTitle: string | null;
      path: string | null;
      activeMsisdn: string | null;
      accountType: string | null;
      serviceType: string | null;
    },
  ): void;

  function ci360(
    operation: 'send',
    parameters: {
      eventName: string;
      apiEventKey: string;
      customName: string;
      customGroupName: string;
      pageEventName: string | null;
      pageEventType: string;
      pageEventValue: string;
      pageEventAttributeOne: string | null;
      pageEventAttributeTwo: string | null;
      pageEventAttributeThree: string | null;
      pageEventAttributeFour: string | null;
      errorAttribute: string | null;
    },
  ): void;

  interface Window {
    ci360: typeof ci360;
  }
}

export default class CI360 {
  public static spots: SasSpots[];

  public static journeyType: journeyType;

  public static TIMEOUT = 15000;

  private static CREATIVES_API_CALL_COUNTER = 0;

  private static CURRENT_CREATIVES_API_CALL_STATUS = CREATIVES_API_CALL_STATUS.INITIAL;

  // :::::: static methods :::::://
  static async getSpotDefinitions(): Promise<unknown> {
    return promiseRaceTimeout(
      () =>
        new Promise((resolve, reject) => {
          if (typeof window !== 'undefined' && typeof window.ci360 === 'function') {
            window.ci360('getSpotDefinitions', this.prepareCI360CallParameters(), (err, data) => {
              if (err) {
                reject(err);
              } else {
                resolve(data);
              }
            });
          } else {
            Logger.info('SAS object is not instantiated, ', { ucode: 'c4531d0' });
            reject(new Error('SAS object error'));
          }
        }),
      { duration: 2 * SECOND },
    );
  }

  /**
   * `MutationObserver` is meant to be the primary way
   * to build creatives but there are intermittent issues
   * on Chrome and Firefox with the SAS script hence
   * `ci360.getCreatives` api call is added as fallback
   * @returns Promise
   */
  static getCreativesDefinitions(): Promise<Schema> {
    return new Promise<Schema>((resolve, reject) => {
      if (typeof window !== 'undefined' && typeof window.ci360 === 'function') {
        const hashID = this.getHashId();
        if (window.location.hostname === 'localhost' || hashID === mockHashID) {
          makeMockedCreatives(new URLSearchParams(window.location.search)).then((mockedCreatives) =>
            resolve(CI360.validateWithSchema(new Map([[hashID, mockedCreatives]]))),
          );
        } else {
          const creatives = this.buildCreativesFromSasTags();
          if (creatives.size !== 0) {
            resolve(CI360.validateWithSchema(creatives));
          } else {
            if (
              CI360.CURRENT_CREATIVES_API_CALL_STATUS === CREATIVES_API_CALL_STATUS.FAIL ||
              CI360.CURRENT_CREATIVES_API_CALL_STATUS === CREATIVES_API_CALL_STATUS.IN_PROGRESS
            ) {
              return;
            }
            CI360.CREATIVES_API_CALL_COUNTER += 1;
            CI360.CURRENT_CREATIVES_API_CALL_STATUS = CREATIVES_API_CALL_STATUS.IN_PROGRESS;
            window.ci360('getCreatives', this.prepareCI360CallParameters(), (err, data) => {
              if (err) {
                CI360.CURRENT_CREATIVES_API_CALL_STATUS = CREATIVES_API_CALL_STATUS.FAIL;
                Logger.info('SAS is not available', { ...err, ucode: '5daf220' });
                reject(new Error(err));
              } else {
                CI360.CURRENT_CREATIVES_API_CALL_STATUS = CREATIVES_API_CALL_STATUS.SUCCESS;
                Logger.info('Data fetched from CI360', { ...data, ucode: 'daaaf52' });
                resolve(CI360.validateWithSchema(data));
              }
            });
          }
        }
      } else {
        CI360.CURRENT_CREATIVES_API_CALL_STATUS = CREATIVES_API_CALL_STATUS.FAIL;
        Logger.info('SAS object is not instantiated', { ucode: 'ca03931' });
        throw new Error('SAS object error');
      }
    }).catch((err) => {
      CI360.CURRENT_CREATIVES_API_CALL_STATUS = CREATIVES_API_CALL_STATUS.FAIL;
      if (err instanceof SasTimeout) {
        Logger.info('SAS callback has been timed out', { ucode: '12cef9a' });
      }
      throw err;
    });
  }

  /**
   * e.g. `{ name: 'express', type: 'upgrade-device' }`
   */
  static createJourneyParameter(): { name: string; type: string } {
    switch (window.location.pathname) {
      case '/express/otp':
      case '/express/pin':
      case '/express/confirm':
      case '/express/checkout': {
        const type = new URLSearchParams(window.location.search).get('journey');
        if (!isExpressJourneySlug(type)) {
          throw new Error(`Unsupported journey: ${type}`);
        }
        return { name: 'express', type };
      }

      case '/express/upgrade-device':
      case '/express/upgrade-plan':
      case '/express/change-plan':
      default: {
        // e.g. '' / 'express' / 'upgrade-device'
        const [, name = '', type = ''] = window.location.pathname.split('/');
        return { name, type };
      }
    }
  }

  static assertIsValidJourney(context: JourneyContext | undefined): boolean {
    // TODO: need to be looked after
    // const path = CI360.createJourneyParameter();
    // if (context && context.creatives) {
    //  const temp = findKey(context?.creatives, 'express');
    // }

    return !!context;
  }

  static sendPurchaseEvent(
    data: ExpressSubmitOrderResponse,
    creatives: Schema | undefined,
    items: readonly SasProduct[],
  ) {
    if (typeof window !== 'undefined' && typeof window.ci360 === 'function') {
      const device = items.find((item) => item.itemType === CartItemType.DEVICE) as SasProductDevice;
      const plan = items.find((item) => item.itemType === CartItemType.PLAN) as SasProductPlan;
      window.ci360('send', {
        eventName: 'cart',
        action: 'purchase',
        apiEventKey: 'Vodafone-EU-Purchase',
        id: data.payload.Order.msisdn,
        name: 'Express Upgrade - [Purchase]',
        orderId: data.payload.Order.orderID,
        paymentType: data.payload.Order.orderType,
        totalCartValue:
          parseFloat(
            creatives?.express?.total_cost?.[
              creatives?.express?.target_device?.td_sdd_flag?.value === 'Y' ? 'tc_price_mth_sdd' : 'tc_price_mth'
            ]?.value ?? '',
          ) || 0,
        items: [
          {
            id: data.payload.Plan.targetPlanID,
            name: data.payload.Device
              ? `${data.payload.Device.deviceName} | ${device.productConfig.color} | ${device.productConfig.capacity}`
              : 'undefined',
            sku: data.payload.Device ? data.payload.Device.deviceSKU : 'undefined',
            quantity: '1',
            unitPrice: data.payload.Device ? data.payload.Device.devicePaymentPlanTerm : 'undefined',
            group: `${plan.productName} | ${plan.relatedContent.planData} | ${data.payload.Plan.targetPlanTerm} months`,
          },
        ],
      });
    }
  }

  static sendCustomerIdentityTrackEvent(customerMsisdn: string) {
    if (typeof window !== 'undefined' && typeof window.ci360 === 'function') {
      window.ci360('send', {
        eventName: 'promotion',
        apiEventKey: 'identity-event-check-success',
        trackingCode: customerMsisdn,
        placementId: window.location.href,
        name: 'Identity Event Check - VFE - [Success]',
        recordType: 'use',
        type: 'vfe-identity-event-success',
      });
    }
  }

  static sendSasContextEventTrack(creatives: Schema | undefined, items: readonly SasProduct[]) {
    const device = items.find((item) => item.itemType === CartItemType.DEVICE) as SasProductDevice;
    const plan = items.find((item) => item.itemType === CartItemType.PLAN) as SasProductPlan;
    // SHOP-7550 We are using the totalDeviceMinCost which we set in use-sas-product-list
    const totalCost = !isEmpty(device)
      ? (device.priceInfo.totalDeviceMinCost || 0) + plan.relatedContent.planTermMonths * plan.priceInfo.recurringCharge
      : plan.relatedContent.planTermMonths * plan.priceInfo.recurringCharge;
    const totalMonthlyCost = !isEmpty(device)
      ? device.priceInfo.recurringCharge + plan.priceInfo.recurringCharge
      : plan.priceInfo.recurringCharge;

    if (device || plan) {
      trackEvent({
        pageEventType: 'pageload',
        pageEventValue: 'Sas Context data',
        device,
        plan,
        totalCost,
        totalMonthlyCost: parseFloat(formatCurrency(totalMonthlyCost)),
      });
    }
  }

  static sendCustomPageTrack(data: VFECustomPageTrackResponse) {
    if (typeof window !== 'undefined' && typeof window.ci360 === 'function') {
      window.ci360('send', {
        eventName: 'custom',
        apiEventKey: 'pageTrack',
        customName: 'pageTrack',
        customGroupName: 'pageTrack',
        pageTitle: data.pageTitle || null,
        path: data.path || null,
        activeMsisdn: data.activeMsisdn || null,
        accountType: data.accountType || null,
        serviceType: data.serviceType || null,
      });
    }
  }

  static sendCustomEventTrack(data: VFECustomEventTrackResponse) {
    if (typeof window !== 'undefined' && typeof window.ci360 === 'function') {
      window.ci360('send', {
        eventName: 'custom',
        apiEventKey: 'eventTrack',
        customName: 'eventTrack',
        customGroupName: 'eventTrack',
        pageEventName: data.pageEventName || null,
        pageEventType: data.pageEventType,
        pageEventValue: data.pageEventValue,
        pageEventAttributeOne: data.pageEventAttributeOne || null,
        pageEventAttributeTwo: data.pageEventAttributeTwo || null,
        pageEventAttributeThree: data.pageEventAttributeThree || null,
        pageEventAttributeFour: data.pageEventAttributeFour || null,
        errorAttribute: data.errorAttribute || null,
      });
    }
  }

  static sendIdentityEvent() {
    if (typeof window !== 'undefined' && typeof window.ci360 === 'function') {
      const hashId = this.getHashId();
      if (hashId) {
        window.ci360('attachIdentity', {
          loginId: hashId,
          loginEventType: 'login_id',
        });
      }
    }
  }

  static createModal(id: string, content: string) {
    return `<vha-modal-trigger type="plain" id="${id}" >${content}</vha-modal-trigger>`;
  }

  private static getUrlParams() {
    return Object.fromEntries(new URLSearchParams(window.location.search)) as Record<string, string | undefined>;
  }

  private static getHashId(): string {
    return this.getUrlParams().hid || '';
  }

  private static validateWithSchema(sasContext: Map<string, SasCreatives>): Schema {
    const journey = CI360.createJourneyParameter();
    const schema: Schema = {};
    let fcidErrorCounter = 0;
    let isFcidErrorInTheResponse = false;
    schema[journey.name] = ci360Schema[journey.name];

    Array.from(sasContext.values()).forEach((item) => {
      const creativeTemplate = item.content || ('na' as string);
      let templates = creativeTemplate.split('\\n');

      if (templates.length === 1) {
        // sometimes creatives are separated with `\\n` instead of `\n`
        templates = creativeTemplate.split('\n');
      }

      if (templates.length === 1) {
        if (CI360.isFCIDinSASResponseforEUSpots(templates[0])) {
          fcidErrorCounter += 1;
          isFcidErrorInTheResponse = true;
        }
      }

      templates.map((template: string) => {
        const templateAsRegex = template.match(EUCreativeRegexStrings.TEMPLATE_ID_EXTRACTION);

        if (templateAsRegex && journey.name && schema[journey.name]) {
          const templateId: string = (templateAsRegex[1] || 'na').toLowerCase();

          const schemaCategory = findKey(schema[journey.name], templateId);
          if (schemaCategory) {
            // We do have a matching ID in schema
            // Now let's get the value out of data-value
            // for the cases that we need to extract value out of creatives
            const dataValue = template.match(EUCreativeRegexStrings.DATA_VALUE_EXTRACTION);
            if (dataValue) {
              // setting journeyType for if there is any creative
              // please refer to schema.ts
              CI360.journeyType = templateId === 'jrn_type' ? (dataValue[1].toLowerCase() as journeyType) : undefined;
              const templateString = dataValue[0];
              const fieldType = schema[journey.name]![schemaCategory]![templateId]!.fieldType || '';

              // eslint-disable-next-line prefer-destructuring -- Need to explicitly set the values
              schema[journey.name]![schemaCategory]![templateId]!.value = dataValue[1];
              // eslint-disable-next-line prefer-destructuring -- Need to explicitly set the values
              schema[journey.name]![schemaCategory]![templateId]!.template = this.validateTemplateWithType(
                templateString,
                fieldType,
              );
            } else {
              // there are cases that data-value is not required for the creative
              schema[journey.name]![schemaCategory]![templateId]!.template = template;
              schema[journey.name]![schemaCategory]![templateId]!.value = undefined;
            }
          }
        }
        return '';
      });
    });
    const enforcedSchema = CI360.enforceTestData(schema);
    if (isFcidErrorInTheResponse && fcidErrorCounter > 2) {
      let errorValue = FCID_NAME;
      if (CI360.CREATIVES_API_CALL_COUNTER === CREATIVES_API_CALL_LIMIT) {
        CI360.CREATIVES_API_CALL_COUNTER = 0;
        errorValue = FCID_TIMEOUT_ERROR;
      }
      enforcedSchema!.express!.journey!.data_err_flag!.value = 'Y';
      enforcedSchema!.express!.journey!.data_err_reas!.value = errorValue;
    }
    LocalStorageClient.setSASContext(enforcedSchema);
    return enforcedSchema;
  }

  // This function is a fall back for the cases that
  // SAS fails to add $ to the price in templates
  // This also can be extended for `GB` for data and `mbps` for speed and ...
  static validateTemplateWithType(template: string, type: string): string {
    let validatedTemplate: string = template.replace('\\n', '').replace('\n', '');

    if (type === 'currency') {
      const currencyValue = validatedTemplate.match(EUCreativeRegexStrings.PRESENTATION_VALUE_EXTRACTION);
      if (currencyValue) {
        validatedTemplate = validatedTemplate.replace('$', TEMPLATE_WITH_TYPE.DOLLAR_SIGN);
      } else {
        validatedTemplate = validatedTemplate.replace('>', `>${TEMPLATE_WITH_TYPE.DOLLAR_SIGN}`);
      }
    }

    if (type === 'date') {
      const dateString = validatedTemplate.match(EUCreativeRegexStrings.DATA_VALUE_EXTRACTION);
      if (dateString && dateString[1] && dateString[1] !== 'null') {
        // Date.parse only accpeting mm/dd/yyyy
        const parsedDateString = parseDateString(dateString[1]);
        const formattedDate = formatDate(parsedDateString, 'dd/MM/yy');
        validatedTemplate = validatedTemplate.replaceAll(dateString[1], formattedDate);
      }
    }

    if (type === 'gb') {
      const dataInclusionString = validatedTemplate.match(EUCreativeRegexStrings.DATA_VALUE_EXTRACTION);
      const indexOfGBSign = validatedTemplate.indexOf('GB');
      const currencyWithDollarSign = dataInclusionString![0].replace('</', `${TEMPLATE_WITH_TYPE.GB}</`);

      if (validatedTemplate.includes(CURRENT_PLAN_DATA) && validatedTemplate.includes(MEGA_BYTE_IDENTIFIER)) {
        validatedTemplate = dataInclusionString![0].replaceAll('MB', '').replace('</', `${TEMPLATE_WITH_TYPE.MB}</`);
      } else if (indexOfGBSign === -1) {
        validatedTemplate = validatedTemplate.replaceAll(dataInclusionString![0], currencyWithDollarSign);
      } else {
        validatedTemplate = validatedTemplate.replaceAll('GB<', `${TEMPLATE_WITH_TYPE.GB}<`);
      }
    }
    return validatedTemplate;
  }

  // this method has been introduced to enforce a change in Schema
  // it should only happen for SAS Test Tenant
  private static enforceTestData(schema: Schema): Schema {
    const urlParams = CI360.getUrlParams();
    const journey = CI360.createJourneyParameter();
    const keys = Object.keys(urlParams);
    // This is the test Tenant checker
    if (process.env.SAS_TENANT_ID === '28d1888f0e00010baeac6ffe') {
      keys.forEach((item) => {
        const schemaCategoryName = findKey(schema[journey.name], item);
        if (schemaCategoryName) {
          const template = this.validateTemplateWithType(
            `<span id="${item}" data-value="${urlParams[item]}">${urlParams[item]}</span>`,
            schema[journey.name]![schemaCategoryName]![item]?.fieldType || '',
          );

          // eslint-disable-next-line no-param-reassign
          schema[journey.name]![schemaCategoryName]![item]!.template = template;
          // eslint-disable-next-line no-param-reassign
          schema[journey.name]![schemaCategoryName!]![item]!.value = urlParams[item];
        }
      });
    }
    return schema;
  }

  private static buildCreativesFromSasTags(): SasCreativesMap {
    const sasTags: NodeListOf<HTMLElement> = document.querySelectorAll(`[id^="eu-attr-"],[id^="eu-ab-test-"]`);
    const creatives: SasCreativesMap = new Map();
    sasTags.forEach((element: HTMLElement, index: number) => {
      if (element) {
        const innerHtml: string = element.innerHTML;
        const children = element.childNodes;
        const taskIdNode = children[0] as HTMLElement;
        const creativeIdNode = children[1] as HTMLElement;
        if (taskIdNode && creativeIdNode) {
          const { taskid } = taskIdNode.dataset;
          const { creativeid } = creativeIdNode.dataset;
          if (taskid && creativeid) {
            creatives.set(index.toString(), { creativeId: creativeid, taskId: taskid, content: innerHtml });
          }
        }
      }
    });
    return creatives;
  }

  /**
   * the fcid error comes in an anchor tag.
   * look for spot id in the response,
   * if spot id matches with EU spots
   * and the reponse has FCID then only
   * re-attempt the next api call to fetch
   * creatives.
   */
  private static isFCIDinSASResponseforEUSpots(responseContent: string): boolean | undefined {
    const anchorTag = responseContent.match(HREF_MATCHER);
    const hrefValue = anchorTag ? anchorTag[1] : '';
    const spotId = hrefValue?.match(SPOT_ID_MATCHER);
    const spotValue = spotId ? spotId[1].split('=')[1] : '';
    const isFCID = hrefValue?.match(FCID_MATCHER);
    return isFCID ? SPOT_IDS?.includes(spotValue) : false;
  }

  private static prepareCI360CallParameters(): Ci360Parameters {
    const urlParams = this.getUrlParams(); // this will provide HID
    const path = window.location.pathname;
    const splitPath = path.split('/');
    const journey = splitPath[splitPath.length - 1];
    const attributes = buildSpotJourneyAttribute(journey);
    return {
      domain: window.location.hostname,
      path,
      names: EU_SPOT_NAMES.split(','),
      params: urlParams as Ci360Parameters['params'],
      attributes,
    };
  }
}
