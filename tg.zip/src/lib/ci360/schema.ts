/* istanbul ignore file */
interface requiredPerJourney {
  simo: boolean;
  rpc: boolean;
  handset: boolean;
}

type FieldType = 'currency' | 'date' | 'gb' | 'mbps';
export interface SchemaItem {
  fieldType?: FieldType;
  value?: string;
  required?: requiredPerJourney;
  template?: string;
}
export interface SchemaCategory {
  [key: string]:
    | {
        [key: string]: SchemaItem | undefined;
      }
    | undefined;
}

export interface Schema {
  [key: string]: SchemaCategory | undefined;
}

export enum AEMSasPromotionCodeMap {
  'td_sdd_flag' = 'EU-PHONEPLANS-SDD-PROMO',
  'tp_btl_disc_flag' = 'EU-DOLLAR-OFF-PROMO',
  'tp_data_bon_flag' = 'EU-BONUS-DATA-PROMO',
}

export enum EUCreativeRegexStrings {
  TEMPLATE_ID_EXTRACTION = '[^>]+?id="([^"]+)".*',
  DATA_VALUE_EXTRACTION = '[^>]+?data-value="([^"]+)".*',
  PRESENTATION_VALUE_EXTRACTION = '>[$][0-9,]+((.[0-9]{2})?)+<',
}

export enum EUJourneyType {
  /**
   * a.k.a. Handset
   */
  PHONE_AND_PLAN = 'HS',
  /**
   * a.k.a. SIM Only
   */
  SIMO = 'SIMO',
  RATE_PLAN_CHANGE = 'RPC',
}

export interface SasSpots {
  [key: string]: {
    key: string;
    value: {
      attributes: string[];
      id: string;
      selector: string;
    };
  };
}

export const ci360Schema: Schema = {
  express: {
    journey: {
      jrn_type: {},
      msisdn_enc: {},
      sblordpl_enc: {},
      cta_btn: {},
      seg_type: {},
      data_err_flag: {
        required: { simo: false, rpc: false, handset: false },
      },
      data_err_reas: {
        required: { simo: false, rpc: false, handset: false },
      },
    },
    current_plan: {
      cp_name: {},
      cp_price: {
        fieldType: 'currency',
      },
      cp_idd_int_flag: {},
      cp_data: {
        fieldType: 'gb',
      },
      cp_data_inf_flag: {},
      cp_data_spd: {},
    },
    target_plan: {
      tp_name: {},
      tp_price_mth: {
        fieldType: 'currency',
      },
      tp_price_disc_mth: {
        fieldType: 'currency',
      },
      tp_promo_code: {},
      tp_data: {
        fieldType: 'gb',
      },
      tp_data_bon: {
        fieldType: 'gb',
      },
      tp_data_bon_exp_dt: {
        fieldType: 'date',
      },
      tp_data_ttl: {
        fieldType: 'gb',
      },
      tp_data_spd: {
        fieldType: 'mbps',
      },
      tp_idd_zone1_min: {},
      tp_idd_zone2_min: {},
      tp_cis_url: {},
      tp_btl_disc_amt: {
        fieldType: 'currency',
      },
      tp_btl_disc_exp_dt: {
        fieldType: 'date',
      },
      tp_price_simo_ttl: {
        fieldType: 'currency',
      },
      tp_term: {},
      tp_data_bon_flag: {},
      tp_btl_disc_flag: {},
      tp_max_spd_data: {},
    },
    target_device: {
      td_sku: {},
      td_clr: {},
      td_cap: {
        fieldType: 'gb',
      },
      td_5g_flag: {},
      td_mfr: {},
      td_dsp_offer_cd: {},
      td_price_sdd_ttl: {
        fieldType: 'currency',
      },
      td_price_sdd_mth: {
        fieldType: 'currency',
      },
      td_rrp_ttl: {
        fieldType: 'currency',
      },
      td_price_mth: {
        fieldType: 'currency',
      },
      td_price_mth_disc: {
        fieldType: 'currency',
      },
      td_ttl_min_cost: {
        fieldType: 'currency',
      },
      td_shoutout_offer_title: {},
      td_shoutout_offer_summ: {},
      td_sdd_flag: {},
      td_dsp_flag: {},
      td_term: {},
      cd_num_offers: {},
    },
    total_cost: {
      tc_price_mth: {
        fieldType: 'currency',
      },
      tc_price_mth_sdd: {
        fieldType: 'currency',
      },
      tc_price_ttl: {
        fieldType: 'currency',
      },
      tc_price_ttl_sdd: {
        fieldType: 'currency',
      },
    },
  },
  nbn: {
    placeholders: {
      placeholder1: {},
    },
  },
};

export const FCID_NAME = 'FCID';
export const FCID_TIMEOUT_ERROR = `${FCID_NAME}_TIME_OUT`;
