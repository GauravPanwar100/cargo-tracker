import { ExtendableError } from '@src/lib/util/error';

export class SasTimeout extends ExtendableError {}
