/* istanbul ignore file */

import { encode } from 'base64-arraybuffer';
import { sumBy } from 'lodash';
import { SasCreatives } from '@src/lib/ci360/ci360';

export const mockedSpots = new Map([
  [
    'EU-PRICE-NEW',
    {
      key: 'EU-PRICE-NEW',
      value: {
        attributes: [],
        id: '81045f95-5379-46e7-aee5-ab47ef56c736',
        selector: 'div#primaryPlans',
      },
    },
  ],
]);

async function encryptAesCbc(key: string, iv: string, data: string): Promise<string> {
  const cryptoKey = await crypto.subtle.importKey('raw', new TextEncoder().encode(key), 'AES-CBC', false, ['encrypt']);
  return encode(
    await crypto.subtle.encrypt(
      { name: 'AES-CBC', iv: new TextEncoder().encode(iv) },
      cryptoKey,
      new TextEncoder().encode(data),
    ),
  );
}

export async function makeMockedCreatives(params: URLSearchParams): Promise<SasCreatives> {
  const jrn_type = (() => {
    const journeySlug =
      params.get('journey') ?? window.location.pathname.startsWith('/express/')
        ? window.location.pathname.slice('/express/'.length)
        : undefined;
    switch (journeySlug) {
      case 'upgrade-plan':
        return 'SIMO';
      case 'change-plan':
        return 'RPC';
      case 'upgrade-device':
      default:
        return 'HS';
    }
  })();
  const td_sdd_flag = 'Y';
  // const td_sdd_flag = params.get('td_sdd_flag') === 'Y' ? 'Y' : 'N';
  // Commented the below line and directly assigned the value of Y to tp_btl_disc_flag so that we will be able to see the success journey
  const tp_btl_disc_flag = 'Y';
  // const tp_btl_disc_flag = params.get('tp_btl_disc_flag') === 'Y' ? 'Y' : 'N';
  const tp_data_bon_flag = 'Y';
  // const tp_data_bon_flag = params.get('tp_data_bon_flag') === 'Y' ? 'Y' : 'N';
  const cta_btn = params.get('cta_btn') === 'Care' ? 'Care' : 'BAU';
  const offerFlagsCount = sumBy([td_sdd_flag, tp_btl_disc_flag, tp_data_bon_flag], (flag) => (flag === 'Y' ? 1 : 0));
  const cd_num_offers = `${Math.max(parseInt(params.get('cd_num_offers') ?? '', 10) || 0, offerFlagsCount)}`;

  const td_price_sdd_ttl = td_sdd_flag === 'Y' ? '300.24' : '';
  const td_price_sdd_mth = td_sdd_flag === 'Y' ? '8.34' : '';
  const td_price_mth_disc = td_sdd_flag === 'Y' ? '25.79888888888889' : '';
  const td_price_mth = '34.138888888888886';
  const td_term = '36';
  const td_rrp_ttl = '1229.00';

  const tp_btl_disc_amt = tp_btl_disc_flag === 'Y' ? '44.54' : '';
  const tp_price_disc_mth = tp_btl_disc_flag === 'Y' ? '44.54' : '';
  const tp_price_mth = '54.54';
  const tp_term = '12';
  const tp_data_bon = tp_data_bon_flag === 'Y' ? '100GB' : '';
  const tp_data_ttl = tp_data_bon_flag === 'Y' ? '160GB' : '';
  const tp_data = '60GB';
  const tp_plan_cd = params.get('tp_plan_cd') ?? 'AU12309';
  const tp_promo_code = '20OFF50';
  // const tp_name = params.get('tp_name') ?? '$40 SIM Only Lite Plan';

  const td_sku = params.get('td_sku') ?? 'MPUF3ZP/A';

  const td_dsp_offer_cd = [
    '$300_SAM_FLIP_TRADE_IN_DISPLAY_01~10/10/41',
    'APPLE_TV+~',
    'EU-BONUS-DATA-PROMO~10/12/41',
    'S21_TRADE_IN_DISPLAY_01~10/12/41',
    '$100_IPH_12_SDD_DIS_DISPLAY_01~10/10/41',
  ].join('|');

  const tc_price_mth = (
    parseFloat(td_price_mth) + parseFloat(tp_btl_disc_flag === 'Y' ? tp_price_disc_mth : tp_price_mth)
  ).toFixed(2);
  const tc_price_mth_sdd =
    td_sdd_flag === 'Y'
      ? (
          parseFloat(td_price_mth_disc) + parseFloat(tp_btl_disc_flag === 'Y' ? tp_price_disc_mth : tp_price_mth)
        ).toFixed(2)
      : '';
  const tc_price_ttl =
    parseInt(td_term, 10) * parseFloat(td_price_mth) +
    parseInt(tp_term, 10) * parseFloat(tp_btl_disc_flag === 'Y' ? tp_price_disc_mth : tp_price_mth);
  const tc_price_ttl_sdd =
    td_sdd_flag === 'Y'
      ? parseInt(td_term, 10) * parseFloat(td_price_mth_disc) +
        parseInt(tp_term, 10) * parseFloat(tp_btl_disc_flag === 'Y' ? tp_price_disc_mth : tp_price_mth)
      : '';

  const sblordpl_enc = await encryptAesCbc(
    'CgC05M4KzQI60HtVWFS8Qj3wbsVfw+ck',
    'CgC05M4KzQI60HtV',
    JSON.stringify({
      tp_plan_cd,
      tp_term,
      tp_promo_code,
      td_dsp_offer_cd,
      td_price_mth_disc,
      td_rrp_ttl,
      td_sku,
      td_term,
      jrn_type,
      // tp_name,
      // tp_price_disc_mth,
      // tp_data_bon,
      // td_price_sdd_mth,
      // td_price_sdd_ttl,
    }),
  );

  return {
    creativeId: '7ef113eb-ebd5-4369-9e5c-5bd91a8ffa23',
    taskId: 'fb577d92-482b-4aed-b799-aa931853eaf8',
    content: `<html><head><meta content="text/html;charset=UTF-8" http-equiv="Content-Type" /><title></title></head><body>\\\n
      \\n<span id="subs_id" data-value="25974861">25974861</span>
      \\n<span id="data_err_flag" data-value="N">N</span>
      \\n<span id="data_err_reas" data-value="CIS not Found">CIS not Found</span>
      \\n<span id="jrn_type" data-value="${jrn_type}">${jrn_type} - Mocked Data</span>
      \\n<span id="seg_type" data-value="H">H</span>
      \\n<span id="cta_btn" data-value="${cta_btn}">${cta_btn}</span>
      \\n<span id="msisdn_enc" data-value="r9tuBqrtNO2sZkwZCfqbtA==">r9tuBqrtNO2sZkwZCfqbtA==</span>
      \\n<span id="sblordpl_enc" data-value="${sblordpl_enc}">${sblordpl_enc}</span>
      \\n<span id="cp_name" data-value="$45 SIMO 12M">$45 SIMO 12M</span>
      \\n<span id="cp_price" data-value="45">$45</span>
      \\n<span id="cp_idd_int_flag" data-value="Y">Y</span> 
      \\n<span id="cp_data" data-value="40GB">40GB</span>
      \\n<span id="cp_data_inf_flag" data-value="Y">Y</span> 
      \\n<span id="cp_data_spd" data-value="25Mbps">25Mbps</span>
      \\n<span id="tp_name" data-value="$40 SIM Only Lite Plan">$40 SIM Only Lite Plan</span>
      \\n<span id="tp_price_mth" data-value="${tp_price_mth}">${tp_price_mth}</span>
      \\n<span id="tp_price_disc_mth" data-value="${tp_price_disc_mth}">${tp_price_disc_mth}</span>
      \\n<span id="tp_promo_code" data-value="${tp_promo_code}">${tp_promo_code}</span>
      \\n<span id="tp_data" data-value="${tp_data}">${tp_data}</span>
      \\n<span id="tp_data_bon" data-value="${tp_data_bon}">${tp_data_bon}</span>
      \\n<span id="tp_data_bon_exp_dt" data-value="27/05/2022">27/05/2022</span>
      \\n<span id="tp_data_ttl" data-value="${tp_data_ttl}">${tp_data_ttl}</span>
      \\n<span id="tp_data_spd" data-value="25Mbps">25Mbps</span>
      \\n<span id="tp_max_spd_data" data-value="Y">Y</span>
      \\n<span id="tp_idd_zone1_min" data-value="100">100</span>
      \\n<span id="tp_idd_zone2_min" data-value="100">100</span>
      \\n<span id="tp_cis_url" data-value="http://www.vodafone.com.au/doc/cis/mobileplans/au12268_au12272/aug2020.pdf">http://www.vodafone.com.au/doc/cis/mobileplans/au12268_au12272/aug2020.pdf</span>
      \\n<span id="tp_btl_disc_amt" data-value="${tp_btl_disc_amt}">${tp_btl_disc_amt}</span>
      \\n<span id="tp_btl_disc_exp_dt" data-value="01/01/21">01/01/21</span>
      \\n<span id="tp_price_simo_ttl" data-value="420">$420</span>
      \\n<span id="tp_term" data-value="${tp_term}">${tp_term}</span>
      \\n<span id="td_sku" data-value="${td_sku}">${td_sku}</span>
      \\n<span id="td_clr" data-value="Grey">Grey</span>
      \\n<span id="td_cap" data-value="128">128</span>
      \\n<span id="td_5g_flag" data-value="Y">Y</span>
      \\n<span id="td_mfr" data-value="Samsung">Samsung</span>

      \\n<span id="td_dsp_offer_cd" data-value="${td_dsp_offer_cd}"></span>

      \\n<span id="td_price_sdd_ttl" data-value="${td_price_sdd_ttl}">${td_price_sdd_ttl}</span>
      \\n<span id="td_price_sdd_mth" data-value="${td_price_sdd_mth}">${td_price_sdd_mth}</span>
      \\n<span id="td_rrp_ttl" data-value="${td_rrp_ttl}">${td_rrp_ttl}</span>
      \\n<span id="td_price_mth" data-value="${td_price_mth}">${td_price_mth}</span>
      \\n<span id="td_price_mth_disc" data-value="${td_price_mth_disc}">${td_price_mth_disc}</span>
      \\n<span id="td_ttl_min_cost" data-value="1383">1383</span>
      \\n<span id="td_shoutout_offer_title" data-value=""></span>
      \\n<span id="td_shoutout_offer_summ" data-value=""></span>

      \\n<span id="td_sdd_flag" data-value="${td_sdd_flag}">${td_sdd_flag}</span>
      \\n<span id="tp_btl_disc_flag" data-value="${tp_btl_disc_flag}">${tp_btl_disc_flag}</span>
      \\n<span id="tp_data_bon_flag" data-value="${tp_data_bon_flag}">${tp_data_bon_flag}</span>

      \\n<span id="td_dsp_flag" data-value="Y">Y</span>
      \\n<span id="cd_num_offers" data-value="${cd_num_offers}">${cd_num_offers}</span>

      \\n<span id="td_term" data-value="${td_term}">${td_term}</span>
      \\n<span id="tc_price_mth" data-value="${tc_price_mth}">${tc_price_mth}</span>
      \\n<span id="tc_price_mth_sdd" data-value="${tc_price_mth_sdd}">${tc_price_mth_sdd}</span>
      \\n<span id="tc_price_ttl" data-value="${tc_price_ttl}">${tc_price_ttl}</span>
      \\n<span id="tc_price_ttl_sdd" data-value="${tc_price_ttl_sdd}">${tc_price_ttl_sdd}</span>
    </body></html>`,
  };
}
