import React from 'react';
import { getApiClient } from '@src/lib/api';
import { EUJourneyType } from '@src/lib/ci360/schema';
import { useSasData } from '@src/lib/context/sas-provider';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import { compact, isEqual } from 'lodash';
import { CartItemType, DataLimit } from '@src/lib/api/types';
import { UNLIMITED, UNLIMITED_PLAN_DATA } from '@src/lib/util/express-upgrades';
import { formatEUPrice, formatGSTInclusiveAmount } from '@src/lib/util/formatUtils';

interface SasProductBase {
  itemType: CartItemType;
  productName: string;
  priceInfo: {
    recurringCharge: number;
    originalRecurringCharge?: number;
    totalDeviceMinCost?: number;
  };
  hideWasLabel?: boolean;
}

export interface SasProductDevice extends SasProductBase {
  itemType: CartItemType.DEVICE;
  manufacturer: string;
  productConfig: {
    capacity: string;
    color: string;
    contractTerm: string;
    deviceSku: string;
    imageUrl?: string;
  };
}

export interface SasProductPlan extends SasProductBase {
  itemType: CartItemType.PLAN;
  cisUrl: string;
  productConfig: {
    dataLimit: DataLimit;
  };
  relatedContent: {
    planData: string;
    planName: string;
    planTenure: string;
    planTermMonths: number;
    planTitle: string;
  };
}

export type SasProduct = SasProductDevice | SasProductPlan;

export default function useSasProductList() {
  const { creatives } = useSasData();
  const data = creatives?.express;
  const journey: EUJourneyType | undefined = data?.journey?.jrn_type?.value as EUJourneyType | undefined;
  const deviceSku = data?.target_device?.td_sku?.value;
  const [deviceDetails, getDeviceDetails] = useImperativeData(getApiClient().fetchDeviceDetails);

  React.useEffect(() => {
    // Don't need to fetch deviceDetails for other journeys
    if (journey !== EUJourneyType.PHONE_AND_PLAN) return;
    // If we don't have a device SKU yet
    if (!deviceSku) return;

    const params = { externalDeviceId: deviceSku };
    // If we already have the details for the device
    if (isEqual(params, deviceDetails.params)) return;

    getDeviceDetails(params);
  }, [deviceDetails.isInitialised, deviceDetails.params, deviceSku, getDeviceDetails, journey]);

  const device = React.useMemo<SasProductDevice | undefined>(() => {
    if (!deviceSku || !deviceDetails.data) return undefined;

    const tdSddFlag = data?.target_device?.td_sdd_flag?.value === 'Y';
    const recurringCharge = formatEUPrice(
      parseFloat(data?.target_device?.[tdSddFlag ? 'td_price_mth_disc' : 'td_price_mth']?.value ?? '') || 0,
    );
    const originalRecurringCharge = tdSddFlag
      ? parseFloat(data?.target_device?.td_price_mth?.value ?? '') || 0
      : undefined;

    // SHOP-7550 We are using the SAS context value to calculate the totalDeviceMinCost
    // If SDD discount is available then we subtract it from the total device value
    const totalDeviceMinCost = formatEUPrice(
      parseFloat(data?.target_device?.td_rrp_ttl?.value ?? '0') -
        parseFloat(data?.target_device?.td_price_sdd_mth?.value ?? '0'),
    );

    const imageUrl = deviceDetails.data.largeImageGalleryUrls?.find((url) => url.endsWith('-s.png'));

    return {
      itemType: CartItemType.DEVICE,
      productConfig: {
        capacity: deviceDetails.data.capacity,
        color: deviceDetails.data.color,
        contractTerm: data?.target_device?.td_term?.value ?? '',
        deviceSku,
        imageUrl,
      },
      productName: deviceDetails.data.model,
      manufacturer: data?.target_device?.td_mfr?.value ?? '',
      priceInfo: {
        recurringCharge,
        originalRecurringCharge,
        totalDeviceMinCost,
      },
      hideWasLabel: false,
    };
  }, [data?.target_device, deviceDetails.data, deviceSku]);

  const plan = React.useMemo<SasProductPlan | undefined>(() => {
    if (!journey) return undefined;

    const tpDataBonFlag = data?.target_plan?.tp_data_bon_flag?.value === 'Y';
    const planData =
      data?.target_plan?.tp_data?.value === UNLIMITED_PLAN_DATA
        ? UNLIMITED
        : data?.target_plan?.[tpDataBonFlag ? 'tp_data_ttl' : 'tp_data']?.value ?? '0GB';

    const isDiscounted = !!data?.target_plan?.tp_btl_disc_amt?.value;
    const nowPrice = data?.target_plan?.[isDiscounted ? 'tp_price_disc_mth' : 'tp_price_mth']?.value ?? '0';
    const wasPrice = isDiscounted ? data?.target_plan?.tp_price_mth?.value ?? '0' : undefined;
    const discountPrice = wasPrice && wasPrice !== '0' ? parseFloat(wasPrice) - parseFloat(nowPrice) : 0;
    const recurringCharge =
      wasPrice && wasPrice !== '0'
        ? formatGSTInclusiveAmount(wasPrice) - Math.round(discountPrice)
        : formatGSTInclusiveAmount(nowPrice);
    const originalRecurringCharge = wasPrice && wasPrice !== '0' ? formatGSTInclusiveAmount(wasPrice) : 0;

    const planTermMonths = parseInt(data?.target_plan?.tp_term?.value ?? '0', 10);

    return {
      itemType: CartItemType.PLAN,
      cisUrl: data?.target_plan?.tp_cis_url?.value ?? '',
      priceInfo: {
        recurringCharge,
        originalRecurringCharge,
      },
      productConfig: {
        dataLimit: DataLimit.LIMITED, // TODO
      },
      productName: data?.target_plan?.tp_name?.value ?? '',
      relatedContent: {
        planData,
        planName: data?.target_plan?.tp_name?.value ?? '',
        planTermMonths,
        planTenure: planTermMonths > 1 ? `${planTermMonths} months` : 'Month to month',
        planTitle: data?.target_plan?.tp_name?.value ?? '',
      },
      hideWasLabel: false, // TODO
    };
  }, [data?.target_plan, journey]);

  const items = React.useMemo<ReadonlyArray<SasProduct>>(() => compact([device, plan]), [device, plan]);

  return {
    isLoading: !data || deviceDetails.isLoading,
    deviceDetails,
    items,
  };
}
