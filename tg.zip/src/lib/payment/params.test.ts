import { AccountType } from '@src/lib/api/types';
import { PaymentIframeHashParams, getPaymentIframeHashParams } from '@src/lib/payment/params';

describe('Payment params lib', () => {
  describe('getPaymentIframeHashParams()', () => {
    it('should return an object containing params from the hash', () => {
      const expected: PaymentIframeHashParams = {
        accounttype: AccountType.PREPAY,
        origin: 'https://www.vodafone.com.au',
        PAYMENT_METHOD: 'CREDITCARD',
        FLOW_TYPE: 'CHARGE',
        ORDER_ID: 'VF12345678',
        'X-SESSION_ID': 'abc123',
        AMOUNT: '40.00',
        HMAC: 'abc123def456',
      };
      jsdom.reconfigure({
        url: `https://www.vodafone.com.au/iframe/ccinput#${new URLSearchParams(Object.entries(expected))}`,
      });

      expect(getPaymentIframeHashParams()).toEqual(expected);
    });

    it('should return an object with defaults', () => {
      jsdom.reconfigure({ url: 'https://www.vodafone.com.au/iframe/ccinput' });

      expect(getPaymentIframeHashParams()).toEqual({
        accounttype: AccountType.POSTPAY,
        origin: '',
        PAYMENT_METHOD: 'CREDITCARD',
        FLOW_TYPE: 'VAULT',
        ORDER_ID: '',
        'X-SESSION_ID': '',
        AMOUNT: '0',
        HMAC: '',
      });
    });
  });
});
