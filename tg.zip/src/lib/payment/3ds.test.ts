import { isThreeDSEnabled, shouldCreateCardTransaction } from './3ds';

describe('3DS lib', () => {
  describe('isThreeDSEnabled', () => {
    it.each([
      { enabledForAccountType: false, amount: 50, amountThreshold: 30, expected: false },
      { enabledForAccountType: true, amount: 50, amountThreshold: 30, expected: true },
      { enabledForAccountType: true, amount: 30, amountThreshold: 30, expected: true },
      { enabledForAccountType: true, amount: 29.5, amountThreshold: 30, expected: false },
      { enabledForAccountType: true, amount: 30, amountThreshold: 0, expected: true },
      { enabledForAccountType: true, amount: 30, amountThreshold: undefined, expected: false },
    ])(
      '3DS enabled should be $expected if enabled on account is $enabledForAccountType, amount is $amount and amount threshold is $amountThreshold',
      ({ enabledForAccountType, amount, amountThreshold, expected }) => {
        expect(isThreeDSEnabled(enabledForAccountType, amount, amountThreshold)).toBe(expected);
      },
    );
  });

  describe('shouldCreateCardTransaction', () => {
    it.each([
      [true, true, true],
      [true, false, true],
      [false, true, false],
      [false, false, false],
    ])(
      'should proceed to create card transaction for shifted(%s) shiftPossible(%s)',
      (shifted, shiftPossible, output) => {
        expect(shouldCreateCardTransaction(shifted, shiftPossible)).toBe(output);
      },
    );
  });
});
