import { ElementType } from '@kablamo/kerosene';
import { noop } from 'lodash';
import React from 'react';
import { CreateTransactionResult } from '@src/lib/api/types';
import Logger from '@src/lib/logger/logger';
import { getAllowedParentOrigin, isAllowedOrigin, isParentSameOrigin } from '@src/lib/payment/origin';
import { isRecord } from '@src/lib/types';

const RECEIVED_MESSAGE_VALIDATORS = [
  (
    data: unknown,
  ): data is {
    source: 'omniscript';
    type: 'CUSTOMER_DETAILS';
    payload: { email: string; phone: string; firstName: string; lastName: string };
  } =>
    isRecord(data) &&
    data.source === 'omniscript' &&
    data.type === 'CUSTOMER_DETAILS' &&
    isRecord(data.payload) &&
    typeof data.payload.email === 'string' &&
    typeof data.payload.phone === 'string' &&
    typeof data.payload.firstName === 'string' &&
    typeof data.payload.lastName === 'string',
  (data: unknown): data is { source: 'omniscript'; type: 'SUBMIT_REQUEST' } =>
    isRecord(data) && data.source === 'omniscript' && data.type === 'SUBMIT_REQUEST',
] as const;

export type ReceivedMessageType = ElementType<typeof RECEIVED_MESSAGE_VALIDATORS> extends (
  data: unknown,
) => data is infer T
  ? T
  : never;

function isReceivedMessageType(data: unknown): data is ReceivedMessageType {
  return RECEIVED_MESSAGE_VALIDATORS.some((validator) => validator(data));
}

export type SubmitFailureErrorCodes =
  | 'VODAFONE_ERROR'
  | 'CUSTOMER_ERROR'
  | 'HIGH_RISK_ERROR'
  | 'NONCE_ALREADY_USED_ERROR'
  | 'ALIPAY_UNAVAILABLE_ERROR'
  | 'ALIPAY_DUPLICATE_SUBMIT_PAYMENT_ERROR'
  | 'ALIPAY_PAYMENT_CANCELLED'
  | 'VFE_3DS_LIABILITY_NOT_SHIFTED';

export type IframeVariants = 'CC' | 'PAYPAL' | 'GOOGLE_PAY' | 'APPLE_PAY' | 'ALIPAY';

export type SendMessageType = {
  source: 'vfe';
} & (
  | {
      type: 'VFE_IFRAME_READY';
      iframe: IframeVariants;
    }
  | {
      type: 'PAYMENT_CLIENT_READY';
      iframe: IframeVariants;
    }
  | {
      type: 'CC_REQUEST_INITIATED';
    }
  | { type: 'VFE_IFRAME_FAILED' }
  | { type: '3DS_MODAL_RENDERED' }
  | { type: '3DS_CARD_VERIFIED' }
  | { type: 'SUBMIT_REQUEST' }
  | { type: 'SUBMIT_INITIATED' }
  | {
      type: 'SUBMIT_SUCCESS';
      payload: CreateTransactionResult;
    }
  | {
      type: 'SUBMIT_FAILURE';
      code: SubmitFailureErrorCodes;
    }
);

export function usePaymentIframePostMessage(callback?: (data: ReceivedMessageType) => void) {
  const callbackRef = React.useRef(callback);
  callbackRef.current = callback;

  React.useEffect(() => {
    // If we're not inside an iframe do nothing
    if (window === window.parent) {
      Logger.error(`${usePaymentIframePostMessage.name}() was called, but we aren't inside an iframe`, {
        ucode: '2e445e3',
      });
      return noop;
    }

    if (!isParentSameOrigin()) {
      Logger.warn(`${usePaymentIframePostMessage.name}() was called, but the parent window is not on the same origin`, {
        ucode: '75c5a08',
      });
    }

    const onMessage = (e: MessageEvent<unknown>) => {
      if (!isAllowedOrigin(e.origin)) {
        Logger.warn('Received message from an unexpected origin', { origin: e.origin, ucode: '448b8bb' });
        return;
      }

      if (!isReceivedMessageType(e.data)) {
        Logger.warn('Received message which did not match any of the expected types', {
          data: e.data,
          ucode: '96d337f',
        });
        return;
      }

      callbackRef.current?.(e.data);
    };

    window.addEventListener('message', onMessage);

    return () => {
      window.removeEventListener('message', onMessage);
    };
  }, []);

  const postMessage = React.useCallback(
    (data: SendMessageType) => window.parent.postMessage(data, getAllowedParentOrigin()),
    [],
  );

  return postMessage;
}
