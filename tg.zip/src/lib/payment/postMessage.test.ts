import { stubProperties } from '@kablamo/kerosene-test';
import { renderHook } from '@testing-library/react-hooks';
import { when } from 'jest-when';

const mockOrigin = 'https://www.vodafone.com.au';
const mockGetAllowedParentOrigin: jest.Mock<string, []> = jest.fn();
const mockIsAllowedOrigin: jest.Mock<boolean, [origin: string]> = jest.fn();

jest.mock('@src/lib/payment/origin', () => ({
  __esModule: true,
  getAllowedParentOrigin: mockGetAllowedParentOrigin,
  isAllowedOrigin: mockIsAllowedOrigin,
  isParentSameOrigin: () => true,
}));

import { ReceivedMessageType, SendMessageType, usePaymentIframePostMessage } from '@src/lib/payment/postMessage';

describe('Payment postMessage lib', () => {
  let restoreParent: () => void;
  let parent: Window;
  let postMessage: jest.MockedFunction<Window['postMessage']>;
  let addEventListener: jest.SpiedFunction<Window['addEventListener']>;
  let removeEventListener: jest.SpiedFunction<Window['removeEventListener']>;
  beforeEach(() => {
    mockGetAllowedParentOrigin.mockReturnValue(mockOrigin);
    mockIsAllowedOrigin.mockReturnValue(false);
    when(mockIsAllowedOrigin).calledWith(mockOrigin).mockReturnValue(true);
    postMessage = jest.fn();
    parent = { postMessage } as Partial<Window> as Window;
    restoreParent = stubProperties(window, {
      parent: {
        get() {
          return parent;
        },
      },
    });
    addEventListener = jest.spyOn(window, 'addEventListener');
    removeEventListener = jest.spyOn(window, 'removeEventListener');
  });

  afterEach(() => {
    jest.clearAllMocks();
    restoreParent();
  });

  describe('usePaymentIframePostMessage', () => {
    let callback: jest.Mock<void, [data: ReceivedMessageType]>;
    beforeEach(() => {
      callback = jest.fn();
    });

    it('should fail when not in an iframe', () => {
      parent = window;
      const error = new Error('error');
      mockGetAllowedParentOrigin.mockImplementation(() => {
        throw error;
      });
      const { result } = renderHook(() => usePaymentIframePostMessage(callback));
      expect(addEventListener).not.toHaveBeenCalledWith('message', expect.any(Function));

      expect(() => result.current({ source: 'vfe', type: 'VFE_IFRAME_READY', iframe: 'CC' })).toThrowError(error);
    });

    it('should return a postMessage function which calls window.parent.postMessage with origin', () => {
      const { result } = renderHook(() => usePaymentIframePostMessage(callback));
      const data: SendMessageType = {
        source: 'vfe',
        type: 'VFE_IFRAME_READY',
        iframe: 'CC',
      };
      result.current(data);
      expect(postMessage).toBeCalledWith(data, mockOrigin);
    });

    it.each([
      {
        message: 'should ignore message from a different origin',
        origin: 'https://evil.com',
        data: { source: 'omniscript', type: 'SUBMIT_REQUEST' } as ReceivedMessageType,
        received: false,
      },
      {
        message: "should ignore message that isn't an object",
        origin: mockOrigin,
        data: 'string',
        received: false,
      },
      {
        message: 'should receive SUBMIT_REQUEST',
        origin: mockOrigin,
        data: { source: 'omniscript', type: 'SUBMIT_REQUEST' } as ReceivedMessageType,
        received: true,
      },
      {
        message: 'should receive CUSTOMER_DETAILS',
        origin: mockOrigin,
        data: {
          source: 'omniscript',
          type: 'CUSTOMER_DETAILS',
          payload: { email: 'test@example.org', phone: '+61491570110', firstName: 'Test', lastName: 'User' },
        } as ReceivedMessageType,
        received: true,
      },
    ] as const)('$message', ({ data, origin, received }) => {
      const { unmount } = renderHook(() => usePaymentIframePostMessage(callback));

      const onMessage = addEventListener.mock.calls.find((call) => call[0] === 'message')![1] as (
        e: MessageEvent<unknown>,
      ) => void;
      onMessage(new MessageEvent('message', { data, origin }));

      if (received) {
        expect(callback).toBeCalledWith(data);
      } else {
        expect(callback).not.toHaveBeenCalled();
      }

      unmount();
      expect(removeEventListener).toBeCalledWith('message', onMessage);
    });
  });
});
