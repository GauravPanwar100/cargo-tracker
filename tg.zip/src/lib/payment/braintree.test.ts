import BraintreeError from 'braintree-web/lib/braintree-error';
import { isBraintreeError } from '@src/lib/payment/braintree';

describe('Payment Braintree lib', () => {
  describe('isBraintreeError', () => {
    it.each([
      { name: 'a regular error', error: new Error('an error'), expected: false },
      {
        name: 'BraintreeError',
        error: new BraintreeError({ type: BraintreeError.types.UNKNOWN, code: 'UNKNOWN', message: 'unknown error' }),
        expected: true,
      },
    ])('should return $expected for $name', ({ error, expected }) => {
      expect(isBraintreeError(error)).toBe(expected);
    });
  });
});
