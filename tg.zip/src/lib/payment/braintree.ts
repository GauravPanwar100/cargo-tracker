import { ElementType } from '@kablamo/kerosene';
import { SubmitFailureErrorCodes } from '@src/lib/payment/postMessage';
import { UnboxArray } from '@src/lib/types';
import braintree from 'braintree-web';
import type BraintreeError from 'braintree-web/lib/braintree-error';
import type { LocalPaymentTokenizePayload } from 'braintree-web/modules/local-payment';

export type HostedFieldsCard = ElementType<braintree.HostedFieldsEvent['cards']>;

export type HostedFieldsState = ReturnType<braintree.HostedFields['getState']>;

export type HostedFieldsFieldData = HostedFieldsState['fields']['number'];

export enum KnownCardType {
  VISA = 'visa',
  MASTERCARD = 'master-card',
  AMERICAN_EXPRESS = 'american-express',
  DINERS_CLUB = 'diners-club',
  DISCOVER = 'discover',
  JCB = 'jcb',
  UNIONPAY = 'unionpay',
  MAESTRO = 'maestro',
  ELO = 'elo',
  MIR = 'mir',
  HIPER = 'hiper',
  HIPERCARD = 'hipercard',
}

type TransactionError = {
  response: {
    data: {
      error: {
        code: SubmitFailureErrorCodes;
      };
    };
  };
};

export type BraintreePayload =
  | braintree.HostedFieldsTokenizePayload
  | braintree.ThreeDSecureVerifyPayload
  | braintree.ApplePayPayload
  | braintree.PayPalTokenizePayload
  | braintree.GooglePaymentTokenizePayload
  | LocalPaymentTokenizePayload;
/**
 * Technically, this type is just `string`, but this still allows editor autocomplete to suggest the known card types
 */
export type CardType = KnownCardType | (string & {});

export function isBraintreeError(error: unknown): error is BraintreeError {
  // We can't use `instanceof BraintreeError` because Braintree does not properly deal with the quirks of extending `Error`
  return error instanceof Error && error.name === 'BraintreeError';
}

export function isTransactionError(error: unknown): error is TransactionError {
  return error instanceof Object && Object.prototype.hasOwnProperty.call(error, 'response');
}

export enum HostedFieldsErrorCode {
  /** occurs when none of the fields are filled in */
  HOSTED_FIELDS_FIELDS_EMPTY = 'HOSTED_FIELDS_FIELDS_EMPTY',
  /** occurs when certain fields do not pass client side validation */
  HOSTED_FIELDS_FIELDS_INVALID = 'HOSTED_FIELDS_FIELDS_INVALID',
  /**
   * occurs when:
   * - the client token used for client authorization was generated
   *   with a customer ID and the fail on duplicate payment method
   *   option is set to true
   * - the card being tokenized has previously been vaulted (with any customer)
   * @see https://developer.paypal.com/braintree/docs/reference/request/client-token/generate#options.fail_on_duplicate_payment_method
   */
  HOSTED_FIELDS_TOKENIZATION_FAIL_ON_DUPLICATE = 'HOSTED_FIELDS_TOKENIZATION_FAIL_ON_DUPLICATE',
  /**
   * occurs when:
   * - the client token used for client authorization was generated
   *   with a customer ID and the verify card option is set to true
   *   and you have credit card verification turned on in the Braintree
   *   control panel
   * - the cvv does not pass verification (https://developer.paypal.com/braintree/docs/reference/general/testing#avs-and-cvv/cid-responses)
   * @see https://developer.paypal.com/braintree/docs/reference/request/client-token/generate#options.verify_card
   */
  HOSTED_FIELDS_TOKENIZATION_CVV_VERIFICATION_FAILED = 'HOSTED_FIELDS_TOKENIZATION_CVV_VERIFICATION_FAILED',
  /** occurs for any other tokenization error on the server */
  HOSTED_FIELDS_FAILED_TOKENIZATION = 'HOSTED_FIELDS_FAILED_TOKENIZATION',
  /** occurs when the Braintree gateway cannot be contacted */
  HOSTED_FIELDS_TOKENIZATION_NETWORK_ERROR = 'HOSTED_FIELDS_TOKENIZATION_NETWORK_ERROR',
}

export enum ThreeDSecureErrorCode {
  /** occurs when 3DS response considered as liability not shifted */
  VFE_3DS_LIABILITY_NOT_SHIFTED = 'VFE_3DS_LIABILITY_NOT_SHIFTED',
}

export enum Currency {
  AUD = 'AUD',
}

export enum PaypalButtonLabel {
  PAYPAL = 'paypal',
  PAY = 'pay',
  CHECKOUT = 'checkout',
  BUYNOW = 'buynow',
  SUBSCRIBE = 'subscribe',
  DONATE = 'donate',
}

export type PaymentMethod = 'CREDITCARD' | 'PAYPAL' | 'GOOGLEPAY' | 'APPLEPAY' | 'ALIPAY';

export type CardFlowType = 'VAULT' | 'CHARGE';
export type PaypalFlowType = 'VAULT' | 'CHARGE';
export type GooglePayFlowType = 'CHARGE';
export type ApplePayFlowType = 'CHARGE';
export type AliPayFlowType = 'CHARGE';

export type AllFlowType = CardFlowType | PaypalFlowType | ApplePayFlowType;

export const paymentMethodFlowsMap = {
  CREDITCARD: ['VAULT', 'CHARGE'] as CardFlowType[],
  PAYPAL: ['VAULT', 'CHARGE'] as PaypalFlowType[],
  APPLEPAY: ['CHARGE'] as ApplePayFlowType[],
  GOOGLEPAY: ['CHARGE'] as GooglePayFlowType[],
  ALIPAY: ['CHARGE'] as AliPayFlowType[],
} as const;
type PaymentMethodFlowsMap = typeof paymentMethodFlowsMap;

export type PaymentMethodFlows = {
  [P in keyof PaymentMethodFlowsMap]: {
    PAYMENT_METHOD: P;
    FLOW_TYPE: UnboxArray<PaymentMethodFlowsMap[P]>;
  };
}[keyof PaymentMethodFlowsMap];

export type ThreeDSecureEventType =
  | 'authentication-modal-render'
  | 'lookup-complete'
  | 'authentication-iframe-available';

export type NextFunction = (() => void) | undefined;
export const merchantDisplayName = 'Vodafone Australia';
