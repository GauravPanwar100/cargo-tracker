import { AccountType } from '@src/lib/api/types';
import { AllFlowType, PaymentMethod } from '@src/lib/payment/braintree';

export type CommonPaymentIframeHashParams = {
  accounttype: AccountType;
  origin: string;
  ORDER_ID: string;
  'X-SESSION_ID': string;
  AMOUNT: string;
  HMAC: string;
};

export type PaymentIframeHashParams = CommonPaymentIframeHashParams & {
  PAYMENT_METHOD: PaymentMethod;
  FLOW_TYPE: AllFlowType;
};

export function getPaymentIframeHashParams(): PaymentIframeHashParams {
  const params = new URLSearchParams(window.location.hash.slice(1));

  const accounttype = params.get('accounttype') === AccountType.PREPAY ? AccountType.PREPAY : AccountType.POSTPAY;
  const origin = params.get('origin') ?? '';
  const PAYMENT_METHOD = params.get('PAYMENT_METHOD') === 'PAYPAL' ? 'PAYPAL' : 'CREDITCARD';

  let FLOW_TYPE: AllFlowType = 'VAULT';

  FLOW_TYPE = params.get('FLOW_TYPE') === 'CHARGE' ? 'CHARGE' : 'VAULT';

  const ORDER_ID = params.get('ORDER_ID') ?? '';
  const X_SESSION_ID = params.get('X-SESSION_ID') ?? '';
  const AMOUNT = params.get('AMOUNT') ?? '0';
  const HMAC = params.get('HMAC') ?? '';

  return {
    accounttype,
    origin,
    PAYMENT_METHOD,
    FLOW_TYPE,
    ORDER_ID,
    'X-SESSION_ID': X_SESSION_ID,
    AMOUNT,
    HMAC,
  };
}

export function getPaymentIframePath(paymentMethod: PaymentMethod): string {
  switch (paymentMethod) {
    case 'CREDITCARD':
      return 'ccinput';
    case 'PAYPAL':
      return 'paypal';
    case 'APPLEPAY':
      return 'apple-pay';
    case 'GOOGLEPAY':
      return 'googlepay';
    case 'ALIPAY':
      return 'alipay';
    default:
      return 'ccinput';
  }
}
