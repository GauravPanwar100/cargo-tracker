import { getPaymentIframeHashParams } from '@src/lib/payment/params';

export function isParentSameOrigin() {
  try {
    // Attempting to access `window.parent.origin` when not same origin will throw
    return window.origin === window.parent.origin;
  } catch (e) {
    return false;
  }
}

/**
 * Returns whether the `origin` is allowed to send messages to the Payment VFE iframe
 * @param origin e.g. `MessageEvent#origin`
 */
export function isAllowedOrigin(origin: string): boolean {
  return [
    // When actually deployed, the parent window (OmniScript) will be same origin
    window.origin,
    // Salesforce OmniScript environments
    'https://vhadf--fcpreprod--vlocity-cmt.visualforce.com',
    'https://vhadf--vhapc1sitp--vlocity-cmt.visualforce.com',
    'https://vhadf--dpdit2--vlocity-cmt.visualforce.com',
    'https://vhadf--vhadp4devn--vlocity-cmt.visualforce.com',
    'https://vhadf--vlocity-cmt.visualforce.com',
  ].includes(origin);
}

/**
 * Returns the parent origin if same origin, or whatever the parent specified for origin in this frame's hash parameters
 * e.g. `/iframe/ccinput#origin=https%3A%2F%2Fwww.vodafone.com.au`
 *
 * NOTE: A parent document can lie about this parameter, but we're just using this for
 * `window.parent.postMessage(data, origin)`, which means that parent documents will only be able to read the message if
 * the `origin` parameter it passed in was correct
 *
 * @throws {Error} if not inside an iframe
 * @throws {Error} if parent is not same origin and did not specify its origin in hash parameters
 * @throws {Error} if parent is not same origin and specified an origin in hash parameters which was not permitted
 */
export function getAllowedParentOrigin() {
  if (window === window.parent) {
    throw new Error('not inside an iframe');
  }

  if (isParentSameOrigin()) return window.origin;

  const { origin } = getPaymentIframeHashParams();

  if (!origin) {
    throw new Error('iframe parent is not same origin and did not specify its origin in hash parameters');
  }

  if (!isAllowedOrigin(origin)) {
    throw new Error(`iframe parent specified parent origin (${origin}) but it is not allowed`);
  }

  return origin;
}
