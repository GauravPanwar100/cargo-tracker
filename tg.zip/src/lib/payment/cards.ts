import { ElementType } from '@kablamo/kerosene';
import { ReactComponent as CardLogoAMEXSvg } from '@src/assets/svg/card-logo-amex.svg';
import { ReactComponent as CardLogoMastercardSvg } from '@src/assets/svg/card-logo-mastercard.svg';
import { ReactComponent as CardLogoVISASvg } from '@src/assets/svg/card-logo-visa.svg';
import { KnownCardType } from '@src/lib/payment/braintree';

export const SUPPORTED_CARD_TYPES = [
  { type: KnownCardType.VISA, Svg: CardLogoVISASvg },
  { type: KnownCardType.MASTERCARD, Svg: CardLogoMastercardSvg },
  { type: KnownCardType.AMERICAN_EXPRESS, Svg: CardLogoAMEXSvg },
] as const;

export type SupportedCardType = ElementType<typeof SUPPORTED_CARD_TYPES>['type'];
