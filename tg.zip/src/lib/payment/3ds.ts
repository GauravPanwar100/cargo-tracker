// Note: this function can be removed if eventually logic is simply dependent on `liabilityShifted`, however keep it for now in case there is a need to rely on other fields from 3DS response on the client side which is yet to be finalized

/**
 * Based on 3DS verifyCard payload returns a boolean indicates whether or not should proceed to create card transaction
 * @param {boolean} liabilityShifted
 * @param {boolean} _liabilityShiftPossible
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function shouldCreateCardTransaction(liabilityShifted: boolean, _liabilityShiftPossible: boolean): boolean {
  // liabilityShifted indicates that 3DS worked and authentication succeeded. This will also be true if the issuing bank does not support 3DS, but the payment method does. In both cases, the liability for fraud has been shifted to the bank. Should go on creating a transaction using the new nonce.

  // If both liabilityShifted and liabilityShiftPossible are false, then card was ineligible for 3DS. *Can* continue to create the transaction with the new nonce. However, liability shift will not apply to this transaction.
  // Note: business decision has been made to not proceed in this case as per - https://tpgtelecom.atlassian.net/wiki/spaces/DFS/pages/9399076323520/F+B+-+Handling+Braintree+Responses+focus+on+3DS+challenge

  // If liabilityShiftPossible is true but liabilityShifted is false, then user failed 3DS. Card brands recommend asking the user for another form of payment.

  // return liabilityShifted || (!liabilityShiftPossible && !liabilityShifted);

  return liabilityShifted;
}

export function isThreeDSEnabled(
  enabledForAccountType: boolean,
  amount: number,
  amountThreshold: number | undefined,
): boolean {
  return (
    enabledForAccountType && typeof amountThreshold === 'number' && amountThreshold >= 0 && amount >= amountThreshold
  );
}
