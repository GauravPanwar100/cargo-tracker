import { stubProperties } from '@kablamo/kerosene-test';
import { getAllowedParentOrigin, isAllowedOrigin, isParentSameOrigin } from '@src/lib/payment/origin';

const url = new URL(
  `https://www.vodafone.com.au/iframe/ccinput#${new URLSearchParams([['origin', 'https://www.vodafone.com.au']])}`,
);

describe('Payment origin utils', () => {
  let restoreParent: () => void;
  let parent: Window;
  beforeEach(() => {
    jsdom.reconfigure({ url: url.href });
    parent = {} as Window;
    restoreParent = stubProperties(window, {
      parent: {
        configurable: true,
        get() {
          return parent;
        },
      },
    });
  });

  afterEach(() => {
    restoreParent();
  });

  describe('isParentSameOrigin', () => {
    it.each([
      {
        message: 'should return true when window.origin === window.parent.origin',
        getter: () => url.origin,
        expected: true,
      },
      {
        message: 'should return false when accessing window.parent.origin throws',
        getter: () => {
          throw new DOMException('Blocked a frame from accessing a cross-origin frame');
        },
        expected: false,
      },
    ])('$message', ({ getter, expected }) => {
      Object.defineProperty(window.parent, 'origin', {
        configurable: true,
        get: getter,
      });
      expect(isParentSameOrigin()).toBe(expected);
    });
  });

  describe('isAllowedOrigin', () => {
    it.each([
      { origin: url.origin, expected: true },
      { origin: 'https://vhadf--fcpreprod--vlocity-cmt.visualforce.com', expected: true },
      { origin: 'https://vhadf--vhapc1sitp--vlocity-cmt.visualforce.com', expected: true },
      { origin: 'https://vhadf--dpdit2--vlocity-cmt.visualforce.com', expected: true },
      { origin: 'https://vhadf--vhadp4devn--vlocity-cmt.visualforce.com', expected: true },
      { origin: 'https://vhadf--vlocity-cmt.visualforce.com', expected: true },
      { origin: 'https://evil.com', expected: false },
    ])('should return $expected for $origin', ({ origin, expected }) => {
      expect(isAllowedOrigin(origin)).toBe(expected);
    });
  });

  describe('getAllowedParentOrigin', () => {
    it('should throw when not in an iframe', () => {
      parent = window;
      expect(() => getAllowedParentOrigin()).toThrowError('not inside an iframe');
    });

    it('should return window.origin when the parent is same-origin', () => {
      Object.defineProperty(window.parent, 'origin', { value: url.origin });
      expect(getAllowedParentOrigin()).toBe(url.origin);
    });

    it('should throw when iframe parent is not same-origin and does not specify origin', () => {
      const noHash = new URL(url.href);
      noHash.hash = '';
      jsdom.reconfigure({ url: noHash.href });
      Object.defineProperty(window.parent, 'origin', {
        get() {
          throw new DOMException('Blocked a frame from accessing a cross-origin frame');
        },
      });
      expect(() => getAllowedParentOrigin()).toThrowError(
        'iframe parent is not same origin and did not specify its origin in hash parameters',
      );
    });

    it('should throw when iframe parent specified origin is not allowed', () => {
      Object.defineProperty(window.parent, 'origin', {
        get() {
          throw new DOMException('Blocked a frame from accessing a cross-origin frame');
        },
      });
      const notAllowed = new URL(url.href);
      notAllowed.hash = `#${new URLSearchParams([['origin', 'https://evil.com']])}`;
      jsdom.reconfigure({ url: notAllowed.href });
      expect(() => getAllowedParentOrigin()).toThrowError(
        'iframe parent specified parent origin (https://evil.com) but it is not allowed',
      );
    });

    it('should return the specified origin if allowed', () => {
      expect(getAllowedParentOrigin()).toBe(url.origin);
    });
  });
});
