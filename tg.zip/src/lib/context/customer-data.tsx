import React from 'react';
import { getApiClient } from '@src/lib/api';
import {
  CurrentServiceData,
  CustomerDetails,
  CustomerProductsEligibility,
  CustomerServiceDetails,
} from '@src/lib/api/types';
import { useAuthentication } from '@src/lib/context/authentication';
import useImperativeData, { ImperativeDataReturnType } from '@src/lib/hooks/use-imperative-data';
import useServiceType from '@src/lib/hooks/use-service-type';
import { LocalStorageClient, SessionStorageClient } from '@src/lib/storage';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { isServiceOfType } from '@src/lib/util/customer';

/**
 * Some of this data is required for page tracking, so will be automatically fetched whenever the user is authenticated
 */
export interface CustomerDataContext {
  activeMsisdn: string | null;
  setActiveMsisdn: React.Dispatch<React.SetStateAction<string | null>>;
  activeService: CustomerServiceDetails | null;
  customerDetails: ImperativeDataReturnType<undefined, CustomerDetails>;
  currentServiceData: ImperativeDataReturnType<{ activeMsisdn: string }, CurrentServiceData>;
  upgradePlanEligibility: ImperativeDataReturnType<{ activeMsisdn: string }, CustomerProductsEligibility>;
  customerBundleAndSaveCount: number;
}

const CustomerData = React.createContext<CustomerDataContext>(undefined as unknown as CustomerDataContext);

export const useCustomerData = () => React.useContext(CustomerData);

export const CustomerDataProvider = ({ children }: { children: React.ReactNode }) => {
  const ApiClient = getApiClient();
  const customerDetails = useImperativeData(ApiClient.fetchCustomerDetails);
  const currentServiceData = useImperativeData(ApiClient.fetchCurrentServiceData);
  const upgradePlanEligibility = useImperativeData(ApiClient.fetchUpgradePlanEligibility);

  const { isAuthenticated, user } = useAuthentication();
  const [serviceType] = useServiceType();

  const [customerDetailsState, getCustomerDetails] = customerDetails;
  const [activeMsisdn, setActiveMsisdn] = React.useState<string | null>(null);
  React.useEffect(() => {
    SessionStorageClient.setLoggedInForAem(isAuthenticated, activeMsisdn);
    document.querySelector<HTMLElement & { updateLoggedIn?(): void }>('vha-header')?.updateLoggedIn?.();
  }, [activeMsisdn, isAuthenticated]);

  const activeService = customerDetailsState.data?.services.find((service) => service.msisdn === activeMsisdn) ?? null;
  React.useEffect(() => {
    if (!user || !customerDetailsState.isSuccess) return;

    const stored = LocalStorageClient.getCustomerID();
    const msisdn =
      customerDetailsState.data?.services.find((service) => service.customerID === stored)?.msisdn ??
      user['https://auth.vodafone.com.au/msisdn'];
    const customerID = customerDetailsState.data?.services.find((service) => service.msisdn === msisdn)?.customerID;
    LocalStorageClient.setCustomerID(customerID ?? null);
    setActiveMsisdn(msisdn);
  }, [customerDetailsState.data?.services, customerDetailsState.isSuccess, user]);

  // Get customer Services when authenticated
  let customerBundleAndSaveCount = 0;
  if (customerDetailsState.data?.services.some((item) => item.bundleAndSaveEligible)) {
    if (isServiceOfType(serviceType, ServiceTypeValue.Upgrade)) {
      customerBundleAndSaveCount = customerDetailsState.data.services.filter(
        (item) => item.msisdn !== activeMsisdn && item.bundleAndSaveEligible,
      ).length;
    } else {
      customerBundleAndSaveCount = customerDetailsState.data.services.filter(
        (item) => item.bundleAndSaveEligible,
      ).length;
    }
  }

  React.useEffect(() => {
    if (
      isAuthenticated &&
      !customerDetailsState.isLoading &&
      !customerDetailsState.isSuccess &&
      !customerDetailsState.error
    ) {
      getCustomerDetails();
    }
  }, [
    customerDetailsState.error,
    customerDetailsState.isLoading,
    customerDetailsState.isSuccess,
    getCustomerDetails,
    isAuthenticated,
  ]);

  // Get current service data when authenticated and intent is Upgrade
  const [currentServiceDataState, getCurrentServiceState] = currentServiceData;
  React.useEffect(() => {
    if (
      isAuthenticated &&
      isServiceOfType(serviceType, ServiceTypeValue.Upgrade) &&
      activeMsisdn &&
      !currentServiceDataState.isLoading &&
      !(currentServiceDataState.isSuccess && currentServiceDataState.params?.activeMsisdn === activeMsisdn) &&
      !currentServiceDataState.error
    ) {
      getCurrentServiceState({ activeMsisdn });
    }
  }, [
    activeMsisdn,
    currentServiceDataState.error,
    currentServiceDataState.isLoading,
    currentServiceDataState.isSuccess,
    currentServiceDataState.params?.activeMsisdn,
    getCurrentServiceState,
    isAuthenticated,
    serviceType,
  ]);

  // Get upgrade Plan Eligibility when authenticated
  const [upgradePlanEligibilityState, getUpgradePlanEligibility] = upgradePlanEligibility;
  React.useEffect(() => {
    if (
      isAuthenticated &&
      activeMsisdn &&
      !upgradePlanEligibilityState.isLoading &&
      !(upgradePlanEligibilityState.isSuccess && upgradePlanEligibilityState.params?.activeMsisdn === activeMsisdn) &&
      !upgradePlanEligibilityState.error
    ) {
      getUpgradePlanEligibility({ activeMsisdn });
    }
  }, [
    activeMsisdn,
    getUpgradePlanEligibility,
    isAuthenticated,
    upgradePlanEligibilityState.error,
    upgradePlanEligibilityState.isLoading,
    upgradePlanEligibilityState.isSuccess,
    upgradePlanEligibilityState.params?.activeMsisdn,
  ]);

  const value = React.useMemo<CustomerDataContext>(
    () => ({
      activeMsisdn,
      setActiveMsisdn,
      activeService,
      customerDetails,
      currentServiceData,
      upgradePlanEligibility,
      customerBundleAndSaveCount,
    }),
    [
      activeMsisdn,
      activeService,
      customerDetails,
      currentServiceData,
      upgradePlanEligibility,
      customerBundleAndSaveCount,
    ],
  );

  return <CustomerData.Provider value={value}>{children}</CustomerData.Provider>;
};
