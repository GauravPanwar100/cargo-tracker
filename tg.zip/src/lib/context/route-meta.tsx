import React, { MutableRefObject, createContext, useContext, useEffect, useRef, useState } from 'react';
import Router, { NextRouter } from 'next/router';
import { stripQueryFromPath } from '@src/lib/util/url';
import { SessionStorageClient } from '@src/lib/storage';
import { OptimizeContentKey } from '@src/lib/api/types';
import { SIMO_PLANS_PAGE } from '@src/lib/constants/pages';

interface RouteMeta {
  currentPath: MutableRefObject<string>;
  previousPath: MutableRefObject<string>;
  routeChangeInProgress: MutableRefObject<boolean>;
  isLoading: boolean;
  isJourneyUpdating: boolean;
  setJourneyUpdating: React.Dispatch<React.SetStateAction<boolean>>;
}

interface RouteMetaProviderProps {
  children: React.ReactNode;
  // NB: This is explicitly set to undefined rather than using the optional ? because a router is
  // required for the provider to work in the "real app". The undefined option is there so that we
  // can still present it inside Storybook where no router is available. If this prop was optional,
  // consumers inside the app may not be aware that the router is required for correct behaviour.
  router: NextRouter | undefined;
}

const RouteMetaContext = createContext<RouteMeta | undefined>(undefined);

export const RouteMetaProvider: React.FC<RouteMetaProviderProps> = ({ children, router }) => {
  const currentPath = useRef<string>(stripQueryFromPath(router?.asPath ?? ''));
  const previousPath = useRef<string>(stripQueryFromPath(''));
  const routeChangeInProgress = useRef<boolean>(false);

  const [isLoading, setLoading] = useState(false);
  const [isJourneyUpdating, setJourneyUpdating] = useState(false);

  // remove PLAN_ONLINE_OFFER from Session storage
  const planOnlineOfferSessionBlank = () => {
    SessionStorageClient.cleanupOptimizeContent(OptimizeContentKey.PLAN_ONLINE_OFFER);
  };

  useEffect(() => {
    // Navigate to any url, PLAN_ONLINE_OFFER session gets clear for first time only
    planOnlineOfferSessionBlank();
  }, []);

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const routeChangeStart = (url: string) => {
      routeChangeInProgress.current = true;
      setLoading(true);
      previousPath.current = stripQueryFromPath(router?.asPath ?? '');
    };

    const routeChangeComplete = (url: string) => {
      if (
        (window.location.href.includes(SIMO_PLANS_PAGE) && window.location.href.includes(`step`)) ||
        !window.location.href.includes(SIMO_PLANS_PAGE)
      )
        planOnlineOfferSessionBlank();
      currentPath.current = stripQueryFromPath(url);
      routeChangeInProgress.current = false;
      setLoading(false);
    };

    Router.events.on('routeChangeComplete', routeChangeComplete);
    Router.events.on('routeChangeStart', routeChangeStart);
    return () => {
      Router.events.off('routeChangeComplete', routeChangeComplete);
      Router.events.off('routeChangeStart', routeChangeStart);
    };
  }, [previousPath, router]);

  return (
    <RouteMetaContext.Provider
      value={{ currentPath, previousPath, routeChangeInProgress, isLoading, isJourneyUpdating, setJourneyUpdating }}
    >
      {children}
    </RouteMetaContext.Provider>
  );
};

export function useRouteMeta() {
  const context = useContext(RouteMetaContext);
  if (context === undefined) {
    throw new Error('useRouteMeta must be used within a RouteMetaProvider');
  }
  return context;
}
