import React from 'react';

export interface ModemPriceInfo {
  recurringCharge: number;
  oneTimeCharge: number;
  loyaltyMRCAmount: number;
  contractTerm: string;
}

interface ModemPriceInfoProviderProps {
  children: React.ReactNode;
  modemPriceInfo: ModemPriceInfo;
}

export interface ModemPriceInfoContext {
  getModemFullPrice: () => number;
}

const ModemPriceInfoContext = React.createContext<ModemPriceInfoContext | undefined>(undefined);

export const ModemPriceInfoProvider = ({ children, modemPriceInfo }: ModemPriceInfoProviderProps) => {
  const getModemFullPrice = React.useCallback(
    () => modemPriceInfo.recurringCharge * parseInt(modemPriceInfo.contractTerm, 10),
    [modemPriceInfo.contractTerm, modemPriceInfo.recurringCharge],
  );

  const value = React.useMemo<ModemPriceInfoContext>(
    () => ({
      getModemFullPrice,
    }),
    [getModemFullPrice],
  );

  return <ModemPriceInfoContext.Provider value={value}>{children}</ModemPriceInfoContext.Provider>;
};

export default function useModemPriceInfo() {
  const context = React.useContext(ModemPriceInfoContext);
  if (context === undefined) {
    throw new Error('useModemPriceInfo must be used within a ModemPriceInfoProvider');
  }
  return context;
}
