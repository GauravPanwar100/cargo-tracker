import React, { createContext, useCallback, useContext, useMemo, useRef } from 'react';
import { getApiClient } from '@src/lib/api';
import { Basket, BasketParams } from '@src/lib/api/types';
import { DataFetchState } from '@src/lib/hooks/data-fetch-reducer';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import useUpdatingRef from '@src/lib/hooks/use-updating-ref';
import { useCustomerData } from '@src/lib/context/customer-data';
import locks from '@src/lib/util/locks';
import { isEqual, omit } from 'lodash';

export interface BasketState {
  getBasketState: DataFetchState<BasketParams, Basket>;
  getBasket: (params: Omit<BasketParams, 'additionalBnsCount'>) => Promise<Basket | undefined>;
  setBasket: (basket: Basket | null) => void;
}

interface BasketProviderProps {
  children: React.ReactNode;
}

const BasketStateContext = createContext<BasketState | undefined>(undefined);

const TEN_SECONDS = 10000;

/**
 * Note: This is only to be used for event tracking
 */
export const BASKET_STATE_FOR_EVENT_TRACKING: { basket?: Basket | null } = {};

export const BasketProvider: React.FC<BasketProviderProps> = ({ children }) => {
  const [getBasketState, getBasket, getBasketDispatch] = useImperativeData(getApiClient().getBasket);
  const { customerBundleAndSaveCount } = useCustomerData();
  // We place the following variables into refs in order to create a stable container for their values
  // so that the dependencies for getBasketAndUpdateTimestamp will not change between renders.
  // This means that `getBasketAndUpdateTimestamp` will be referentially stable, and can be used safely
  // in useEffect hooks where you only want it to run once in a page session e.g. on the cart page
  //
  // If we didn't do this, then when a useEffect wanted to call getBasket, it would have to include
  // getBasket in its dependency array, and the value of that function would change whenever
  // getBasketState.data or updatedAt changed, triggering a re-run of the getBasket call
  const data = useUpdatingRef(getBasketState.data);
  BASKET_STATE_FOR_EVENT_TRACKING.basket = getBasketState.data;
  const updatedAt = useRef<Date | undefined>();
  const previousBnSCount = useRef<number | undefined>();
  const previousParams = useRef<BasketParams | undefined>();

  const getBasketAndUpdateTimestamp = useCallback(
    (params: Omit<BasketParams, 'additionalBnsCount'>) =>
      // Using locks here to ensure only one request can be made at a time
      locks.request('basket', { mode: 'exclusive' }, async () => {
        // Get rest of all params except basletId from previous params
        const previousParamsWithoutBasketId = omit(previousParams.current, ['basketId']);
        // Get rest of all params except basletId from current params
        const currentParamsWithoutBasketId = omit(params, ['basketId']);
        if (
          data.current?.basketId === params.basketId &&
          updatedAt.current &&
          (!previousBnSCount.current || previousBnSCount.current === customerBundleAndSaveCount) && // if there is no bns count or if it hasn't changed
          isEqual(previousParamsWithoutBasketId, currentParamsWithoutBasketId) // If there are no changes in params (except basketId)
        ) {
          const now = new Date();
          if (now.getTime() - updatedAt.current.getTime() < TEN_SECONDS) {
            return data.current;
          }
        }
        const basket = await getBasket({ ...params, additionalBnsCount: customerBundleAndSaveCount });
        updatedAt.current = new Date();
        previousBnSCount.current = customerBundleAndSaveCount;
        previousParams.current = params;
        return basket;
      }),
    [data, getBasket, customerBundleAndSaveCount],
  );

  const setBasket = useCallback(
    (basket: Basket | null) => {
      if (!basket) {
        getBasketDispatch({
          type: 'CLEAR_DATA',
        });
        return;
      }
      getBasketDispatch({
        type: 'FETCH_SUCCESS',
        payload: basket,
      });
      updatedAt.current = new Date();
      previousBnSCount.current = customerBundleAndSaveCount;
    },
    [customerBundleAndSaveCount, getBasketDispatch],
  );

  const value = useMemo(
    () => ({
      getBasket: getBasketAndUpdateTimestamp,
      getBasketState,
      setBasket,
    }),
    [getBasketAndUpdateTimestamp, getBasketState, setBasket],
  );

  return <BasketStateContext.Provider value={value}>{children}</BasketStateContext.Provider>;
};

export function useBasketState() {
  const context = useContext(BasketStateContext);
  if (context === undefined) {
    throw new Error('useBasketState must be used within a BasketProvider');
  }
  return context;
}
