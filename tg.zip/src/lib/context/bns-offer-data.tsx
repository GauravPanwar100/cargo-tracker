import React from 'react';
import { BnsOffer, BnsPromotion } from '@src/lib/api/types';

type BnsOfferProviderProps = {
  children: React.ReactNode;
  offers?: BnsOffer | null | undefined;
};

type getBnsDiscountFromPlanIdResponse = {
  bnsDiscount: number;
  bnsPromotion: BnsPromotion | null;
};

export type BnsOfferContext = {
  getBnsDiscountFromPlanId: (planCode: string) => getBnsDiscountFromPlanIdResponse;
};

const BnsOfferContext = React.createContext<BnsOfferContext>(undefined as unknown as BnsOfferContext);

export const BnsOfferProvider = ({ children, offers }: BnsOfferProviderProps) => {
  const getBnsDiscountFromPlanId = React.useCallback(
    (planCode: string): getBnsDiscountFromPlanIdResponse => {
      const bnsDiscount = offers?.plans.find((plan) => plan.planCode === planCode)?.bnsDiscount;
      return {
        bnsDiscount: bnsDiscount || 0,
        bnsPromotion: bnsDiscount && offers?.promotion?.promotionCode ? { ...offers.promotion } : null,
      };
    },
    [offers],
  );

  const value = React.useMemo<BnsOfferContext>(
    () => ({
      getBnsDiscountFromPlanId,
    }),
    [getBnsDiscountFromPlanId],
  );

  return <BnsOfferContext.Provider value={value}>{children}</BnsOfferContext.Provider>;
};

export default function useBnsOffer() {
  const context = React.useContext(BnsOfferContext);
  if (context === undefined) {
    throw new Error('useBnsOffer must be used within a BNSOfferProvider');
  }
  return context;
}
