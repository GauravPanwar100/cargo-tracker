import React, { useContext, useEffect, useRef } from 'react';

import { AbandonedCartData, NavigationResponse } from '../api/types';

interface HeaderDataProviderProps {
  children: React.ReactNode;
  navigation?: NavigationResponse;
}

const HeaderDataContext = React.createContext<NavigationResponse | undefined>(undefined);

export const HeaderDataProvider: React.FC<HeaderDataProviderProps> = ({ children, navigation }) => {
  return <HeaderDataContext.Provider value={navigation}>{children}</HeaderDataContext.Provider>;
};

export const useHeaderData = () => {
  const context = useContext(HeaderDataContext);
  if (context === undefined) {
    throw new Error('useHeaderData must be used within a HeaderDataProvider');
  }
  return context;
};

export const usePlanIconUrl = () => {
  const urlRef = useRef<string>('');
  useEffect(() => {
    const vhaHeader = document.getElementsByTagName('vha-header')[0];
    if (vhaHeader) {
      const abandonedCartData = JSON.parse(vhaHeader.getAttribute('abandonedcartdata') || '') as AbandonedCartData;
      urlRef.current = abandonedCartData.planIcon;
    }
  }, []);

  return urlRef.current;
};
