/* eslint-disable no-console */
import Router from 'next/router';
import React from 'react';
import {
  Auth0Client,
  Auth0ClientOptions,
  GetIdTokenClaimsOptions,
  GetTokenSilentlyOptions,
  GetTokenWithPopupOptions,
  IdToken,
  LogoutOptions,
  PopupConfigOptions,
  RedirectLoginOptions,
} from '@auth0/auth0-spa-js';
import * as qs from 'query-string';
import Cookies from 'universal-cookie';
import { getApiClient } from '@src/lib/api';
import { AccountType, ProductServiceType } from '@src/lib/api/types';
import { LocalStorageClient } from '@src/lib/storage';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { isSpaNavigable, safeRouterReplace } from '@src/lib/util/router';
import { removeAuthenticatedRoutePrefix } from '@src/lib/util/journey';
import { getReferrerURL, isRelativeUrl } from '@src/lib/util/url';

export interface User {
  name: string;
  nickname: string;
  picture: string;
  sub: string;
  /**
   * NOTE: This MSISDN is only to be used where the authenticated MSISDN is required. Most of the time, `activeMsisdn`
   * should be used instead which accounts for the user switching between services on their account.
   */
  'https://auth.vodafone.com.au/msisdn': string;
  'https://auth.vodafone.com.au/servicetype': ProductServiceType;
  'https://auth.vodafone.com.au/accounttype': AccountType;
  updated_at: string;
}

interface LoginParams extends RedirectLoginOptions {
  journey?: 'upgrade' | 'newservice' | 'login';
  deviceId?: string;
  nudgeReferrer?: string;
  cmp: string | undefined;
  DealerCode: string | undefined;
  AgentID: string | undefined;
}

export type AuthenticationState = {
  /**
   * Whilst the authentication state is loading, you cannot be certain whether the user is or isn't logged in
   */
  loading: boolean;
} & (
  | {
      isAuthenticated: false;
      user: undefined;
    }
  | {
      isAuthenticated: true;
      user: User;
    }
);

type AuthenticationContext = AuthenticationState & {
  login: (
    serviceType: Exclude<ServiceTypeValue, ServiceTypeValue.NewAcquisition>,
    params: LoginParams,
    journeyOrigin?: string,
    returnRoute?: string,
  ) => void;
  logout: (opts?: LogoutOptions) => void;
  getIdTokenClaims: () => undefined | Promise<IdToken | undefined>;
  getTokenSilently: (opts?: GetTokenSilentlyOptions | undefined) => undefined | Promise<string>;
  getTokenWithPopup: (
    getTokenWithPopupOptions?: GetTokenWithPopupOptions | undefined,
    config?: PopupConfigOptions | undefined,
  ) => undefined | Promise<string>;
};

export const Authentication = React.createContext<AuthenticationContext>(undefined as unknown as AuthenticationContext);

export const useAuthentication = () => React.useContext(Authentication);

type AuthenticationProviderProps = {
  children: React.ReactNode;
  options: Auth0ClientOptions;
};

export const ServiceTypeContext = React.createContext<
  [ServiceTypeValue | undefined, (value: ServiceTypeValue) => void]
>([
  undefined,
  () => {
    throw new Error('ServiceTypeContext must be used inside a Provider');
  },
]);

export const AuthenticationProvider = ({ children, options }: AuthenticationProviderProps) => {
  // This state is combined into a single `useState` so that co-dependent properties always change together
  // without requiring the use of `ReactDOM.unstable_batchedUpdates(callback)`
  const [state, setState] = React.useState<AuthenticationState>({
    loading: true,
    isAuthenticated: false,
    user: undefined,
  });
  const [auth0Client, setAuth0] = React.useState<Auth0Client | undefined>();
  const [_serviceType, _setServiceType] = React.useState<ServiceTypeValue | undefined>();

  const setServiceType = React.useCallback((value: ServiceTypeValue) => {
    LocalStorageClient.setServiceType(value);
    new Cookies().set('vfe.servicetype', value, { maxAge: 86400, path: '/' });
    _setServiceType(value);
  }, []);

  const setAuthentication = React.useCallback(
    async (_auth0Client?: Auth0Client) => {
      const ApiClient = getApiClient();
      if (!_auth0Client) {
        ApiClient.setGetAccessToken();
        setState((previous) => ({ ...previous, isAuthenticated: false, user: undefined }));
        return;
      }

      const auth = await _auth0Client.isAuthenticated();

      let auth0User: User | undefined;
      if (auth) {
        auth0User = await _auth0Client.getUser();
        const getAccessTokenSilently = () =>
          _auth0Client.getTokenSilently().then((result) => {
            if (result) {
              new Cookies().set('vfe.is.authenticated', 'true', { maxAge: 86400, path: '/' });
            }
            return result;
          });
        await getAccessTokenSilently();
        ApiClient.setGetAccessToken(getAccessTokenSilently);
        setServiceType(
          LocalStorageClient.getServiceType() === ServiceTypeValue.Upgrade
            ? ServiceTypeValue.Upgrade
            : ServiceTypeValue.AnotherService,
        );
      } else {
        setServiceType(ServiceTypeValue.NewAcquisition);
      }

      setState((previous) => ({ ...previous, isAuthenticated: auth, user: auth0User } as AuthenticationState));
    },
    [setServiceType],
  );

  // Initialise the Auth0 client
  React.useEffect(() => {
    const initAuth0 = async () => {
      try {
        const auth0FromHook = new Auth0Client(options);
        setAuth0(auth0FromHook);

        // If we're on the auth callback page when initialising, we have special logic which logs the user in
        // and sets the `serviceType`
        let redirectTo: string | undefined;
        if (window.location.pathname === '/auth/callback') {
          const params = new URLSearchParams(window.location.search);
          const route = params.get('route') || '/another-service';
          const returnPath = params.get('returnPath') || route;
          if (params.get('code') && params.get('state')) {
            await auth0FromHook.handleRedirectCallback();
            await Router.replace(window.location.pathname);

            // Clear any customerID that might have been set from a previous session
            LocalStorageClient.setCustomerID(null);

            // Update `serviceType` according to login intent
            setServiceType(
              params.get('serviceType') === ServiceTypeValue.Upgrade
                ? ServiceTypeValue.Upgrade
                : ServiceTypeValue.AnotherService,
            );

            // Set Cookie used for UX optimisation for early redirects on authorisation-protected routes
            new Cookies().set('vfe.is.authenticated', 'true', { maxAge: 86400, path: '/' });

            redirectTo = route;
          } else {
            // this prevents the app from getting stuck if the user lands on the callback page without authenticating
            redirectTo = removeAuthenticatedRoutePrefix(returnPath) || '/';
          }
        }

        await setAuthentication(auth0FromHook);

        // Need a hard redirect for some pages because we need to go to the AEM version in Cloudfront environments
        // rather than our SPA route
        if (redirectTo && isRelativeUrl(redirectTo) && !isSpaNavigable(redirectTo)) {
          window.location.href = redirectTo;
        } else if (redirectTo) {
          await safeRouterReplace(redirectTo);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setState((previous) => ({ ...previous, loading: false }));
      }
    };
    initAuth0();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = React.useCallback(
    async (
      serviceType: Exclude<ServiceTypeValue, ServiceTypeValue.NewAcquisition>,
      params: LoginParams,
      journeyOrigin?: string,
      returnRoute?: string,
    ) => {
      if (typeof auth0Client === 'undefined') {
        return;
      }

      const route = journeyOrigin || `${window.location.pathname}${window.location.search}`;
      const returnPath = returnRoute || getReferrerURL() || route;
      const loginParams: LoginParams = {
        journey: {
          [ServiceTypeValue.Upgrade]: 'upgrade' as const,
          [ServiceTypeValue.AnotherService]: 'newservice' as const,
        }[serviceType],
        deviceId: new Cookies().get('v_deviceid') || '',
        nudgeReferrer: window.location.pathname,
        ...params,
        redirect_uri: `${window.location.origin}/auth/callback?${qs.stringify({ returnPath, route, serviceType })}`,
      };
      try {
        await auth0Client.loginWithRedirect(loginParams);
      } catch (error) {
        console.error(error);
      }

      setAuthentication(auth0Client);
    },
    [auth0Client, setAuthentication],
  );

  const getIdTokenClaims = React.useCallback(
    (idTokenClaimsOptions?: GetIdTokenClaimsOptions | undefined) => {
      if (typeof auth0Client === 'undefined' || !state.user) {
        return undefined;
      }
      return auth0Client.getIdTokenClaims(idTokenClaimsOptions);
    },
    [auth0Client, state.user],
  );

  // Token example:
  // const { user, getTokenSilently } = useAuthentication();

  // React.useEffect(() => {
  //   const getCurrentService = async () => {
  //     const token = await getTokenSilently();
  //     const currentServiceData = await getApiClient().fetchCurrentServiceData(token);
  //     return currentServiceData;
  //   };
  //   if (user) {
  //     getCurrentService();
  //   }
  // }, [user]);

  const getTokenSilently = React.useCallback(
    (getTokenSilentlyOptions?: GetTokenSilentlyOptions | undefined) => {
      if (typeof auth0Client === 'undefined' || !state.user) {
        return undefined;
      }
      return auth0Client.getTokenSilently(getTokenSilentlyOptions).then((result) => {
        if (result) {
          new Cookies().set('vfe.is.authenticated', 'true', { maxAge: 86400, path: '/' });
        }
        return result;
      });
    },
    [auth0Client, state.user],
  );
  const getTokenWithPopup = React.useCallback(
    (getTokenWithPopupOptions?: GetTokenWithPopupOptions | undefined, config?: PopupConfigOptions | undefined) => {
      if (typeof auth0Client === 'undefined' || !state.user) {
        return undefined;
      }
      return auth0Client.getTokenWithPopup(getTokenWithPopupOptions, config);
    },
    [auth0Client, state.user],
  );
  const logout = React.useCallback(
    (logoutOptions?: LogoutOptions | undefined) => {
      if (typeof auth0Client === 'undefined') {
        return;
      }

      // Remove the encrypted customer ID from local storage on logout
      LocalStorageClient.clearCustomerID();

      setServiceType(ServiceTypeValue.NewAcquisition);
      new Cookies().remove('vfe.is.authenticated', { path: '/' });
      // The Auth0 client will perform a redirect (and consequent page load), so we don't need to update any local state
      auth0Client.logout(logoutOptions);
    },
    [auth0Client, setServiceType],
  );

  const authenticationContextValue = React.useMemo<AuthenticationContext>(
    () => ({
      ...state,
      login,
      getIdTokenClaims,
      getTokenSilently,
      getTokenWithPopup,
      logout,
    }),
    [getIdTokenClaims, getTokenSilently, getTokenWithPopup, login, logout, state],
  );

  const serviceTypeContextValue = React.useMemo<React.ContextType<typeof ServiceTypeContext>>(
    () => [_serviceType, setServiceType],
    [_serviceType, setServiceType],
  );

  return (
    <Authentication.Provider value={authenticationContextValue}>
      <ServiceTypeContext.Provider value={serviceTypeContextValue}>{children}</ServiceTypeContext.Provider>
    </Authentication.Provider>
  );
};
