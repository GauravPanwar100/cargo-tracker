import React, { createContext, useContext, useEffect, useReducer } from 'react';
import getDisplayName from 'react-display-name';
import { BasketRequestItem, CartItemType } from '@src/lib/api/types';

export type StickyCartAction =
  | { type: 'COMMIT_TO_HISTORY'; payload: HistoryActionPayload }
  | { type: 'RESET_STICKY_CART'; payload?: CartItemType[] }
  | { type: 'SET_CTA_LABEL'; payload: string }
  | { type: 'SET_IS_CTA_DISABLED'; payload: boolean }
  | { type: 'SET_IS_CTA_LOADING'; payload: boolean }
  | { type: 'SET_IS_ERROR'; payload: boolean }
  | { type: 'SET_ITEM_TYPES'; payload: CartItemType[] }
  | {
      type: 'SET_ON_CTA_CLICK';
      payload?: {
        ctaLabel?: string;
        onCtaClick?: React.MouseEventHandler<HTMLButtonElement>;
      };
    }
  | {
      type: 'SET_STICKY_CART';
      payload: {
        items: React.SetStateAction<BasketRequestItem[] | undefined>;
        history?: Omit<HistoryActionPayload, 'cart'>;
      };
    };

export type StickyCartDispatch = (action: StickyCartAction) => void;

export interface StickyCartState {
  ctaLabel: string;
  history: StickyCartHistory[];
  isCtaDisabled: boolean;
  isCtaLoading: boolean;
  isError: boolean;
  itemTypes: CartItemType[];
  onCtaClick: React.MouseEventHandler<HTMLButtonElement> | undefined;
  stickyCart: BasketRequestItem[];
}

export interface StickyCartHistory {
  configured?: BasketRequestItem[];
  original?: BasketRequestItem[];
}

type StickyCartHistoryType = keyof Pick<StickyCartHistory, 'configured' | 'original'>;

interface HistoryActionPayload {
  items?: BasketRequestItem[];
  historyType: StickyCartHistoryType;
  step: number;
}

interface StickyCartProviderProps {
  children: React.ReactNode;
  defaultState?: Partial<StickyCartState>;
}

export const StickyCartStateContext = createContext<StickyCartState | undefined>(undefined);
const StickyCartDispatchContext = createContext<StickyCartDispatch | undefined>(undefined);

export const defaultStickyCartState: StickyCartState = {
  ctaLabel: 'Continue',
  history: [],
  isCtaDisabled: false,
  isCtaLoading: false,
  isError: false,
  itemTypes: [],
  onCtaClick: undefined,
  stickyCart: [],
};

const updateHistory = (state: StickyCartState, payload: HistoryActionPayload): StickyCartState => {
  let history: StickyCartHistory[];

  const existingHistory: StickyCartHistory[] = [...state.history];
  const existingStep = existingHistory[payload.step];

  let isNextStep = false;
  if (existingHistory) {
    isNextStep = existingHistory.length === payload.step;
  }

  if (isNextStep) {
    // Is next step: Add history to the end of the existing array
    history = [
      ...existingHistory,
      {
        [payload.historyType]: payload.items,
      },
    ];
  } else {
    // Is an existing or current step. Remove the history for any future steps, and set up a history
    // item
    let updatedStep: StickyCartHistory = {
      [payload.historyType]: payload.items,
    };
    // If this is not the new original, then there will be an original already stored in this
    // history. Let's include it in the updated history we just created for this step.
    if (payload.historyType !== 'original') {
      updatedStep = {
        ...existingStep,
        ...updatedStep,
      };
    }
    // Slice everything up to this step (discarding the rest which are no longer valid as they are
    // for future journey steps and we are revisiting an earlier one), and add our updated step
    history = [...existingHistory.slice(0, payload.step), updatedStep];
  }

  return {
    ...state,
    history,
  };
};

function stickyCartReducer(state: StickyCartState, action: StickyCartAction): StickyCartState {
  switch (action.type) {
    case 'COMMIT_TO_HISTORY': {
      return updateHistory(state, action.payload);
    }
    case 'RESET_STICKY_CART': {
      return {
        ...defaultStickyCartState,
        itemTypes: action.payload || defaultStickyCartState.itemTypes,
      };
    }
    case 'SET_CTA_LABEL': {
      return {
        ...defaultStickyCartState,
        ctaLabel: action.payload,
      };
    }
    case 'SET_IS_CTA_DISABLED': {
      return {
        ...state,
        isCtaDisabled: action.payload,
      };
    }
    case 'SET_IS_CTA_LOADING': {
      return {
        ...state,
        isCtaLoading: action.payload,
      };
    }
    case 'SET_IS_ERROR': {
      return {
        ...state,
        isError: action.payload,
      };
    }
    case 'SET_ITEM_TYPES': {
      return {
        ...state,
        itemTypes: action.payload,
      };
    }
    case 'SET_ON_CTA_CLICK': {
      return {
        ...state,
        ctaLabel: action.payload?.ctaLabel || state.ctaLabel,
        onCtaClick: action.payload?.onCtaClick,
      };
    }
    case 'SET_STICKY_CART': {
      const newState = {
        ...state,
        stickyCart:
          typeof action.payload.items === 'function'
            ? action.payload.items(state.stickyCart) ?? []
            : action.payload.items ?? [],
      };

      if (action.payload.history) {
        return updateHistory(newState, {
          ...action.payload.history,
          items: newState.stickyCart,
        });
      }

      return newState;
    }
    default:
      throw new Error('Unhandled action type for stickyCartReducer');
  }
}

export const STICKY_CART_FOR_EVENT_TRACKING: { stickyCart: readonly BasketRequestItem[] } = { stickyCart: [] };

export const StickyCartProvider: React.FC<StickyCartProviderProps> = ({ children, defaultState }) => {
  const [state, dispatch] = useReducer(stickyCartReducer, {
    ...defaultStickyCartState,
    ...defaultState,
  });
  STICKY_CART_FOR_EVENT_TRACKING.stickyCart = state.stickyCart;

  return (
    <StickyCartStateContext.Provider value={state}>
      <StickyCartDispatchContext.Provider value={dispatch}>{children}</StickyCartDispatchContext.Provider>
    </StickyCartStateContext.Provider>
  );
};

export function withStickyCartProvider(defaultState?: StickyCartProviderProps['defaultState']) {
  return <P extends {}>(WrappedComponent: React.ComponentType<P>) =>
    Object.assign(
      (props: P) => (
        <StickyCartProvider defaultState={defaultState}>
          <WrappedComponent {...props} />
        </StickyCartProvider>
      ),
      { displayName: `withStickyCartProvider(${getDisplayName(WrappedComponent)})`, WrappedComponent },
    );
}

export function useStickyCartState() {
  const context = useContext(StickyCartStateContext);
  if (context === undefined) {
    throw new Error('useStickyCartState must be used within a StickyCartProvider');
  }
  return context;
}

export function useStickyCartDispatch() {
  const context = React.useContext(StickyCartDispatchContext);
  if (context === undefined) {
    throw new Error('useStickyCartDispatch must be used within a StickyCartProvider');
  }
  return context;
}

export function useStickyCart() {
  return [useStickyCartState(), useStickyCartDispatch()] as [StickyCartState, StickyCartDispatch];
}

interface CommitStickyCartToHistoryParams {
  // Is this a page like the mobile phones page where the user does not configure a new cart item
  // on this page? If so, we need to know so we can set both the original and the configured history
  // items at the same time
  isInterimStep?: boolean;
  restoreTo?: StickyCartHistoryType;
  step?: number;
  stickyCart?: BasketRequestItem[];
}
export function useCommitStickyCartToHistoryOnMount({
  isInterimStep,
  restoreTo = 'configured',
  step,
  stickyCart,
}: CommitStickyCartToHistoryParams) {
  const [state, dispatch] = useStickyCart();
  useEffect(() => {
    // Choice of allowing undefined here is intentional as some templates are sometimes part of
    // journeys and sometimes not. For example, the MobilePhonesTemplate is sometimes in the middle
    // of the PostpaidPlanAndMobilePhone journey, but is not part of the PostpaidMobilePhoneAndPlan
    // journey because the sticky cart is not yet visible on that page. Therefore, the
    // MobilePhonesTemplate sometimes has a step and sometimes does not, but we cannot conditionally
    // run hooks.
    if (typeof step === 'undefined') {
      return;
    }

    const existingHistory = state.history[step];
    // History is not present for this step. In this case, we want to set up the configured cart
    // key from the previous step as the original history for this step
    if (!existingHistory) {
      const items: BasketRequestItem[] = step === 0 ? [] : state.history[step - 1]?.configured ?? [];
      dispatch({
        type: 'SET_STICKY_CART',
        payload: {
          items,
          history: {
            historyType: 'original',
            step,
          },
        },
      });

      if (isInterimStep) {
        dispatch({
          type: 'COMMIT_TO_HISTORY',
          payload: {
            items: stickyCart,
            historyType: 'configured',
            step,
          },
        });
      }
      return;
    }

    // There is an existing history for this step. We should set it back as the current sticky cart
    // History does not need adjustment as the `original` is still the same
    if (existingHistory[restoreTo]) {
      dispatch({
        type: 'SET_STICKY_CART',
        payload: {
          items: existingHistory[restoreTo],
        },
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
