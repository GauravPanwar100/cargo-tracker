/* istanbul ignore file */
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import CI360 from '@src/lib/ci360/ci360';
import { FCID_NAME, Schema, ci360Schema } from '@src/lib/ci360/schema';
import Head from 'next/head';
import SasCustomEvent from '@src/components/core/SasTag';
import Logger from '@src/lib/logger/logger';
import { LocalStorageClient } from '@src/lib/storage';
import { ExpressJourneySlug } from '@src/lib/constants/express';
import { cloneDeep, isEmpty } from 'lodash';
import { MockBuilderForm } from '@src/components/sas/EUbuildMock/EUbuildMock';
import { EUReviewCustomerData, ExpressSubmitOrderResponse, OffersList } from '@src/lib/api/types';
import { DEFAULT_MUTATION_OBSERVER_OPTIONS, useMutationObserver } from '@src/lib/hooks/use-mutation-observer';
import { Flag, useFeatureFlag } from '@src/lib/context/feature-flags';
import { useRouter } from 'next/router';
import { stripQueryFromPath } from '@src/lib/util/url';
import { useAuthentication } from '@src/lib/context/authentication';

interface SasProviderProps {
  children: React.ReactNode;
  path: string;
}

export interface JourneyContext {
  creatives: Schema | undefined;
  euCustomerDetails: EUReviewCustomerData | undefined;
  euOfferEmail: ExpressSubmitOrderResponse['payload']['OfferEmailContent'] | undefined;
  errors: { name: string; message: string } | undefined;
  injectCreativesInSpots: (creatives: Schema | undefined) => void;
  updateCreatives: (mockedSchema: MockBuilderForm | {}) => void;
  updateEUCustomerDetails: (euCustomerDetails: EUReviewCustomerData) => void;
  updateEUOfferEmail: (euOfferEmail: OffersList[]) => void;
}

const SasStateContext = createContext<JourneyContext | undefined>(undefined);

export const SasProvider = ({ children, path }: SasProviderProps) => {
  const [creatives, setCreatives] = useState<Schema>();
  const [euCustomerDetails, setEUCustomerDetails] = useState<EUReviewCustomerData>();
  const [euOfferEmail, setEUOfferEmail] = useState<ExpressSubmitOrderResponse['payload']['OfferEmailContent']>();
  const [errors, setErrors] = useState<JourneyContext['errors']>();
  const mutationRef = React.useRef<HTMLDivElement>(null);
  const { loading, isAuthenticated, user } = useAuthentication();
  const [activeMsisdn, setActiveMsisdn] = React.useState<string | null>(null);
  const router = useRouter();
  const getPath = stripQueryFromPath(router?.asPath) || '';

  const disableCustomerIdentityEvent = !!useFeatureFlag(Flag.DISABLE_CUSTOMER_IDENTITY_EVENT).data;

  const updateEUCustomerDetails = useCallback((details: EUReviewCustomerData) => {
    setEUCustomerDetails(details);
  }, []);

  const updateEUOfferEmail = useCallback((emailArray: OffersList[]) => {
    setEUOfferEmail(
      emailArray.map((eachOffer) => {
        return {
          title: eachOffer?.title,
          description: eachOffer?.description,
          iconPath: eachOffer?.iconUrl || '',
        };
      }),
    );
  }, []);

  const injectCreativesInSpots = useCallback((contextCreatives: Schema | undefined) => {
    const journey = CI360.createJourneyParameter();
    if (contextCreatives && contextCreatives[journey.name]) {
      const creativeCategories = Object.keys(contextCreatives[journey.name]!);

      creativeCategories.forEach((categoryName: string) => {
        const arrayOfCreativeIds = Object.keys(contextCreatives[journey.name]![categoryName]!);

        arrayOfCreativeIds.forEach((id: string) => {
          const injectingDom: string = contextCreatives[journey.name]![categoryName]![id]!.template!;
          const existingDOM = document.querySelector(`#${id}`);

          if (existingDOM && injectingDom) {
            existingDOM.innerHTML = injectingDom;
          }
          return '';
        });
        return '';
      });
    } else {
      Logger.info('Error in Injecting creatives into Spots', { ucode: 'c33648b' });
    }
  }, []);

  const handleSASErrors = (schema: Schema | undefined) => {
    if (Object.keys(schema!).length === 0) {
      setErrors({
        name: 'no response',
        message: 'no response error',
      });
      return;
    }
    if (schema?.express?.journey!.data_err_flag!.value === 'Y') {
      setErrors({
        name: 'error flag is Y',
        message: schema.express!.journey!.data_err_reas!.value ?? 'undefined error',
      });
    } else {
      setErrors(undefined);
    }
  };

  const updateCreatives = useCallback(
    (mockedSchema: MockBuilderForm) => {
      const journey = CI360.createJourneyParameter();
      const newSchema = !isEmpty(mockedSchema) ? cloneDeep(creatives) : {};

      if (newSchema![journey.name]) {
        Object.keys(newSchema![journey.name]!).forEach((category) => {
          Object.keys(mockedSchema).forEach((key) => {
            if (newSchema![journey.name]![category]![key] && mockedSchema && key) {
              const newValue = mockedSchema[key];
              const newTemplate = `<span id="${key}" data-value="${mockedSchema[key]}">${mockedSchema[key]}</span>`;
              newSchema![journey.name]![category]![key] = {
                value: newValue?.toString(),
                template: CI360.validateTemplateWithType(
                  newTemplate,
                  newSchema![journey.name]![category || '']![key]?.fieldType || '',
                ),
              };
            }
          });
        });
      }

      setCreatives(newSchema);
      handleSASErrors(newSchema);
    },
    [creatives],
  );

  const getCreatives = useCallback(async () => {
    const journey = CI360.createJourneyParameter();

    switch (window.location.pathname) {
      // SAS will populate creatives on landing page(s)
      case `/express/${ExpressJourneySlug.PHONE_AND_PLAN}`:
      case `/express/${ExpressJourneySlug.SIMO}`:
      case `/express/${ExpressJourneySlug.RPC}`: {
        if (creatives) return;
        const response = await CI360.getCreativesDefinitions();
        if (
          response?.express?.journey?.data_err_flag?.value === 'Y' &&
          response?.express?.journey?.data_err_reas?.value === FCID_NAME
        ) {
          setCreatives(undefined);
          setTimeout(() => {
            getCreatives();
          }, 1000);
        } else {
          setCreatives(response);
          handleSASErrors(response);
        }
        return;
      }
      default:
      // do nothing
    }

    // if the journey is defined in the schema
    // populate from local storage if available
    if (journey.name && Object.keys(ci360Schema).indexOf(journey.name) > -1) {
      const creativesFromStorage = LocalStorageClient.getSASContext();
      if (creativesFromStorage) {
        setCreatives(creativesFromStorage);
      }
      // TODO: Do we throw an error?
    }
    // commenting this since it throws error during running test and hangs it indefinitely
    // else {
    //   setCreatives({});
    // }
  }, [creatives]);

  /**
   * SAS script will update the div style in
   * `SaSTag` to have `visibility: visible;`
   * after loading it with creatives from SAS,
   * listen to `attributes` mutation type to
   * invoke the callback to build creatives
   */
  const mutationCallback = useCallback(
    (mutationList: MutationRecord[]) => {
      for (const mutation of mutationList) {
        if (mutation.type === 'attributes') {
          getCreatives();
        }
      }
    },
    [getCreatives],
  );

  // register mutation observer to detect style changes in SasTags
  useMutationObserver(mutationRef, mutationCallback, {
    ...DEFAULT_MUTATION_OBSERVER_OPTIONS,
    subtree: true,
    attributeFilter: ['style'],
  });

  useEffect(() => {
    getCreatives();
  }, [getCreatives]);

  useEffect(() => {
    if (!loading && isAuthenticated && user && !disableCustomerIdentityEvent) {
      const msisdnValue = user['https://auth.vodafone.com.au/msisdn'];
      setActiveMsisdn(msisdnValue);
      window.customerMsisdn = msisdnValue;
      // Adding a timeout of 1s to wait for the ot-all.min.js to load
      // If not window.ci360 returns undefined because of which the track event is not getting fired
      setTimeout(() => {
        CI360.sendCustomerIdentityTrackEvent(msisdnValue);
      }, 1000);
    }
  }, [loading, isAuthenticated, user, disableCustomerIdentityEvent]);

  const value: JourneyContext = useMemo(
    () => ({
      creatives,
      errors,
      injectCreativesInSpots,
      updateCreatives,
      euCustomerDetails,
      updateEUCustomerDetails,
      euOfferEmail,
      updateEUOfferEmail,
    }),
    [
      creatives,
      errors,
      injectCreativesInSpots,
      updateCreatives,
      euCustomerDetails,
      updateEUCustomerDetails,
      euOfferEmail,
      updateEUOfferEmail,
    ],
  );

  return (
    <>
      {!path.includes('iframe') && (
        <Head>
          {/* If it is logged in journey we load the customer identity tracking event */}
          {['/upgrade', '/another-service', '/cart'].includes(getPath) &&
          activeMsisdn &&
          !disableCustomerIdentityEvent ? (
            <>
              <script
                type="text/javascript"
                id="identity-event"
                /* eslint-disable-next-line react/no-danger */
                dangerouslySetInnerHTML={{
                  __html: `(function(ci,a){
                     var ef=window[ci]=function(){
                       return ef.q.push(arguments);
                     };
                     ef.q=[];ef.a=a||{};
                   })('ci360',{
                   identity:{
                     source:'jsvar', 
                     type:'customer_id', 
                     name:'customerMsisdn'}
                   });`,
                }}
              />
              <script
                type="text/javascript"
                src="https://www.vodafone.com.au/js/ot-all.min.js"
                data-efname="ci360"
                data-a={`${process.env.SAS_TENANT_ID}`}
                id="ob-script-async"
                async={true}
              />
            </>
          ) : (
            <>
              {/* We load the HID event for EU pages */}
              {getPath.startsWith('/express') && (
                <script
                  type="text/javascript"
                  /* eslint-disable-next-line react/no-danger */
                  dangerouslySetInnerHTML={{
                    __html: `(function(ci,a){
                    var ef=window[ci]=function(){
                        return ef.q.push(arguments);
                    };
                    ef.q=[];ef.a=a||{};
                })('ci360',{
                  identity:{
                    source:'url', 
                    type:'login_id', 
                    name:'hid'}
                });`,
                  }}
                />
              )}
              {/* The below condition is added to prevent ot-all.min.js to load during auth redirection which blocks the
              customer identity tracking event. Also if it is unauthenticated version of cart page we just load the
              CI360 script */}
              {!getPath.startsWith('/auth') &&
                ((getPath === '/cart' && isAuthenticated) ||
                ['/upgrade', '/another-service'].includes(getPath) ? null : (
                  <script
                    type="text/javascript"
                    src="https://www.vodafone.com.au/js/ot-all.min.js"
                    data-efname="ci360"
                    data-a={`${process.env.SAS_TENANT_ID}`}
                    id="ob-script-async"
                    async={true}
                  />
                ))}
            </>
          )}
        </Head>
      )}
      <SasCustomEvent ref={mutationRef} />
      <SasStateContext.Provider value={value}>{children}</SasStateContext.Provider>
    </>
  );
};

export function useSasData() {
  const context = useContext(SasStateContext);
  if (context === undefined) {
    throw new Error('SasState must be used within a SasProvider');
  }
  return context;
}
