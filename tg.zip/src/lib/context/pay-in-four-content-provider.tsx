import React from 'react';

export interface PayIn4Content {
  showPayIn4PromoContent: boolean;
  payIn4PromoContentThreshold: number;
}

interface PayIn4ContentProviderProps {
  children: React.ReactNode;
  payIn4Content: PayIn4Content;
}

export interface PayIn4ContentContext {
  getPayIn4Content: () => PayIn4Content;
}

const PayIn4ContentContext = React.createContext<PayIn4ContentContext | undefined>(undefined);

export const PayIn4ContentProvider = ({ children, payIn4Content }: PayIn4ContentProviderProps) => {
  const getPayIn4Content = React.useCallback(
    () => ({
      showPayIn4PromoContent: payIn4Content.showPayIn4PromoContent,
      payIn4PromoContentThreshold: payIn4Content.payIn4PromoContentThreshold,
    }),
    [payIn4Content.showPayIn4PromoContent, payIn4Content.payIn4PromoContentThreshold],
  );

  const value = React.useMemo<PayIn4ContentContext>(
    () => ({
      getPayIn4Content,
    }),
    [getPayIn4Content],
  );

  return <PayIn4ContentContext.Provider value={value}>{children}</PayIn4ContentContext.Provider>;
};

export default function usePayIn4Content() {
  const context = React.useContext(PayIn4ContentContext);
  if (context === undefined) {
    throw new Error('usePayIn4Content must be used within a PayIn4ContentProvider');
  }
  return context;
}
