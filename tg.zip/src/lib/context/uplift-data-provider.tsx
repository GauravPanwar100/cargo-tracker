import React from 'react';

export interface UpliftDataProviderProps {
  upliftEnabled: boolean;
  children: React.ReactNode;
}

const UpliftDataContext = React.createContext<boolean>(false);

export const UpliftDataProvider = ({ children, upliftEnabled }: UpliftDataProviderProps) => {
  const value = upliftEnabled;
  return <UpliftDataContext.Provider value={value}>{children}</UpliftDataContext.Provider>;
};

export const useUpliftDataContent = () => {
  const context = React.useContext(UpliftDataContext);
  if (context === undefined) {
    throw new Error('useUpliftDataContent must be used within a UpliftDataProvider.');
  }
  return context;
};
