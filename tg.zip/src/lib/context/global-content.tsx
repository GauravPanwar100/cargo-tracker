import React, { useContext, useState } from 'react';

import { getApiClient } from '../api';
import {
  PreviouslyViewedResponse,
  PromotionalCampaignsContentResponse,
  StudentValidationContentResponse,
} from '../api/types';

interface GlobalContentProviderProps {
  children: React.ReactNode;
}

const GlobalContentDataContext = React.createContext<GlobalContentContext | undefined>(undefined);

export const GlobalContentDataProvider: React.FC<GlobalContentProviderProps> = ({ children }) => {
  const [globalContent, setGlobalContent] = useState<GlobalContent>({});
  const [state, setState] = useState<GlobalContentState>({ loading: true });

  React.useEffect(() => {
    const keys = Object.keys(FetchFnMappings) as ContentKeys[];
    const tempContent: GlobalContent = {};

    keys.forEach(async (key) => {
      const fetchFn = FetchFnMappings[key];
      const data = await fetchFn();
      tempContent[key] = data;
    });
    setState({ loading: false });
    setGlobalContent(tempContent);
  }, []);

  const globalContentValue = React.useMemo<GlobalContentContext>(
    () => ({
      ...state,
      content: globalContent,
    }),
    [globalContent, state],
  );

  return <GlobalContentDataContext.Provider value={globalContentValue}>{children}</GlobalContentDataContext.Provider>;
};

export const useGlobalContent = () => {
  const context = useContext(GlobalContentDataContext);
  if (context === undefined) {
    throw new Error('useGlobalContent must be used within a GlobalContentDataProvider');
  }
  return context;
};

// utility function to extract single content from aggregated global content by the content key
export function useSingleGlobalContent<T extends GlobalContentResponse>(key: ContentKeys): T {
  const { content } = useGlobalContent();
  return content[key] as T;
}

export const usePreviouslyViewedContent = () => {
  return useSingleGlobalContent<PreviouslyViewedResponse>(ContentKeys.PREVIOUSLY_VIEWED);
};

export const useStudentValidationContent = () => {
  return useSingleGlobalContent<StudentValidationContentResponse>(ContentKeys.STUDENT_VALIDATION);
};

export const usePromotionalCampaignsContent = () => {
  return useSingleGlobalContent<PromotionalCampaignsContentResponse>(ContentKeys.PROMOTIONAL_CAMPAIGNS);
};

// add new global content keys here
export enum ContentKeys {
  PREVIOUSLY_VIEWED = 'previously-viewed',
  STUDENT_VALIDATION = 'student-validation',
  PROMOTIONAL_CAMPAIGNS = 'promotional-campaigns',
}

// add new global content keys and fetch function mappings here
const FetchFnMappings: { [key in ContentKeys]: NullaryFunction<GlobalContentResponse> } = {
  [ContentKeys.PREVIOUSLY_VIEWED]: getApiClient().fetchPreviouslyViewedContent,
  [ContentKeys.STUDENT_VALIDATION]: getApiClient().fetchStudentOfferContent,
  [ContentKeys.PROMOTIONAL_CAMPAIGNS]: getApiClient().fetchPromotionalCampaigns,
};

type GlobalContent = {
  [key in ContentKeys]?: GlobalContentResponse;
};

type GlobalContentState = {
  loading: boolean;
};

type GlobalContentContext = {
  content: GlobalContent;
  loading: boolean;
};

type NullaryFunction<ReturnType> = () => ReturnType | PromiseLike<ReturnType>;

// to add new type of GlobalContentResponse, append the new type with the '|' e.g.
// type GlobalContentResponse = PreviouslyViewedResponse | OtherTypeOfResponse;
type GlobalContentResponse =
  | PreviouslyViewedResponse
  | StudentValidationContentResponse
  | PromotionalCampaignsContentResponse;
