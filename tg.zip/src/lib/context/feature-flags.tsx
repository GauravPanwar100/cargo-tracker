import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef } from 'react';
import FeatureClient from '@src/lib/omega-flagger/client-library';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import { Environment, FeatureToggle } from '@src/lib/omega-flagger/client-library/types';
import { MaintenancePage } from '@src/lib/util/error';
import { PlanEndpoint } from '@src/lib/api/types';

/**
 * Feature flags configured in the Configuration Management Portal (https://config.npe.my.aws.vodafone.com.au).
 * A feature flag holds a boolean value.
 * The featureId of new feature flags should be added here.
 */
export enum Flag {
  DISABLE_4G_HOME_WIRELESS_JOURNEY_BUSINESS = '4G-HOME-WIRELESS.BUSINESS.DISABLED',
  DISABLE_4G_HOME_WIRELESS_JOURNEY_OPERATIONAL = '4G-HOME-WIRELESS.OPERATIONAL.DISABLED',
  DISABLE_5G_HOME_WIRELESS_JOURNEY_BUSINESS = '5G-HOME-WIRELESS.BUSINESS.DISABLED',
  DISABLE_5G_HOME_WIRELESS_JOURNEY_OPERATIONAL = '5G-HOME-WIRELESS.OPERATIONAL.DISABLED',
  DISABLE_ACN = 'ACN.DISABLED',
  DISABLE_ALL_JOURNEYS_BUSINESS = 'ALL-JOURNEYS.BUSINESS.DISABLED',
  DISABLE_ALL_JOURNEYS_OPERATIONAL = 'ALL-JOURNEYS.OPERATIONAL.DISABLED',
  DISABLE_ANOTHER_SERVICE_JOURNEY_BUSINESS = 'ANOTHER-SERVICE.BUSINESS.DISABLED',
  DISABLE_ANOTHER_SERVICE_JOURNEY_OPERATIONAL = 'ANOTHER-SERVICE.OPERATIONAL.DISABLED',
  DISABLE_ASD_PRESENTATION_UPLIFT = 'DISABLE_ASD_PRESENTATION_UPLIFT',
  DISABLE_CUSTOMER_IDENTITY_EVENT = 'CUSTOMER-IDENTITY-EVENT.DISABLED',
  DISABLE_EXPRESS_UPGRADES_PHONE_PLAN = 'EU-PHONE-PLAN.DISABLED',
  DISABLE_EXPRESS_UPGRADES_REQUEST_PLAN_CHANGE = 'EU-RPC.DISABLED',
  DISABLE_EXPRESS_UPGRADES_SIM_ONLY = 'EU-SIMO.DISABLED',
  DISABLE_INSURANCE = 'INSURANCE.DISABLED',
  DISABLE_MOBILE_PHONES_JOURNEY_BUSINESS = 'MOBILE-PHONES.BUSINESS.DISABLED',
  DISABLE_MOBILE_PHONES_JOURNEY_DEVICE_STEP_STICKY_CART = 'MOBILE-PHONES-JOURNEY-DEVICE-STEP-STICKY-CART.DISABLED',
  DISABLE_MOBILE_PHONES_JOURNEY_OPERATIONAL = 'MOBILE-PHONES.OPERATIONAL.DISABLED',
  DISABLE_MAKE_PAYMENT_JOURNEY_BUSINESS = 'MAKE-PAYMENT.BUSINESS.DISABLED',
  DISABLE_MAKE_PAYMENT_JOURNEY_OPERATIONAL = 'MAKE-PAYMENT.OPERATIONAL.DISABLED',
  DISABLE_NBN_HIGH_SPEED_PLANS = 'NBN.HIGH-SPEED-PLANS.DISABLED',
  DISABLE_NBN_JOURNEY_BUSINESS = 'NBN.BUSINESS.DISABLED',
  DISABLE_NBN_JOURNEY_OPERATIONAL = 'NBN.OPERATIONAL.DISABLED',
  DISABLE_NBN_PLANLISTING_UPLIFT = 'NBN.PLANLISTING.UPLIFT.DISABLED',
  DISABLE_PLANS_ALWAYS_ON_SIMO_BUSINESS = 'PLANS-ALWAYS-ON-SIMO.BUSINESS.DISABLED',
  DISABLE_PLANS_ALWAYS_ON_SIMO_OPERATIONAL = 'PLANS-ALWAYS-ON-SIMO.OPERATIONAL.DISABLED',
  DISABLE_PLANS_SIM_ONLY_JOURNEY_BUSINESS = 'PLANS-SIM-ONLY.BUSINESS.DISABLED',
  DISABLE_PLANS_SIM_ONLY_JOURNEY_OPERATIONAL = 'PLANS-SIM-ONLY.OPERATIONAL.DISABLED',
  DISABLE_PREPAID_HIDE_WAS = 'PREPAID_HIDE_WAS.DISABLED',
  DISABLE_PREPAID_PLANS_JOURNEY_BUSINESS = 'PREPAID-PLANS.BUSINESS.DISABLED',
  DISABLE_PREPAID_PLANS_JOURNEY_OPERATIONAL = 'PREPAID-PLANS.OPERATIONAL.DISABLED',
  DISABLE_PREPAID_PLANS_PAY_AND_GO_JOURNEY_BUSINESS = 'PREPAID-PLANS-PAY-AND-GO.BUSINESS.DISABLED',
  DISABLE_PREPAID_PLANS_PAY_AND_GO_JOURNEY_OPERATIONAL = 'PREPAID-PLANS-PAY-AND-GO.OPERATIONAL.DISABLED',
  DISABLE_PREVIOUSLY_VIEWED_COMPONENT = 'PREVIOUSLY-VIEWED-COMPONENT.DISABLED',
  DISABLE_RECAPTCHA = 'RECAPTCHA.DISABLED',
  DISABLE_RELATED_PRODUCTS_NAV = 'RELATED-DEVICES-NAV.DISABLED',
  DISABLE_SIM_SELECTION = 'SIM-SELECTION.DISABLED',
  DISABLE_STUCK_CART = 'STUCK-CART.DISABLED',
  DISABLE_SWAP_AND_GO = 'SWAP-AND-GO.BUSINESS.DISABLED',
  DISABLE_TABLETS_JOURNEY_BUSINESS = 'TABLETS.BUSINESS.DISABLED',
  DISABLE_TABLETS_JOURNEY_DEVICE_STEP_STICKY_CART = 'TABLETS-JOURNEY-DEVICE-STEP-STICKY-CART.DISABLED',
  DISABLE_TABLETS_JOURNEY_OPERATIONAL = 'TABLETS.OPERATIONAL.DISABLED',
  DISABLE_TABLETS_SIM_ONLY_JOURNEY_BUSINESS = 'TABLETS-SIM-ONLY.BUSINESS.DISABLED',
  DISABLE_TABLETS_SIM_ONLY_JOURNEY_OPERATIONAL = 'TABLETS-SIM-ONLY.OPERATIONAL.DISABLED',
  DISABLE_MBB_MODEM_SIM_ONLY_JOURNEY_BUSINESS = 'MBB-MODEM-SIM-ONLY.BUSINESS.DISABLED',
  DISABLE_MBB_MODEM_SIM_ONLY_JOURNEY_OPERATIONAL = 'MBB-MODEM-SIM-ONLY.OPERATIONAL.DISABLED',
  DISABLE_MBB_MODEMS_JOURNEY_BUSINESS = 'MBB-MODEMS-JOURNEY.BUSINESS.DISABLED',
  DISABLE_MBB_MODEMS_JOURNEY_OPERATIONAL = 'MBB-MODEMS-JOURNEY.OPERATIONAL.DISABLED',
  DISABLE_TWO_WAY_SMS = 'TWO-WAY-SMS.DISABLED',
  DISABLE_EU_TWO_WAY_SMS = 'EU-TWO-WAY-SMS.DISABLED',
  DISABLE_UPGRADE_JOURNEY_BUSINESS = 'UPGRADE.BUSINESS.DISABLED',
  DISABLE_UPGRADE_JOURNEY_OPERATIONAL = 'UPGRADE.OPERATIONAL.DISABLED',
  IAM_MAINTENANCE_MODE = 'MAINTENANCEMODE',
  DISABLE_3DS_PREPAID = '3DS-PREPAID.DISABLED',
  DISABLE_3DS_POSTPAID = '3DS-POSTPAID.DISABLED',
  STUDENT_OFFER = 'STUDENT-OFFER.DISABLED',
  DISABLE_TREE_ESIM_ONBOARDING = 'TREE-ESIM-ONBOARDING.DISABLED',
  TRADE_IN_DEVICE = 'TRADE-IN-DEVICE.DISABLED',
  DISABLE_SAMSUNG = 'SAMSUNG.DISABLED',
  DISABLE_EU_PLAN_REFRESH = 'EU-PLAN-REFRESH.DISABLED',
  DISABLE_MAX_SPEED = 'MAX_SPEED.DISABLED',
  DISABLE_SMART_WATCH_JOURNEY_BUSINESS = 'SMART-WATCHES.BUSINESS.DISABLED',
  DISABLE_SMART_WATCH_JOURNEY_OPERATIONAL = 'SMART-WATCHES.OPERATIONAL.DISABLED',
  DISABLE_SMART_WATCH_JOURNEY_DEVICE_STEP_STICKY_CART = 'SMART-WATCHES-JOURNEY-DEVICE-STEP-STICKY-CART.DISABLED',
  DISABLE_PREPAID_DEVICES_JOURNEY_BUSINESS = '',
  DISABLE_PREPAID_DEVICES_JOURNEY_OPERATIONAL = '',
  DISABLE_PREPAID_DEVICES_JOURNEY_DEVICE_STEP_STICKY_CART = '',
  DISABLE_SIMO_PAGE_UPLIFT = 'SIMO-PAGE-UPLIFT.DISABLED',
  DISABLE_HANDSET_PLANS_PAGE_UPLIFT = 'HANDSET-PLANS-PAGE-UPLIFT.DISABLED',
  DISABLE_CLICK_AND_COLLECT_FEATURE = 'CLICK_AND_COLLECT_FEATURE.DISABLED',
  DISABLE_REFER_A_FRIEND = 'REFER-A-FRIEND.DISABLED',
  DISABLE_NEW_TRADE_IN_DEVICE = 'NEW-TRADE-IN-DEVICE.DISABLED',
}

export interface RedirectFlag {
  businessRedirect: Flag;
  operationalRedirect: Flag;
}

/**
 * Redirect feature flags that gets passed to the page templates
 * Page templates using redirect flags: AdditionalServices, Device, Devices, Extras, Nbn, Plans, Upgrades
 * New journeys should have business and operational redirect flags added here
 */
export const redirectFlags = {
  ANOTHER_SERVICE: {
    businessRedirect: Flag.DISABLE_ANOTHER_SERVICE_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_ANOTHER_SERVICE_JOURNEY_OPERATIONAL,
  },
  MOBILE_PHONES: {
    businessRedirect: Flag.DISABLE_MOBILE_PHONES_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_MOBILE_PHONES_JOURNEY_OPERATIONAL,
  },
  MAKE_PAYMENT: {
    businessRedirect: Flag.DISABLE_MAKE_PAYMENT_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_MAKE_PAYMENT_JOURNEY_OPERATIONAL,
  },
  NBN: {
    businessRedirect: Flag.DISABLE_NBN_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_NBN_JOURNEY_OPERATIONAL,
  },
  PLANS_ALWAYS_ON_SIMO: {
    businessRedirect: Flag.DISABLE_PLANS_ALWAYS_ON_SIMO_BUSINESS,
    operationalRedirect: Flag.DISABLE_PLANS_ALWAYS_ON_SIMO_OPERATIONAL,
  },
  PLANS_SIM_ONLY: {
    businessRedirect: Flag.DISABLE_PLANS_SIM_ONLY_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_PLANS_SIM_ONLY_JOURNEY_OPERATIONAL,
  },
  PREPAID_PLANS: {
    businessRedirect: Flag.DISABLE_PREPAID_PLANS_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_PREPAID_PLANS_JOURNEY_OPERATIONAL,
  },
  PREPAID_PLANS_PAY_AND_GO: {
    businessRedirect: Flag.DISABLE_PREPAID_PLANS_PAY_AND_GO_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_PREPAID_PLANS_PAY_AND_GO_JOURNEY_OPERATIONAL,
  },
  TABLETS: {
    businessRedirect: Flag.DISABLE_TABLETS_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_TABLETS_JOURNEY_OPERATIONAL,
  },
  TABLETS_SIM_ONLY: {
    businessRedirect: Flag.DISABLE_TABLETS_SIM_ONLY_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_TABLETS_SIM_ONLY_JOURNEY_OPERATIONAL,
  },
  UPGRADE: {
    businessRedirect: Flag.DISABLE_UPGRADE_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_UPGRADE_JOURNEY_OPERATIONAL,
  },
  HOME_WIRELESS_4G: {
    businessRedirect: Flag.DISABLE_4G_HOME_WIRELESS_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_4G_HOME_WIRELESS_JOURNEY_OPERATIONAL,
  },
  HOME_WIRELESS_5G: {
    businessRedirect: Flag.DISABLE_5G_HOME_WIRELESS_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_5G_HOME_WIRELESS_JOURNEY_OPERATIONAL,
  },
  SMARTWATCH: {
    businessRedirect: Flag.DISABLE_SMART_WATCH_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_SMART_WATCH_JOURNEY_OPERATIONAL,
  },
  PREPAID_MOBILE_PHONE: {
    businessRedirect: Flag.DISABLE_PREPAID_DEVICES_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_PREPAID_DEVICES_JOURNEY_OPERATIONAL,
  },
  POSTPAID_MBB_MODEM_SIMO: {
    businessRedirect: Flag.DISABLE_MBB_MODEM_SIM_ONLY_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_MBB_MODEM_SIM_ONLY_JOURNEY_OPERATIONAL,
  },
  MBB_MODEMS: {
    businessRedirect: Flag.DISABLE_MBB_MODEMS_JOURNEY_BUSINESS,
    operationalRedirect: Flag.DISABLE_MBB_MODEMS_JOURNEY_OPERATIONAL,
  },
};

/**
 * Configs configured in the Configuration Management Portal (https://config.npe.my.aws.vodafone.com.au).
 * A config holds a string value.
 * The featureId of new configs should be added here.
 */
export enum Config {
  TEST = 'config1',
}

export const VFE_OMEGA_ENVIRONMENT: Environment = {
  appVersion: '1.0',
  configVersion: '1.0',
  application: 'Digital First',
  platform: process.env.OMEGA_PLATFORM || 'DEV',
  env: 'DEFAULT',
  toggleAPIDomain: process.env.OMEGA_DOMAIN || 'https://config.npe.my.aws.vodafone.com.au/v1',
  configAPIDomain: process.env.OMEGA_DOMAIN || 'https://config.npe.my.aws.vodafone.com.au/v1',
  apiKey: process.env.OMEGA_API_KEY || 'avXBADNrnO1fdVWl5sHKea7TQyzDs8qj3HgJoJvS',
  isLibCacheRequired: true,
  libCacheTTL: 30,
  asyncCallAttempts: 0,
};

export const IAM_OMEGA_ENVIRONMENT: Environment = {
  appVersion: '1.0',
  configVersion: '1.0',
  application: 'Digital First',
  platform: 'IAM',
  env: process.env.IAM_OMEGA_ENV || 'TEST01_SHOP',
  toggleAPIDomain: process.env.IAM_OMEGA_DOMAIN || 'https://dfmvshcme4.execute-api.ap-southeast-2.amazonaws.com/v1',
  configAPIDomain: process.env.IAM_OMEGA_DOMAIN || 'https://dfmvshcme4.execute-api.ap-southeast-2.amazonaws.com/v1',
  apiKey: process.env.IAM_OMEGA_API_KEY || 'VdvPHWBcVf2cATsKXuB875bml0xqgxBJ5dsOAxKq',
  isLibCacheRequired: true,
  libCacheTTL: 30,
  asyncCallAttempts: 0,
};

export function getFullFeatureId(featureId: Flag | Config, environment: Environment): string {
  return `${environment.env}-${environment.appVersion}-${environment.configVersion}-${featureId}`;
}

interface FeatureFlags {
  getAllFlags: () => Promise<FeatureToggle[]>;
  getFlag: (featureId: Flag) => Promise<boolean>;
  getConfig: (featureId: Config) => Promise<string>;
}

interface FeatureFlagsEnvironmentProviderProps {
  children: React.ReactNode;
  environment?: Environment;
}

const FeatureFlagsContext = createContext<Map<Environment, FeatureFlags> | undefined>(undefined);

/*
 * Provides React context to get a single feature flag, or a single config, using the Omega Flagger client library
 */
export const FeatureFlagsEnvironmentProvider: React.FC<FeatureFlagsEnvironmentProviderProps> = ({
  children,
  environment = VFE_OMEGA_ENVIRONMENT,
}) => {
  // The useRef hook persists the omega FeatureClient for the full lifetime of the component
  // By persisting the omega client, the client's in-memory caching works as expected – saving us network calls
  // https://reactjs.org/docs/hooks-reference.html#useref
  const omega = useRef(new FeatureClient());
  omega.current.setEnvironment(environment);

  /**
   * Returns a list of all feature flags, checks cache first
   */
  const getAllFlags = useCallback(() => {
    return omega.current.getAllFeatureToggles();
  }, []);

  /**
   * Returns boolean result for a single feature flag, checks cache first
   */
  const getFlag = useCallback(
    (featureId: Flag) => {
      return omega.current.getFeatureToggle(getFullFeatureId(featureId, environment));
    },
    [environment],
  );

  /**
   * Returns string result for a single config flag, checks cache first
   */
  const getConfig = useCallback(
    (featureId: Config) => {
      return omega.current.getConfigToggle(getFullFeatureId(featureId, environment));
    },
    [environment],
  );

  const parentContext = useContext(FeatureFlagsContext);

  const value = useMemo(
    () => new Map(parentContext ?? []).set(environment, { getAllFlags, getConfig, getFlag }),
    [environment, getAllFlags, getConfig, getFlag, parentContext],
  );

  return <FeatureFlagsContext.Provider value={value}>{children}</FeatureFlagsContext.Provider>;
};

export const FeatureFlagsProvider = ({ children }: { children: React.ReactNode }) => (
  <FeatureFlagsEnvironmentProvider environment={VFE_OMEGA_ENVIRONMENT}>
    <FeatureFlagsEnvironmentProvider environment={IAM_OMEGA_ENVIRONMENT}>{children}</FeatureFlagsEnvironmentProvider>
  </FeatureFlagsEnvironmentProvider>
);

export function useFeatureFlags(environment = VFE_OMEGA_ENVIRONMENT) {
  const context = useContext(FeatureFlagsContext);
  const omega = context?.get(environment);
  if (omega === undefined) {
    throw new Error('useFeatureFlags must be used within a FeatureFlagsProvider with a matching environment');
  }
  return omega;
}

/*
 * Redirect the customer to a maintenance page if the feature flag returns true
 */
export function useRedirectFeatureFlag({
  flag,
  redirect,
  overrideRedirect,
}: {
  flag: Flag;
  redirect: MaintenancePage;
  overrideRedirect?: boolean;
}) {
  const omega = useFeatureFlags(VFE_OMEGA_ENVIRONMENT);
  const [featureFlag, getFeatureFlag] = useImperativeData(omega.getFlag);

  // In useEffect so that we're not making a call to omega on the server
  useEffect(() => {
    getFeatureFlag(flag);
  }, [flag, getFeatureFlag]);

  // In useEffect so that we're not trying to set window.location on the server
  useEffect(() => {
    // Redirects user if returned isEnabled boolean in data is true
    // AND we have not used the override (as used in AdditionalServicesTitleSection)
    if (featureFlag.data && !overrideRedirect) {
      // Using window.location.replace as the maintenance page is an AEM page, external to VFE
      window.location.replace(window.location.origin + redirect);
    }
  }, [featureFlag.data, redirect, overrideRedirect]);

  return featureFlag;
}

/*
 * Return feature flag isEnabled boolean, with state around loading, success, errors
 */
export function useFeatureFlag(flag: Flag, environment = VFE_OMEGA_ENVIRONMENT) {
  const omega = useFeatureFlags(environment);
  const [featureFlag, getFeatureFlag] = useImperativeData(omega.getFlag);

  // In useEffect so that we're not making a call to omega on the server
  useEffect(() => {
    getFeatureFlag(flag);
  }, [flag, getFeatureFlag]);

  return featureFlag;
}

/*
 * Return feature flag value
 * The return value of this hook is invert of flag value set in config portal,
 * which is a clear representation of feature enabled or disabled
 */
export function useFeatureFlagValue(flag: Flag, environment = VFE_OMEGA_ENVIRONMENT) {
  const omega = useFeatureFlags(environment);
  const [featureFlag, getFeatureFlag] = useImperativeData(omega.getFlag);

  // In useEffect so that we're not making a call to omega on the server
  useEffect(() => {
    getFeatureFlag(flag);
  }, [flag, getFeatureFlag]);

  const { isInitialised, isLoading, isSuccess, data } = featureFlag;

  return isInitialised && !isLoading && isSuccess && !data;
}

/*
 * Map of plan types to journey flags
 * Add new journeys flags/plan types here
 * Used with isPlanTypeDisabled to skip cart deeplinks when a plan type's journey is disabled
 */
const planTypeToJourneyFlagsMap: { [key: string]: string[] | undefined } = {
  [PlanEndpoint.POSTPAID]: [
    Flag.DISABLE_MOBILE_PHONES_JOURNEY_BUSINESS,
    Flag.DISABLE_MOBILE_PHONES_JOURNEY_OPERATIONAL,
  ],
  [PlanEndpoint.POSTPAID_SIMO]: [
    Flag.DISABLE_PLANS_SIM_ONLY_JOURNEY_BUSINESS,
    Flag.DISABLE_PLANS_SIM_ONLY_JOURNEY_OPERATIONAL,
  ],
  [PlanEndpoint.PREPAID_COMBO_PLUS]: [
    Flag.DISABLE_PREPAID_PLANS_JOURNEY_BUSINESS,
    Flag.DISABLE_PREPAID_PLANS_JOURNEY_OPERATIONAL,
  ],
  [PlanEndpoint.PREPAID_PAY_AND_GO]: [
    Flag.DISABLE_PREPAID_PLANS_PAY_AND_GO_JOURNEY_BUSINESS,
    Flag.DISABLE_PREPAID_PLANS_PAY_AND_GO_JOURNEY_OPERATIONAL,
  ],
  [PlanEndpoint.TABLET]: [Flag.DISABLE_TABLETS_JOURNEY_BUSINESS, Flag.DISABLE_TABLETS_JOURNEY_OPERATIONAL],
  [PlanEndpoint.TABLET_SIMO]: [
    Flag.DISABLE_TABLETS_SIM_ONLY_JOURNEY_BUSINESS,
    Flag.DISABLE_TABLETS_SIM_ONLY_JOURNEY_OPERATIONAL,
  ],
  [PlanEndpoint.POSTPAID_MBB_MODEM_SIMO]: [
    Flag.DISABLE_MBB_MODEM_SIM_ONLY_JOURNEY_BUSINESS,
    Flag.DISABLE_MBB_MODEM_SIM_ONLY_JOURNEY_OPERATIONAL,
  ],
};

/*
 * Returns a boolean used to skip cart deeplinks when a plan type's journey is disabled
 */
export function isPlanTypeDisabled(planType: PlanEndpoint, flags: FeatureToggle[]) {
  // Get the journey flags relevant for the planType. Don't disable planType if no journey flags are found
  const journeyFlags = planTypeToJourneyFlagsMap[planType];
  if (!journeyFlags) return false;

  // Go through the relevant journey flags
  // If any of the relevant journey flags have been toggled to disable the journey, the planType should be disabled also
  if (journeyFlags.some((journeyFlag) => flags.some((flag) => flag.featureId === journeyFlag && flag.isEnabled))) {
    return true;
  }

  return false;
}

export const FeatureFlagDisableAllJourneys: React.FC = () => {
  useRedirectFeatureFlag({ flag: Flag.DISABLE_ALL_JOURNEYS_BUSINESS, redirect: MaintenancePage.BUSINESS });
  useRedirectFeatureFlag({ flag: Flag.DISABLE_ALL_JOURNEYS_OPERATIONAL, redirect: MaintenancePage.OPERATIONAL });
  return null;
};
