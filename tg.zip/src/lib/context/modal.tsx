import { noop } from 'lodash';
import React from 'react';
import Modal, { ModalProps } from '@src/components/core/Modal/Modal';
import { GlobalModal as GlobalModalType, ModalItem } from '@src/lib/api/types';
import { Enrichment, enrichContent } from '@src/lib/util/formatUtils';
import { MixinProperty } from '../util/mixins';

export interface ModalProviderProps {
  children: React.ReactNode;
  modals: ModalItem[];
}

export interface ModalState {
  value: string | GlobalModalType;
  enrichments: Enrichment[];
}

type ModalAction =
  | { type: 'SET_VALUE'; value: string | GlobalModalType }
  | { type: 'ADD_ENRICHMENT'; enrichment: Enrichment }
  | { type: 'REMOVE_ENRICHMENT'; enrichment: Enrichment }
  | { type: 'REMOVE_ALL_ENRICHMENTS' };

export const modalReducer = (state: ModalState, action: ModalAction): ModalState => {
  switch (action.type) {
    case 'SET_VALUE':
      return {
        ...state,
        value: action.value,
      };

    case 'ADD_ENRICHMENT':
      return {
        ...state,
        enrichments: [...state.enrichments, action.enrichment],
      };

    case 'REMOVE_ENRICHMENT':
      return {
        ...state,
        enrichments: state.enrichments.filter((enrichment) => enrichment !== action.enrichment),
      };

    case 'REMOVE_ALL_ENRICHMENTS':
      return {
        ...state,
        enrichments: [],
      };
    default:
      return state;
  }
};

const initialState: ModalState = {
  value: '',
  enrichments: [],
};

const ModalValueContext = React.createContext<string | GlobalModalType>('');
const ModalEnrichmentsContext = React.createContext<Enrichment[]>([]);
const ModalDispatchContext = React.createContext<React.Dispatch<ModalAction>>(noop);
const ModalContentContext = React.createContext<ModalItem[]>([]);

export const useModalContent = () => React.useContext(ModalContentContext);

export const ModalDataProvider: React.FC<ModalProviderProps> = ({ children, modals }) => {
  const [{ value, enrichments }, dispatch] = React.useReducer(modalReducer, initialState);
  return (
    <ModalContentContext.Provider value={modals}>
      <ModalDispatchContext.Provider value={dispatch}>
        <ModalValueContext.Provider value={value}>
          <ModalEnrichmentsContext.Provider value={enrichments}>{children}</ModalEnrichmentsContext.Provider>
        </ModalValueContext.Provider>
      </ModalDispatchContext.Provider>
    </ModalContentContext.Provider>
  );
};

export const useSetModal = () => {
  const dispatch = React.useContext(ModalDispatchContext);
  return React.useCallback(
    (value: string | GlobalModalType) =>
      dispatch({
        type: 'SET_VALUE',
        value,
      }),
    [dispatch],
  );
};

/**
 * useUpdateEnrichments is used to add enrichment after enrichments are reset incase same modal is used multiple times.
 */
export const useUpdateEnrichments = () => {
  const dispatch = React.useContext(ModalDispatchContext);
  return React.useCallback(
    (value: Enrichment) =>
      dispatch({
        type: 'ADD_ENRICHMENT',
        enrichment: value,
      }),
    [dispatch],
  );
};

/**
 * useResetEnrichments is used to remove all existing enrichments.
 */
export const useResetEnrichments = () => {
  const dispatch = React.useContext(ModalDispatchContext);
  return React.useCallback(() => dispatch({ type: 'REMOVE_ALL_ENRICHMENTS' }), [dispatch]);
};

export const useModalEnrichment = (enrichment: Enrichment) => {
  const dispatch = React.useContext(ModalDispatchContext);
  React.useLayoutEffect(() => {
    dispatch({ type: 'ADD_ENRICHMENT', enrichment });
    return () => dispatch({ type: 'REMOVE_ENRICHMENT', enrichment });
  }, [dispatch, enrichment]);
};

const maxWidthOverrideMap: { [modalId: string]: MixinProperty<string> | undefined } = {
  comboplusrechargeoptions: '1024px',
  // other possible modal ids:
};

export const GlobalModal: React.FC = () => {
  const dispatch = React.useContext(ModalDispatchContext);
  const modalValue = React.useContext(ModalValueContext);
  const enrichments = React.useContext(ModalEnrichmentsContext);
  const modals = useModalContent();

  const onClose = React.useCallback(() => dispatch({ type: 'SET_VALUE', value: '' }), [dispatch]);

  const modal: ModalProps | undefined = React.useMemo(() => {
    if (!modals || !modalValue) return undefined;
    if (typeof modalValue === 'string') {
      const matchedModal = modals.find((m) => m.id === modalValue);
      if (matchedModal) {
        return {
          ...matchedModal,
          content: enrichContent(modalValue, matchedModal.content, enrichments),
          isOpen: false,
          onClose,
          cancelCtaAction: noop,
          confirmCtaAction: noop,
        };
      }
    } else if (typeof modalValue === 'object') {
      const matchedModal = modals.find((m) => m.id === modalValue.id);
      if (matchedModal) {
        return {
          ...matchedModal,
          content: enrichContent(modalValue.id, matchedModal.content, enrichments),
          ...modalValue,
        };
      }
    }
    return undefined;
  }, [enrichments, modalValue, modals, onClose]);

  return (
    <>
      {modal && (
        <Modal
          id={modal.id}
          title={modal.title}
          content={modal.content}
          cancelCtaLabel={modal.cancelCtaLabel || ''}
          confirmCtaLabel={modal.confirmCtaLabel || ''}
          confirmCtaAction={modal.confirmCtaAction || ''}
          cancelCtaAction={modal.cancelCtaAction || ''}
          isOpen={!!modalValue}
          onClose={modal.onClose}
          maxWidth={maxWidthOverrideMap[modal.id]}
        />
      )}
    </>
  );
};
