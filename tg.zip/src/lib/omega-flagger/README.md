# Omega Flagger

## typescript-client-lib

The TypeScript client library was copied to the `client-library` folder from https://github.com/VodafoneAustralia/omega-config-client-lib/tree/master/typescript-client-lib/src

Modifications have been done to the client library after copying. As such, this version of `typescript-client-lib` can be considered a fork.

- `node-fetch` imports have been commented out in `utils.ts`
- tests and mocks have been removed
- linting errors for `consistent-return` and `no-console` have been suppressed

Consider moving `typescript-client-lib` to a package, so it can be better managed and updated as a dependency.
