export const MAX_TRACKABLE_PRODUCTS = process.env.MAX_TRACKABLE_PRODUCTS || '6';

// todo: to be replaced with configurable value from Config Portal,
// default to 14 days for now
export const PREVIOUSLY_VIEWED_EXPIRY_DAYS = 14;

// Maximum attempts to enter an invalid Refer A Friend code.
export const REFER_A_FRIEND_CODE_MAX_ATTEMPTS = 5;
