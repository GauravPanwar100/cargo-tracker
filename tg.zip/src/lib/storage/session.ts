import { mockStorage } from '@src/lib/storage/mock';
import { formatMSISDN } from '@src/lib/util/customer';
import {
  AemOffer,
  ExpressLandingPageQuery,
  OptimizeContentKey,
  PromotionalCampaignsContent,
  tradeInDeviceDetails,
} from '@src/lib/api/types';
import { AddressStatus, PickedMatchedAddress } from '@src/components/vfe/AddressChecker/AddressChecker.interfaces';

export class SessionStorage {
  private storage: Storage;

  /**
   * This is used by the AEM header to read logged in status
   */
  private VHA_IS_LOGGED_IN = 'vhaIsLoggedIn';

  /**
   * This is used by the AEM header to read logged in status
   */
  private VHA_MASKED_MSISDN = 'vhaMaskedMsisdn';

  /**
   * This is to store the Express Upgrade query on landing page
   */
  private VHA_EXPRESS_UPGRADE_QUERY = 'vhaEUQuery';

  /**
   * This is to store the Express Upgrade passwordless token
   */
  private VHA_EXPRESS_UPGRADE_PASSWORDLESS_TOKEN = 'vhaExpressUpgradePasswordlessToken';

  /**
   * This is to store the device price
   */
  private VHA_EU_DEVICE_PRICE = 'vhaEUDevicePrice';

  /**
   * This is to store the Express Upgrade passwordless token set time for expiration
   */
  private VHA_EU_PASSWORDLESS_TOKEN_EXPIRY = 'vhaEUPasswordlessTokenExpry';

  /**
   * This is to store the 4G, 5G, nbn Address to reuse when the page is reloaded with the extra parameter.
   */
  private INTERNET_SESSION_STORAGE_KEY = 'internetDetails';

  /**
   * This is to store to identify the page to reduce api call for address check on page reload
   */
  private ADDRESS_SESSION_STORAGE_KEY = 'addressDetails';

  /**
   * This is to store to succes of page pin Validation to block direct accessing of OTP page
   */
  private VHA_EU_PIN_SUCCESS = 'pinSuccess';

  /**
   * This is to store current route name
   */
  private ROUTE_SESSION_STORAGE_KEY = 'routeName';

  /**
   * This is to store Raf code attempt count.
   */
  private REFER_A_FRIEND_CODE_ATTEMPT_COUNT = 'rafAttemptCount';

  /**
   * This is to store Raf offer data.
   */
  private REFER_A_FRIEND_OFFER = 'rafOffer';

  /**
   * This is to store tradeIn Device Details
   */
  private TRADE_IN_DEVICE_DETAILS = 'tradeInDeviceDetails';

  constructor(storage: Storage) {
    this.storage = storage;
  }

  public setLoggedInForAem(isLoggedIn: boolean, msisdn: string | null) {
    if (isLoggedIn) {
      this.storage.setItem(this.VHA_IS_LOGGED_IN, `${isLoggedIn}`);
      this.storage.setItem(this.VHA_MASKED_MSISDN, formatMSISDN(msisdn || '', true));
    } else {
      this.storage.removeItem(this.VHA_IS_LOGGED_IN);
      this.storage.removeItem(this.VHA_MASKED_MSISDN);
    }
  }

  public setEUQuery(query: ExpressLandingPageQuery) {
    this.storage.setItem(this.VHA_EXPRESS_UPGRADE_QUERY, JSON.stringify(query));
  }

  public getEUQuery(): ExpressLandingPageQuery {
    const EUQuery = this.storage.getItem(this.VHA_EXPRESS_UPGRADE_QUERY);
    return EUQuery ? JSON.parse(EUQuery) : undefined;
  }

  public setExpressUpgradePasswordlessToken(token: string) {
    this.storage.setItem(this.VHA_EXPRESS_UPGRADE_PASSWORDLESS_TOKEN, token);
  }

  public getExpressUpgradePasswordlessToken(): string | undefined {
    return this.storage.getItem(this.VHA_EXPRESS_UPGRADE_PASSWORDLESS_TOKEN) || undefined;
  }

  public setEUPasswordlessTokenExpiry(expireTime: string) {
    this.storage.setItem(this.VHA_EU_PASSWORDLESS_TOKEN_EXPIRY, expireTime);
  }

  public getEUDevicePrice(): string | undefined {
    return this.storage.getItem(this.VHA_EU_DEVICE_PRICE) || undefined;
  }

  public setEUDevicePrice(devicePrice: string) {
    this.storage.setItem(this.VHA_EU_DEVICE_PRICE, devicePrice);
  }

  public getEUPasswordlessTokenExpiry(): string | undefined {
    return this.storage.getItem(this.VHA_EU_PASSWORDLESS_TOKEN_EXPIRY) || undefined;
  }

  public setEUPinSuccessFlag(flag: string) {
    this.storage.setItem(this.VHA_EU_PIN_SUCCESS, flag);
  }

  public getEUPinSuccessFlag(): string | undefined {
    return this.storage.getItem(this.VHA_EU_PIN_SUCCESS) || undefined;
  }

  public clearExpressUpgradeStorage() {
    this.storage.removeItem(this.VHA_EXPRESS_UPGRADE_QUERY);
    this.storage.removeItem(this.VHA_EXPRESS_UPGRADE_PASSWORDLESS_TOKEN);
    this.storage.removeItem(this.VHA_EU_PASSWORDLESS_TOKEN_EXPIRY);
    this.storage.removeItem(this.VHA_EU_PIN_SUCCESS);
    this.storage.removeItem(this.VHA_EU_DEVICE_PRICE);
  }

  public setOptimizeContent(key: OptimizeContentKey, content: PromotionalCampaignsContent) {
    this.storage.setItem(key, JSON.stringify(content));
  }

  public getOptimizeContent(key: OptimizeContentKey): PromotionalCampaignsContent | null {
    const content = this.storage.getItem(key);
    return content ? JSON.parse(content) : null;
  }

  public cleanupOptimizeContent(key: OptimizeContentKey) {
    this.storage.removeItem(key);
  }

  public setValidInternetDetailsInSession(internetUIMessages: AddressStatus) {
    this.storage.setItem(this.INTERNET_SESSION_STORAGE_KEY, JSON.stringify(internetUIMessages));
  }

  public setValidAddressDetailsInSession(address: PickedMatchedAddress) {
    this.storage.setItem(this.ADDRESS_SESSION_STORAGE_KEY, JSON.stringify(address));
  }

  public getRafAttemptCount(): string | undefined {
    return this.storage.getItem(this.REFER_A_FRIEND_CODE_ATTEMPT_COUNT) || undefined;
  }

  public setRafAttemptCount() {
    const count = this.storage.getItem(this.REFER_A_FRIEND_CODE_ATTEMPT_COUNT) ?? undefined;
    if (count) this.storage.setItem(this.REFER_A_FRIEND_CODE_ATTEMPT_COUNT, JSON.stringify(parseInt(count, 10) + 1));
    else this.storage.setItem(this.REFER_A_FRIEND_CODE_ATTEMPT_COUNT, JSON.stringify(1));
  }

  public cleanupRafAttemptCount() {
    this.storage.removeItem(this.REFER_A_FRIEND_CODE_ATTEMPT_COUNT);
  }

  public getRafOfferData(): string | null {
    return this.storage.getItem(this.REFER_A_FRIEND_OFFER);
  }

  public setRafOfferData(offer: AemOffer) {
    this.storage.setItem(this.REFER_A_FRIEND_OFFER, JSON.stringify(offer));
  }

  public cleanupRafOfferData() {
    this.storage.removeItem(this.REFER_A_FRIEND_OFFER);
  }

  public setRouteNameInSession(route: string) {
    this.storage.setItem(this.ROUTE_SESSION_STORAGE_KEY, JSON.stringify(route));
  }

  public getAddressSessionContent(): string | undefined {
    return this.storage.getItem(this.ADDRESS_SESSION_STORAGE_KEY) || undefined;
  }

  public getInternetSessionContent(): string | undefined {
    return this.storage.getItem(this.INTERNET_SESSION_STORAGE_KEY) || undefined;
  }

  public getRouteSessionContent(): string | undefined {
    return this.storage.getItem(this.ROUTE_SESSION_STORAGE_KEY) || undefined;
  }

  public setTradeInDeviceDetails(deviceData: tradeInDeviceDetails) {
    this.storage.setItem(this.TRADE_IN_DEVICE_DETAILS, JSON.stringify(deviceData));
  }

  public getTradeInDeviceDetails(): tradeInDeviceDetails | null {
    const content = this.storage.getItem(this.TRADE_IN_DEVICE_DETAILS);
    return content ? JSON.parse(content) : null;
  }

  public cleanupTradeInDeviceDetails() {
    this.storage.removeItem(this.TRADE_IN_DEVICE_DETAILS);
  }

  public clearInternetJourneySessionContent() {
    this.storage.removeItem(this.ROUTE_SESSION_STORAGE_KEY);
    this.storage.removeItem(this.ADDRESS_SESSION_STORAGE_KEY);
    this.storage.removeItem(this.INTERNET_SESSION_STORAGE_KEY);
  }
}

const defaultInstanceStorageObj = typeof window === 'undefined' ? mockStorage : window.sessionStorage;

// The default export is a pre-configured instance that uses the Local Storage API
export default new SessionStorage(defaultInstanceStorageObj);
