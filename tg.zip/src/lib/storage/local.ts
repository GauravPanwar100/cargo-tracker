import Cookie from 'universal-cookie';
import {
  AddressDetails,
  AddressStatusMapping,
  NbnDetails,
  PreviouslyViewedProduct,
  ProductItem,
  PromotionItem,
  ServiceTypeValue,
  StorageCartItem,
  StoredProductItem,
  VhaAbandonedBasket,
} from '@src/lib/storage/types';
import { Basket, BasketItem, CartAemEvents, CartItemType, ProductSubType, Promotion } from '@src/lib/api/types';
import { flattenBasket } from '@src/lib/util/cart';
import { mockStorage } from '@src/lib/storage/mock';
import { HomeInternetDataMap, HomeInternetType } from '@src/templates/HomeWireless/HomeWireless.constants';
import { Schema } from '@src/lib/ci360/schema';
import { MAX_TRACKABLE_PRODUCTS, PREVIOUSLY_VIEWED_EXPIRY_DAYS } from '@src/lib/storage/constants';
import { add, isAfter, isBefore, parseISO } from 'date-fns';
import { GAValueProps } from '@src/lib/util/upgradeHub';
import AppStore from '../util/app-store';
import { addDays } from '../util/date';

export const VHA_CART_EXPIRY_DAYS = process.env.VHA_CART_EXPIRY_DAYS || '15';

enum COOKIE {
  dealer = 'dealer',
  agent = 'agent',
}
export interface Agent {
  agentID: string;
}
export interface Dealer {
  dealerCode: string;
  id: number;
}

// Export the class to simplify testing
export class LocalStorage {
  public SERVICE_TYPE = 'serviceType';

  private E2E_SESSION_ID = 'e2eSessionId';

  private CART_ITEMS = 'cartItems';

  private NBN_DETAILS = 'nbnDetails';

  private HOME_WIRELESS_4G_DETAILS = 'homeWireless4gDetails';

  private HOME_WIRELESS_5G_DETAILS = 'homeWireless5gDetails';

  private BASKET_ID = 'basketID';

  private VHA_ABANDONED_CART = 'vhaAbandonedCart';

  private VHA_CART_EXPIRY = 'vhaCartExpiry';

  private VFE_APIS_ENDPOINT = 'vfeApisEndpoint';

  private SALESFORCE_PROXY_ENDPOINT = 'sfProxyEndpoint';

  private CUSTOMER_ID = 'customerID';

  private SOURCE_IP = 'sourceIP';

  private LAST_INTERACTION_TIME = 'lastInteractionTime';

  public PARTNER_DETAILS = 'partnerDetails';

  private VIEWED_PRODUCTS = 'viewedProducts';

  private SAS_CONTEXT = 'sasContext';

  private ADDRESS_STATUS_MAPPING = 'addressStatusMapping';

  private IS_HOME_INTERNET_ASD_ELIGIBLE = 'isHomeInternetASDEligible';

  private STUDENT_EMAIL = 'studentEmail';

  private STUDENT_OFFER_PLAN_ID = 'studentOfferPlanId';

  private EXISTING_CUSTOMER_FROM_1SQ = 'existingCustomerFrom1SQ';

  private DELIVERY_UPDATES = 'deliveryUpdatesSelection';

  private RAF_ITEM_UPDATED = 'rafItemUpdated';

  private storage: Storage;

  public cookies = new Cookie();

  public dealerCookieValue = '';

  public agentCookieValue = '';

  /**
   * This is to store GA key value from _ga cookie
   */
  public GACookieKey = '_ga';

  constructor(storage: Storage) {
    this.storage = storage;
  }

  private clear = () => {
    this.storage.clear();
  };

  public getCookie(key: string) {
    return this.cookies.get(key);
  }

  public getDocumentCookie = () => {
    return document.cookie;
  };

  public checkCookieExists = (cookieName: string) => {
    return this.getDocumentCookie()
      .split(';')
      .some((item) => item.trim().startsWith(`${cookieName}=`));
  };

  public setPartnerDetails = () => {
    // get acn toggle and read cookies
    // if cookies exist create partnerDetails json object
    if (
      typeof document !== 'undefined' &&
      (this.checkCookieExists(COOKIE.dealer) || this.checkCookieExists(COOKIE.agent))
    ) {
      let dealerCookieExpire = '';
      let dealerCookieValue = '';
      if (this.checkCookieExists(COOKIE.dealer)) {
        dealerCookieValue = this.getDealerCookie();
        const dealerCookieExpiryDateValue = new Date();
        dealerCookieExpiryDateValue.setTime(this.getDealerCookieExpiry());
        dealerCookieExpire = dealerCookieExpiryDateValue.toJSON();
      }

      let agentCookieValue = '';
      if (this.checkCookieExists(COOKIE.agent)) {
        agentCookieValue = this.getAgentCookie();
      }

      const partnerDetails = JSON.stringify({
        dealerCode: dealerCookieValue,
        agentId: agentCookieValue,
        expires: dealerCookieExpire,
      });
      this.storage.setItem(this.PARTNER_DETAILS, partnerDetails);
    }
  };

  public getPartnerDetails = (): string | null => {
    const partnerDetails = this.storage.getItem(this.PARTNER_DETAILS);
    return partnerDetails;
  };

  private getAgentCookie = () => {
    const agent = this.getCookie(COOKIE.agent) as Agent;
    return agent.agentID;
  };

  private getDealerCookie = () => {
    const dealer = this.getCookie(COOKIE.dealer) as Dealer;
    return dealer.dealerCode;
  };

  private getDealerCookieExpiry = () => {
    const dealer = this.getCookie(COOKIE.dealer) as Dealer;
    return dealer.id;
  };

  public setServiceType = (serviceType: ServiceTypeValue) => {
    this.storage.setItem(this.SERVICE_TYPE, serviceType);
  };

  public getServiceType = (): ServiceTypeValue | undefined => {
    let serviceType = this.storage.getItem(this.SERVICE_TYPE);
    const isValid = (
      [ServiceTypeValue.AnotherService, ServiceTypeValue.NewAcquisition, ServiceTypeValue.Upgrade, null] as Array<
        string | null
      >
    ).includes(serviceType);
    if (!isValid) {
      this.storage.removeItem(this.SERVICE_TYPE);
      serviceType = null;
    }
    return (serviceType ?? undefined) as ServiceTypeValue | undefined;
  };

  public getBasketId = (): string => {
    const basketId = this.storage.getItem(this.BASKET_ID) || '';
    if (!basketId) this.clearDisplayedCartStorage();
    return basketId;
  };

  public setBasketId = (basketId: string) => {
    // TODO: make ServiceType dynamic, default to new now
    this.setServiceType(this.getServiceType() ?? ServiceTypeValue.NewAcquisition);
    const existingBasketId = this.storage.getItem(this.BASKET_ID);

    if (existingBasketId) {
      this.storage.removeItem(existingBasketId);
    }
    this.storage.setItem(this.BASKET_ID, basketId);
  };

  public removeBasketId = () => {
    const basketId = this.storage.getItem(this.BASKET_ID);
    if (basketId) {
      this.storage.removeItem(basketId);
    }
    this.storage.removeItem(this.BASKET_ID);
    // If we remove the basket, we also want to clear the displayed cart storage (so we don't keep getting told about the items we've just cleared)
    this.clearDisplayedCartStorage();
    this.removeNbnContext();
    this.clearStudentOfferInfo();
  };

  public getInstallationAddress = (internetType: HomeInternetType): string => {
    const { localStorageItemKey } = HomeInternetDataMap[internetType];
    const detailsString = this.storage.getItem(this[localStorageItemKey]);

    const emptyInstallationAddress = {
      streetNumber: '',
      street: '',
      streetType: '',
      unitNumber: 0,
      unitType: '',
      suburb: '',
      state: '',
      postcode: '',
    };
    let installationAddress = JSON.stringify(emptyInstallationAddress);
    if (detailsString) {
      const details = JSON.parse(detailsString);
      if (details && details.address && details.address.matchedAddress && details.address.matchedAddress.address) {
        installationAddress = JSON.stringify(details.address.matchedAddress.address);
      }
    }
    return installationAddress;
  };

  public setNbnContext = (basketId: string, nbnDetails: NbnDetails) => {
    this.setBasketId(basketId);
    this.storage.setItem(this.NBN_DETAILS, JSON.stringify(nbnDetails));
  };

  public removeNbnContext = () => {
    this.storage.removeItem(this.NBN_DETAILS);
  };

  public setHomeWirelessContext = (
    basketId: string | undefined,
    addressDetails: AddressDetails,
    internetType: HomeInternetType,
  ) => {
    const { localStorageItemKey } = HomeInternetDataMap[internetType];
    if (basketId) {
      this.setBasketId(basketId);
    }
    this.storage.setItem(this[localStorageItemKey], JSON.stringify(addressDetails));
  };

  public removeHomeWirelessContext = (internetType: HomeInternetType) => {
    const { localStorageItemKey } = HomeInternetDataMap[internetType];
    this.storage.removeItem(this[localStorageItemKey]);
  };

  public setCheckoutCart(basket: Basket | null, disclaimer: string) {
    if (!basket) {
      this.clearCheckoutCart();
      return;
    }
    this.storage.setItem(this.E2E_SESSION_ID, AppStore.getE2eSessionId());
    // Mapping rules https://hub.deloittedigital.com.au/wiki/pages/viewpage.action?spaceKey=VDF&title=038+-+LLD+-+Cross+Platform+Communication
    const items = flattenBasket(basket.packages);
    const storageCartItems: StorageCartItem[] = items.map((item) => {
      const relatedContent = item.relatedContent ?? {};
      const promotions: PromotionItem[] = item.promotions
        ? item.promotions.map((promo: Promotion) => ({
            promoCode: promo.promotionCode,
            icon: promo.iconUrl,
            description: promo.description,
            title: promo.title,
          }))
        : [];
      return {
        productCode: item.productCode,
        productName: item.productName,
        packageId: item.packageId,
        promotions,
        image: relatedContent.image ? relatedContent.image.imageUrl : '',
      };
    });
    this.storage.setItem(
      this.CART_ITEMS,
      JSON.stringify({
        common: {
          disclaimer,
        },
        items: storageCartItems,
      }),
    );
  }

  public clearCheckoutCart() {
    this.storage.removeItem(this.E2E_SESSION_ID);
    this.storage.removeItem(this.CART_ITEMS);
  }

  public trackViewedProduct(productItem: ProductItem) {
    const productsStr = this.storage.getItem(this.VIEWED_PRODUCTS);

    const viewedDateExpiry = add(new Date(), {
      days: PREVIOUSLY_VIEWED_EXPIRY_DAYS,
    }).toISOString();
    const item: StoredProductItem = { ...productItem, viewedDate: new Date().toISOString(), viewedDateExpiry };
    let products: StoredProductItem[] = [];
    if (productsStr) {
      products = JSON.parse(productsStr);
    }
    products.push(item);
    // remove duplicates by unique id e.g. catalog code/product code
    products = [...Array.from(new Map(products.map((i) => [i.id, i])).values())];

    const result = products
      .sort((p1, p2) => Date.parse(p2.viewedDate) - Date.parse(p1.viewedDate))
      .slice(0, Number(MAX_TRACKABLE_PRODUCTS));

    this.storage.setItem(this.VIEWED_PRODUCTS, JSON.stringify(result));
  }

  public getViewedProducts(productSubType?: ProductSubType): PreviouslyViewedProduct[] | null {
    const viewedProducts = this.storage.getItem(this.VIEWED_PRODUCTS);
    // SHOP-5182: check expiry before returning the values,
    // if expired, remove the item from localstorage
    const products: PreviouslyViewedProduct[] = viewedProducts ? JSON.parse(viewedProducts) : null;
    if (!products) {
      return null;
    }

    const now = new Date();

    const productsNotExpired = products.filter((product) => {
      return isBefore(now, parseISO(product.viewedDateExpiry));
    });

    this.storage.setItem(this.VIEWED_PRODUCTS, JSON.stringify(productsNotExpired));

    return productSubType
      ? productsNotExpired.filter((product) => product.productSubType === productSubType)
      : productsNotExpired;
  }

  public setDisplayedCartStorage(cartResponse: Basket | null) {
    if (!(cartResponse && cartResponse.packages && Array.isArray(cartResponse.packages))) {
      return;
    }

    this.updateCartExpiryDate(false);

    const cartItemFilter = (item: BasketItem) =>
      item.itemType === CartItemType.PLAN ||
      item.itemType === CartItemType.MODEM ||
      item.itemType === CartItemType.DEVICE;

    // Mapping rules https://hub.deloittedigital.com.au/wiki/pages/viewpage.action?spaceKey=VDF&title=038+-+LLD+-+Cross+Platform+Communication
    const abandonedCartItems: VhaAbandonedBasket[] = cartResponse.packages.map((bundle) => {
      // Loop over the bundles, including only the BasketItems with the correct itemType
      return {
        items: bundle.items.filter(cartItemFilter).map((item: BasketItem) => {
          const relatedContent = item.relatedContent ?? {};
          const promotions: PromotionItem[] = item.promotions
            ? item.promotions.map((promo: Promotion) => ({
                promoCode: promo.promotionCode,
                icon: promo.iconUrl,
                description: promo.description,
                title: promo.title,
              }))
            : [];
          return {
            catalogCode: item.catalogCode,
            itemType: item.itemType === CartItemType.PLAN ? 'plan' : 'device',
            packageId: item.packageId,
            productCode: item.productCode,
            productName: item.productName,
            promotions,
            productType: item.productType,
            productSubType: item.productSubType,
            imageUrl: relatedContent.image ? relatedContent.image.imageUrl : '',
          };
        }),
      };
    });

    // Remove any bundles that are empty
    const abandonedPackages = abandonedCartItems.filter((bundles) => bundles.items.length);

    this.storage.setItem(
      this.VHA_ABANDONED_CART,
      JSON.stringify({
        packages: abandonedPackages,
        lastUpdatedAt: new Date().toJSON(),
      }),
    );
    notifyCartHeader(CartAemEvents.RESET_ABANDONED_CART);
  }

  public clearDisplayedCartStorage() {
    this.storage.removeItem(this.VHA_CART_EXPIRY);
    this.storage.removeItem(this.VHA_ABANDONED_CART);
    notifyCartHeader(CartAemEvents.RESET_ABANDONED_CART);
  }

  public setCheckoutUrls() {
    this.storage.setItem(
      this.VFE_APIS_ENDPOINT,
      process.env.VFE_INTEGRATION_API || 'VFE INTEGRATION API NOT CONFIGURED',
    );
    this.storage.setItem(
      this.SALESFORCE_PROXY_ENDPOINT,
      process.env.SALESFORCE_PROXY_URL || 'SALESFORCE PROXY URL NOT CONFIGURED',
    );
  }

  public getStudentOfferInfo() {
    return {
      email: this.storage.getItem(this.STUDENT_EMAIL),
      planId: this.storage.getItem(this.STUDENT_OFFER_PLAN_ID),
    };
  }

  public setStudentOfferInfo(email: string, planId: string) {
    // If a student email is already present, we should not override the value
    if (!this.storage.getItem(this.STUDENT_EMAIL)) {
      this.storage.setItem(this.STUDENT_EMAIL, email);
    }
    this.storage.setItem(this.STUDENT_OFFER_PLAN_ID, planId);
  }

  public clearStudentOfferInfo() {
    this.storage.removeItem(this.STUDENT_EMAIL);
    this.storage.removeItem(this.STUDENT_OFFER_PLAN_ID);
  }

  public getIsExistingCustomerFrom1SQ() {
    return this.storage.getItem(this.EXISTING_CUSTOMER_FROM_1SQ) !== 'false';
  }

  public setIsExistingCustomerFrom1SQ(isExistingCustomer: boolean) {
    this.storage.setItem(this.EXISTING_CUSTOMER_FROM_1SQ, String(isExistingCustomer));
  }

  public clearIsExistingCustomerFrom1SQ() {
    this.storage.removeItem(this.EXISTING_CUSTOMER_FROM_1SQ);
  }

  public clearCheckoutUrls() {
    this.storage.removeItem(this.VFE_APIS_ENDPOINT);
    this.storage.removeItem(this.SALESFORCE_PROXY_ENDPOINT);
  }

  public removePartnerCookies = () => {
    if (
      typeof document !== 'undefined' &&
      (this.checkCookieExists(COOKIE.dealer) || this.checkCookieExists(COOKIE.agent))
    ) {
      const d = new Date();
      d.setTime(d.getTime());
      const expires = `expires=${d.toUTCString()}`;
      if (this.checkCookieExists(COOKIE.dealer)) {
        document.cookie = `${COOKIE.dealer}=;path=/;${expires}`;
      }
      if (this.checkCookieExists(COOKIE.agent)) {
        document.cookie = `${COOKIE.agent}=;path=/;${expires}`;
      }
    }
  };

  public getCustomerID(): string | null {
    return this.storage.getItem(this.CUSTOMER_ID);
  }

  public setCustomerID(customerID: string | null) {
    if (customerID) {
      this.storage.setItem(this.CUSTOMER_ID, customerID);
    } else {
      this.storage.removeItem(this.CUSTOMER_ID);
    }
  }

  public clearCustomerID() {
    this.storage.removeItem(this.CUSTOMER_ID);
  }

  public setSourceIP(sourceIP: string) {
    this.storage.setItem(this.SOURCE_IP, sourceIP);
  }

  public clearSourceIP() {
    this.storage.removeItem(this.SOURCE_IP);
  }

  public checkCartExpired(nowTimeMillis = Date.now()) {
    // Check if there is a VHA_EXPIRED_CART
    const expiredCartStr = this.storage.getItem(this.VHA_CART_EXPIRY);
    if (!expiredCartStr) {
      return;
    }

    const cartExpiryDate = Date.parse(expiredCartStr);

    if (nowTimeMillis > cartExpiryDate) {
      // This removes 3-or-4 keys - <basketIDCode>, basketID, vhaCartExpiry, vhaAbandonedCart:
      this.removeBasketId();
    }
  }

  public getLastInteractionTime(): number | undefined {
    const lastInteractionTimeStr = this.storage.getItem(this.LAST_INTERACTION_TIME);
    if (!lastInteractionTimeStr) {
      return undefined;
    }
    return Date.parse(lastInteractionTimeStr);
  }

  public setLastInteractionTime(nowTimeMillis = Date.now()) {
    this.storage.setItem(this.LAST_INTERACTION_TIME, nowTimeMillis.toString());
  }

  public clearLastInteractionTime() {
    this.storage.removeItem(this.LAST_INTERACTION_TIME);
  }

  // SAS Context
  public setSASContext(schema: Schema): void {
    this.storage.setItem(this.SAS_CONTEXT, JSON.stringify(schema));
  }

  public getSASContext(): Schema | null {
    const serialised = this.storage.getItem(this.SAS_CONTEXT);
    if (!serialised) return null;
    return JSON.parse(serialised);
  }

  // RAF Upsert state
  public setRafItemUpdated(rafItemUpdated: boolean): void {
    this.storage.setItem(this.RAF_ITEM_UPDATED, JSON.stringify(rafItemUpdated));
  }

  public getRafItemUpdated(): boolean | null {
    const rafItemUpdated = this.storage.getItem(this.RAF_ITEM_UPDATED);
    if (!rafItemUpdated) return null;
    return JSON.parse(rafItemUpdated);
  }

  public clearRafItemUpdated() {
    this.storage.removeItem(this.RAF_ITEM_UPDATED);
  }

  public setAddressStatusMapping(addressStatusMapping: AddressStatusMapping) {
    this.storage.setItem(
      this.ADDRESS_STATUS_MAPPING,
      JSON.stringify({ ...addressStatusMapping, expiredAt: addDays(new Date(), 1).toISOString() }),
    );
  }

  public getAddressStatusMapping(): AddressStatusMapping | undefined {
    const mapping = this.storage.getItem(this.ADDRESS_STATUS_MAPPING);

    if (!mapping) {
      return undefined;
    }

    const statusMapping: AddressStatusMapping = JSON.parse(mapping);

    if (!statusMapping.expiredAt || isAfter(new Date(), new Date(statusMapping.expiredAt))) {
      this.clearAddressStatusMapping();
      return undefined;
    }

    return statusMapping;
  }

  public clearAddressStatusMapping = () => {
    this.storage.removeItem(this.ADDRESS_STATUS_MAPPING);
  };

  public setHomeInternetASDEligibility(eligible: boolean) {
    this.storage.setItem(this.IS_HOME_INTERNET_ASD_ELIGIBLE, JSON.stringify(eligible));
  }

  public updateCartExpiryDate = (updateIfExists = true) => {
    const expiryDate = this.storage.getItem(this.VHA_CART_EXPIRY);
    if (!expiryDate || updateIfExists) {
      const newExpiryDate = new Date();
      const newDate = newExpiryDate.getDate() + parseInt(VHA_CART_EXPIRY_DAYS, 10);
      newExpiryDate.setUTCHours(18, 0, 0, 0);
      newExpiryDate.setDate(newDate);

      this.storage.setItem(this.VHA_CART_EXPIRY, newExpiryDate.toISOString());
    }
  };

  public getDeliveryUpdates = () => {
    const selectionsFromLocal = this.storage.getItem(this.DELIVERY_UPDATES);
    return selectionsFromLocal ? JSON.parse(selectionsFromLocal) : '';
  };

  public setDeliveryUpdates = (selectionObj: {
    byEmail: {
      status: boolean;
      newEmail: string;
    };
    bySMS: {
      status: boolean;
      msisdnContact: boolean;
    };
  }) => {
    this.storage.setItem(this.DELIVERY_UPDATES, JSON.stringify(selectionObj));
  };

  public getGAValue(): GAValueProps | null {
    const GASessionValue = this.storage.getItem(this.GACookieKey);
    return GASessionValue ? JSON.parse(GASessionValue) : null;
  }

  public setGAValue(GASessionValue: GAValueProps) {
    this.storage.setItem(this.GACookieKey, JSON.stringify(GASessionValue));
  }

  public clearLocalStorage = () => {
    this.storage.clear();
  };
}

/** VFE-902 needs to trigger events by dispatching browser event with the corresponding string */
// Sends an event which is caught by the VHA Header component.
// At this point in time, there is only one cart event, which causes the cart to re-read local storage.
// Moving this code here (instead of in util/cart.ts) as updating local storage and the cart-header are
// closely related activities.
function notifyCartHeader(aemEvent: CartAemEvents) {
  if (typeof window !== 'undefined') window.dispatchEvent(new Event(aemEvent));
}

const defaultInstanceStorageObj = typeof window === 'undefined' ? mockStorage : window.localStorage;

// The default export is a pre-configured instance that uses the Local Storage API
export default new LocalStorage(defaultInstanceStorageObj);
