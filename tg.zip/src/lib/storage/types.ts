import { CartItem, CartProductSubType, CartProductType, CatalogCode, ProductSubType } from '@src/lib/api/types';
import { AddressStatus, PickedMatchedAddress } from '@src/components/vfe/AddressChecker/AddressChecker.interfaces';

// These types are derived from the LLD for cross platform communication
// https://hub.deloittedigital.com.au/wiki/pages/viewpage.action?spaceKey=VDF&title=038+-+LLD+-+Cross+Platform+Communication

export type AddressStatusMapping = {
  pickedAddress: PickedMatchedAddress;
  addressStatus: AddressStatus;
  expiredAt?: string;
};

export interface NbnASRServiceSpecification {
  businessFibre?: boolean;
  name: string;
  primaryAccessTechnology: string;
  serviceabilityClass: string;
}

export interface NbnASRSiteBoundaries {
  csaId: string;
  region?: string;
}

export interface NbnASRLocationFeatures {
  inHomeAmplifier?: boolean;
  mdu?: boolean;
  networkBoundaryPoint?: string;
  newDevelopmentsChargeApplies: boolean;
  safetyCriticalServiceAlert?: boolean;
  selfAndRSPProfessionalInstallEligible?: boolean;
}

export interface NbnASRCapabilityAvailability {
  available?: boolean;
  capacity?: number;
  featureType?: string;
  highSpeedNotLessThan?: boolean;
  unitOfMeasure?: string;
}

export interface NbnASRProductFeatures {
  capacityAvailability?: NbnASRCapabilityAvailability[];
  ftpUNIV?: boolean;
  multicast?: boolean;
  speedTierAvailability?: string[];
  tc2?: boolean;
  tr069UNIV?: boolean;
  type?: string;
  version?: string;
}

export type NbnASRBandwidthRates = {
  bandwidthRate?: number;
  featureType?: string;
  supported?: boolean;
  unitOfMeasure?: string;
};

export type NbnASRCopperBandwidthRates = {
  bandwidth?: number;
  bandwidthType?: string;
  featureType?: string;
  unitOfMeasure?: string;
};

export interface NbnUniPort {
  id: string;
  status: string;
}

export interface NbnBatteryBackup {
  batteryPowerUnit?: boolean;
  batteryPowerUnitMonitored?: string;
  powerSupplywithBatteryBackupInstallDate?: string;
}

export interface NbnASRResource {
  bandwidthRatesSupported?: NbnASRBandwidthRates[];
  copperBandwidthRates?: NbnASRCopperBandwidthRates[];
  copperPairStatus?: string;
  id: string;
  nbnServiceStatus?: string;
  networkCoexistance?: boolean;
  ntdBatteryBackup?: NbnBatteryBackup;
  ntdInstallDate?: string;
  ntdLocation?: string;
  ntdPowerType?: string;
  ntdType?: string;
  remediationRequired?: boolean;
  serviceabilityClass?: string;
  subsequentInstallationChargeApplies?: boolean;
  type: string;
  uniPortD?: NbnUniPort[];
  uniPortV?: NbnUniPort[];
  version?: string;
}

export interface NbnASRTerminationError {
  code?: string;
  message?: string;
  reason?: string;
  status?: string;
  type?: string;
}

export interface NbnASRService {
  serviceabilityStatus: string;
  serviceSpecification: NbnASRServiceSpecification;
  supportingProductFeatures?: NbnASRProductFeatures[];
  supportingRelatedLocationFeatures?: NbnASRLocationFeatures;
  supportingRelatedSiteBoundaries?: NbnASRSiteBoundaries;
  supportingResource?: NbnASRResource[];
  terminationError?: NbnASRTerminationError[];
}

export interface NbnASRServiceQualificationItem {
  id: string;
  service: NbnASRService;
}

export interface ServiceQualification {
  correlationId: string;
  locationId: string;
  serviceabilityClass: string;
  serviceQualificationItem: NbnASRServiceQualificationItem;
}

export interface NbnDetailsWithServiceQualification {
  address: PickedMatchedAddress;
  serviceQualification: ServiceQualification;
  siteQualificationAppointmentRequired: string;
  siteQualificationAuthorisationDate: string; // UTC string date
}

export type NbnDetails = NbnDetailsWithServiceQualification;

export interface AddressDetails {
  address: PickedMatchedAddress;
}

export interface PromotionItem {
  // enriched promotion content
  promoCode: string; // promotion code
  title: string; // eg: "Bonus 15 GB data"
  icon?: string;
  description: string; // eg: "Includes 15GB per month for use in Oz ... Offer ends 01/01/21."
}
export interface StorageCartItem {
  productCode: string;
  packageId: string;
  productName: string;
  image: string;
  promotions: PromotionItem[];
}

export interface StorageCartItems {
  common: {
    disclaimer: string;
  };
  items: StorageCartItem[];
}

export enum ServiceTypeValue {
  NewAcquisition = 'New',
  Upgrade = 'Upgrade',
  AnotherService = 'Additional Services',
}

export type VhaAbandonedCartItemType = 'device' | 'plan';

export interface VhaAbandonedCartItem {
  catalogCode: CatalogCode;
  imageUrl: string;
  itemType: VhaAbandonedCartItemType;
  productCode: string;
  productName: string;
  productType: CartProductType;
  packageId: string;
  productSubType?: CartProductSubType;
}

export interface VhaAbandonedBasket {
  items: VhaAbandonedCartItem[];
}

export type VhaAbandonedCart = VhaAbandonedCartItem[];

export type VhaCartExpiry = string;

export interface CPCData {
  cartContextKey: string; // customer's basket key returned by the Vlocity Digital Commerce API
  customerID?: string; // customer's MSIDSN,
  serviceType: ServiceTypeValue; // type of service - new acquisition, upgrade, add services
  e2eSessionId: string; // customer's session ID used for monitoring and reporting,

  // customer's NBN details, if applicable
  nbnDetails?: NbnDetails;

  // enriched cart content
  cartItems?: CartItem[];
}

export interface JWTObject {
  payload: CPCData;
}

export interface ProductItem {
  productName: string;
  productSubType?: ProductSubType;
  productImg: DeviceImage;
  productUrl: string;
  id: string;
}

export interface StoredProductItem extends ProductItem {
  viewedDate: string;
  viewedDateExpiry: string;
}

interface DeviceImage {
  altText: string;
  imageUrl: string;
}

export interface PreviouslyViewedProduct {
  productName: string;
  productSubType?: ProductSubType;
  productImg: {
    imageUrl: string;
    altText: string;
  };
  productUrl: string;
  id: string;
  viewedDate: string;
  viewedDateExpiry: string;
}

// Samsung Cookie object type
export interface SamsungCookie {
  partnerCode: string;
  planId: string;
  deviceSku: string;
  callbackUrl: string;
  resumeUrl: string;
  cartId: string;
}
