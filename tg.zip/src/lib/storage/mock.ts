// If we are running in the server, provide a mock storage implementation. If on the Browser, use localStorage.
export const mockStorage: Storage = {
  clear() {},
  getItem() {
    return '';
  },
  removeItem() {},
  setItem() {},
  length: 0,
  key() {
    return null;
  },
};
