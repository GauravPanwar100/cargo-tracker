export type Image = {
  alt?: string;
  src: string;
};

export type Svg = {
  src: string;
};

export function isRecord(obj: unknown): obj is Record<PropertyKey, unknown> {
  return typeof obj === 'object' && !!obj;
}

/**
 * Unwraps a `PromiseLike<T>` value
 */
export type Awaited<T> = T extends PromiseLike<infer U> ? Awaited<U> : T;

export function isPromiseLike<T = unknown>(obj: unknown): obj is PromiseLike<T> {
  return isRecord(obj) && typeof obj.then === 'function';
}

/**
 * https://github.com/KablamoOSS/kerosene/blob/master/packages/kerosene/src/types/index.ts#L37-L41
 * Like `keyof T`, but distributes across all members of unions to include all keys (including those
 * not shared by all members)
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type KeysOfUnion<T> = T extends any ? keyof T : never;

/**
 * https://github.com/KablamoOSS/kerosene/blob/master/packages/kerosene/src/types/index.ts#L50-L73
 * This utility type is just used to provide two different references to the same type so that one
 * instance may be distributed and the other left intact. Here, `T1` is used to distribute across
 * each member of the union, whereas `T2` is used as the complete union. Both are the same type.
 * @private
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type __MergedUnion__<T1 extends object, T2 extends object> = T1 extends any
  ? {
      [K in Exclude<KeysOfUnion<T2>, keyof T1>]?: undefined;
    } & T1
  : never;

/**
 * From a union type `T`, allows properties which are not shared by all members to be `undefined`
 *
 * e.g.
 * ```typescript
 * type FooBar = MergedUnion<{ common: string; foo: string } | { common: string; bar: string }>;
 * // equivalent to
 * type FooBar = { common: string; foo: string; bar?: undefined } | { common: string; foo?: undefined; bar: string };
 * ```
 */
export type MergedUnion<T extends object> = __MergedUnion__<T, T>;

/**
 * Make all properties of `T` mutable
 */
export type Mutable<T> = { -readonly [P in keyof T]: T[P] };

/**
 * A more permissive type than `unknown` that is still type-safe
 */
export type NullableRecord = Record<string, unknown> | null | undefined;

/**
 * Mapped type for object entry
 */
type Entries<T> = {
  [K in keyof T]: [K, T[K]];
}[keyof T][];

/**
 * Helper function to preserve correct types for object entries
 */
export const entries = <T>(obj: T): Entries<T> => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return Object.entries(obj) as any;
};

export type UnboxArray<T> = T extends Array<infer Member> ? Member : T;
