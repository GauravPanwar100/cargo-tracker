/* eslint-disable @typescript-eslint/no-explicit-any */
import winston, { format, transports } from 'winston';
import AppStore from '../util/app-store';

// list of fields that can be displayed in the logger - extendable but try not to have synonyms
export type LoggerExtras = {
  error?: any;
  response?: any;
  request?: any;
  ucode: string;
};

// TODO below method currently does nothing, commenting it out until clear what is required
// stringifying and then parsing data creates a massive bottle neck in the BE
// function hidePiiData(data: any) {
//   // clone the response data and ensure the log does not show PII data
//   const hiddenPiiData = JSON.parse(JSON.stringify(data ?? ''));
//   // extend this check for any field that is pii
//   // if (hiddenPiiData.pii) {
//   //   hiddenPiiData.pii = '*';
//   // }
//   return hiddenPiiData;
// }

function logFormat(info: any) {
  if (info.request) {
    // ensure request does not show PII data and minimise display // TODO see hidePiiData todo above
    // eslint-disable-next-line no-param-reassign
    info.request = {
      url: info.request.url,
      method: info.request.method,
      // body: hidePiiData(info.request.body), // TODO see hidePiiData todo above
      body: info.request.body,
    };
  }
  if (info.response) {
    // ensure response does not show PII data and minimise display // TODO see hidePiiData todo above
    // eslint-disable-next-line no-param-reassign
    info.response = {
      headers: info.response.headers,
      status: info.response.status,
      statusText: info.response.statusText,
      config: {
        ...info.response.config,
        transformRequest: undefined,
        transformResponse: undefined,
        timeout: undefined,
        xsrfCookieName: undefined,
        xsrfHeaderName: undefined,
        maxContentLength: undefined,
      },
      // data: hidePiiData(info.response.data), // TODO see hidePiiData todo above
      data: info.response.data,
    };
  }

  return {
    level: info.level.toUpperCase(),
    message: info.message,
    'X-SessionID': AppStore.getE2eSessionId(),
    'X-InitialSystem': AppStore.getXInitialSystem(),
    'X-InitialComponent': AppStore.getXInitialComponent(),
    ...info,
  };
}

winston.configure({
  exitOnError: false,
  level: process.env.LOGGING_LEVEL,
  transports: [
    new transports.Console({
      level: typeof window === 'undefined' ? process.env.SERVER_SIDE_LOGGING_LEVEL ?? 'info' : 'error',
    }),
  ],
  format: format.combine(format(logFormat)(), format.json()), // this format.json() is currently a bottle neck in the BE, if we want to further optimise the response time we can either agree to not send logs in a JSON format or hack the stringify to be faster
  silent: process.env.UNIT_TEST_LOGS === 'silent',
});

export default winston;
