import {
  AccountType,
  AdditionalServiceBundleDetails,
  AddressCheckerResponse,
  Basket,
  BasketItem,
  BasketPackage,
  BasketRequestItem,
  CartItem,
  CartItemType,
  CartPageResponse,
  CartPriceInfo,
  CartProductSubType,
  CartProductType,
  CatalogCode,
  CheckoutSplitterContent,
  CheckoutSplitterGroup,
  CurrentServiceData,
  CustomerDetails,
  CustomerProductsEligibility,
  DataLimit,
  DevicePageResponse,
  FaqContent,
  NbnModemsContent,
  NbnPageResponse,
  NbnPlan,
  NbnPlanBasketItem,
  NbnPlansResponse,
  OfferItem,
  PageHeaderContent,
  PlanBasketItem,
  PlansContent,
  PlansPageResponse,
  PostpaidPlan,
  PrepaidPlan,
  ProductServiceType,
  ProductSubType,
  Promotion,
  TermsAndConditionsContent,
  UpgradesPageHeaderContent,
} from '@src/lib/api/types';
import { Theme } from '@src/lib/theme';
import { AuthenticationState, User } from '../context/authentication';

export const mockHeaderData: PageHeaderContent = {
  experienceFragments: [[], []],
  seoData: [],
  metaTags: '',
  seoTitle: 'TEST PAGE',
  defaultTitle: 'Choose your mobile phone',
  altTitle: 'Device Listing Alt title',
  altDescription:
    '<p></p>\r\n<p>Default DescriptionDefault DescriptionDefault DescriptionDefault Description</p>\r\n<p>Default DescriptionDefault DescriptionDefault Description</p>\r\n',
  altBreadcrumb: 'Alt Breadcrumb',
  defaultBreadcrumb: 'Default Breadcrumb',
  defaultDescription:
    'Enjoy the feeling of a new mobile phone. With Vodafone, you can pay for your new phone interest free over 12, 24 or 36 months, and get a Red or Red Plus Plan with a no lock-in contract. If your Plan is cancelled, you’ll need to pay off your phone on your next bill.',
};

export const mockPrepaidHeaderData: PageHeaderContent = {
  experienceFragments: [[], []],
  seoData: ['SEO_value_Prepaid'],
  metaTags: '',
  seoTitle: 'TEST PREPAID PAGE',
  defaultTitle: 'Choose your prepaid mobile phone',
  altTitle: 'Prepaid Device Listing Alt title',
  altDescription:
    '<p></p>\r\n<p>Prepaid Default Desc</p>\r\n<p>Default DescriptionDefault DescriptionDefault Description</p>\r\n',
  altBreadcrumb: 'Prepaid Alt Breadcrumb',
  defaultBreadcrumb: 'Prepaid Default Breadcrumb',
  defaultDescription: 'Get a prepaid phone while you are fixing your credit score.',
};

export const mockTermsAndConditions = {
  identifier: 'identifer',
  termsConditionsTitle: 'Terms and Conditions',
  termsConditionsDesc:
    'Your Max Speed means the maximum speed the Vodafone network can deliver to your handset at the time and place you are using data.',
};

const mockFaqItemOne = {
  title: 'Why should I choose Vodafone to get a mobile phone plan?',
  description:
    'With our Red Plus Plans, you’ll get heaps of data at Your Max Speed and then you can keep using data at speeds of up to 1.5Mbps in Oz.',
};

const mockFaqItemTwo = {
  title: 'Can I bring my current number across to Vodafone?',
  description:
    'Yes. Once you’ve signed up to a plan, give us a call so that we can bring your current number across to us.',
};

const mockFaqItemThree = {
  title: 'Can I save if I have multiple plans under one account?',
  description: 'Yes. You can bundle eligible plans under one account and save from 5% to 20% on plan fees. T&C apply.',
};

const mockFaqItemFour = {
  title: 'Can I share data from my Red or Red Plus Plan with other Vodafone plans?',
  description:
    'Yes. You can share Your Max Speed data with other Plus Plans under one account, and you can share data with other SIM Only and Red Plans under one account. Up to 5 eligible services can be shared and data is for use in Australia. T&C apply.',
};

export const mockFaq: FaqContent = {
  identifier: 'Identifier',
  sectionTitle: 'Frequently asked questions',
  faqItems: [mockFaqItemOne, mockFaqItemTwo, mockFaqItemThree, mockFaqItemFour],
};

const addressCoverage = {
  fields: [
    {
      isRequired: false,
      fieldPlaceholder: 'Enter your address',
      fieldName: 'addressAutocomplete',
      fieldOptions: '',
      fieldLabel: 'Enter your address',
      validationMessage: 'Please enter an address',
      fieldType: 'autocomplete',
    },
    {
      isRequired: false,
      fieldPlaceholder: '',
      fieldName: 'manualAddressCheck',
      fieldOptions: '',
      fieldLabel: 'Enter address manually',
      validationMessage: '',
      fieldType: 'checkbox',
    },
    {
      isRequired: false,
      fieldPlaceholder: '',
      fieldName: 'unitType',
      fieldOptions: '',
      fieldLabel: 'Unit type (optional)',
      validationMessage: '',
      fieldType: 'select',
    },
    {
      isRequired: false,
      fieldPlaceholder: '',
      fieldName: 'unitNumber',
      fieldOptions: '',
      fieldLabel: 'Unit number (optional)',
      validationMessage: '',
      fieldType: 'text',
    },
    {
      isRequired: true,
      fieldPlaceholder: '',
      fieldName: 'streetNumber',
      fieldOptions: '',
      fieldLabel: 'Street number',
      validationMessage: 'Please enter a street number',
      fieldType: 'text',
    },
    {
      isRequired: true,
      fieldPlaceholder: '',
      fieldName: 'streetName',
      fieldOptions: '',
      fieldLabel: 'Street name',
      validationMessage: 'Please enter a street name',
      fieldType: 'text',
    },
    {
      isRequired: true,
      fieldPlaceholder: '',
      fieldName: 'streetType',
      fieldOptions: '',
      fieldLabel: 'Street type',
      validationMessage: 'Please select a street type',
      fieldType: 'select',
    },
    {
      isRequired: true,
      fieldPlaceholder: '',
      fieldName: 'suburb',
      fieldOptions: '',
      fieldLabel: 'Suburb',
      validationMessage: 'Please enter a suburb',
      fieldType: 'text',
    },
    {
      isRequired: true,
      fieldPlaceholder: '',
      fieldName: 'state',
      fieldOptions: '',
      fieldLabel: 'State',
      validationMessage: 'Please enter a state',
      fieldType: 'select',
    },
    {
      isRequired: true,
      fieldPlaceholder: '',
      fieldName: 'postcode',
      fieldOptions: '',
      fieldLabel: 'Postcode',
      validationMessage: 'Please enter a postcode',
      fieldType: 'autocomplete',
    },
    {
      isRequired: false,
      fieldPlaceholder: '',
      fieldName: 'livingInComplex',
      fieldOptions: '',
      fieldLabel: 'I live in a complex',
      validationMessage: '',
      fieldType: 'checkbox',
    },
    {
      isRequired: false,
      fieldPlaceholder: '',
      fieldName: 'level',
      fieldOptions: '',
      fieldLabel: 'Level (optional)',
      validationMessage: '',
      fieldType: 'text',
    },
    {
      isRequired: false,
      fieldPlaceholder: '',
      fieldName: 'complexStreetNumber',
      fieldOptions: '',
      fieldLabel: 'Street number in a complex (optional)',
      validationMessage: '',
      fieldType: 'text',
    },
    {
      isRequired: false,
      fieldPlaceholder: '',
      fieldName: 'complexOrSiteName',
      fieldOptions: '',
      fieldLabel: 'Complex or Site name (optional)',
      validationMessage: '',
      fieldType: 'text',
    },
    {
      isRequired: false,
      fieldPlaceholder: '',
      fieldName: 'buildingName',
      fieldOptions: '',
      fieldLabel: 'Building name in a complex (optional)',
      validationMessage: '',
      fieldType: 'text',
    },
    {
      isRequired: false,
      fieldPlaceholder: '',
      fieldName: 'complexStreet',
      fieldOptions: '',
      fieldLabel: 'Street name in a complex (optional)',
      validationMessage: '',
      fieldType: 'text',
    },
    {
      isRequired: false,
      fieldPlaceholder: '',
      fieldName: 'complexStreetType',
      fieldOptions: '',
      fieldLabel: 'Street type in a complex (optional)',
      validationMessage: '',
      fieldType: 'select',
    },
  ],
  cta: 'Check Address',
  cancelCta: 'Cancel',
};

const coverageStatus = {
  nbnTechnology: [
    {
      type: 'FTTP',
      message: '<p>Great news, you can connect to Vodafone nbn™ via Fibre to the Premises.</p>',
      serviceClasses: ['1', '2', '3'],
    },
    {
      type: 'FTTB',
      message: '<p>Great news, you can connect to Vodafone nbn™ via Fibre to the Building.</p>',
      serviceClasses: ['4', '5'],
    },
    {
      type: 'FTTN',
      message: '<p>Great news, you can connect to Vodafone nbn™ via Fibre to the Node. </p>',
      serviceClasses: ['11', '12'],
    },
    {
      type: 'FTTC',
      message: '<p>Great news, you can connect to Vodafone nbn™ via Fibre to the Curb.</p>',
      serviceClasses: ['30', '31', '32', '33', '34'],
    },
    {
      type: 'HFC',
      message: '<p>Great news, you can connect to Vodafone nbn™ via Hybrid Fibre Coaxial</p>',
      serviceClasses: ['21', '22', '23', '24'],
    },
    {
      type: 'wireless',
      message: '<p>Unfortunately NBN is not available</p>',
      serviceClasses: ['4', '5', '6'],
    },
  ],
  installation: [
    {
      serviceClasses: ['3', '12', '13', '24', '33', '34'],
      type: 'self',
      message:
        '&lt;p&gt;You&rsquo;re able to self install and you won&rsquo;t require an nbn&trade; technician. Once your service is activated, you can connect to Vodafone nbn&trade;.&lt;/p&gt;',
    },
    {
      serviceClasses: ['1', '2', '11', '21', '22', '23', '31', '32'],
      type: 'assisted',
      message:
        '&lt;p&gt;We&rsquo;ll arrange for an nbn&trade; technician to install your nbn&trade; service. Once your service is activated, you can connect to Vodafone nbn&trade;.&lt;/p&gt;',
    },
    {
      serviceClasses: ['11', '12', '13', '31', '32', '23'],
      type: 'HFC-speeds',
      message:
        '&lt;p&gt;Actual speeds for Fibre to the Building, Fibre to the Node and Fibre to the Curb to be confirmed and may vary.&lt;/p&gt;',
    },
  ],
  mobileCoverage: [
    {
      type: 'limited',
      message:
        "<p>You’ll be able to connect to our mobile network from day one through 4G Back Up on the Vodafone Wi-Fi Hub™. The <a href='path'>mobile network coverage</a> at your address is limited. Max speeds apply.</p>",
    },
    {
      type: 'good',
      message:
        '<p>You’ll be able to connect to our mobile network from day one through 4G Back Up on the Vodafone Wi-Fi Hub™. Your mobile network coverage at your address is good. Max speeds apply.</p>',
    },
    {
      type: 'unavailable',
      message: '<p>Unfortunately, 4G Back Up on the Vodafone Wi-Fi Hub™ is unavailable at your address.</p>',
    },
  ],
  exceptions: [
    {
      type: 'nbn-unavailable',
      message: '<p>Unfortunately, Vodafone nbn™ isn’t available at your address yet.',
    },
    {
      type: 'timeout',
      message: '<p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.</p>',
    },
    {
      type: 'contact',
      message: '<p>Please call us on 1300 123 456.</p>',
    },
    {
      type: 'sign-up-unavailable',
      message:
        "<p>&lt;p&gt;Unfortunately, you can't sign up to nbn&trade; online. To sign up to Vodafone nbn&trade; for that address, please give us a call on &lt;a href=&quot;tel:1300650410&quot;&gt;1300 650 410&lt;/a&gt;.&lt;/p&gt;</p>",
    },
  ],
};

const alerts = [
  {
    alertType: 'neutral',
    alertId: 'multiple-addresses',
    alertText:
      '&lt;p&gt;There are multiple addresses at this location. Please select your address below and&amp;nbsp; select manually&lt;/p&gt;',
  },
  {
    alertType: 'error',
    alertId: 'address-not-found',
    alertText: "&lt;p&gt;Unfortunately we can't find your address. Please enter it manually.&lt;/p&gt;",
  },
  {
    alertType: 'error',
    alertId: 'address-error',
    alertText:
      "&lt;p&gt;Unfortunately we are facing a technical issue and can't find your address. Please enter it manually.&lt;/p&gt;",
  },
  {
    alertType: 'positive',
    alertId: 'Information',
    alertText: '&lt;p&gt;Information- Desc&lt;/p&gt;',
  },
  {
    alertType: 'error',
    alertId: 'address-nomatch',
    alertText:
      "&lt;p&gt;Unfortunately, something didn't go as planned. Please try again later or call our team on &lt;a href=&quot;tel:1300650410&quot;&gt;1300 650 410&lt;/a&gt;.&lt;/p&gt;",
  },
];

export const addressCheckerApi = {
  addressCoverage,
  coverageStatus,
  alerts,
} as AddressCheckerResponse;

export const mockPromotions: Promotion[] = [
  {
    title: '$468 Loyalty Discount off your plan cost',
    description:
      "Includes a $468 Loyalty Discount off your plan fees. A loyalty discount is applied for new and existing when you stay with us for a longer repayment term. That's a saving of $13 per month over 36 months. Loyalty Discount ends after device repayment period. T&C apply.",
    promotionCode: 'promo_code_111',
    iconUrl: '',
    endDate: '2200-05-30T14:00:00.000Z',
    productAdjustment: [
      {
        productCode: 'AU12141',
        priceAdjustment: [
          {
            chargeType: 'Recurring',
            baseAmount: 60,
            chargeAmount: 60,
          },
          {
            chargeType: 'One-time',
            baseAmount: 0,
            chargeAmount: 0,
          },
        ],
        dataAllowanceAdjustment: [],
      },
    ],
  },
  {
    title: 'Bonus 15GB data',
    description:
      'Includes 15GB/mth bonus data for use in Oz when you sign up to this plan with the Pixel 3 128GB. OFfer ends 03/09/19. T&C apply.',
    promotionCode: 'promo_code_112',
    iconUrl: '',
    endDate: '2200-05-30T14:00:00.000Z',
    productAdjustment: [
      {
        productCode: 'AU12141',
        priceAdjustment: [
          {
            chargeType: 'Recurring',
            baseAmount: 60,
            chargeAmount: 60,
          },
          {
            chargeType: 'One-time',
            baseAmount: 0,
            chargeAmount: 0,
          },
        ],
        dataAllowanceAdjustment: [
          {
            withBonusAllowance: '150GB',
          },
        ],
      },
    ],
  },
  {
    title: 'Get 1 month free plan fees',
    description:
      "Includes a $468 Loyalty Discount off your plan fees. A loyalty discount is applied for new and existing when you stay with us for a longer repayment term. That's a saving of $13 per month over 36 months. Loyalty Discount ends after device repayment period. T&C apply",
    promotionCode: 'promo_code_113',
    iconUrl: '',
    endDate: '2200-05-30T14:00:00.000Z',
    productAdjustment: [
      {
        productCode: 'AU12141',
        priceAdjustment: [
          {
            chargeType: 'Recurring',
            baseAmount: 60,
            chargeAmount: 60,
          },
          {
            chargeType: 'One-time',
            baseAmount: 0,
            chargeAmount: 0,
          },
        ],
        dataAllowanceAdjustment: [],
      },
    ],
  },
];

export const mockPlans: PostpaidPlan[] = [
  {
    discountedRecurringCharge: 9,
    subHeadingSecondary: 'per month',
    subHeadingPrimary: 'Data in Oz',
    planName: '$55 Red Plan',
    planCategory: 'Postpaid',
    heroLabel: 'Our Pick',
    planImage: {
      altText: 'Alt text',
      imageUrl:
        'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/0274_FoundationRefresh_HelloSundayLogo.png',
    },
    planTenure: 'Month to month',
    ctaLabel: 'Select this plan',
    ctaDisabledLabel: '',
    ctaSelectedLabel: '',
    heroOfferId: '',
    planId: 'AU12069',
    planDescription: 'Get 45GB at Your Max Speed, then keep using data at speeds of up to 1.5MBps',
    cisLabel: 'Summary Label',
    cisUrl: '/content/vha/test-page0.html',
    ratesLabel: 'Rates and Charges Label',
    ratesUrl: '',
    planTitle: '',
    order: 1,
    recurringCharge: 40,
    planProductName: '$40 Red Plan',
    planSubType: 'Handset M2M Plus',
    planExtraInfo: '',
    planData: '80',
    contractTerm: 1,
    inclusions: [
      {
        description: '',
        title: 'Endless data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/broadband.png',
        planId: '',
      },
      {
        description: 'Get {AT_STD_NAT_TXT} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: '',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/broadband.png',
        planId: '',
      },
      {
        description: '{AT_INTL_ZONE1} to Zone 1 & {AT_INTL_ZONE2} to Zone 2',
        title: 'Standard national calls and texts',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/nbn.png',
        planId: '',
      },
      {
        description: '',
        title: '',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/nbn.png',
        planId: '',
      },
    ],
    promotions: mockPromotions,
    isBundleAndSaveEligible: true,
    isTrialPlan: false,
  },
  {
    discountedRecurringCharge: 9,
    subHeadingSecondary: 'per month',
    subHeadingPrimary: 'Data in OZ',
    planName: '$55 red Plus Plan',
    planCategory: 'Postpaid',
    heroLabel: 'Our Pick',
    planImage: {
      altText: '',
      imageUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/0355_PipeAboutPage-icon-4g.png',
    },
    planTenure: '12 months',
    ctaLabel: 'Select this plan',
    ctaDisabledLabel: '',
    ctaSelectedLabel: '',
    ratesUrl: '/content/vha/en',
    cisUrl: '/content/vha/en',
    heroOfferId: 'PROMO_UNLMTD_IDD_STDNT',
    planId: 'AU12075',
    planDescription: '$55 Red Plus Plan - 12 months',
    cisLabel: 'Summary Label',
    ratesLabel: 'Rates and Charges Applied',
    planTitle: 'Endless Data',
    order: 2,
    recurringCharge: 32,
    planProductName: '$32 Red Plus Plan',
    planSubType: 'Handset M2M Plus',
    planExtraInfo: '',
    planData: '40',
    contractTerm: 1,
    inclusions: [
      {
        description: 'Get {AT_STD_INTL_MINS} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: 'Endless data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/download.jpeg',
        planId: '',
      },
      {
        description: 'Get {AT_STD_NAT_TXT} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: 'Limited data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/broadband.png',
        planId: '',
      },
      {
        description: '{AT_INTL_ZONE1} to Zone 1 & {AT_INTL_ZONE2} to Zone 2',
        title: 'Standard national calls and texts',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/nbn.png',
        planId: '',
      },
    ],
    promotions: [],
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
  },
  {
    discountedRecurringCharge: 9,
    subHeadingSecondary: '12 months',
    subHeadingPrimary: 'Data in Oz',
    planName: '$55 SIM Only Plus Plan',
    planCategory: 'Postpaid',
    heroLabel: '',
    planImage: {
      altText: 'Plan image',
      imageUrl:
        'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/0274_FoundationRefresh_HelloSundayLogo.png',
    },
    planTenure: '12 months',
    heroOfferId: '',
    planId: 'AU12072',
    planDescription: '$55 SIM Only Plus Plan - 12 Months',
    cisLabel: 'Summary Label',
    ctaDisabledLabel: '',
    ctaSelectedLabel: '',
    cisUrl: '/content/vha/en',
    ctaLabel: 'Select this plan',
    ratesLabel: 'Rates and Charges',
    ratesUrl: '/content/vha/en',
    planTitle: 'Endless Data',
    order: 3,
    recurringCharge: 40,
    planProductName: '$40 SIM Only Plus Plan',
    planSubType: 'SIM Only M2M Plus',
    planExtraInfo: '',
    planData: '80',
    contractTerm: 1,
    inclusions: [
      {
        description: 'Get {AT_STD_INTL_MINS} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: 'Endless data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/download.jpeg',
        planId: '',
      },
      {
        description: 'Get {AT_STD_NAT_TXT} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: 'Limited data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/broadband.png',
        planId: '',
      },
      {
        description: '{AT_INTL_ZONE1} to Zone 1 & {AT_INTL_ZONE2} to Zone 2',
        title: 'Standard national calls and texts',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/nbn.png',
        planId: '',
      },
    ],
    promotions: [],
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
  },
  {
    discountedRecurringCharge: 9,
    subHeadingSecondary: 'per month',
    subHeadingPrimary: 'Data plus',
    planName: '$35 SIM Only Plan',
    planCategory: 'Postpaid',
    heroLabel: '',
    planImage: {
      altText: 'Plan Image',
      imageUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/0339_SegmentsABtest-Families2.png',
    },
    planTenure: '12 Months',
    ctaLabel: 'Select this Plan',
    ctaDisabledLabel: '',
    ctaSelectedLabel: '',
    heroOfferId: '',
    planId: 'AU12060',
    planDescription: '$35 SIM Only Plan-12 Months',
    cisLabel: 'Summary Label',
    cisUrl: '/content/vha/en',
    ratesLabel: 'Rates and Charges Label',
    ratesUrl: '/content/vha/en',
    planTitle: 'Endless Data',
    order: 4,
    recurringCharge: 40,
    planProductName: '$40 SIM Only Plus Plan',
    planSubType: 'SIM Only M2M Plus',
    planExtraInfo: '',
    planData: '80',
    contractTerm: 1,
    inclusions: [
      {
        description: 'Get {AT_STD_INTL_MINS} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: 'Endless data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/download.jpeg',
        planId: '',
      },
      {
        description: 'Get {AT_STD_NAT_TXT} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: 'Limited data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/broadband.png',
        planId: '',
      },
      {
        description: '{AT_INTL_ZONE1} to Zone 1 & {AT_INTL_ZONE2} to Zone 2',
        title: 'Standard national calls and texts',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/nbn.png',
        planId: '',
      },
    ],
    promotions: mockPromotions,
    isBundleAndSaveEligible: true,
    isTrialPlan: false,
  },
];

export const mockPrepaidPlans: PrepaidPlan[] = [
  {
    discountedOneTimeCharge: 9,
    subHeadingSecondary: 'one off coz prepaid duh',
    subHeadingPrimary: 'Data in Oz',
    planName: '$40 Value Meal',
    planCategory: 'Prepaid',
    heroLabel: 'Our Pick',
    planImage: {
      altText: 'Alt text',
      imageUrl:
        'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/0274_FoundationRefresh_HelloSundayLogo.png',
    },
    planTenure: '7 Weeks',
    ctaLabel: 'Select this plan',
    ctaDisabledLabel: '',
    ctaSelectedLabel: '',
    heroOfferId: '',
    planId: 'AU12069',
    planDescription: 'Get 45GB at Your Max Speed, then keep using data at speeds of up to 1.5MBps',
    cisLabel: 'Summary Label',
    cisUrl: '/content/vha/test-page0.html',
    ratesLabel: 'Rates and Charges Label',
    ratesUrl: '',
    planTitle: '',
    planProductName: '',
    planSubType: '',
    order: 1,
    recurringCharge: 0,
    discountedRecurringCharge: 0,
    oneTimeCharge: 40,
    planExtraInfo: '',
    planData: '80',
    contractTerm: 1,
    inclusions: [
      {
        description: '',
        title: 'Endless data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/broadband.png',
        planId: '',
      },
      {
        description: 'Get {AT_STD_NAT_TXT} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: '',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/broadband.png',
        planId: '',
      },
      {
        description: '{AT_INTL_ZONE1} to Zone 1 & {AT_INTL_ZONE2} to Zone 2',
        title: 'Standard national calls and texts',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/nbn.png',
        planId: '',
      },
      {
        description: '',
        title: '',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/nbn.png',
        planId: '',
      },
    ],
    promotions: [],
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
  },
  {
    discountedOneTimeCharge: 9,
    subHeadingSecondary: 'prepaid',
    subHeadingPrimary: 'Data in OZ',
    planName: '$55 Fast fingers',
    planCategory: 'Prepaid',
    heroLabel: 'Our Pick',
    planImage: {
      altText: '',
      imageUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/0355_PipeAboutPage-icon-4g.png',
    },
    planTenure: '1 month',
    ctaLabel: 'Select this plan',
    ctaDisabledLabel: '',
    ctaSelectedLabel: '',
    ratesUrl: '/content/vha/en',
    cisUrl: '/content/vha/en',
    heroOfferId: 'PROMO_UNLMTD_IDD_STDNT',
    planId: 'AU12075',
    planDescription: '$55 for the month you got kicked out of your neighbours wifi',
    cisLabel: 'Summary Label',
    ratesLabel: 'Rates and Charges Applied',
    planTitle: 'Endless Data',
    planProductName: '',
    planSubType: '',
    order: 2,
    recurringCharge: 0,
    discountedRecurringCharge: 0,
    oneTimeCharge: 55,
    planExtraInfo: '',
    planData: '40',
    contractTerm: 1,
    inclusions: [
      {
        description: 'Get {AT_STD_INTL_MINS} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: 'Endless data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/download.jpeg',
        planId: '',
      },
      {
        description: 'Get {AT_STD_NAT_TXT} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: 'Limited data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/broadband.png',
        planId: '',
      },
      {
        description: '{AT_INTL_ZONE1} to Zone 1 & {AT_INTL_ZONE2} to Zone 2',
        title: 'Standard national calls and texts',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/nbn.png',
        planId: '',
      },
    ],
    promotions: mockPromotions,
    isBundleAndSaveEligible: true,
    isTrialPlan: false,
  },
  {
    discountedOneTimeCharge: 9,
    subHeadingSecondary: '12 months recurring',
    subHeadingPrimary: 'Data in Oz',
    planName: '$55 SIM Only Plus Plan',
    planCategory: 'Prepaid',
    heroLabel: '',
    planImage: {
      altText: 'Plan image',
      imageUrl:
        'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/0274_FoundationRefresh_HelloSundayLogo.png',
    },
    planTenure: '12 months',
    heroOfferId: '',
    planId: 'AU12072',
    planDescription:
      '$55 SIM Only Plus Plan - Got kicked out of your neighbours wifi and not sure this year when you would get connected',
    cisLabel: 'Summary Label',
    cisUrl: '/content/vha/en',
    ctaLabel: 'Select this plan',
    ctaDisabledLabel: '',
    ctaSelectedLabel: '',
    ratesLabel: 'Rates and Charges',
    ratesUrl: '/content/vha/en',
    planTitle: 'Endless Data',
    planProductName: '',
    planSubType: '',
    order: 3,
    recurringCharge: 50,
    discountedRecurringCharge: 0,
    oneTimeCharge: 50,
    planExtraInfo: '',
    planData: '80',
    contractTerm: 1,
    inclusions: [
      {
        description: 'Get {AT_STD_INTL_MINS} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: 'Endless data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/download.jpeg',
        planId: '',
      },
      {
        description: 'Get {AT_STD_NAT_TXT} at Your Max Speed then keep using data at speeds of up to 1.5Mbps',
        title: 'Limited data in Oz',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/broadband.png',
        planId: '',
      },
      {
        description: '{AT_INTL_ZONE1} to Zone 1 & {AT_INTL_ZONE2} to Zone 2',
        title: 'Standard national calls and texts',
        iconUrl: 'https://aem-publish-65.demo.nonprod.vha.dd-au.io/content/dam/vha/nbn.png',
        planId: '',
      },
    ],
    promotions: [],
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
  },
];

export const mockPlanListing: PlansContent = {
  title: 'Plans with Endless Data',
  plans: mockPlans,
  usps: [
    {
      imageUrl: '/content/dam/vha/omniscript/Lock.png',
      description: "Once you've used your included set data",
      title: 'Additional data',
    },
    {
      imageUrl: '/content/dam/vha/omniscript/SA DL.png',
      description: 'Icon Description',
      title: 'Additional data_new',
    },
  ],
  showPayIn4PromoContent: false,
  payIn4PromoContentThreshold: 28.83,
  planListingTheme: 'dark',
  planListingBackgroundColor: '#5e2750',
};

export const mockPrepaidPlanListing: PlansContent = {
  title: 'Prepaid Plans',
  plans: mockPrepaidPlans,
  usps: [
    {
      imageUrl: '/content/dam/vha/omniscript/Lock.png',
      description: "Once you've used your included set data",
      title: 'Additional data',
    },
    {
      imageUrl: '/content/dam/vha/omniscript/SA DL.png',
      description: 'Icon Description',
      title: 'Additional data_new',
    },
  ],
  showPayIn4PromoContent: false,
  payIn4PromoContentThreshold: 28.83,
  planListingTheme: 'dark',
  planListingBackgroundColor: '#5e2750',
};

export const mockCartPageData: CartPageResponse = {
  cartSummary: {
    appliedCta: '',
    bundleCartLabel: 'Bundled Plan',
    emptyCartMessage: 'Your cart is Empty',
    continueCtaUrl: '/content/vha/en.html',
    continueCta: 'Continue Shopping',
    promoCodeTitle: 'Promo Code',
    title: 'Your Cart',
    checkoutCta: 'Checkout',
    promoCodeCta: 'Apply',
    disclaimer:
      '&lt;p&gt;If you have 2 or more eligible plans, your Bundle &amp;amp; Save discount will be applied to your next bill.&lt;/p&gt;',
    remainingBalanceLabel: '',
    remainingBalanceModal: '',
    totalCostLabelAddService: '',
    totalCostLabelUpgrades: '',
    totalCostLabel: '',
    includedLabel: 'Included',
    repairWarranty:
      '&lt;p&gt;All devices comes with a 24 month warranty for faulty devices. &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/device/service.html&quot;&gt;Find out more&lt;/a&gt;.&lt;/p&gt;',
    repairWarrantyTitle: 'Repair Warranty',
  },
  persistentCart: {
    collapseCta: 'See Less',
    label: 'Continue to Cart',
    expandCta: 'See More',
  },
  seoData: [],
  metaTags: '',
  seoTitle: 'SEO_Title',
  alerts: [
    {
      alertId: 'limit-of-5',
      alertText:
        'You can only add a maximum of 5 items to your cart. Please remove some items so that you only have 5 left.',
      alertType: 'error',
    },
  ],
  checkoutSplitterGroups: [
    {
      id: 'simo',
      content: [
        {
          secondaryCtaStyle: 'primary',
          secondaryCtaLabel: '',
          primaryCtaStyle: 'primary',
          secondaryCtaRole: 'new',
          primaryCtaLabel: "Yes, I'm new",
          title: 'New to Vodafone?',
          body: '',
          primaryCtaRole: 'new',
        },
        {
          secondaryCtaStyle: 'secondary',
          secondaryCtaLabel: 'Add another plan',
          primaryCtaStyle: 'secondary',
          secondaryCtaRole: 'additional-service',
          primaryCtaLabel: 'Change your plan',
          title: 'Already with Vodafone?',
          body: '',
          primaryCtaRole: 'change-plan',
        },
      ],
    },
    {
      id: 'home-internet',
      content: [
        {
          secondaryCtaStyle: 'primary',
          secondaryCtaLabel: '',
          primaryCtaStyle: 'primary',
          secondaryCtaRole: 'new',
          primaryCtaLabel: 'Add it as a new plan',
          title: 'Already with Vodafone?',
          body: '&lt;p&gt;What would you like to do with the plan in your shopping cart?&lt;/p&gt;',
          primaryCtaRole: 'additional-service',
        },
        {
          secondaryCtaStyle: 'primary',
          secondaryCtaLabel: '',
          primaryCtaStyle: 'secondary',
          secondaryCtaRole: 'new',
          primaryCtaLabel: "Yes, I'm new",
          title: 'New to Vodafone?',
          body: '',
          primaryCtaRole: 'new',
        },
      ],
    },
  ],
  checkoutSplitterLogo: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/VF-logo-desktop.svg',
  rafCartLabels: {
    icon: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/00_placeholder.svg',
    title: 'Refer A Friend',
    description:
      '&lt;p&gt;RAF &lt;b&gt;Description&lt;/b&gt;&nbsp;&lt;a href=&quot;https://www-sit.test.cms.df.services.vodafone.com.au/support&quot;&gt;support&lt;/a&gt;&lt;a href=&quot;https://www-sit.test.cms.df.services.vodafone.com.au/support&quot;&gt;&lt;/a&gt;&lt;/p&gt;',
    placeholderText: 'RAF',
    primaryCtaLabel: 'Submit Code',
    cartLabel: 'RAF Credit applied',
  },
};

export const mockTotalPrice: CartPriceInfo = {
  recurringCharge: 33.99,
  oneTimeCharge: 0,
  oneTimeLoyalty: 0,
  recurringLoyalty: 0,
};

export const mockNbnModems = {
  modemPlans: [
    {
      tabName: 'Plans with a modem',
      thumbnailUrl: 'https://webkit.org/demos/srcset/image-2x.png',
      productId: 'modem123',
      altText: 'modem logo',
      productDisplayName: 'Vodafone Wi-Fi Hub<sup>tm</sup>',
      textBlock:
        '<p>More details of Vodafone’s nbn™ plans will be announced in coming months.</p><p>The Vodafone Wi-Fi Hub comes with a pre-installed mobile broadband SIM.</p><p>*Vodafone is giving customers complimentary unlimited internet access via its 3G or 4G mobile network in-between sign-up and service installation and in the case of an nbn™ fault on a specific service (not for mass nbn™ outages) for a maximum of 30 days. Speeds during this period are throttled at a theoretical maximum of 12Mbps for downloads and 1 Mbps for uploads. Service performance varies depending on network coverage and your location with speeds likely less than the maximum. Both services will end when your nbn service is activated or re-activated. Our Fair Use Policy applies see vodafone.com.au for details. To find out where we have 4G see vodafone.com.au/coverage.</p><p>nbn™, nbn co and other nbn™ logos and brands are trademarks of nbn co limited and used under licence.</p><p><b>Device specifications for Vodafone Wi-Fi Hub™</b></p><ul><li>Supports up to 32 devices simultaneously</li><li>Compatible with ADSL, VDSL and NBN</li><li>2X Ethernet LAN port</li><li>1X Ethernet WAN port</li><li>2.4GHz Wi-Fi 802.11 a/b/g/n certified®</li><li>5GHz Wi-Fi 802.11 a/b/g/n/ac certified®</li><li>Integrated 4G LTE capability with 3G backup</li><li>1 x Multi-function USB 2.0 Port</li><li>CPE Remote Management</li><li>DLNA Certified®</li><li>Easy push button connection to pair wireless devices (WPS)</li><li>VPN Pass-through for PPTP, L2TP and Ipsec.</li><li>IPv4 / IPv6 support</li><li>QoS support</li><li>Customer facing GUI for Advanced Settings Management</li></ul>',
    },
    {
      tabName: 'Plans without a modem',
      thumbnailUrl: 'https://webkit.org/demos/srcset/image-2x.png',
      productId: null,
      altText: 'your own modem logo',
      productDisplayName: 'Bring your own modem',
      textBlock:
        '<h1>Using your own Compatible Modem with Vodafone nbn™.</h1><p>It’s best to use the <a href=https://www.vodafone.com.au/support/nbn/wi-fi-hub&#34;>Vodafone Wi-Fi Hub™</a> with Vodafone nbn™. However, you are also able to use your own Compatible Modem or router on selected plans. If you prefer to do this, we recommend getting a qualified network specialist to set up your equipment.</p><p>Here’s what you’ll need to know to use your own Compatible Modem or router with Vodafone nbn™.</p><h2>Network settings for your Compatible Modem.</h2><p>To access your network settings, you’ll need to login to your Compatible Modem or router’s default gateway server. Please check your User Guide for details on how to access your network settings before you configure your Compatible Modem.</p><p>Here’s how your Compatible Modem general network settings should be configured.</p><ul><li>Set the Network Connection Type to IPoE. For some modems or routers, this is referred to as either DHCP or Dynamic IP.</li><li>If you are connecting to FTTN or FTTB, set the DSL Modulation type in your modem settings to VDSL2 or Auto-sync Up.</li><li>Set the L2 Maximum Transfer Unit (MTU) size to 1500 Bytes. Don’t set it any higher as this can affect the performance of your nbn™ service.</li><li>Set the Upstream Maximum Bit Rate (MBR) to the uplink speed profile of the nbn™ service that you’re subscribed to. For example, set the uplink MBR to 5 Mbps for an nbn™ 25/5 speed profile.</li></ul>',
    },
  ],
} as NbnModemsContent;

export const mockNbnTermsAndConditions = {
  identifier: CatalogCode.NBN_PLANS,
  termsConditionsTitle: '&lt;p&gt;Vodafone nbn&trade; Month-to-Month plans&lt;/p&gt;',
  termsConditionsDesc:
    '&lt;p&gt;For personal use by approved customers only. Subject to service qualification check. Vodafone nbn&trade; is a data-only service and is not compatible with your home phone line service meaning you may no longer be able to use your landline (or existing phone number) for calls after you sign-up. Vodafone nbn&trade; service may also impact or interfere with existing technology, devices or services at your premises including medical devices, alarms, eftpos machines, lift emergency phones and some email or fax services. You cannot share the data between your Vodafone nbn&trade; plan and your Vodafone postpaid mobile plan and vice versa. You can find out which plans support sharing or you can opt-out of sharing altogether at any time by calling 1555. Additional fees may apply for nbn&trade; installation or appointments.&lt;/p&gt;&lt;p&gt;Minimum monthly spend is $65, $75 or $95. The total maximum cost of the Vodafone Wi-Fi Hub Modem (&lsquo;Modem&rsquo;) is $180. There is no option to purchase the Modem outright or on a monthly payment plan. The Modem cost equates to $5 per month (&lsquo;Undiscounted Price&rsquo;) over 36 months or $0 per month (&lsquo;Discounted Price&rsquo;) if you stay connected for 36 months (&lsquo;Device Period&rsquo;). The Discounted Price will appear as a credit on your monthly bill. If you choose to cancel your plan before the end of the Device Period you will need to pay the full Undiscounted Price x months remaining on Device Period. This remaining Modem cost will be applied as a lump sum on your final bill. You must connect for a minimum of one month. Recurring monthly plan fees are charged until the end of the month in which you notify that you wish to cancel. You will be charged for using your plan from the point of nbn&trade; activation at your premises.&lt;/p&gt;&lt;p&gt;Total minimum cost excludes any additional costs for call outs when there is a missed appointment or where no fault is found or the $300 New Development Charge that is triggered when you live in a new development. You must connect for a minimum of one month. Recurring monthly plan fees are charged until the end of the month in which you notify that you wish to cancel. You will be charged for using your plan from the point of nbn&trade; activation at your premises.&lt;/p&gt;',
} as TermsAndConditionsContent;

const mockNbnFaq = {
  identifier: CatalogCode.NBN_PLANS,
  sectionTitle: 'Frequently asked questions',
  faqItems: [
    {
      description:
        'The nbn&trade; network refers to the ongoing upgrade of Australia&rsquo;s current phone and internet infrastructure by the corporation NBN Co Limited, otherwise known as nbn.',
      title: 'What is nbn™?',
    },
    {
      description:
        '&lt;p&gt;Your existing phone and internet services may no longer work once nbn&trade; has been available in your area for 18 months. To continue using Fixed Broadbrand and voice services, most people will need to move to the nbn&trade; network.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;Individuals and businesses are not automatically switched over to the nbn&trade; network and will need to get in touch with a phone or internet provider like Vodafone to make the change.&lt;/p&gt;',
      title: 'Will I have to switch to nbn™?',
    },
    {
      description:
        '&lt;p&gt;Given the nbn&trade; network is still being rolled out across Australia, it will become available for different addresses at different times.&lt;/p&gt;&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;p&gt;Use our address checker above to see if nbn&trade; is available at your address.&lt;/p&gt;',
      title: 'When is nbn™ coming to my area?',
    },
  ],
};

export const mockNbnBaseContent: NbnPageResponse = {
  nbnModemsContent: mockNbnModems,
  nbnTitleContent: mockHeaderData,
  nbnInfoContent: {
    textBlock:
      "You will typically experience slower speeds than the maximum connection speed available on your plan. Typical Busy Speed: This is the typical download speed you may experience between 7pm and 11pm. It is not a guaranteed minimum speed and you may experience lower speeds during this period and at other times. Speed will vary on a number of factors such as technology type, plan choice and internet traffic demand. Please see our <a href='https://www.vodafone.com.au/support/nbn/speed-test'>Speed Guide</a> for more information.",
    altText: ' ',
    logo: 'https://webkit.org/demos/srcset/image-2x.png',
  },
  nbnStepsContent: {
    steps: [
      {
        description: '&lt;h2&gt;Enter your address to see what plans are available for you&lt;/h2&gt;',
        title: 'Step 1',
      },
      {
        description:
          "&lt;h2&gt;Choose your nbn Plan&lt;/h2&gt;&lt;p&gt;Not sure what you&#39;re looking for? &lt;a href='https://www.vodafone.com.au/nbn' target='_blank'&gt;Find out more about nbn speeds&lt;/a&gt;&lt;/p&gt;",
        title: 'Step 2',
      },
    ],
  },
  nbnTncsContent: mockNbnTermsAndConditions,
  nbnFaqContent: mockNbnFaq,
} as NbnPageResponse;

export const mockNbnPlans: NbnPlan[] = [
  {
    discountedRecurringCharge: 50,
    planId: 'AU11972',
    order: 1,
    planName: '$59 Essential nbn plan',
    customPlanName: 'nbn&trade 25',
    planDescription: 'Essential nbn&trade; plan',
    planTenure: 'Month to month',
    planTitle: 'Unlimited data',
    subHeadingPrimary: 'per month',
    subHeadingSecondary: 'Data in Oz',
    ctaLabel: 'Select this plan',
    ctaDisabledLabel: '',
    ctaSelectedLabel: 'Plan selected',
    heroLabel: 'Our Pick',
    heroOfferId: '',
    cisLabel: 'Summary Label',
    cisUrl: '',
    factSheetLabel: '',
    factSheetUrl: '',
    planExtraInfo: '',
    planImage: {
      altText: 'Alt text',
      imageUrl:
        '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/0274_FoundationRefresh_HelloSundayLogo.png',
    },
    inclusions: [
      {
        description: 'Change plan any time with no fees.',
        planId: '',
        title: '-',
        iconUrl: '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/ic_tick_solved_green.png',
      },
      {
        description:
          '30 days to decide if you love our network with our 30 Day Network Satisfaction Guarantee. New connections only. T&C apply.',
        planId: 'AU11972',
        title: '-',
        iconUrl: '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/ic_tick_solved_green.png',
      },
    ],
    recurringCharge: 59,
    planProductName: '$59 Essential nbn™ Plan',
    planSubType: 'NBN Modem M2M',
    contractTerm: 1,
    withModem: true,
    connectionSpeed: '25',
    planData: 'Unlimited',
    promotions: [],
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
  },
  {
    discountedRecurringCharge: 50,
    planId: 'AU11959',
    order: 2,
    planName: 'Essential+ nbn plan',
    customPlanName: 'nbn&trade 50',
    planDescription: 'Essential nbn&trade; plan',
    planTenure: '12 months',
    planTitle: 'Endless Data',
    subHeadingPrimary: 'per month',
    subHeadingSecondary: 'Data in OZ',
    ctaLabel: 'Select this plan',
    ctaDisabledLabel: '',
    ctaSelectedLabel: 'Plan selected',
    heroLabel: 'Our Pick',
    heroOfferId: 'PROMO_UNLMTD_IDD_STDNT',
    cisLabel: 'Summary Label',
    cisUrl: '',
    factSheetLabel: 'sheet_label',
    factSheetUrl: '',
    planExtraInfo: 'standard+ Evening speed',
    planImage: {
      altText: '',
      imageUrl: '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/0355_PipeAboutPage-icon-4g.png',
    },
    inclusions: [
      {
        description: 'Change plan any time with no fees.',
        planId: '',
        title: '-',
        iconUrl: '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/ic_tick_solved_green.png',
      },
      {
        description:
          '30 days to decide if you love our network with our 30 Day Network Satisfaction Guarantee. New connections only. T&C apply.',
        planId: 'AU11972',
        title: '-',
        iconUrl: '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/ic_tick_solved_green.png',
      },
    ],
    recurringCharge: 69,
    planProductName: '$69 Essential+ nbn™ Plan',
    planSubType: 'NBN Modem M2M',
    contractTerm: 1,
    withModem: true,
    connectionSpeed: '50',
    planData: 'Unlimited',
    promotions: mockPromotions,
    isBundleAndSaveEligible: true,
    isTrialPlan: false,
  },
  {
    discountedRecurringCharge: 50,
    planId: 'AU11960',
    order: 3,
    planName: 'Premium nbn plan',
    customPlanName: 'nbn&trade 100',
    planDescription: 'Essential nbn&trade; plan',
    planTenure: '12 months',
    planTitle: 'Endless Data',
    subHeadingPrimary: '12 months',
    subHeadingSecondary: 'Data in Oz',
    ctaLabel: 'Select this plan',
    ctaDisabledLabel: '',
    ctaSelectedLabel: 'Plan selected',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Summary Label',
    cisUrl: '',
    factSheetLabel: 'label_2',
    factSheetUrl: '',
    planExtraInfo: 'standard+ Evening speed_1',
    planImage: {
      altText: 'Plan image',
      imageUrl:
        '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/0274_FoundationRefresh_HelloSundayLogo.png',
    },
    inclusions: [
      {
        description: 'Change plan any time with no fees.',
        planId: '',
        title: '-',
        iconUrl: '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/ic_tick_solved_green.png',
      },
      {
        description:
          '30 days to decide if you love our network with our 30 Day Network Satisfaction Guarantee. New connections only. T&C apply.',
        planId: 'AU11972',
        title: '-',
        iconUrl: '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/ic_tick_solved_green.png',
      },
    ],
    recurringCharge: 89,
    planProductName: '$95 Premium nbn™ Plan',
    planSubType: 'NBN Modem M2M',
    contractTerm: 1,
    withModem: true,
    connectionSpeed: '100',
    planData: 'Unlimited',
    promotions: mockPromotions,
    isBundleAndSaveEligible: true,
    isTrialPlan: false,
  },
  {
    discountedRecurringCharge: 50,
    planId: 'AU12054',
    order: 4,
    planName: 'BYO - Essential + nbn plan',
    customPlanName: 'nbn&trade 50',
    planDescription: 'Essential nbn&trade; plan',
    planTenure: '12 Months',
    planTitle: 'Endless Data',
    subHeadingPrimary: 'per month',
    subHeadingSecondary: 'Data plus',
    ctaLabel: 'Select this Plan',
    ctaDisabledLabel: '',
    ctaSelectedLabel: 'Plan selected',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Summary Label',
    cisUrl: '',
    factSheetLabel: 'label_2',
    factSheetUrl: '',
    planExtraInfo: '',
    planImage: {
      altText: 'Plan Image',
      imageUrl: '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/0339_SegmentsABtest-Families2.png',
    },
    inclusions: [
      {
        description: 'Change plan any time with no fees.',
        planId: '',
        title: '-',
        iconUrl: '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/ic_tick_solved_green.png',
      },
      {
        description:
          '30 days to decide if you love our network with our 30 Day Network Satisfaction Guarantee. New connections only. T&C apply.',
        planId: 'AU11972',
        title: '-',
        iconUrl: '//st01-publish.test.cms.df.services.vodafone.com.au/content/dam/vha/ic_tick_solved_green.png',
      },
    ],
    recurringCharge: 69,
    planProductName: '$69 Essential+ nbn™ BYO Plan',
    planSubType: 'NBN Modem M2M',
    contractTerm: 1,
    withModem: false,
    connectionSpeed: '50',
    planData: 'Unlimited',
    promotions: [],
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
  },
];

export const mockNbnPlanListing = {
  planListing: { plans: mockNbnPlans },
} as NbnPlansResponse;

export const mockOffers: OfferItem[] = [
  {
    title: '$468 Loyalty Discount off your plan cost',
    description:
      "Includes a $468 Loyalty Discount off your plan fees. A loyalty discount is applied for new and existing when you stay with us for a longer repayment term. That's a saving of $13 per month over 36 months. Loyalty Discount ends after device repayment period. T&C apply.",
    code: 'promo_code_111',
    iconUrl: '',
  },
  {
    title: 'Bonus 15GB data',
    description:
      'Includes 15GB/mth bonus data for use in Oz when you sign up to this plan with the Pixel 3 128GB. OFfer ends 03/09/19. T&C apply.',
    code: 'promo_code_112',
    iconUrl: '',
  },
  {
    title: 'Get 1 month free plan fees',
    description:
      "Includes a $468 Loyalty Discount off your plan fees. A loyalty discount is applied for new and existing when you stay with us for a longer repayment term. That's a saving of $13 per month over 36 months. Loyalty Discount ends after device repayment period. T&C apply",
    code: 'promo_code_113',
    iconUrl: '',
  },
];

export const mockPlanListingApiResponse: PlansPageResponse = {
  pageHeaderData: mockHeaderData,
  offers: {
    analyticsAttribute: '',
    disableAnalytics: true,
    offersList: mockOffers,
    numberOfOffers: 3,
  },
  faqs: mockFaq,
  catalogCode: CatalogCode.POSTPAID_HANDSET_PLANS,
  termsAndConditions: mockTermsAndConditions,
  planListing: mockPlanListing,
};

export const mockUpliftedDarkTheme: Theme = {
  breakpoints: {
    xs: 340,
    s: 640,
    m: 768,
    l: 1024,
    xl: 1440,
    xxl: 1920,
  },
  colors: {
    red: '#E60000',
    redDark: '#990000',
    greyLight: '#D8D8D8',
    grey: '#4A4D4E',
    greyDark: '#333333',
    white: '#FFFFFF',
    turquoise: '#007C92',
    aquaBlue: '#00B0CA',
    aubergine: '#5E2750',
    redViolet: '#9C2AA0',
    springGreen: '#A8B400',
    lightGreen: '#009900',
    freshOrange: '#EB9700',
    lemonYellow: '#FECB00',
    transparent: 'transparent',
    persianBlue: '#005EA5',
    uiGreen: '#008A00',
    maroon: '#990000',
    darkRed: '#BD0000',
    black: '#000000',
    darkGrey: '#333333',
    anthracite: '#666666',
    midGrey: '#999999',
    platinum: '#AFAFAF',
    silver: '#CCCCCC',
    aluminium: '#EBEBEB',
    lightGrey: '#F4F4F4',
    mainColor: '#333333',
    linkColor: '#333333',
    focusColor: '#00B0CA',
  },
  fonts: {
    regular: "'VodafoneRegular', Arial, sans-serif",
    light: "'VodafoneLight', Arial, sans-serif",
    bold: "'VodafoneRegularBold', Arial, sans-serif",
  },
  fontSizes: {
    heading1: 64,
    heading1Tablet: 56,
    heading1Mobile: 32,
    heading2: 56,
    heading2Tablet: 40,
    heading2Mobile: 28,
    heading3: 40,
    heading3Tablet: 34,
    heading3Mobile: 24,
    heading4: 28,
    heading4Tablet: 24,
    heading4Mobile: 20,
    heading5: 20,
    heading5Tablet: 20,
    heading5Mobile: 18,
    heading6: 18,
    heading6Tablet: 18,
    heading6Mobile: 18,
    heading7: 27,
    button: 20,
    buttonMobile: 18,
    price: 40,
    priceMedium: 22,
    priceSmall: 20,
    priceXSmall: 15,
    base: 16,
    baseSmall: 14,
    baseLarge: 18,
    baseXSmall: 13,
    footnote: 14,
    footnoteMobile: 12,
    priceContainer: 16,
    priceStrikeThroughTitle: 20,
    amountSmall: 20,
    priceSmallText: 14,
    priceLarge: 48,
    priceRegular: 36,
  },
  lineHeights: {
    heading1: 72,
    heading1Tablet: 62,
    heading1Mobile: 40,
    heading2: 62,
    heading2Tablet: 48,
    heading2Mobile: 36,
    heading3: 48,
    heading3Tablet: 40,
    heading3Mobile: 30,
    heading3MobileUplifted: 38,
    heading4: 34,
    heading4Tablet: 30,
    heading4Mobile: 28,
    heading5: 28,
    heading5Tablet: 28,
    heading5Mobile: 24,
    heading6: 20,
    heading6Tablet: 20,
    heading6Mobile: 20,
    heading7: 32,
    button: 28,
    buttonMobile: 24,
    price: 48,
    priceSmall: 28,
    priceXSmall: 24,
    priceMedium: 22,
    base: 22,
    baseSmall: 20,
    baseXSmall: 18,
    baseLarge: 24,
    footnote: 18,
    footnoteMobile: 16,
    priceContainer: 28,
    priceStrikeThroughTitle: 26,
    amountSmall: 24,
    priceSmallText: 15,
    priceLarge: 40,
    priceRegular: 30,
  },
  durations: {
    transition: '250ms',
  },
  sizes: {
    modulePaddingSmallest: 4,
    modulePaddingSmallSmall: 8,
    modulePaddingSemiSmall: 12,
    modulePaddingSmall: 16,
    modulePaddingPromoTiles: 20,
    modulePaddingSmallMedium: 24,
    modulePadding: 32,
    modulePaddingLarge: 48,
    textMaxWidth: 780,
    textMaxWidthTablet: 476,
    containerMaxWidth: 1180,
    videoHeight: 450,
    borderRadius: 6,
  },
  spacing: {
    none: 0,
    xxxs: 8,
    xxs: 16,
    xs: 24,
    s: 32,
    m: 40,
    l: 48,
    xl: 52,
    ml: 55,
    xxl: 60,
    xxxl: 64,
  },
  boxShadows: {
    brand: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    card: '0 3px 10px rgb(0 0 0 / 0.2)',
  },
  zIndex: {
    liveChat: 999998,
    grecaptcha: 999000,
  },
  variants: {
    mainColor: '#333333',
    linkColor: '#FFFFFF',
    hoverColor: '#CCCCCC',
    focusColor: '#007C92',
    backgroundColor: '#5e2750',
    greyBorderColor: '#EBEBEB',
    tableHeaderBackgroundColor: '#F4F4F4',
    tableCellBackgroundColor: '#FFFFFF',
    featuredLinkColor: '#E60000',
    accordionBackgroundColor: '#FFFFFF',
    accordionBoxShadow: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    accordionColor: '#333333',
    accordionIndicatorColor: '#E60000',
    accordionSeparatorColor: '#CCCCCC',
    accordionTitleFontFamily: "'VodafoneRegularBold', Arial, sans-serif",
  },
};

export const mockUpliftedLightTheme: Theme = {
  breakpoints: {
    xs: 340,
    s: 640,
    m: 768,
    l: 1024,
    xl: 1440,
    xxl: 1920,
  },
  colors: {
    red: '#E60000',
    redDark: '#990000',
    greyLight: '#D8D8D8',
    grey: '#4A4D4E',
    greyDark: '#333333',
    white: '#FFFFFF',
    turquoise: '#007C92',
    aquaBlue: '#00B0CA',
    aubergine: '#5E2750',
    redViolet: '#9C2AA0',
    springGreen: '#A8B400',
    lightGreen: '#009900',
    freshOrange: '#EB9700',
    lemonYellow: '#FECB00',
    transparent: 'transparent',
    persianBlue: '#005EA5',
    uiGreen: '#008A00',
    maroon: '#990000',
    darkRed: '#BD0000',
    black: '#000000',
    darkGrey: '#333333',
    anthracite: '#666666',
    midGrey: '#999999',
    platinum: '#AFAFAF',
    silver: '#CCCCCC',
    aluminium: '#EBEBEB',
    lightGrey: '#F4F4F4',
    mainColor: '#333333',
    linkColor: '#333333',
    focusColor: '#00B0CA',
  },
  fonts: {
    regular: "'VodafoneRegular', Arial, sans-serif",
    light: "'VodafoneLight', Arial, sans-serif",
    bold: "'VodafoneRegularBold', Arial, sans-serif",
  },
  fontSizes: {
    heading1: 64,
    heading1Tablet: 56,
    heading1Mobile: 32,
    heading2: 56,
    heading2Tablet: 40,
    heading2Mobile: 28,
    heading3: 40,
    heading3Tablet: 34,
    heading3Mobile: 24,
    heading4: 28,
    heading4Tablet: 24,
    heading4Mobile: 20,
    heading5: 20,
    heading5Tablet: 20,
    heading5Mobile: 18,
    heading6: 18,
    heading6Tablet: 18,
    heading6Mobile: 18,
    heading7: 27,
    button: 20,
    buttonMobile: 18,
    price: 40,
    priceLarge: 48,
    priceRegular: 36,
    priceMedium: 22,
    priceSmall: 20,
    priceXSmall: 15,
    base: 16,
    baseSmall: 14,
    baseLarge: 18,
    baseXSmall: 13,
    footnote: 14,
    footnoteMobile: 12,
    priceContainer: 16,
    priceStrikeThroughTitle: 20,
    amountSmall: 20,
    priceSmallText: 14,
  },
  lineHeights: {
    heading1: 72,
    heading1Tablet: 62,
    heading1Mobile: 40,
    heading2: 62,
    heading2Tablet: 48,
    heading2Mobile: 36,
    heading3: 48,
    heading3Tablet: 40,
    heading3Mobile: 30,
    heading3MobileUplifted: 38,
    heading4: 34,
    heading4Tablet: 30,
    heading4Mobile: 28,
    heading5: 28,
    heading5Tablet: 28,
    heading5Mobile: 24,
    heading6: 20,
    heading6Tablet: 20,
    heading6Mobile: 20,
    heading7: 32,
    button: 28,
    buttonMobile: 24,
    price: 48,
    priceLarge: 40,
    priceSmall: 28,
    priceXSmall: 24,
    priceMedium: 22,
    priceRegular: 30,
    base: 22,
    baseSmall: 20,
    baseXSmall: 18,
    baseLarge: 24,
    footnote: 18,
    footnoteMobile: 16,
    priceContainer: 28,
    priceStrikeThroughTitle: 26,
    amountSmall: 24,
    priceSmallText: 15,
  },
  durations: {
    transition: '250ms',
  },
  sizes: {
    modulePaddingSmallest: 4,
    modulePaddingSmallSmall: 8,
    modulePaddingSemiSmall: 12,
    modulePaddingSmall: 16,
    modulePaddingPromoTiles: 20,
    modulePaddingSmallMedium: 24,
    modulePadding: 32,
    modulePaddingLarge: 48,
    textMaxWidth: 780,
    textMaxWidthTablet: 476,
    containerMaxWidth: 1180,
    videoHeight: 450,
    borderRadius: 6,
  },
  spacing: {
    none: 0,
    xxxs: 8,
    xxs: 16,
    xs: 24,
    s: 32,
    m: 40,
    l: 48,
    xl: 52,
    ml: 55,
    xxl: 60,
    xxxl: 64,
  },
  boxShadows: {
    brand: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    card: '0 3px 10px rgb(0 0 0 / 0.2)',
  },
  zIndex: {
    liveChat: 999998,
    grecaptcha: 999000,
  },
  variants: {
    mainColor: '#333333',
    linkColor: '#333333',
    hoverColor: '#333333',
    focusColor: '#007C92',
    backgroundColor: '#FFFFFF',
    greyBorderColor: '#EBEBEB',
    tableHeaderBackgroundColor: '#F4F4F4',
    tableCellBackgroundColor: '#FFFFFF',
    featuredLinkColor: '#E60000',
    accordionBackgroundColor: '#FFFFFF',
    accordionBoxShadow: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    accordionColor: '#333333',
    accordionIndicatorColor: '#E60000',
    accordionSeparatorColor: '#CCCCCC',
    accordionTitleFontFamily: "'VodafoneRegularBold', Arial, sans-serif",
  },
};

export const mockPrepaidPlanListingApiResponse: PlansPageResponse = {
  pageHeaderData: mockPrepaidHeaderData,
  offers: {
    analyticsAttribute: '',
    disableAnalytics: true,
    offersList: mockOffers,
    numberOfOffers: 2,
  },
  faqs: mockFaq,
  catalogCode: CatalogCode.PREPAID_COMBO_PLUS_PLANS,
  termsAndConditions: mockTermsAndConditions,
  planListing: mockPrepaidPlanListing,
};

export const mockMobilePhoneAndPlanItems: CartItem[] = [
  {
    productCode: 'AU12076',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.HANDSET_M2M_PLUS,
    quantity: 1,
    name: '$65 Red Plus Plan',
    actions: {
      delete: {
        lineItemKey: '',
        bundleContextKey: '',
      },
      update: {
        lineItemKey: '',
        bundleContextKey: '',
      },
    },
    priceInfo: {
      recurringCharge: 65,
      oneTimeCharge: 0,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productConfig: {
      capacity: '',
      color: '',
      contractTerm: '1',
      deviceSku: '',
      orderType: '',
      packageId: '',
    },
    catalogCode: CatalogCode.POSTPAID_HANDSET_PLANS,
    itemType: CartItemType.PLAN,
    relatedContent: {
      planTenure: 'Month to month',
    },
  },
  {
    actions: {
      delete: {
        bundleContextKey: '',
        lineItemKey: '',
      },
      update: {
        bundleContextKey: '',
        lineItemKey: '',
      },
    },
    catalogCode: CatalogCode.POSTPAID_HANDSETS,
    itemType: CartItemType.DEVICE,
    name: 'iPhone XS Max',
    priceInfo: {
      recurringCharge: 49.97,
      oneTimeCharge: 0,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productCode: 'IPH_XS_MAX',
    productConfig: {
      color: 'Silver',
      capacity: '64 GB',
      contractTerm: '36',
      orderType: 'Connect',
      deviceSku: 'MT512X/A',
      packageId: '',
    },
    productSubType: CartProductSubType.HANDSET,
    productType: CartProductType.DEVICE,
    quantity: 1,
    relatedContent: {
      offers: {
        disableAnalytics: false,
        analyticsAttribute: '',
        offersList: [
          {
            code: 'GWP_PXL3a',
            description:
              '10% Off on 7GB Month to Month Data Add On when purchased with $60 SIM Only Month to Month MBB Plan for customers with ABN or ACN, when purchased through CARE channel (Sales Channel = DIRECT or INTERNAL or OL)',
            title: 'Pixel offer',
            iconUrl: '',
          },
          {
            code: '',
            description: '',
            title: '',
            iconUrl: '',
          },
        ],
        numberOfOffers: 2,
      },
      image: {
        altText: '',
        imageUrl: 'https://www.vodafone.com.au/api/mobile/m49943496_iPhoneXs-SpaceGrey-215-front.png',
      },
    },
  },
];

export const mockPrepaidComboPlusSimOnlyItems: CartItem[] = [
  {
    productCode: 'AU12076',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.HANDSET_M2M_PLUS,
    quantity: 1,
    name: '$40 Combo Plus Starter Pack',
    actions: {
      delete: {
        lineItemKey: '',
        bundleContextKey: '',
      },
      update: {
        lineItemKey: '',
        bundleContextKey: '',
      },
    },
    priceInfo: {
      recurringCharge: 0,
      oneTimeCharge: 40,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productConfig: {
      capacity: '',
      color: '',
      contractTerm: '1',
      deviceSku: '',
      orderType: '',
      packageId: '',
    },
    catalogCode: CatalogCode.PREPAID_COMBO_PLUS_PLANS,
    itemType: CartItemType.PLAN,
    relatedContent: {
      image: {
        altText: '',
        imageUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/Cart-vodafone-sim-card-s.png',
      },
    },
  },
];

export const mockPrepaidPayAndGoSimOnlyItems: CartItem[] = [
  {
    productCode: 'AU12076',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.HANDSET_M2M_PLUS,
    quantity: 1,
    name: '$30 Pay and Go Starter Pack',
    actions: {
      delete: {
        lineItemKey: '',
        bundleContextKey: '',
      },
      update: {
        lineItemKey: '',
        bundleContextKey: '',
      },
    },
    priceInfo: {
      recurringCharge: 0,
      oneTimeCharge: 30,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productConfig: {
      capacity: '',
      color: '',
      contractTerm: '35 days expiry',
      deviceSku: '',
      orderType: '',
      packageId: '',
    },
    catalogCode: CatalogCode.PREPAID_PAY_AND_GO_PLANS,
    itemType: CartItemType.PLAN,
    relatedContent: {
      image: {
        altText: '',
        imageUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/Cart-vodafone-sim-card-s.png',
      },
    },
  },
];

export const mockMultiplePrepaidSimOnlyItems: CartItem[] = [
  {
    productCode: 'AU12076',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.HANDSET_M2M_PLUS,
    quantity: 1,
    name: '$40 Combo Plus Starter Pack',
    actions: {
      delete: {
        lineItemKey: '',
        bundleContextKey: '',
      },
      update: {
        lineItemKey: '',
        bundleContextKey: '',
      },
    },
    priceInfo: {
      recurringCharge: 0,
      oneTimeCharge: 40,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productConfig: {
      capacity: '',
      color: '',
      contractTerm: '1',
      deviceSku: '',
      orderType: '',
      packageId: '',
    },
    catalogCode: CatalogCode.PREPAID_COMBO_PLUS_PLANS,
    itemType: CartItemType.PLAN,
    relatedContent: {
      image: {
        altText: '',
        imageUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/Cart-vodafone-sim-card-s.png',
      },
    },
  },
  {
    productCode: 'AU12076',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.HANDSET_M2M_PLUS,
    quantity: 1,
    name: '$30 Pay and Go Starter Pack',
    actions: {
      delete: {
        lineItemKey: '',
        bundleContextKey: '',
      },
      update: {
        lineItemKey: '',
        bundleContextKey: '',
      },
    },
    priceInfo: {
      recurringCharge: 0,
      oneTimeCharge: 30,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productConfig: {
      capacity: '',
      color: '',
      contractTerm: '35',
      deviceSku: '',
      orderType: '',
      packageId: '',
    },
    catalogCode: CatalogCode.PREPAID_PAY_AND_GO_PLANS,
    itemType: CartItemType.PLAN,
    relatedContent: {
      image: {
        altText: '',
        imageUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/Cart-vodafone-sim-card-s.png',
      },
    },
  },
];

export const mockPrepaidMobilePhoneAndPlanItems: CartItem[] = [
  {
    productCode: 'AU12076',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.HANDSET_M2M_PLUS,
    quantity: 1,
    name: '$30 Pay and Go Starter Pack',
    actions: {
      delete: {
        lineItemKey: '',
        bundleContextKey: '',
      },
      update: {
        lineItemKey: '',
        bundleContextKey: '',
      },
    },
    priceInfo: {
      recurringCharge: 0,
      oneTimeCharge: 30,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productConfig: {
      capacity: '',
      color: '',
      contractTerm: '',
      deviceSku: '',
      orderType: '',
      packageId: '',
    },
    catalogCode: CatalogCode.PREPAID_COMBO_PLUS_PLANS,
    itemType: CartItemType.PLAN,
    relatedContent: {},
  },
  {
    actions: {
      delete: {
        bundleContextKey: '',
        lineItemKey: '',
      },
      update: {
        bundleContextKey: '',
        lineItemKey: '',
      },
    },
    catalogCode: CatalogCode.PREPAID_PAY_AND_GO_PLANS,
    itemType: CartItemType.DEVICE,
    name: 'iPhone XS Max',
    priceInfo: {
      recurringCharge: 49.97,
      oneTimeCharge: 0,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productCode: 'IPH_XS_MAX',
    productConfig: {
      color: 'Silver',
      capacity: '64 GB',
      contractTerm: '36',
      orderType: 'Connect',
      deviceSku: 'MT512X/A',
      packageId: '',
    },
    productSubType: CartProductSubType.HANDSET,
    productType: CartProductType.DEVICE,
    quantity: 1,
    relatedContent: {
      offers: {
        disableAnalytics: false,
        analyticsAttribute: '',
        numberOfOffers: 2,
        offersList: [
          {
            code: 'GWP_PXL3a',
            description:
              '10% Off on 7GB Month to Month Data Add On when purchased with $60 SIM Only Month to Month MBB Plan for customers with ABN or ACN, when purchased through CARE channel (Sales Channel = DIRECT or INTERNAL or OL)',
            title: 'Pixel offer',
            iconUrl:
              'https://sit01-dispatcher.test.cms.df.services.vodafone.com.au/content/dam/vha/images/icons/like.svg',
          },
          {
            code: '',
            description: '',
            title: '',
            iconUrl: '',
          },
        ],
      },
      image: {
        altText: '',
        imageUrl:
          'https://sit01-dispatcher.test.cms.df.services.vodafone.com.au/content/dam/vha/images/devices/apple/iPhone-XS-Max-Silver-Front-L.jpg',
      },
    },
  },
];

export const mockMixedMobilePhoneAndPlanItems: CartItem[] = [
  {
    productCode: 'AU12076',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.HANDSET_M2M_PLUS,
    quantity: 1,
    name: '$65 Red Plus Plan',
    actions: {
      delete: {
        lineItemKey: '',
        bundleContextKey: '',
      },
      update: {
        lineItemKey: '',
        bundleContextKey: '',
      },
    },
    priceInfo: {
      recurringCharge: 65,
      oneTimeCharge: 0,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productConfig: {
      capacity: '',
      color: '',
      contractTerm: '1',
      deviceSku: '',
      orderType: '',
      packageId: '',
    },
    catalogCode: CatalogCode.POSTPAID_HANDSET_PLANS,
    itemType: CartItemType.PLAN,
    relatedContent: {
      planTenure: 'Month to month',
    },
  },
  {
    actions: {
      delete: {
        bundleContextKey: '',
        lineItemKey: '',
      },
      update: {
        bundleContextKey: '',
        lineItemKey: '',
      },
    },
    catalogCode: CatalogCode.POSTPAID_HANDSETS,
    itemType: CartItemType.DEVICE,
    name: 'iPhone XS Max',
    priceInfo: {
      recurringCharge: 49.97,
      oneTimeCharge: 0,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productCode: 'IPH_XS_MAX',
    productConfig: {
      color: 'Silver',
      capacity: '64 GB',
      contractTerm: '36',
      orderType: 'Connect',
      deviceSku: 'MT512X/A',
      packageId: '',
    },
    productSubType: CartProductSubType.HANDSET,
    productType: CartProductType.DEVICE,
    quantity: 1,
    relatedContent: {
      offers: {
        disableAnalytics: false,
        analyticsAttribute: '',
        offersList: [
          {
            code: 'GWP_PXL3a',
            description:
              '10% Off on 7GB Month to Month Data Add On when purchased with $60 SIM Only Month to Month MBB Plan for customers with ABN or ACN, when purchased through CARE channel (Sales Channel = DIRECT or INTERNAL or OL)',
            title: 'Pixel offer',
            iconUrl: '',
          },
          {
            code: '',
            description: '',
            title: '',
            iconUrl: '',
          },
        ],
        numberOfOffers: 2,
      },
      image: {
        altText: '',
        imageUrl: 'https://www.vodafone.com.au/api/mobile/m49943496_iPhoneXs-SpaceGrey-215-front.png',
      },
    },
  },
  {
    productCode: 'AU12076',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.HANDSET_M2M_PLUS,
    quantity: 1,
    name: '$65 Red Plus Plan',
    actions: {
      delete: {
        lineItemKey: '',
        bundleContextKey: '',
      },
      update: {
        lineItemKey: '',
        bundleContextKey: '',
      },
    },
    priceInfo: {
      recurringCharge: 65,
      oneTimeCharge: 0,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productConfig: {
      capacity: '',
      color: '',
      contractTerm: '1',
      deviceSku: '',
      orderType: '',
      packageId: '',
    },
    catalogCode: CatalogCode.PREPAID_COMBO_PLUS_PLANS,
    itemType: CartItemType.PLAN,
    relatedContent: {},
  },
  {
    actions: {
      delete: {
        bundleContextKey: '',
        lineItemKey: '',
      },
      update: {
        bundleContextKey: '',
        lineItemKey: '',
      },
    },
    catalogCode: CatalogCode.PREPAID_PAY_AND_GO_PLANS,
    itemType: CartItemType.DEVICE,
    name: 'iPhone XS Max',
    priceInfo: {
      recurringCharge: 49.97,
      oneTimeCharge: 0,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productCode: 'IPH_XS_MAX',
    productConfig: {
      color: 'Silver',
      capacity: '64 GB',
      contractTerm: '36',
      orderType: 'Connect',
      deviceSku: 'MT512X/A',
      packageId: '',
    },
    productSubType: CartProductSubType.HANDSET,
    productType: CartProductType.DEVICE,
    quantity: 1,
    relatedContent: {
      offers: {
        disableAnalytics: false,
        analyticsAttribute: '',
        numberOfOffers: 2,
        offersList: [
          {
            code: 'GWP_PXL3a',
            description:
              '10% Off on 7GB Month to Month Data Add On when purchased with $60 SIM Only Month to Month MBB Plan for customers with ABN or ACN, when purchased through CARE channel (Sales Channel = DIRECT or INTERNAL or OL)',
            title: 'Pixel offer',
            iconUrl:
              'https://sit01-dispatcher.test.cms.df.services.vodafone.com.au/content/dam/vha/images/icons/like.svg',
          },
          {
            code: '',
            description: '',
            title: '',
            iconUrl: '',
          },
        ],
      },
      image: {
        altText: '',
        imageUrl:
          'https://sit01-dispatcher.test.cms.df.services.vodafone.com.au/content/dam/vha/images/devices/apple/iPhone-XS-Max-Silver-Front-L.jpg',
      },
    },
  },
];

export const mockMobilePhoneAndPlanBasketItems: BasketItem[] = [
  {
    catalogCode: CatalogCode.POSTPAID_HANDSETS,
    itemType: CartItemType.DEVICE,
    packageId: '1',
    priceInfo: {
      recurringCharge: 33.31,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 33.31,
    },
    promotions: [
      {
        promotionExpired: false,
        promotionCode: '$5_CREDIT_$50_01_APR_20',
        title: '$60 Credit to You over 12 mths',
        description:
          "&lt;p&gt;Save $60 over 12 months when you sign up to this plan. That's $5/mth off plan fees for 12 months. Excludes rate plan change. Offer ends 2020-10-30T13:00:00.000Z unless extended. T&amp;amp;C apply.&lt;/p&gt;",
        iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/redeemed-unlocked-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
      {
        description: "&lt;p&gt;That's a saving of 10 per month over 36 months. RRP $1248.84.&lt;/p&gt;",
        iconUrl: 'https://www-dit.test.cms.df.services.vodafone.com.au/images/icons/dollar-sign.svg',
        promotionCode: 'PROMO_SDD_VOICE_HANDSET_DISPLAY',
        promotionExpired: false,
        title: "Save 360 on this phone's RRP",
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    productCode: 'IPH_11',
    productConfig: {
      capacity: '64GB',
      color: 'Purple',
      contractTerm: '36 months',
      deviceSku: 'MWLX2X/A',
      orderType: 'Connect',
    },
    productName: 'iPhone 11',
    productSubType: CartProductSubType.HANDSET,
    productType: CartProductType.DEVICE,
    productExpired: false,
    productConfigChanged: false,
    relatedContent: {
      image: {
        altText: 'iPhone 11',
        useInCart: true,
        imageUrl:
          'https://www-prod.prod.cms.df.services.vodafone.com.au/images/devices/apple/iphone-11/iphone-11-purple-front-s.png',
      },
      offers: {
        disableAnalytics: false,
        analyticsAttribute: '',
        offersList: [
          {
            code: 'PROMO_5_PCT_OFF_BUNDLE_AND_SAVE',
            description:
              '&lt;p&gt;Bundle this plan with other eligible plans under one account and save on all plan fees. T&amp;amp;C apply. &lt;a href=&quot;https://www-prod.prod.cms.df.services.vodafone.com.au/plans/bundle&quot;&gt;Find out more&lt;/a&gt;.&lt;/p&gt;',
            title: 'Bundle & Save',
            iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/redeemed-unlocked-rewards.svg',
          },
          {
            code: 'POC_15OFF_50COMBO PLUS',
            description:
              '&lt;p&gt;Code [15OFFCOMBOPLUS50] applied. You&rsquo;ll get $15 off the $50 Combo Plus Starter Pack. T&amp;amp;C apply.&lt;/p&gt;',
            title: 'Promotional Offer',
            iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/redeemed-unlocked-rewards.svg',
          },
        ],
        numberOfOffers: 20,
      },
    },
  },
  {
    catalogCode: CatalogCode.POSTPAID_HANDSET_PLANS,
    itemType: CartItemType.PLAN,
    packageId: '1',
    priceInfo: {
      recurringCharge: 40,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 40,
    },
    productCode: 'SAM2014',
    productConfig: {
      contractTerm: '1',
    },
    promotions: [
      {
        promotionExpired: false,
        promotionCode: 'PROMO_5_PCT_OFF_BUNDLE_AND_SAVE',
        title: 'Bundle & Save',
        description:
          '&lt;p&gt;Bundle this Unlimited plan with other eligible plans under one account and save on all plan fees. T&amp;amp;C apply. &lt;a href=&quot;www.vodafone.com.au/doc/cis/mobileplans/au12139_au12142_au12266/aug2020.pdf&quot;&gt;Find out more&lt;/a&gt;.&lt;/p&gt;',
        iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/redeemed-unlocked-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    productExpired: false,
    productConfigChanged: false,
    productName: '$40 Red Plus Plan',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.HANDSET_M2M_PLUS,
    relatedContent: {
      planTenure: 'Month to month',
      planTitle: 'Endless data',
      planData: '10GB',
      subHeadingPrimary: 'data in Oz',
      subHeadingSecondary: 'per month',
      cisLabel: 'Critical Infomation Summary',
      planExtraInfo: '',
      image: {
        imageUrl: '',
        altText: '$40 Red Plus Plan',
      },
      inclusions: [
        {
          description:
            'Get 10GB data at Your Max Speed, then keep using data in Oz at &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;maxspeed&quot; style=&quot;color: black;&quot;&gt;speeds of up to 1.5Mbps&lt;/vha-modal-trigger&gt;.',
          planId: '',
          title: '10GB Endless data',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;Unlimited standard national calls and text, and unlimited&amp;nbsp;&lt;span&gt;standard international SMS.&lt;/span&gt;&lt;/p&gt;',
          planId: '',
          title: 'Standard national calls and texts',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;Tethering permitted but for personal devices only and not as a substitute for a home internet service.&lt;/p&gt;',
          planId: '',
          title: 'Tethering',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
      ],
      planName: '$40 Red Plus Plan',
      planDescription:
        '&lt;p&gt;Get 10GB data at Your Max Speed, then keep using data in Oz at speeds of up to 1.5Mbps.&lt;/p&gt;',
    },
    isBundleSaveEligible: true,
  } as PlanBasketItem,
];

export const mockMobilePhoneAndPlanBundle: BasketPackage = {
  items: mockMobilePhoneAndPlanBasketItems,
  packageId: '1',
};

export const mockMobilePhoneBasketRequestItems: BasketRequestItem[] = [
  {
    catalogCode: CatalogCode.POSTPAID_HANDSETS,
    childProducts: [],
    itemType: CartItemType.DEVICE,
    matrixRowKey: '0beb923515e014443d4b8b43685c16fb',
    productName: 'iPhone 11',
    packageId: '1',
    priceInfo: {
      recurringCharge: 33.31,
    },
    productSubType: CartProductSubType.HANDSET,
    productType: CartProductType.DEVICE,
    productCode: 'IPH_11',
    productConfig: {
      capacity: '64GB',
      color: 'Purple',
      contractTerm: '36 months',
      deviceSku: 'MWLX2X/A',
      orderType: 'Connect',
    },
  },
];

export const mockMobilePhoneAndPlanBasketRequestItems: BasketRequestItem[] = [
  {
    catalogCode: CatalogCode.POSTPAID_HANDSETS,
    childProducts: [],
    itemType: CartItemType.DEVICE,
    matrixRowKey: '0beb923515e014443d4b8b43685c16fb',
    productName: 'iPhone 11',
    packageId: '1',
    priceInfo: {
      recurringCharge: 33.31,
    },
    productSubType: CartProductSubType.HANDSET,
    productType: CartProductType.DEVICE,
    productCode: 'IPH_11',
    productConfig: {
      capacity: '64GB',
      color: 'Purple',
      contractTerm: '36 months',
      deviceSku: 'MWLX2X/A',
      orderType: 'Connect',
    },
  },
  {
    catalogCode: CatalogCode.POSTPAID_HANDSET_PLANS,
    childProducts: [],
    itemType: CartItemType.PLAN,
    packageId: '1',
    priceInfo: {
      recurringCharge: 41,
      originalRecurringCharge: 50,
    },
    productCode: 'AU12139',
    productConfig: {
      contractTerm: '1',
    },
    productName: '$40 Red Plus Plan',
    productType: CartProductType.PLAN_VOICE,
    hideWasLabel: false,
  },
];

export const mockNbnPlanAndModemBasketRequestItems: BasketRequestItem[] = [
  {
    catalogCode: CatalogCode.NBN_PLANS,
    productCode: 'AU12312',
    childProducts: [
      {
        catalogCode: CatalogCode.NBN_MODEMS,
        itemType: CartItemType.MODEM,
        packageId: '',
        priceInfo: {
          recurringCharge: 7.5,
          adjustedMRCAmount: 0,
        },
        productCode: 'BVODWIFIHUB2',
        productConfig: {
          contractTerm: '24',
        },
        productName: '&lt;div&gt;Vodafone Wi-Fi Hub&trade; 2.0&lt;/div&gt;',
        productType: CartProductType.DEVICE,
        productSubType: CartProductSubType.NBN_MODEM,
      },
    ],
    itemType: CartItemType.PLAN,
    packageId: '',
    priceInfo: {
      recurringCharge: 75,
      adjustedMRCAmount: 75,
    },
    productConfig: {
      contractTerm: '1',
    },
    productName: 'Essential nbn™ plan',
    productType: CartProductType.PLAN_FIXED,
    asdSubCopy: 'mock asd sub copy',
  },
];

export const mockTabletAndPlanCart: Basket = {
  basketId:
    'CC95HYYTVAqibWEZW0A3XWjPs3Cd2YAfW5Y_V-R3NV8.e-jM-c_tsHTSoNWSt4midsNmFglkhFhZ7iqbJ3g3rkzKMiCQs2Lhcdz9xSzPhqJe',
  packages: [
    {
      items: [
        {
          productCode: 'SAM_GAL_TAB_A7',
          catalogCode: CatalogCode.POSTPAID_TABLET,
          productName: 'Samsung Galaxy Tab A7 4G',
          productType: CartProductType.DEVICE,
          productSubType: CartProductSubType.TABLET,
          itemType: CartItemType.TABLET,
          productConfig: {
            color: 'Dark Gray',
            capacity: '32GB',
            contractTerm: '36 months',
            orderType: 'Connect',
            deviceSku: 'HSAMGTA732G',
          },
          priceInfo: {
            recurringCharge: 14.69,
            oneTimeCharge: 0,
            nrcPriceAdjustment: 0,
            adjustedNRCAmount: 0,
            adjustedMRCAmount: 14.69,
            nrcPercentDiscount: 0,
          },
          promotions: [],
          relatedContent: {
            image: {
              altText: ' Samsung Galaxy Tab A7 4G Front',
              useInCart: true,
              imageUrl:
                'https://www-sit.test.cms.df.services.vodafone.com.au/images/devices/samsung/samsung-galaxy-tab-a7-2020/samsung-galaxy-tab-a7-dark-gray-front-s.png',
            },
            heroOfferId: '',
          },
          productConfigChanged: false,
          productExpired: false,
          packageId: '1',
        },
        {
          productCode: 'AU12230',
          catalogCode: CatalogCode.POSTPAID_TABLET_PLANS,
          productName: '$45 Red Tablet Plus Plan',
          productType: CartProductType.PLAN_MBB,
          productSubType: ProductSubType.MBB_M2M_PLUS,
          itemType: CartItemType.PLAN,
          productConfig: {
            contractTerm: '1',
            dataLimit: DataLimit.UNLIMITED,
          },
          priceInfo: {
            recurringCharge: 45,
            oneTimeCharge: 0,
            nrcPriceAdjustment: 0,
            adjustedNRCAmount: 0,
            adjustedMRCAmount: 45,
            nrcPercentDiscount: 0,
          },
          cisUrl: 'https://www.vodafone.com.au/doc/cis/mobilebroadbandplans/au12228_au12231/nov2020.pdf',
          promotions: [],
          relatedContent: {
            planTenure: 'Month to month',
            planTitle: 'Endless data',
            planData: '60GB',
            subHeadingPrimary: 'data in Oz',
            subHeadingSecondary: 'per month',
            cisLabel: 'Critical Information Summary',
            planExtraInfo: '',
            image: {
              imageUrl: '',
              altText: '',
            },
            heroOfferId: '',
            inclusions: [
              {
                description:
                  '&lt;p&gt;Get 60GB data at Your Max Speed, then keep using data in Oz at &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;tabletsmaxspeed&quot;&gt;speeds of up to 1.5Mbps&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
                planId: '',
                title: 'Endless data',
                iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
              },
              {
                description: '&lt;p&gt;Share Your Max Speed data with other Plus Plans. T&amp;amp;C apply.&lt;/p&gt;',
                planId: '',
                title: 'Share your data',
                iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
              },
            ],
            planName: 'Red Tablet Plus Plan',
            planDescription:
              '&lt;p&gt;Get 60GB&nbsp;Max Speed data, then keep using data in Oz at speeds of up to 1.5Mbps.&lt;/p&gt;',
            hasDataOverride: false,
          },
          productConfigChanged: false,
          productExpired: false,
          packageId: '2',
        },
      ],
      packageId: '1',
    },
  ],
  totalPrice: {
    recurringCharge: 59.69,
    oneTimeCharge: 0,
  },
  bundleAndSaveApplied: false,
};

export const mockMobilePhoneAndPlanCart: Basket = {
  basketId:
    'w-ig_WpvQq65uPhRp3WaXj6kl2LQYV4jFeIow4Tbqtw.OcFg0d5WOTFJEkGNUMJ3olO2O33V-2tfjMyB81jLTeltPUHNvVkkGpl-XWtn0WfW',
  bundleAndSaveApplied: false,
  packages: [
    {
      items: [
        {
          productCode: 'SAM2014',
          catalogCode: CatalogCode.POSTPAID_HANDSET_INSURANCE_PLANS,
          productName: 'Keep Talking Plus',
          productType: CartProductType.INSURANCE,
          productSubType: CartProductSubType.INSURANCE,
          itemType: CartItemType.EXTRA,
          productConfig: {
            contractTerm: '1',
          },
          productExpired: false,
          productConfigChanged: false,
          priceInfo: {
            recurringCharge: 15,
            oneTimeCharge: 0,
            nrcPriceAdjustment: 0,
            nrcPercentDiscount: 0,
            adjustedNRCAmount: 0,
            adjustedMRCAmount: 15,
          },
          relatedContent: {
            image: {
              altText: '',
              imageUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/security-camera-mid.svg',
            },
            pdsLinkLabel: 'Combined Financial Services Guide and Product Disclosure Statement',
          },
          packageId: '1',
        },
        {
          productCode: 'AU12139',
          catalogCode: CatalogCode.POSTPAID_HANDSET_PLANS,
          productName: '$40 Red Plus Plan',
          productType: CartProductType.PLAN_VOICE,
          productSubType: CartProductSubType.HANDSET_M2M_PLUS,
          itemType: CartItemType.PLAN,
          productConfig: {
            contractTerm: '1',
          },
          productExpired: false,
          productConfigChanged: false,
          priceInfo: {
            recurringCharge: 40,
            oneTimeCharge: 0,
            nrcPriceAdjustment: 0,
            nrcPercentDiscount: 0,
            adjustedNRCAmount: 0,
            adjustedMRCAmount: 40,
          },
          relatedContent: {
            planTenure: 'Month to month',
            planTitle: 'Endless data',
            planData: '10GB',
            subHeadingPrimary: 'data in Oz',
            subHeadingSecondary: 'per month',
            cisLabel: 'Critical Infomation Summary',
            planExtraInfo: '',
            image: {
              imageUrl: '',
              altText: '$40 Red Plus Plan',
            },
            inclusions: [
              {
                description:
                  'Get 10GB data at Your Max Speed, then keep using data in Oz at &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;maxspeed&quot; style=&quot;color: black;&quot;&gt;speeds of up to 1.5Mbps&lt;/vha-modal-trigger&gt;.',
                planId: '',
                title: '10GB Endless data',
                iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
              },
              {
                description:
                  '&lt;p&gt;Unlimited standard national calls and text, and unlimited&amp;nbsp;&lt;span&gt;standard international SMS.&lt;/span&gt;&lt;/p&gt;',
                planId: '',
                title: 'Standard national calls and texts',
                iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
              },
              {
                description:
                  '&lt;p&gt;Tethering permitted but for personal devices only and not as a substitute for a home internet service.&lt;/p&gt;',
                planId: '',
                title: 'Tethering',
                iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
              },
            ],
            planName: 'Red Plus Plan',
            planDescription:
              '&lt;p&gt;Get 10GB data at Your Max Speed, then keep using data in Oz at speeds of up to 1.5Mbps.&lt;/p&gt;',
          },
          packageId: '1',
        },
        {
          productCode: 'IPH_11',
          catalogCode: CatalogCode.POSTPAID_HANDSETS,
          productName: 'iPhone 11',
          productType: CartProductType.DEVICE,
          productSubType: CartProductSubType.HANDSET,
          itemType: CartItemType.DEVICE,
          productConfig: {
            color: 'Purple',
            capacity: '64GB',
            contractTerm: '36',
            orderType: 'Connect',
            deviceSku: 'MWLX2X/A',
          },
          productExpired: false,
          productConfigChanged: false,
          priceInfo: {
            recurringCharge: 33.31,
            oneTimeCharge: 0,
            nrcPriceAdjustment: 0,
            nrcPercentDiscount: 0,
            adjustedNRCAmount: 0,
            adjustedMRCAmount: 33.31,
          },
          relatedContent: {
            image: {
              altText: 'iPhone 11',
              useInCart: true,
              imageUrl:
                'https://www-prod.prod.cms.df.services.vodafone.com.au/images/devices/apple/iphone-11/iphone-11-purple-front-s.png',
            },
            offers: {
              disableAnalytics: false,
              analyticsAttribute: '',
              offersList: [
                {
                  code: 'PROMO_5_PCT_OFF_BUNDLE_AND_SAVE',
                  description:
                    '&lt;p&gt;Bundle this plan with other eligible plans under one account and save on all plan fees. T&amp;amp;C apply. &lt;a href=&quot;https://www-prod.prod.cms.df.services.vodafone.com.au/plans/bundle&quot;&gt;Find out more&lt;/a&gt;.&lt;/p&gt;',
                  title: 'Bundle & Save',
                  iconUrl:
                    'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/redeemed-unlocked-rewards.svg',
                },
                {
                  code: 'POC_15OFF_50COMBO PLUS',
                  description:
                    '&lt;p&gt;Code [15OFFCOMBOPLUS50] applied. You&rsquo;ll get $15 off the $50 Combo Plus Starter Pack. T&amp;amp;C apply.&lt;/p&gt;',
                  title: 'Promotional Offer',
                  iconUrl:
                    'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/redeemed-unlocked-rewards.svg',
                },
              ],
              numberOfOffers: 20,
            },
          },
          packageId: '1',
        },
      ],
      packageId: '1',
    },
  ],
  totalPrice: {
    recurringCharge: 88.31,
    oneTimeCharge: 0,
  },
};

export const mockMobilePhoneAndPlanCartWithRaf: Basket = {
  ...mockMobilePhoneAndPlanCart,
  raf: {
    discountAmount: 60,
    appliedCatalogCode: 'CATPOSTPAIDHANDSETPLANS' as CatalogCode,
    rafCode: 'RAF000017',
    isValid: true,
  },
};

export const mockNbnPlanAndDeviceBasketItems: (BasketItem | NbnPlanBasketItem)[] = [
  {
    productCode: 'AU12152',
    catalogCode: CatalogCode.NBN_PLANS,
    productName: '$75 Essential+ nbn™ Plan',
    productType: CartProductType.PLAN_FIXED,
    productSubType: CartProductSubType.NBN_MODEM_M2M,
    itemType: CartItemType.PLAN,
    productConfig: {
      contractTerm: '1',
    },
    priceInfo: {
      recurringCharge: 75,
      oneTimeCharge: 0,
      nrcPriceAdjustment: -10,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 65,
    },
    cisUrl: 'https://www.vodafone.com.au/doc/cis/nbnplans/au12256_au12257/jul2020.pdf',
    factSheetUrl: 'https://www.vodafone.com.au/doc/kfs/nbnplans/jul2020.pdf',
    promotions: [
      {
        promotionExpired: false,
        promotionCode: '$10_NBN_6M_6_MAY_20_01',
        title: '$10 off monthly plan fees for 6 months',
        description:
          '&lt;p&gt;Get a $10/mth discount on plan fees for 6 months when you sign up to this plan. Offer ends 2999-12-31T23:59:59.000Z unless extended. T&amp;amp;C apply.&lt;/p&gt;',
        iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/redeemed-unlocked-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
      {
        promotionExpired: false,
        promotionCode: 'PROMO_5_PCT_OFF_BUNDLE_AND_SAVE',
        title: 'Bundle & Save',
        description:
          '&lt;p&gt;Bundle this Unlimited plan with other eligible plans under one account and save on all plan fees. T&amp;amp;C apply. &lt;a href=&quot;www.vodafone.com.au/doc/cis/mobileplans/au12139_au12142_au12266/aug2020.pdf&quot;&gt;Find out more&lt;/a&gt;.&lt;/p&gt;',
        iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/redeemed-unlocked-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    relatedContent: {
      planTenure: 'Month to month',
      planTitle: 'Unlimited data',
      planData: 'Unlimited',
      subHeadingPrimary: 'Typical Evening Speed 40Mbps (7pm-11pm)',
      subHeadingSecondary: 'per month',
      cisLabel: 'Critical Infomation Summary',
      planExtraInfo: 'Standard Evening Speed',
      image: {
        imageUrl:
          'https://www-prod.prod.cms.df.services.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-black-front.jpg',
        altText: 'Essential+ nbn™ plan with modem',
      },
      heroOfferId: '$10_NBN_6M_6_MAY_20_01',
      inclusions: [
        {
          description: 'Better for browsing online, streaming movies in 4K and online gaming.',
          planId: 'AU12152',
          title: 'Great for 2-4 users',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/my-vodafone-mid.svg',
        },
        {
          description: 'With unlimited data you can stream, download and share what you love.',
          planId: '',
          title: 'Unlimited data',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            'As this is a month to month plan, you can change your plan to suit your needs at any time without paying a fee.',
          planId: '',
          title: 'Month to month plan',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            'Take 30 days to decide if you love us with our &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;nbnnetworksatisfaction&quot; style=&quot;color: black;&quot;&gt;Network Satisfaction Guarantee&lt;/vha-modal-trigger&gt;. If you&rsquo;re not satisfied, we&rsquo;ll refund your plan fee. T&amp;amp;C apply.',
          planId: '',
          title: 'Network Guarantee',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
      ],
      planName: 'Essential+ nbn™ plan',
      planDescription: '&lt;p&gt;Essential+ nbn&trade; plan&lt;/p&gt;',
    },
    productConfigChanged: false,
    productExpired: false,
    packageId: '1',
    isBundleAndSaveEligible: true,
  },
  {
    packageId: '1',
    productCode: 'BVODWIFIHUB',
    catalogCode: CatalogCode.NBN_MODEMS,
    productName: 'Vodafone Wi-Fi Hub™',
    productType: CartProductType.DEVICE,
    productSubType: CartProductSubType.NBN_MODEM,
    itemType: CartItemType.MODEM,
    productConfig: {
      contractTerm: '36',
    },
    priceInfo: {
      recurringCharge: 5,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 5,
      loyaltyMRCAmount: 0,
    },
    promotions: [],
    relatedContent: {
      modemName: 'Vodafone Wi-Fi Hub&trade;',
      image: {
        altText: 'Vodafone Wi-Fi Hub™',
        imageUrl:
          'https://www-prod.prod.cms.df.services.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-black-front.jpg',
      },
    },
    productConfigChanged: false,
    productExpired: false,
  },
];

export const mockASDNbnPlanAndDeviceBasketItems: (BasketItem | NbnPlanBasketItem)[] = [
  {
    productCode: 'AU12152',
    catalogCode: CatalogCode.NBN_PLANS,
    productName: '$75 Essential+ nbn™ Plan',
    productType: CartProductType.PLAN_FIXED,
    productSubType: CartProductSubType.NBN_MODEM_M2M,
    itemType: CartItemType.PLAN,
    productConfig: {
      contractTerm: '1',
    },
    priceInfo: {
      recurringCharge: 75,
      oneTimeCharge: 0,
      nrcPriceAdjustment: -10,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 65,
    },
    cisUrl: 'https://www.vodafone.com.au/doc/cis/nbnplans/au12256_au12257/jul2020.pdf',
    factSheetUrl: 'https://www.vodafone.com.au/doc/kfs/nbnplans/jul2020.pdf',
    promotions: [
      {
        promotionExpired: false,
        promotionCode: '$10_NBN_6M_6_ASD_20_01',
        title: '$10 off monthly plan fees for 6 months',
        description:
          '&lt;p&gt;Get a $10/mth discount on plan fees for 6 months when you sign up to this plan. Offer ends 2999-12-31T23:59:59.000Z unless extended. T&amp;amp;C apply.&lt;/p&gt;',
        iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/redeemed-unlocked-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    relatedContent: {
      planTenure: 'Month to month',
      planTitle: 'Unlimited data',
      planData: 'Unlimited',
      subHeadingPrimary: 'Typical Evening Speed 40Mbps (7pm-11pm)',
      subHeadingSecondary: 'per month',
      cisLabel: 'Critical Infomation Summary',
      planExtraInfo: 'Standard Evening Speed',
      image: {
        imageUrl:
          'https://www-prod.prod.cms.df.services.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-black-front.jpg',
        altText: 'Essential+ nbn™ plan with modem',
      },
      heroOfferId: '$10_NBN_6M_6_MAY_20_01',
      inclusions: [
        {
          description: 'Better for browsing online, streaming movies in 4K and online gaming.',
          planId: 'AU12152',
          title: 'Great for 2-4 users',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/my-vodafone-mid.svg',
        },
        {
          description: 'With unlimited data you can stream, download and share what you love.',
          planId: '',
          title: 'Unlimited data',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            'As this is a month to month plan, you can change your plan to suit your needs at any time without paying a fee.',
          planId: '',
          title: 'Month to month plan',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            'Take 30 days to decide if you love us with our &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;nbnnetworksatisfaction&quot; style=&quot;color: black;&quot;&gt;Network Satisfaction Guarantee&lt;/vha-modal-trigger&gt;. If you&rsquo;re not satisfied, we&rsquo;ll refund your plan fee. T&amp;amp;C apply.',
          planId: '',
          title: 'Network Guarantee',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
      ],
      planName: 'Essential+ nbn™ plan',
      planDescription: '&lt;p&gt;Essential+ nbn&trade; plan&lt;/p&gt;',
    },
    productConfigChanged: false,
    productExpired: false,
    packageId: '1',
    isBundleAndSaveEligible: true,
  },
  {
    packageId: '1',
    productCode: 'BVODWIFIHUB',
    catalogCode: CatalogCode.NBN_MODEMS,
    productName: 'Vodafone Wi-Fi Hub™',
    productType: CartProductType.DEVICE,
    productSubType: CartProductSubType.NBN_MODEM,
    itemType: CartItemType.MODEM,
    productConfig: {
      contractTerm: '36',
    },
    priceInfo: {
      recurringCharge: 5,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 5,
      loyaltyMRCAmount: 0,
    },
    promotions: [],
    relatedContent: {
      modemName: 'Vodafone Wi-Fi Hub&trade;',
      image: {
        altText: 'Vodafone Wi-Fi Hub™',
        imageUrl:
          'https://www-prod.prod.cms.df.services.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-black-front.jpg',
      },
    },
    productConfigChanged: false,
    productExpired: false,
  },
];

export const mockNbnPlanAndDeviceBundle: BasketPackage = {
  items: mockNbnPlanAndDeviceBasketItems,
  packageId: '1',
};

export const mockNbnPlanAndDevice: Basket = {
  basketId:
    'qFUKiTO4Ar6Vd38oK7Nsjnq6XC6Uk0sppetRCzB9wdU.te-UQwAl73xdBwoIlgPGiM6Y8_68FHnWfF1ZtZrwF3uVcp55cuBqyUK8chCsrYBk',
  bundleAndSaveApplied: false,
  packages: [
    {
      packageId: '1',
      items: mockNbnPlanAndDeviceBasketItems,
    },
  ],
  totalPrice: {
    recurringCharge: 70,
    oneTimeCharge: 0,
  },
};

export const mockFhwPlanAndDeviceBasketItems: (BasketItem | NbnPlanBasketItem)[] = [
  {
    productCode: 'AU12310',
    catalogCode: CatalogCode.FHW_4G_PLANS,
    productName: '$55 4G Home Wireless Plan',
    productType: CartProductType.PLAN_FIXED,
    productSubType: CartProductSubType.FHW_4G_M2M,
    itemType: CartItemType.PLAN,
    productConfig: {
      contractTerm: '1',
      dataLimit: DataLimit.UNLIMITED,
    },
    priceInfo: {
      recurringCharge: 55,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 55,
    },
    cisUrl:
      'https://www.vodafone.com.au/cis/mobile-broadband-plans/vodafone-home-wireless-month-to-month-plans/au12310-au12311-april2021.pdf',
    promotions: [
      {
        title: 'Save $5/mth on plan fees',
        description:
          '&lt;p&gt;Save $5 per month on this 4G Home Wireless Broadband plan when you already have a mobile phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$5_4G_FWA_ASD_DISPLAY_01',
        iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/all-rewards.svg',
        promotionExpired: false,
        endDate: '2200-05-30T14:00:00.000Z',
      },
      {
        title: 'Get your first month on us',
        description:
          '&lt;p&gt;Get your first month of plan fees for free on this 4G Home Wireless Broadband plan when you sign up by 15/09/2021. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '1MAF_4G_FWA_DISPLAY_01',
        iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/dollar-sign.svg',
        promotionExpired: false,
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    relatedContent: {
      planTenure: 'Month to month',
      planTitle: 'Save $5/mth on plan fees',
      planData: '200GB',
      subHeadingPrimary: 'Included Data',
      subHeadingSecondary: '$50/mth when you already have a phone plan with us.',
      cisLabel: 'Critical Information Summary',
      planExtraInfo: 'Total min cost $235',
      image: {
        imageUrl:
          'https://www-sit.test.cms.df.services.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-2-0-black-front.jpg',
        altText: 'Vodafone Wi-Fi Hub™ 2.0',
      },
      heroOfferId: '',
      inclusions: [
        {
          description:
            '&lt;p&gt;Get 200GB Included Data, then keep using data in Oz at &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;included-data-hi&quot;&gt;speeds of up to 1.5Mbps&lt;/vha-modal-trigger&gt;&lt;/p&gt;',
          planId: '',
          title: 'No excess data charges',
          iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;Take 30 days to decide if you love our network with our &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;networksatisfactionhi&quot;&gt;Network Satisfaction Guarantee&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
          planId: '',
          title: 'Network Guarantee',
          iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
      ],
      planName: '$55 4G Home Wireless Broadband Plan | Total min cost $235',
      planDescription:
        '&lt;p&gt;Save $5 per month on this 4G Home Wireless Broadband plan when you already have a mobile phone plan with us.&lt;/p&gt;',
      hasDataOverride: false,
    },
    productConfigChanged: false,
    productExpired: false,
    isBundleAndSaveEligible: false,
    packageId: '1',
  },
  {
    productCode: 'BVODHWB',
    catalogCode: CatalogCode.NBN_MODEMS,
    productName: 'Vodafone Wi-Fi Hub™ 2.0',
    productType: CartProductType.DEVICE,
    productSubType: CartProductSubType.NBN_MODEM,
    itemType: CartItemType.MODEM,
    productConfig: {
      contractTerm: '36',
    },
    priceInfo: {
      recurringCharge: 5,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 5,
      loyaltyMRCAmount: 0,
    },
    promotions: [],
    relatedContent: {
      modemName: '&lt;p&gt;Vodafone Wi-Fi Hub&trade; 2.0&lt;/p&gt;',
      image: {
        altText: 'Vodafone Wi-Fi Hub™ 2.0',
        imageUrl:
          'https://www-sit.test.cms.df.services.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-2-0-black-front.jpg',
      },
    },
    productConfigChanged: false,
    productExpired: false,
    isBundleAndSaveEligible: false,
    packageId: '1',
  },
];

export const mockNbnAndTabletSimoItems: BasketPackage[] = [
  {
    items: [
      {
        productCode: 'AU12313',
        catalogCode: CatalogCode.NBN_PLANS,
        productName: 'Essential+ nbn™ plan',
        productType: CartProductType.PLAN_FIXED,
        productSubType: CartProductSubType.NBN_MODEM_M2M,
        itemType: CartItemType.PLAN,
        productConfig: { contractTerm: '1', dataLimit: DataLimit.UNLIMITED },
        priceInfo: {
          recurringCharge: 80,
          oneTimeCharge: 0,
          nrcPriceAdjustment: -15,
          nrcPercentDiscount: 0,
          adjustedNRCAmount: 0,
          adjustedMRCAmount: 65,
        },
        cisUrl:
          'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-plans/au12312-au12314-au12295-au12296-oct2021.pdf',
        factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
        promotions: [
          {
            title: 'Save $15/mth on plan fees',
            description:
              '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
            promotionCode: '$15_NBN_ASD_DISPLAY_01',
            iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/all-rewards.svg',
            promotionExpired: false,
            endDate: '2200-05-30T14:00:00.000Z',
          },
        ],
        relatedContent: {
          planTenure: '',
          planTitle: '',
          planData: 'Unlimited',
          subHeadingPrimary: 'Typical Evening Speed 50Mbps (7pm-11pm)',
          cisLabel: 'Critical Infomation Summary',
          planExtraInfo: 'Standard+ Evening Speed',
          image: {
            imageUrl:
              'https://www-sit.test.cms.df.services.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-2-0-black-front.jpg',
            altText: 'Essential+ nbn™ plan with modem',
          },
          heroOfferId: '',
          inclusions: [
            {
              description: '&lt;p&gt;Good for browsing online, streaming movies in 4K and online gaming.&lt;/p&gt;',
              planId: 'AU12313',
              title: 'Great for 2-4 users',
              iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/my-vodafone-mid.svg',
              hideFromCart: false,
            },
            {
              description:
                '&lt;p&gt;Included when&amp;nbsp;you stay connected for 24 months. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;nbn-modem-info&quot;&gt;Find out more&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
              planId: 'AU12313',
              title: '$0 upfront modem',
              iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
              hideFromCart: false,
            },
          ],
          planName: 'Essential+ nbn™ plan',
          planDescription:
            '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
          planSpeedLabel: 'Unlimited data',
          hasDataOverride: false,
          subHeadingSecondary: '$65/mth when you already have a phone plan with us',
        },
        productConfigChanged: false,
        productExpired: false,
        isBundleAndSaveEligible: false,
        packageId: '37634710',
      },
      {
        productCode: 'BVODWIFIHUB2',
        catalogCode: CatalogCode.NBN_MODEMS,
        productName: 'Vodafone Wi-Fi Hub™ 2.0',
        productType: CartProductType.DEVICE,
        productSubType: CartProductSubType.NBN_MODEM,
        itemType: CartItemType.MODEM,
        productConfig: { contractTerm: '24' },
        priceInfo: {
          recurringCharge: 7.5,
          oneTimeCharge: 0,
          nrcPriceAdjustment: 0,
          nrcPercentDiscount: 0,
          adjustedNRCAmount: 0,
          adjustedMRCAmount: 7.5,
          loyaltyMRCAmount: 0,
        },
        promotions: [],
        relatedContent: {
          modemName: '&lt;div&gt;Vodafone Wi-Fi Hub&trade; 2.0&lt;/div&gt;',
          image: {
            altText: 'Vodafone Wi-Fi Hub™ 2.0',
            imageUrl:
              'https://www-sit.test.cms.df.services.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-2-0-black-front.jpg',
          },
        },
        productConfigChanged: false,
        productExpired: false,
        isBundleAndSaveEligible: false,
        packageId: '37634710',
      },
    ],
    packageId: '37634710',
  },
  {
    items: [
      {
        productCode: 'AU12234',
        catalogCode: CatalogCode.POSTPAID_TABLET_SIMO_PLANS,
        productName: '$30 SIM Only Tablet Plus Plan',
        productType: CartProductType.PLAN_MBB,
        productSubType: CartProductSubType.SIM,
        itemType: CartItemType.PLAN,
        productConfig: { contractTerm: '1', dataLimit: DataLimit.UNLIMITED },
        priceInfo: {
          recurringCharge: 30,
          oneTimeCharge: 0,
          nrcPriceAdjustment: -5,
          nrcPercentDiscount: 0,
          adjustedNRCAmount: 0,
          adjustedMRCAmount: 25,
        },
        cisUrl: 'https://www.vodafone.com.au/doc/cis/mobilebroadbandplans/au12233_au12236/nov2020.pdf',
        promotions: [
          {
            title: 'Save $5/mth on plan fees',
            description:
              '&lt;p&gt;Save $5/mth over 12 months when you sign up to this plan. Offer ends 13/01/22. T&amp;amp;C apply.&lt;/p&gt;',
            promotionCode: 'CREDIT_TO_YOU_SIMO_TAB',
            iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/dollar-sign.svg',
            promotionExpired: false,
            endDate: '2200-05-30T14:00:00.000Z',
          },
        ],
        relatedContent: {
          planTenure: 'Month to month',
          planTitle: 'Endless data',
          planData: '30GB',
          subHeadingPrimary: 'data in Oz',
          cisLabel: 'Critical Information Summary',
          planExtraInfo: '',
          image: {
            imageUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/Cart-vodafone-sim-card-s.png',
            altText: 'SIM Only Tablet Plus Plan',
          },
          heroOfferId: '',
          inclusions: [
            {
              description:
                '&lt;p&gt;Get 30GB Max Speed data, then keep using data in Oz at &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;tabletsmaxspeed&quot;&gt;speeds of up to 1.5Mbps&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
              planId: '',
              title: 'Endless data',
              iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
              hideFromCart: false,
            },
            {
              description:
                '&lt;p&gt;Share Max Speed data with up to 10 eligible plans under one &lt;a&gt;account&lt;/a&gt;. T&amp;amp;C apply.&lt;/p&gt;',
              planId: '',
              title: 'Share your data',
              iconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
              hideFromCart: false,
            },
          ],
          planName: 'SIM Only Tablet Plus Plan',
          planDescription:
            '&lt;p&gt;Get 30GB&nbsp;Max Speed data, then keep using data in Oz at speeds of up to 1.5Mbps.&lt;/p&gt;',
          planSpeedLabel: '',
          hasDataOverride: false,
          subHeadingSecondary: 'per month',
        },
        productConfigChanged: false,
        productExpired: false,
        isBundleAndSaveEligible: true,
        packageId: '37749779',
      },
      {
        catalogCode: CatalogCode.POSTPAID_TABLET_PLANS,
        productCode: 'SIM100089',
        productName: 'SIM Card',
        productType: CartProductType.HARDWARE,
        productSubType: CartProductSubType.SIM,
        itemType: CartItemType.HARDWARE,
        priceInfo: {
          recurringCharge: 0,
          oneTimeCharge: 0,
          nrcPriceAdjustment: 0,
          nrcPercentDiscount: 0,
          adjustedNRCAmount: 0,
          adjustedMRCAmount: 0,
        },
        promotions: [],
        productConfigChanged: false,
        productExpired: false,
        isBundleAndSaveEligible: false,
        packageId: '37749779',
      },
    ],
    packageId: '37749779',
  },
];

export const mockFhwPlanAndDevice: Basket = {
  basketId: 'basketId',
  bundleAndSaveApplied: false,
  packages: [
    {
      packageId: '1',
      items: mockFhwPlanAndDeviceBasketItems,
    },
  ],
  totalPrice: {
    recurringCharge: 70,
    oneTimeCharge: 0,
  },
};

export const mockFhwPlanAndDeviceBundle: BasketPackage = {
  items: mockFhwPlanAndDeviceBasketItems,
  packageId: '1',
};

export const mockDataListData = [
  'East Lindfield, 2070',
  'Lindfield, 2070',
  'Lindfield West, 2070',
  'East Killara, 2071',
  'Killara, 2071',
  'Gordon, 2072',
  'Pymble, 2073',
  'West Pymble, 2073',
  'North Turramurra, 2074',
  'South Turramurra, 2074',
  'Turramurra, 2074',
  'Warrawee, 2074',
  'St Ives, 2075',
  'St Ives Chase, 2075',
  'Normanhurst, 2076',
  'North Wahroonga, 2076',
  'Wahroonga, 2076',
  'Asquith, 2077',
  'Hornsby, 2077',
  'Hornsby Heights, 2077',
  'Waitara, 2077',
  'Mount Colah, 2079',
];

export const mockNbnPlanAndModemItems: CartItem[] = [
  {
    productCode: 'BVODWIFIHUB',
    productType: CartProductType.DEVICE,
    productSubType: CartProductSubType.NBN_MODEM,
    quantity: 1,
    name: 'Vodafone Wi-Fi Hub™',
    actions: {
      delete: {
        lineItemKey: '11280f8163ffc5dc3636e9b9fa1dc269',
        bundleContextKey: '11280f8163ffc5dc3636e9b9fa1dc269',
      },
      update: {
        lineItemKey: '11280f8163ffc5dc3636e9b9fa1dc269',
        bundleContextKey: '11280f8163ffc5dc3636e9b9fa1dc269',
      },
    },
    priceInfo: {
      recurringCharge: 5,
      oneTimeCharge: 0,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productConfig: {
      contractTerm: '36',
    },
    catalogCode: CatalogCode.NBN_MODEMS,
    itemType: CartItemType.MODEM,
    relatedContent: {
      modemName: 'Vodafone Wi-Fi Hub&trade;',
      image: {
        altText: 'Vodafone Wi-Fi Hub™',
        imageUrl:
          'https://sit01-dispatcher.test.cms.df.services.vodafone.com.au/content/dam/vha/images/devices/vodafone/img-800x586-vodafone-wifi-hub-black-front.jpg',
      },
    },
  },
  {
    productCode: 'AU12151',
    productType: CartProductType.PLAN_FIXED,
    productSubType: CartProductSubType.NBN_MODEM_M2M,
    quantity: 1,
    name: '$65 Essential nbn™ Plan',
    actions: {
      delete: {
        lineItemKey: '07b6042ee88badec2288892eb647c238',
        bundleContextKey: '07b6042ee88badec2288892eb647c238',
      },
      update: {
        lineItemKey: '07b6042ee88badec2288892eb647c238',
        bundleContextKey: '07b6042ee88badec2288892eb647c238',
      },
    },
    priceInfo: {
      recurringCharge: 65,
      oneTimeCharge: 0,
      oneTimeLoyalty: 0,
      recurringLoyalty: 0,
    },
    productConfig: {
      contractTerm: '1',
    },
    catalogCode: CatalogCode.NBN_PLANS,
    itemType: CartItemType.PLAN,
    cisUrl: '',
    pdsLinkUrl: '',
    relatedContent: {
      cisLabel: 'Critical Infomation Summary',
      inclusions: [
        {
          description: 'Good for browsing online, streaming movies and using social media.',
          title: 'Great for 1-2 users',
          iconUrl:
            'https://sit01-dispatcher.test.cms.df.services.vodafone.com.au/content/dam/vha/images/icons/admin-mid.svg',
          planId: 'AU12151',
        },
        {
          description: 'With unlimited data you can stream, download and share what you love.',
          title: 'Unlimited data',
          iconUrl:
            'https://sit01-dispatcher.test.cms.df.services.vodafone.com.au/content/dam/vha/images/icons/tick-or-solved-green.svg',
          planId: '',
        },
        {
          description:
            'As this is a month to month plan, you can change your plan to suit your needs at any time without paying a fee.',
          title: 'Month to month plan',
          iconUrl:
            'https://sit01-dispatcher.test.cms.df.services.vodafone.com.au/content/dam/vha/images/icons/tick-or-solved-green.svg',
          planId: '',
        },
        {
          description:
            'Take 30 days to decide if you love us with our Network Satisfaction Guarantee. If you&rsquo;re not satisfied, we&rsquo;ll refund your plan fee. T&amp;C apply',
          title: 'Network Guarantee',
          iconUrl:
            'https://sit01-dispatcher.test.cms.df.services.vodafone.com.au/content/dam/vha/images/icons/tick-or-solved-green.svg',
          planId: '',
        },
      ],
      image: {
        imageUrl:
          'https://sit01-dispatcher.test.cms.df.services.vodafone.com.au/content/dam/vha/images/devices/vodafone/img-800x586-vodafone-wifi-hub-black-front.jpg',
        altText: 'Essential nbn™ plan with modem',
      },
      planName: 'Essential nbn™ plan',
      planDescription: 'Essential nbn&trade; plan',
      planExtraInfo: 'Standard Evening Speed',
      planTenure: 'Month to month',
      planTitle: 'Unlimited data',
      subHeadingPrimary: 'Typical Evening Speed 21Mbps (7pm-11pm)',
      subHeadingSecondary: 'per month',
      withModem: true,
      connectionSpeed: '25',
    },
  },
];

export const mockNbnPlanAndModemCart = {
  cartContextKey: '652760cb456766e555ea353998e9b67b',
  cartItems: mockNbnPlanAndModemItems,
  priceInfo: {
    recurringCharge: 64,
    oneTimeCharge: 0,
    oneTimeLoyalty: 0,
    recurringLoyalty: 0,
  },
};

export const mockPostpaidSimoBasketItems: BasketItem[] = [
  {
    productCode: 'AU12277',
    catalogCode: CatalogCode.POSTPAID_SIMO_PLANS,
    productName: '$120 SIM Only Ultra Plan',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.SIM,
    itemType: CartItemType.PLAN,
    productConfig: {
      contractTerm: '1',
      dataLimit: DataLimit.UNLIMITED,
    },
    priceInfo: {
      recurringCharge: 120,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 120,
    },
    cisUrl: 'https://www.vodafone.com.au/doc/cis/mobileplans/au12273_au12277/aug2020.pdf',
    promotions: [],
    relatedContent: {
      planTenure: 'Month to month',
      planTitle: 'Infinite data – speeds up to 25Mbps',
      planData: '150GB',
      subHeadingPrimary: 'Max Speed data <br /> SIM Only Ultra Plan',
      subHeadingSecondary: 'per month',
      cisLabel: 'Critical Infomation Summary',
      planExtraInfo: 'Month to month',
      image: {
        imageUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/Cart-vodafone-sim-card-s.png',
        altText: '$120 SIM Only Ultra Plan',
      },
      heroOfferId: '',
      inclusions: [
        {
          description:
            '&lt;p&gt;First use 150GB Max Speed data, then use infinite data in Oz at &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;maxspeed&quot; style=&quot;color: black;&quot;&gt;speeds of up to 25Mbps&lt;/vha-modal-trigger&gt; at no extra cost.&lt;/p&gt;',
          planId: 'AU12277',
          title: 'Max Speed and infinite data',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;25Mbps is great for video streaming and using cloud storage, but uploading very large files may be slow. Not suitable for HD video. Find out more about &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;maxspeed&quot; style=&quot;color: black;&quot;&gt;what you can do at 2Mbps, 10Mbps and 25Mbps&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
          planId: 'AU12277',
          title: 'Speeds of up to 25Mbps',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/acceleration-middle.svg',
        },
        {
          description:
            '&lt;p&gt;Unlimited to &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;zone1&quot; style=&quot;color: black;&quot;&gt;Zone 1&lt;/vha-modal-trigger&gt; &amp;amp; 300 mins to &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;zone2&quot; style=&quot;color: black;&quot;&gt;Zone 2&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
          planId: '',
          title: 'Standard int’l minutes from Oz',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;Unlimited standard national calls and text, and unlimited&amp;nbsp;&lt;span&gt;standard international SMS.&lt;/span&gt;&lt;/p&gt;',
          planId: '',
          title: 'Standard national calls and texts',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;Tethering permitted but for personal devices only and not as a substitute for a home internet service.&lt;/p&gt;',
          planId: '',
          title: 'Tethering',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
      ],
      planName: 'SIM Only Ultra Plan',
      planDescription:
        '&lt;p&gt;&lt;span&gt;First use&nbsp;150GB Max Speed data, then use infinite data in Oz at speeds of up to 25Mbps.&lt;/span&gt;&lt;br /&gt;&lt;/p&gt;',
      hasDataOverride: false,
    },
    productConfigChanged: false,
    productExpired: false,
    packageId: '1',
  },
  {
    productCode: 'SIM100032',
    productName: 'SIM Card',
    productType: CartProductType.HARDWARE,
    productSubType: CartProductSubType.SIM,
    itemType: CartItemType.HARDWARE,
    catalogCode: CatalogCode.POSTPAID_SIMO_PLANS,
    priceInfo: {
      recurringCharge: 0,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 0,
    },
    promotions: [],
    productConfigChanged: false,
    productExpired: false,
    packageId: '1',
  },
];

export const mockRafPostpaidSimoBasketItems: BasketItem[] = [
  {
    productCode: 'AU12277',
    catalogCode: CatalogCode.POSTPAID_SIMO_PLANS,
    productName: '$120 SIM Only Ultra Plan',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.SIM,
    itemType: CartItemType.PLAN,
    productConfig: {
      contractTerm: '1',
      dataLimit: DataLimit.UNLIMITED,
    },
    priceInfo: {
      recurringCharge: 120,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 120,
    },
    cisUrl: 'https://www.vodafone.com.au/doc/cis/mobileplans/au12273_au12277/aug2020.pdf',
    promotions: [],
    relatedContent: {
      planTenure: 'Month to month',
      planTitle: 'Infinite data – speeds up to 25Mbps',
      planData: '150GB',
      subHeadingPrimary: 'Max Speed data <br /> SIM Only Ultra Plan',
      subHeadingSecondary: 'per month',
      cisLabel: 'Critical Infomation Summary',
      planExtraInfo: 'Month to month',
      image: {
        imageUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/Cart-vodafone-sim-card-s.png',
        altText: '$120 SIM Only Ultra Plan',
      },
      heroOfferId: '',
      inclusions: [
        {
          description:
            '&lt;p&gt;First use 150GB Max Speed data, then use infinite data in Oz at &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;maxspeed&quot; style=&quot;color: black;&quot;&gt;speeds of up to 25Mbps&lt;/vha-modal-trigger&gt; at no extra cost.&lt;/p&gt;',
          planId: 'AU12277',
          title: 'Max Speed and infinite data',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;25Mbps is great for video streaming and using cloud storage, but uploading very large files may be slow. Not suitable for HD video. Find out more about &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;maxspeed&quot; style=&quot;color: black;&quot;&gt;what you can do at 2Mbps, 10Mbps and 25Mbps&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
          planId: 'AU12277',
          title: 'Speeds of up to 25Mbps',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/acceleration-middle.svg',
        },
        {
          description:
            '&lt;p&gt;Unlimited to &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;zone1&quot; style=&quot;color: black;&quot;&gt;Zone 1&lt;/vha-modal-trigger&gt; &amp;amp; 300 mins to &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;zone2&quot; style=&quot;color: black;&quot;&gt;Zone 2&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
          planId: '',
          title: 'Standard int’l minutes from Oz',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;Unlimited standard national calls and text, and unlimited&amp;nbsp;&lt;span&gt;standard international SMS.&lt;/span&gt;&lt;/p&gt;',
          planId: '',
          title: 'Standard national calls and texts',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;Tethering permitted but for personal devices only and not as a substitute for a home internet service.&lt;/p&gt;',
          planId: '',
          title: 'Tethering',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
      ],
      planName: 'SIM Only Ultra Plan',
      planDescription:
        '&lt;p&gt;&lt;span&gt;First use&nbsp;150GB Max Speed data, then use infinite data in Oz at speeds of up to 25Mbps.&lt;/span&gt;&lt;br /&gt;&lt;/p&gt;',
      hasDataOverride: false,
    },
    productConfigChanged: false,
    productExpired: false,
    packageId: '1',
  },
  {
    productCode: 'SIM100032',
    productName: 'SIM Card',
    productType: CartProductType.HARDWARE,
    productSubType: CartProductSubType.SIM,
    itemType: CartItemType.HARDWARE,
    catalogCode: CatalogCode.POSTPAID_SIMO_PLANS,
    priceInfo: {
      recurringCharge: 0,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 0,
    },
    promotions: [],
    productConfigChanged: false,
    productExpired: false,
    packageId: '2',
  },
];

export const mockMultipleRafEligibleItems: Basket = {
  basketId: 'basketId',
  bundleAndSaveApplied: false,
  packages: [
    {
      packageId: '1',
      items: mockFhwPlanAndDeviceBasketItems,
    },
    {
      packageId: '2',
      items: mockRafPostpaidSimoBasketItems,
    },
  ],
  totalPrice: {
    recurringCharge: 70,
    oneTimeCharge: 0,
  },
};

export const mockSimOnlyPlanCart: Basket = {
  basketId:
    'w-3m_HWvxf0GqI05ErIT3S1kBH6dQZiOuHjLDv_0BtSKM.SWwXYxORbX23fvr-btqvMpaSa_YeeL07jZESCYeG3xmyqaTs6vlI0U9JlV3v5lrd.OcFg0d5WOTFJEkGNUMJ3olO2O33V-2tfjMyB81jLTeltPUHNvVkkGpl-XWtn0WfW',
  bundleAndSaveApplied: false,
  packages: [
    {
      items: mockPostpaidSimoBasketItems,
      packageId: '1',
    },
  ],
  totalPrice: {
    recurringCharge: 120,
    oneTimeCharge: 0,
  },
};

export const mockPrepaidBasketItems: BasketItem[] = [
  {
    productCode: 'PRD_PREPAID_$40PREPAID_PLUS_STARTER_PACK',
    catalogCode: CatalogCode.PREPAID_COMBO_PLUS_PLANS,
    productName: '$40 Prepaid Plus Starter Pack',
    productType: CartProductType.PLAN_VOICE,
    productSubType: CartProductSubType.PREPAID,
    itemType: CartItemType.PLAN,
    productConfig: {
      contractTerm: '1',
      dataLimit: DataLimit.UNLIMITED,
    },
    priceInfo: {
      recurringCharge: 120,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 120,
    },
    cisUrl: 'https://www.vodafone.com.au/doc/cis/mobileplans/au12273_au12277/aug2020.pdf',
    promotions: [],
    relatedContent: {
      planTenure: 'Month to month',
      planTitle: 'Infinite data – speeds up to 25Mbps',
      planData: '150GB',
      subHeadingPrimary: 'Max Speed data <br /> SIM Only Ultra Plan',
      subHeadingSecondary: 'per month',
      cisLabel: 'Critical Infomation Summary',
      planExtraInfo: 'Month to month',
      image: {
        imageUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/Cart-vodafone-sim-card-s.png',
        altText: '$120 SIM Only Ultra Plan',
      },
      heroOfferId: '',
      inclusions: [
        {
          description:
            '&lt;p&gt;First use 150GB Max Speed data, then use infinite data in Oz at &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;maxspeed&quot; style=&quot;color: black;&quot;&gt;speeds of up to 25Mbps&lt;/vha-modal-trigger&gt; at no extra cost.&lt;/p&gt;',
          planId: 'AU12277',
          title: 'Max Speed and infinite data',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;25Mbps is great for video streaming and using cloud storage, but uploading very large files may be slow. Not suitable for HD video. Find out more about &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;maxspeed&quot; style=&quot;color: black;&quot;&gt;what you can do at 2Mbps, 10Mbps and 25Mbps&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
          planId: 'AU12277',
          title: 'Speeds of up to 25Mbps',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/acceleration-middle.svg',
        },
        {
          description:
            '&lt;p&gt;Unlimited to &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;zone1&quot; style=&quot;color: black;&quot;&gt;Zone 1&lt;/vha-modal-trigger&gt; &amp;amp; 300 mins to &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;zone2&quot; style=&quot;color: black;&quot;&gt;Zone 2&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
          planId: '',
          title: 'Standard int’l minutes from Oz',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;Unlimited standard national calls and text, and unlimited&amp;nbsp;&lt;span&gt;standard international SMS.&lt;/span&gt;&lt;/p&gt;',
          planId: '',
          title: 'Standard national calls and texts',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
        {
          description:
            '&lt;p&gt;Tethering permitted but for personal devices only and not as a substitute for a home internet service.&lt;/p&gt;',
          planId: '',
          title: 'Tethering',
          iconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
        },
      ],
      planName: 'SIM Only Ultra Plan',
      planDescription:
        '&lt;p&gt;&lt;span&gt;First use&nbsp;150GB Max Speed data, then use infinite data in Oz at speeds of up to 25Mbps.&lt;/span&gt;&lt;br /&gt;&lt;/p&gt;',
      hasDataOverride: false,
    },
    productConfigChanged: false,
    productExpired: false,
    packageId: '66301',
  },
  {
    productCode: 'SIM100032',
    productName: 'SIM Card',
    productType: CartProductType.HARDWARE,
    productSubType: CartProductSubType.SIM,
    itemType: CartItemType.HARDWARE,
    catalogCode: CatalogCode.PREPAID_COMBO_PLUS_PLANS,
    priceInfo: {
      recurringCharge: 0,
      oneTimeCharge: 0,
      nrcPriceAdjustment: 0,
      nrcPercentDiscount: 0,
      adjustedNRCAmount: 0,
      adjustedMRCAmount: 0,
    },
    promotions: [],
    productConfigChanged: false,
    productExpired: false,
    packageId: '1',
  },
];

export const mockPrepaidPlanOnlyCart: Basket = {
  basketId:
    'w-3m_HWvxf0GqI05ErIT3S1kBH6dQZiOuHjLDv_0BtSKM.SWwXYxORbX23fvr-btqvMpaSa_YeeL07jZESCYeG3xmyqaTs6vlI0U9JlV3v5lrd.OcFg0d5WOTFJEkGNUMJ3olO2O33V-2tfjMyB81jLTeltPUHNvVkkGpl-XWtn0WfW',
  bundleAndSaveApplied: false,
  packages: [
    {
      items: mockPrepaidBasketItems,
      packageId: '1',
    },
  ],
  totalPrice: {
    recurringCharge: 120,
    oneTimeCharge: 0,
  },
};

export const mockPostpaidSMSimoBasketItems: BasketItem[] = [
  { ...mockPostpaidSimoBasketItems[0], catalogCode: CatalogCode.POSTPAID_SIMO_TPG_SM },
];

export const mockSMSimOnlyPlanCart: Basket = {
  basketId:
    'w-3m_HWvxf0GqI05ErIT3S1kBH6dQZiOuHjLDv_0BtSKM.SWwXYxORbX23fvr-btqvMpaSa_YeeL07jZESCYeG3xmyqaTs6vlI0U9JlV3v5lrd.OcFg0d5WOTFJEkGNUMJ3olO2O33V-2tfjMyB81jLTeltPUHNvVkkGpl-XWtn0WfW',
  bundleAndSaveApplied: false,
  packages: [
    {
      items: mockPostpaidSMSimoBasketItems,
      packageId: '1',
    },
  ],
  totalPrice: {
    recurringCharge: 120,
    oneTimeCharge: 0,
  },
};

export const mockPostpaidSimoBasketPackage: BasketPackage = {
  items: mockPostpaidSimoBasketItems,
  packageId: '1',
};

export const mockLocalityData = {
  localities: [
    {
      category: 'Delivery Area',
      id: 448,
      latitude: -33.86051951,
      location: 'BARANGAROO',
      longitude: 151.2015802,
      postcode: 2000,
      state: 'NSW',
    },
    {
      category: 'Delivery Area',
      id: 449,
      latitude: -33.85659644,
      location: 'DAWES POINT',
      longitude: 151.2069524,
      postcode: 2000,
      state: 'NSW',
    },
  ],
};

export const mockNoneASDEligibleBasket: Basket = {
  basketId:
    'qFUKiTO4Ar6Vd38oK7Nsjnq6XC6Uk0sppetRCzB9wdU.te-UQwAl73xdBwoIlgPGiM6Y8_68FHnWfF1ZtZrwF3uVcp55cuBqyUK8chCsrYBk',
  bundleAndSaveApplied: false,
  packages: [
    {
      packageId: '1',
      items: mockASDNbnPlanAndDeviceBasketItems,
    },
  ],
  totalPrice: {
    recurringCharge: 75,
    oneTimeCharge: 0,
  },
};

export const mockAsdEligibleBasket: Basket = {
  basketId:
    'qFUKiTO4Ar6Vd38oK7Nsjnq6XC6Uk0sppetRCzB9wdU.te-UQwAl73xdBwoIlgPGiM6Y8_68FHnWfF1ZtZrwF3uVcp55cuBqyUK8chCsrYBk',
  bundleAndSaveApplied: false,
  packages: [
    {
      packageId: '1',
      items: mockASDNbnPlanAndDeviceBasketItems.concat(mockPostpaidSimoBasketItems),
    },
  ],
  totalPrice: {
    recurringCharge: 185,
    oneTimeCharge: 0,
  },
};

export const mockAsdEligibleFhwBasket: Basket = {
  basketId:
    'qFUKiTO4Ar6Vd38oK7Nsjnq6XC6Uk0sppetRCzB9wdU.te-UQwAl73xdBwoIlgPGiM6Y8_68FHnWfF1ZtZrwF3uVcp55cuBqyUK8chCsrYBk',
  bundleAndSaveApplied: false,
  packages: [
    {
      packageId: '1',
      items: mockFhwPlanAndDeviceBasketItems.concat(mockPostpaidSimoBasketItems),
    },
  ],
  totalPrice: {
    recurringCharge: 185,
    oneTimeCharge: 0,
  },
};

export const mockAddressesData = {
  addresses: [
    {
      address: '177 Pacific Highway, North Sydney 2060',
      id: 1,
    },
    {
      address: 'Suite 1 177 Pacific Highway, North Sydney 2060',
      id: 2,
    },
  ],
};

export const mockEmptyLocalityData = {
  localities: [],
};

export const mockedSingleMatchedAddress = [
  {
    nbnLocationId: 'LOC000181490986',
    geocode: { geographicDatum: 'GDA94', latitude: '-33.83705259', longitude: '151.2062657' },
    address: {
      streetNumber: '177',
      street: 'PACIFIC',
      streetType: 'HWY',
      suburb: 'NORTH SYDNEY',
      state: 'NSW',
      postcode: '2060',
      level: '2',
      buildingName: 'CPB CONTRACTORS NSW AND ACT',
    },
  },
];

export const mockedMultipleMatchedAddresses = [
  {
    nbnLocationId: 'LOC000181490986',
    geocode: { geographicDatum: 'GDA94', latitude: '-33.83705259', longitude: '151.2062657' },
    address: {
      streetNumber: '177',
      street: 'PACIFIC',
      streetType: 'HWY',
      suburb: 'NORTH SYDNEY',
      state: 'NSW',
      postcode: '2060',
      level: '2',
      buildingName: 'CPB CONTRACTORS NSW AND ACT',
    },
  },
  {
    nbnLocationId: 'LOC000181491241',
    geocode: { geographicDatum: 'GDA94', latitude: '-33.83705259', longitude: '151.2062657' },
    address: {
      streetNumber: '177',
      street: 'PACIFIC',
      streetType: 'HWY',
      suburb: 'NORTH SYDNEY',
      state: 'NSW',
      postcode: '2060',
      level: '26',
    },
  },
  {
    nbnLocationId: 'LOC000181491256',
    geocode: { geographicDatum: 'GDA94', latitude: '-33.83705259', longitude: '151.2062657' },
    address: {
      streetNumber: '177',
      street: 'PACIFIC',
      streetType: 'HWY',
      suburb: 'NORTH SYDNEY',
      state: 'NSW',
      postcode: '2060',
      level: '27',
      buildingName: 'PEPPER',
    },
  },
];

export const mockedAddressStatusResponse = {
  status: '13',
  signalStrength: 'good',
  continueNbnJourney: true,
  continue4gFhwJourney: true,
  continue5gFhwJourney: false,
  serviceQualification: {
    locationId: 'LOC000175870737',
    correlationId: '3a65c9c3-de2c-4cd1-afd1-f38536947f1e',
    serviceabilityClass: '13',
    serviceQualificationItem: {
      id: 'LOC000175870737',
      service: {
        serviceabilityStatus: 'Serviceable',
        place: [
          {
            id: 'LOC000175870737',
          },
        ],
        serviceSpecification: {
          name: 'NBN',
          businessFibre: false,
          primaryAccessTechnology: 'Fibre To The Node',
          serviceabilityClass: '13',
        },
        supportingResource: [
          {
            id: 'CPI300005618560',
            type: 'CopperLineResource',
            version: '2.4.0',
            nbnServiceStatus: 'Line Not In Use',
            bandwidthRatesSupported: [
              {
                bandwidthRate: 5,
                featureType: 'TC2',
                supported: true,
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidthRate: 10,
                featureType: 'TC2',
                supported: true,
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidthRate: 20,
                featureType: 'TC2',
                supported: true,
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidthRate: 30,
                featureType: 'TC2',
                supported: false,
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidthRate: 40,
                featureType: 'TC2',
                supported: false,
                unitOfMeasure: 'Mbps',
              },
            ],
            copperBandwidthRates: [
              {
                bandwidth: 40,
                bandwidthType: 'UpstreamMeanRate',
                featureType: 'TC4',
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidth: 80,
                bandwidthType: 'DownstreamCurrentAssuredRate',
                featureType: 'TC4',
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidth: 100,
                bandwidthType: 'DownstreamMeanRate',
                featureType: 'TC4',
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidth: 95,
                bandwidthType: 'DownstreamLowerRate',
                featureType: 'TC4',
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidth: 100,
                bandwidthType: 'DownstreamUpperRate',
                featureType: 'TC4',
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidth: 38,
                bandwidthType: 'UpstreamLowerRate',
                featureType: 'TC4',
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidth: 40,
                bandwidthType: 'UpstreamUpperRate',
                featureType: 'TC4',
                unitOfMeasure: 'Mbps',
              },
              {
                bandwidth: 32,
                bandwidthType: 'UpstreamCurrentAssuredRate',
                featureType: 'TC4',
                unitOfMeasure: 'Mbps',
              },
            ],
            lastActiveDate: '2022-05-06',
            networkCoexistence: true,
            remediationRequired: false,
            serviceabilityClass: '13',
            subsequentInstallationChargeApplies: false,
          },
        ],
        supportingProductFeatures: [
          {
            speedTierAvailability: ['Home Fast'],
            capacityAvailability: [
              {
                available: true,
                capacity: 10,
                featureType: 'TC2',
                unitOfMeasure: 'Mbps',
              },
              {
                available: false,
                capacity: 30,
                featureType: 'TC2',
                unitOfMeasure: 'Mbps',
              },
              {
                available: true,
                capacity: 20,
                featureType: 'TC2',
                unitOfMeasure: 'Mbps',
              },
              {
                available: true,
                capacity: 5,
                featureType: 'TC2',
                unitOfMeasure: 'Mbps',
              },
              {
                available: false,
                capacity: 40,
                featureType: 'TC2',
                unitOfMeasure: 'Mbps',
              },
              {
                capacity: 2,
                featureType: 'TC1',
                highSpeedNotLessThan: true,
                unitOfMeasure: 'Mbps',
              },
              {
                capacity: 20,
                featureType: 'TC2',
                highSpeedNotLessThan: true,
                unitOfMeasure: 'Mbps',
              },
            ],
            multicast: false,
            type: 'NCAS',
            version: '2.4.0',
          },
        ],
        supportingRelatedLocationFeatures: {
          networkBoundaryPoint: 'Telecommunications Outlet',
          newDevelopmentsChargeApplies: false,
          nonPremiseLocation: 'No',
        },
        supportingRelatedSiteBoundaries: {
          csaId: 'CSA200000000824',
          region: 'Urban',
        },
      },
    },
  },
  siteQualificationAuthorisationDate: '2022-05-12T01:39:39.525Z',
};

export const mockNetworkCoverageStatus = {
  fwaStatus: { is4G: true, is5Gsa: true, is5Gnsa: true },
  mobileStatus: {
    is3G: true,
    is4G: true,
    is5G: true,
    is5Gnsa: true,
    is3Gindoor: true,
    is4Gindoor: true,
    is5Gindoor: true,
    is5GindoorNsa: false,
  },
  uiUrl: 'https://mapt.vodafone.com.au/VHAMap/mobile/coverage?lat=-33.84062829&lon=151.20816811&zl=16&device=generic5g',
};

export const mockedAddressStatusResponseWithEmptyStatus = {
  status: '',
  signalStrength: 'good',
  continueNbnJourney: false,
  continue4gFhwJourney: true,
  continue5gFhwJourney: false,
  serviceQualification: {
    locationId: 'LOC000000000001',
    correlationId: 'cor12345',
    serviceabilityClass: '2',
    serviceQualificationItem: {
      id: 'LOC000000000001',
      service: {
        serviceabilityStatus: 'Serviceable',
        serviceSpecification: {
          name: 'NBN',
          primaryAccessTechnology: 'Fibre',
          serviceabilityClass: '2',
          businessFibre: false,
        },
        supportingRelatedSiteBoundaries: {
          region: 'Urban',
          csaId: 'CSA000000000001',
        },
        supportingRelatedLocationFeatures: {
          newDevelopmentsChargeApplies: false,
        },
        supportingProductFeatures: [
          {
            type: 'NFAS',
            version: '2.0.0',
            multicast: true,
            capacityAvailability: [
              {
                featureType: 'TC1',
                capacity: 2,
                unitOfMeasure: 'Mbps',
                highSpeedNotLessThan: true,
              },
              {
                featureType: 'TC2',
                capacity: 20,
                unitOfMeasure: 'Mbps',
                highSpeedNotLessThan: true,
              },
              {
                featureType: 'TC2',
                capacity: 90,
                unitOfMeasure: 'Mbps',
                available: true,
              },
              {
                featureType: 'TC2',
                capacity: 20,
                unitOfMeasure: 'Mbps',
                available: true,
              },
              {
                featureType: 'TC2',
                capacity: 80,
                unitOfMeasure: 'Mbps',
                available: true,
              },
              {
                featureType: 'TC2',
                capacity: 70,
                unitOfMeasure: 'Mbps',
                available: true,
              },
              {
                featureType: 'TC2',
                capacity: 10,
                unitOfMeasure: 'Mbps',
                available: true,
              },
              {
                featureType: 'TC2',
                capacity: 30,
                unitOfMeasure: 'Mbps',
                available: true,
              },
              {
                featureType: 'TC2',
                capacity: 100,
                unitOfMeasure: 'Mbps',
                available: true,
              },
              {
                featureType: 'TC2',
                capacity: 60,
                unitOfMeasure: 'Mbps',
                available: true,
              },
              {
                featureType: 'TC2',
                capacity: 40,
                unitOfMeasure: 'Mbps',
                available: true,
              },
              {
                featureType: 'TC2',
                capacity: 5,
                unitOfMeasure: 'Mbps',
                available: true,
              },
              {
                featureType: 'TC2',
                capacity: 50,
                unitOfMeasure: 'Mbps',
                available: true,
              },
            ],
            speedTierAvailability: ['Home Fast', 'Home Superfast', 'Home Ultrafast'],
            tc2: true,
            tr069UNIV: true,
            ftpUNIV: false,
          },
        ],
        supportingResource: [
          {
            id: 'NTD000000000001',
            type: 'NTD',
            version: '2.0.0',
            uniPortD: [
              {
                id: '1-UNI-D1',
                status: 'Used',
              },
              {
                id: '1-UNI-D2',
                status: 'Free',
              },
              {
                id: '1-UNI-D3',
                status: 'Free',
              },
              {
                id: '1-UNI-D4',
                status: 'Free',
              },
            ],
            uniPortV: [
              {
                id: '1-UNI-V1',
                status: 'Free',
              },
              {
                id: '1-UNI-V2',
                status: 'Free',
              },
            ],
            ntdInstallDate: '2024-06-12T01:06:31Z',
            ntdLocation: 'INDOOR',
            ntdType: 'INTERNAL',
            ntdPowerType: 'AC',
            ntdBatteryBackup: {
              batteryPowerUnit: true,
              powerSupplywithBatteryBackupInstallDate: '2020-06-12T01:06:31Z',
              batteryPowerUnitMonitored: 'ENABLED',
            },
          },
        ],
      },
    },
  },
  siteQualificationAuthorisationDate: '2021-08-13T02:57:18.432Z',
};

export const mockModalData = [
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'findoutmoreesim',
    title: 'eSIM',
    content:
      '&lt;p&gt;An eSIM, as opposed to a physical SIM card, is a SIM that&rsquo;s already embedded into selected mobile phones, tablets and smart watches.&lt;/p&gt;&lt;p&gt;An eSIM allows you to use up to 5 different numbers on the same device.&lt;/p&gt;&lt;p&gt;For example, you&rsquo;ll be able to use one number for business and another number for personal use.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Popular eSIM enabled devices with Vodafone&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Here are some popular eSIM enabled devices with Vodafone.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;iPhone 11&amp;nbsp;&lt;/li&gt;&lt;li&gt;iPhone 11 Pro&lt;/li&gt;&lt;li&gt;iPhone 11 Pro Max&lt;/li&gt;&lt;li&gt;iPhone XR&lt;/li&gt;&lt;li&gt;iPhone XS&lt;/li&gt;&lt;li&gt;iPhone XS Max&lt;/li&gt;&lt;li&gt;10.5 inch iPad Air&lt;/li&gt;&lt;li&gt;11 inch iPad Pro&lt;/li&gt;&lt;li&gt;12.9 inch iPad Pro&lt;/li&gt;&lt;li&gt;iPad (7&lt;sup&gt;th&lt;/sup&gt; gen)&lt;/li&gt;&lt;li&gt;iPad mini&lt;/li&gt;&lt;/ul&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'esimdevices',
    title: 'Popular eSIM enabled devices with Vodafone',
    content:
      '&lt;p&gt;Here are some popular eSIM enabled devices with Vodafone.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;iPhone 11&lt;/li&gt;&lt;li&gt;iPhone 11 Pro&lt;/li&gt;&lt;li&gt;iPhone 11 Pro Max&lt;/li&gt;&lt;li&gt;iPhone XR&lt;/li&gt;&lt;li&gt;iPhone XS&lt;/li&gt;&lt;li&gt;iPhone XS Max&lt;/li&gt;&lt;li&gt;10.5 inch iPad Air&lt;/li&gt;&lt;li&gt;11 inch iPad Pro&lt;/li&gt;&lt;li&gt;12.9 inch iPad Pro&lt;/li&gt;&lt;li&gt;iPad (7th gen)&lt;/li&gt;&lt;li&gt;iPad mini&lt;/li&gt;&lt;/ul&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'simsize',
    title: 'SIM card sizes',
    content:
      '&lt;p&gt;There are several physical SIM card sizes. If you&rsquo;re unsure of your SIM size take out your SIM and compare it to these images. Standard SIMs and Micro SIMs have the same chip size but have a different amount of plastic surrounding them. Nano SIMs are slightly smaller.&lt;/p&gt;&lt;p&gt;Standard SIM&lt;/p&gt;&lt;p&gt;Micro SIM&lt;/p&gt;&lt;p&gt;Nano SIM&lt;/p&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'remainingbalance',
    title: '',
    content:
      '&lt;p&gt;&lt;b&gt;Remaining phone balance&lt;br&gt;&lt;br&gt;&lt;/b&gt;To get a new phone today, you&rsquo;ll need to pay $90.00 on your next bill. This is the remaining balance for your current phone.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Here are some other repayment options&lt;br&gt;&lt;br&gt;&lt;/b&gt;Give us a call on 1555 to discuss these options.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;You could trade-up your current phone if eligible and put the amount towards your new phone&lt;/li&gt;&lt;li&gt;You could pay the monthly repayments of your new phone if eligible, together with the repayments of your current phone&lt;/li&gt;&lt;/ul&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'maxspeed',
    title: 'Your Max Speed',
    content:
      "&lt;p&gt;Once you've used Your Max Speed data, you can keep using as much data as you want at speeds of up to 1.5Mbps.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Your Max Speed&lt;/b&gt; is the fastest speed the Vodafone network can deliver to your phone at the time and place you&rsquo;re using data. You can share Your Max Speed data with other Plus Plans.&lt;/p&gt;&lt;p&gt;&lt;b&gt;With 1.5Mbps&lt;/b&gt; you can stream music and standard definition video, make a video call, browse the internet and catch up on social media. For more information on what you can do at 1.5Mbps, check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/plans/speed-guide.html&quot;&gt;speed guide&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;On Plus Plans, you won&rsquo;t be charged for additional data within Australia.&lt;/p&gt;",
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'zone1',
    title: 'Zone 1 countries',
    content:
      '&lt;p&gt;Here are our Zone 1 countries. These countries are subject to change.&lt;/p&gt;&lt;p&gt;Canada, China, Germany, Guam, Hong Kong, Iceland, India, Ireland, Japan, Malaysia, Mexico, New Zealand, Norway, Puerto Rico, Romania, Singapore, South Korea, Sweden, United Kingdom and the United States of America.&lt;/p&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'zone2',
    title: 'Zone 2 countries',
    content:
      '&lt;p&gt;Here are our Zone 2 countries. These countries are subject to change.&lt;/p&gt;&lt;p&gt;Andorra, Guadeloupe, Philippines, Argentina, Guatemala, Poland, Austria, Holy See (Vatican City State), Portugal, Bahrain, Hungary, Reunion, Bangladesh, Indonesia, Russia, Belgium, Israel, San Marino, Bermuda, Italy, Saudi Arabia, Bolivia, Kazakhstan, Slovakia, Brazil, Kuwait, South Africa, Brunei, Laos, Spain, Cambodia, Lebanon, Spain, Canary Islands, Cayman Islands, Luxembourg, Sri Lanka, Chile, Macau, Swaziland, Colombia, Malta, Switzerland, Costa Rica, Mongolia, Taiwan, Cyprus, Mozambique, Thailand, Czech Republic, Namibia, Turkey, Denmark, Nepal, Turkmenistan, Dominican Republic, Netherlands, United Arab Emirates, Egypt, Northern Mariana Islands, Uruguay, Faroe Islands, Pakistan, Venezuela, France, Panama, Vietnam, Gibraltar, Paraguay, Greece, Peru.&lt;/p&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'networksatisfaction',
    title: 'Our 30 Day Network Satisfaction Guarantee.',
    content:
      'If you&rsquo;re a new customer signing up to a plan and you&rsquo;re not satisfied with our network within the first 30 days, you can leave us. We&rsquo;ll even refund any monthly plan fees or device instalments that you&rsquo;ve paid - just return your device in its original packaging within 10 days of your claim. You&rsquo;ll only have to pay for usage charges or charges for services not included in your plan, which were incurred up to when your cancellation is finalised. Only up to 9 connections for business customers. T&amp;amp;C apply.',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'nbnspeedguide',
    title: 'Factors that affect the speed of nbn™.',
    content:
      '&lt;p&gt;&lt;b&gt;Speed tier of your plan&lt;br&gt;&lt;/b&gt;The speed tier of your plan is like a speed limit. For example, if your plan uses nbn&trade; 25, your maximum download speed will be 25Mbps &ndash; even if your internet could potentially reach higher speeds. It&rsquo;s important to note that various factors affect your internet speed. Because of this, you may not always receive the maximum speed available on your plan.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Your nbn&trade; connection&lt;br&gt;&lt;/b&gt;There may be a maximum line speed for the nbn&trade; connection at your premises. This could be due to your nbn&trade; technology type or other factors, such as the condition of the wiring in your building.&lt;/p&gt;&lt;p&gt;For customers with FTTB/FTTN/FTTC technology, we&rsquo;ll undertake a speed check after your service is activated. If your maximum line speed doesn&rsquo;t support the speed tier of the plan you&rsquo;ve chosen, we&rsquo;ll let you know. We may change your plan to one that&rsquo;s more suitable, so you&rsquo;re not paying more for speeds you can&rsquo;t achieve.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Typical Busy Speed&lt;br&gt;&lt;/b&gt;This is the typical busy period download speed that the average consumer can expect to receive between 7pm and 11pm or 9am to 5pm for business customers. This is not a guaranteed minimum speed and you may experience lower speeds during this period due to the factors discussed on this page.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Content that you access&lt;br&gt;&lt;/b&gt;Driving somewhere that&rsquo;s far away takes longer compared to somewhere that&rsquo;s close. Similarly, downloading content from overseas takes longer than downloading local content. Also, you may experience slower speeds if you&rsquo;re trying to access content that&rsquo;s affected by congestion. This typically happens when a lot of people are trying to access the same site.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Peak hours for internet usage&lt;br&gt;&lt;/b&gt;We constantly monitor the speeds of Vodafone nbn&trade; to try and optimise the experience for our customers. However when a lot of people are online at the same time, your internet speeds can be impacted. It&rsquo;s similar to traffic during peak hour on a busy road, except that the peak time for internet use is usually between 7pm to 11pm.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Our network capacity&lt;br&gt;&lt;/b&gt;Think of the nbn&trade; as a highway, with each provider having a certain number of lanes that customers can use. When you drive on a highway in peak hour, you&rsquo;re less likely to be stuck in traffic if there are more lanes. Similarly the more network capacity your provider buys from nbn co, the faster your internet speeds will be during peak hours. We&rsquo;re constantly monitoring the speeds of Vodafone nbn&trade; to try and optimise the experience for our customers.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Number of devices connected&lt;br&gt;&lt;/b&gt;If you use the internet on a single device, it can access all of your bandwidth. But when multiple devices use your internet at the same time, your bandwidth is shared between them. This may feel like you&rsquo;re experiencing slower speeds, even though it&rsquo;s really the effect of reduced bandwidth for each device.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Modem type&lt;br&gt;&lt;/b&gt;The quality of your modem will impact your speeds, as not all modems are the same. You can select a plan that comes with the Vodafone Wi-Fi Hub&trade; to maximise the performance of your nbn&trade; service.&lt;/p&gt;&lt;p&gt;Modems used on ADSL may not work with Vodafone nbn&trade;, and modems made before 2009 may struggle to reach higher speeds.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Wi-Fi performance&lt;br&gt;&lt;/b&gt;Wi-Fi performance can be impacted by multiple people using the same Wi-Fi network, physical obstacles or interference from surrounding devices.&lt;/p&gt;&lt;p&gt;The Vodafone Wi-Fi Hub&trade; comes with a 2.4GHz and 5GHz Wi-Fi frequency. Generally, the 5Ghz frequency can give you faster speeds at a shorter distance, while 2.4GHz offers more range but may have slower speeds.&lt;/p&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'nbnnetworksatisfaction',
    title: 'Our 30 Day Network Satisfaction Guarantee.',
    content:
      'If you&rsquo;re a new customer signing up to an nbn&trade; plan and you&rsquo;re not satisfied with the network within the first 30 days, you can leave us. We&rsquo;ll even refund any monthly plan fees or device instalments that you&rsquo;ve paid - just return your Wi-Fi Hub&trade; in its original packaging within 10 days of your claim. You&rsquo;ll only have to pay for usage charges or charges for services not included in your plan, which were incurred up to when your cancellation is finalised. Only up to 9 connections for business customers. T&amp;amp;C apply.',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'modemcapability',
    title: '',
    content:
      '&lt;p&gt;&lt;b&gt;Is your modem compatible with Vodafone nbn&trade; at your address?&lt;br&gt;&lt;/b&gt;If you&rsquo;re planning on using your own modem with Vodafone nbn&trade;, it&rsquo;s essential that you verify that your own modem is compatible with nbn&trade; technology used at your address. Vodafone will only be able to provide general support on your service. For technical support related to your modem you&rsquo;ll need to contact the modem manufacturer directly.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Your modem will need to support IPoE authentication&lt;br&gt;&lt;/b&gt;Check if the nbn&trade; technology used at your address is FTTN, FTTB or FTTC. If it is, then your BYO modem will need to be VDSL2 compatible. Review your modem device guide to see if your modem supports IPoE authentication and is VDSL2 compatible.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Even if you have your own modem, a Vodafone Wi-Fi Hub&trade; may provide a better service&lt;br&gt;&lt;/b&gt;If you use Vodafone Wi-Fi Hub&trade; to connect to the nbn&trade; and you need assistance, our support team can help. If many cases, we&rsquo;ll be able to connect to your Vodafone Wi-Fi Hub&trade; remotely to help troubleshoot your service.&lt;/p&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'redplusrates',
    title: 'Red Plus Plans',
    content:
      '&lt;table cellpadding=&quot;1&quot; cellspacing=&quot;0&quot; border=&quot;1&quot; width=&quot;100%&quot;&gt;&lt;tbody&gt;&lt;tr&gt;&lt;td&gt;Standard international video calls&lt;/td&gt;&lt;td&gt;1.5 x international call rates + 40c flag fall&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;International call rates&lt;/td&gt;&lt;td&gt;Check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/plans/international-calls.html&quot;&gt;support page for international call rates&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;International roaming rates&lt;/td&gt;&lt;td&gt;Check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/plans/roaming-rates.html&quot;&gt;support page for international roaming rates&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Premium SMS&lt;/td&gt;&lt;td&gt;Rates dependent on service&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;123 (including 0414100123 &amp;amp; 0414123123) Ask Anything&lt;/td&gt;&lt;td&gt;$1.30/minute and $3.10 connection fee&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;1223 &amp;amp; 1225 Directory assistance&lt;/td&gt;&lt;td&gt;$0.95/minute and $1.50 connection fee&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'simoplusrates',
    title: 'SIM Only Plus Plans',
    content:
      '&lt;table cellpadding=&quot;1&quot; cellspacing=&quot;0&quot; border=&quot;1&quot; width=&quot;100%&quot;&gt;&lt;tbody&gt;&lt;tr&gt;&lt;td&gt;Standard international video calls&nbsp;&lt;/td&gt;&lt;td&gt;1.5 x international call rates + 40c flag fall&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;International call rates&lt;/td&gt;&lt;td&gt;Check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/plans/international-calls.html&quot;&gt;support page for international call rates&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;International roaming rates&nbsp;&lt;/td&gt;&lt;td&gt;Check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/plans/roaming-rates.html&quot;&gt;support page for international roaming rates&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Premium SMS&lt;/td&gt;&lt;td&gt;Rates dependent on service&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;123 (including 0414100123 &amp;amp; 0414123123) Ask Anything&lt;/td&gt;&lt;td&gt;$1.30/minute and $3.10 connection fee&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;1223 &amp;amp; 1225 Directory asistance&lt;/td&gt;&lt;td&gt;$0.95/minute and $1.50 connection fee&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'autorecharge',
    title: 'Automatic recharge',
    content:
      "You can save your credit or debit card to opt-in for Automatic Recharge. By saving your card, you authorise Vodafone to use these details to perform an Automatic Recharge on your prepaid plan's expiry date. The plan you will be Auto Recharged on will be the same plan as your most recent recharge, and you can opt-out at any time.",
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'comboplusrechargeoptions',
    title: 'Combo Plus recharges',
    content:
      '&lt;p&gt;Here are the Combo Plus recharge options.&lt;/p&gt;&lt;table cellpadding=&quot;1&quot; cellspacing=&quot;0&quot; border=&quot;1&quot; width=&quot;100%&quot;&gt;&lt;tbody&gt;&lt;tr&gt;&lt;th scope=&quot;col&quot; style=&quot;text-align: center;&quot;&gt;&nbsp;&lt;/th&gt;&lt;th scope=&quot;col&quot; style=&quot;text-align: center;&quot;&gt;$10&lt;/th&gt;&lt;th scope=&quot;col&quot; style=&quot;text-align: center;&quot;&gt;$20&lt;/th&gt;&lt;th scope=&quot;col&quot; style=&quot;text-align: center;&quot;&gt;$30&lt;/th&gt;&lt;th scope=&quot;col&quot; style=&quot;text-align: center;&quot;&gt;$40&lt;/th&gt;&lt;th scope=&quot;col&quot; style=&quot;text-align: center;&quot;&gt;$50&lt;/th&gt;&lt;th scope=&quot;col&quot; style=&quot;text-align: center;&quot;&gt;$60&lt;/th&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Data&lt;/td&gt;&lt;td&gt;4GB&lt;/td&gt;&lt;td&gt;8GB&lt;/td&gt;&lt;td&gt;10GB&lt;/td&gt;&lt;td&gt;20GB&lt;/td&gt;&lt;td&gt;30GB&lt;/td&gt;&lt;td&gt;45GB&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Expiry&lt;/td&gt;&lt;td&gt;14 days&lt;/td&gt;&lt;td&gt;35 day&lt;/td&gt;&lt;td&gt;35 days&lt;/td&gt;&lt;td&gt;35 days&lt;/td&gt;&lt;td&gt;35 days&lt;/td&gt;&lt;td&gt;35 days&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Unlimited standard national calls&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Unlimited standard national text&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;td&gt;&nbsp;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard international minutes&lt;/td&gt;&lt;td&gt;N/A&lt;/td&gt;&lt;td&gt;N/A&lt;/td&gt;&lt;td&gt;N/A&lt;/td&gt;&lt;td&gt;500 minutes to Zone 1 countries and 100 minutes to Zone 2 countries&lt;/td&gt;&lt;td&gt;1000 minutes to Zone 1 countries and 150 minutes to Zone 2 countries&lt;/td&gt;&lt;td&gt;2000 minutes to Zone 1 countries and 200 minutes to Zone 2 countries&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard international text&lt;/td&gt;&lt;td&gt;50&lt;/td&gt;&lt;td&gt;50&lt;/td&gt;&lt;td&gt;50&lt;/td&gt;&lt;td&gt;50&lt;/td&gt;&lt;td&gt;50&lt;/td&gt;&lt;td&gt;50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;7&quot;&gt;All data charged per 1KB. View the Critical Information Summary for Combo Plus recharges.&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'comboplusrates',
    title: 'Combo Plus rates and charges to use through My Credit',
    content:
      '&lt;table cellpadding=&quot;1&quot; cellspacing=&quot;0&quot; border=&quot;1&quot;&gt;&lt;tbody&gt;&lt;tr&gt;&lt;td&gt;Standard international calls&lt;/td&gt;&lt;td&gt;If your plan doesn&rsquo;t include standard international calls or if you&rsquo;ve used all your standard international calls, check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.auhttps://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/prepaid/international-call-rates.html&quot;&gt;support page for international call rates&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard international video calls&lt;/td&gt;&lt;td&gt;Check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.auhttps://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/prepaid/international-call-rates.html&quot;&gt;support page for international call rates&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;International roaming&lt;/td&gt;&lt;td&gt;Check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/prepaid/roaming-rates.html&quot;&gt;support page for international roaming rates&lt;/a&gt; &lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Premium SMS/MMS&lt;/td&gt;&lt;td&gt;Rates dependent on service&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;123 (including 0414100123 &amp;amp; 0414123123) Ask Anything&lt;/td&gt;&lt;td&gt;$1.30/minute and $3.10 connection fee&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;1223 &amp;amp; 1225 Directory assistance&lt;/td&gt;&lt;td&gt;$0.95/minute and $1.50 connection fee&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard international MMS&lt;/td&gt;&lt;td&gt;$0.50 per message&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard international video MMS&lt;/td&gt;&lt;td&gt;$0.75 per message&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Voicemail&lt;/td&gt;&lt;td&gt;Unlimited&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'payandgointrates',
    title: 'Standard international call rates',
    content:
      '&lt;p&gt;Here are our rates for standard international calls for Pay and Go.&lt;/p&gt;&lt;div class=&quot;spl-table-container&quot;&gt;&lt;table cellpadding=&quot;0&quot; cellspacing=&quot;0&quot; class=&quot;striped table-hover&quot;&gt;&lt;tbody&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Country&lt;/b&gt;&lt;/td&gt;&lt;td&gt;&lt;b&gt;Rate per 60 secs&lt;/b&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Afghanistan (+93)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Albania (+355)&lt;/td&gt;&lt;td&gt;$1.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Algeria (+213)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;American Samoa (+1-684)&lt;/td&gt;&lt;td&gt;$1.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Andorra (+376)&lt;/td&gt;&lt;td&gt;$0.35&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Angola (+244)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Anguilla (+1-264)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Antarctica (+672)&lt;/td&gt;&lt;td&gt;$2.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Antigua and Barbuda (+1-268)&lt;/td&gt;&lt;td&gt;$0.60&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Argentina (+54)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Armenia (+374)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Aruba (+297)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Ascension (+247)&lt;/td&gt;&lt;td&gt;$2.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Austria (+43)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Azerbaijan (+994)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Bahamas (+1-242)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Bahrain (+973)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Bangladesh (+880)&lt;/td&gt;&lt;td&gt;$0.06&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Barbados (+1-246)&lt;/td&gt;&lt;td&gt;$0.60&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Belarus (+375)&lt;/td&gt;&lt;td&gt;$1.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Belgium (+32)&lt;/td&gt;&lt;td&gt;$0.10&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Belize (+501)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Benin (+229)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Bermuda (+1-441)&lt;/td&gt;&lt;td&gt;$0.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Bhutan (+975)&lt;/td&gt;&lt;td&gt;$0.35&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Bolivia (+591)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Bosnia and Herzegovina (+387)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Botswana (+267)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Brazil (+55)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Brunei (+673)&lt;/td&gt;&lt;td&gt;$0.10&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Bulgaria (+359)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Burkina Faso (+226)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Burundi (+257)&lt;/td&gt;&lt;td&gt;$1.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Cambodia (+855)&lt;/td&gt;&lt;td&gt;$0.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Cameroon (+237)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Canada (+1)&lt;/td&gt;&lt;td&gt;$0.03&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Cape Verde (+238)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Cayman Islands (+1-345)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Central African Republic (+236)&lt;/td&gt;&lt;td&gt;$1.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Chad (+235)&lt;/td&gt;&lt;td&gt;$1.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Chile (+56)&lt;/td&gt;&lt;td&gt;$0.08&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;China (+86)&lt;/td&gt;&lt;td&gt;$0.02&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Colombia (+57)&lt;/td&gt;&lt;td&gt;$0.08&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Comoros (+269)&lt;/td&gt;&lt;td&gt;$1.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Congo (+242)&lt;/td&gt;&lt;td&gt;$1.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Cook Islands (+682)&lt;/td&gt;&lt;td&gt;$2.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Costa Rica (+506)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Croatia (+385)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Cuba (+53)&lt;/td&gt;&lt;td&gt;$1.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Curacao (+599)&lt;/td&gt;&lt;td&gt;$1.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Cyprus (+357)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Czech Republic (+420)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Denmark (+45)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Diego Garcia (+246)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Djibouti (+253)&lt;/td&gt;&lt;td&gt;$0.70&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Dominica (+1-767)&lt;/td&gt;&lt;td&gt;$1.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Dominican Republic (+1-809, +1-829, +1-849)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;East Timor (+670)&lt;/td&gt;&lt;td&gt;$3.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Ecuador (+593)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Egypt (+20)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;El Salvador (+503)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Equatorial Guinea (+240)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Eritrea (+291)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Estonia (+372)&lt;/td&gt;&lt;td&gt;$0.95&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Ethiopia (+251)&lt;/td&gt;&lt;td&gt;$0.60&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Falkland Islands (+500)&lt;/td&gt;&lt;td&gt;$1.90&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Faroe Islands (+298)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Fiji (+679)&lt;/td&gt;&lt;td&gt;$0.45&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Finland (+358)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;France (+33)&lt;/td&gt;&lt;td&gt;$0.10&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;French Antilles (+596)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;French Guiana (+594)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;French Polynesia (+689)&lt;/td&gt;&lt;td&gt;$1.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Gabon (+241)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Gambia (+220)&lt;/td&gt;&lt;td&gt;$3.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Georgia (+995)&lt;/td&gt;&lt;td&gt;$1.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Germany (+49)&lt;/td&gt;&lt;td&gt;$0.09&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Ghana (+233)&lt;/td&gt;&lt;td&gt;$0.60&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Gibraltar (+350)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Greece (+30)&lt;/td&gt;&lt;td&gt;$0.10&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Greenland (+299)&lt;/td&gt;&lt;td&gt;$1.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Grenada (+1-473)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Guadeloupe (+590)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Guam (+1-671)&lt;/td&gt;&lt;td&gt;$0.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Guantanamo Bay (+5399)&lt;/td&gt;&lt;td&gt;$3.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Guatemala (+502)&lt;/td&gt;&lt;td&gt;$1.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Guinea (+224)&lt;/td&gt;&lt;td&gt;$1.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Guinea-Bissau (+245)&lt;/td&gt;&lt;td&gt;$1.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Guyana (+592)&lt;/td&gt;&lt;td&gt;$0.95&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Haiti (+509)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Honduras (+504)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Hong Kong (+852)&lt;/td&gt;&lt;td&gt;$0.04&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Hungary (+36)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Iceland (+354)&lt;/td&gt;&lt;td&gt;$0.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;India (+91)&lt;/td&gt;&lt;td&gt;$0.03&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Indonesia (+62)&lt;/td&gt;&lt;td&gt;$0.11&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Iran (+98)&lt;/td&gt;&lt;td&gt;$0.35&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Iraq (+964)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Ireland (+353)&lt;/td&gt;&lt;td&gt;$0.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Israel (+972)&lt;/td&gt;&lt;td&gt;$0.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Italy (+39)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Ivory coast (Cote DIvoire) (+225)&lt;/td&gt;&lt;td&gt;$3.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Jamaica (+1-876)&lt;/td&gt;&lt;td&gt;$1.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Japan (+81)&lt;/td&gt;&lt;td&gt;$0.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Jordan (+962)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Kazakhstan (+7)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Kenya (+254)&lt;/td&gt;&lt;td&gt;$0.35&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Kiribati (+686)&lt;/td&gt;&lt;td&gt;$2.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Korea, North (DPRK) (+850)&lt;/td&gt;&lt;td&gt;$0.95&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Korea, South (+82)&lt;/td&gt;&lt;td&gt;$0.04&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Kuwait (+965)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Kyrgyzstan (+996)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Laos (+856)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Latvia (+371)&lt;/td&gt;&lt;td&gt;$1.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Lebanon (+961)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Lesotho (+266)&lt;/td&gt;&lt;td&gt;$1.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Liberia (+231)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Libya (+218)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Liechtenstein (+423)&lt;/td&gt;&lt;td&gt;$2.40&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Lithuania (+370)&lt;/td&gt;&lt;td&gt;$1.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Luxembourg (+352)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Macau (+853)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Macedonia (+389)&lt;/td&gt;&lt;td&gt;$0.60&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Madagascar (+261)&lt;/td&gt;&lt;td&gt;$3.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Malawi (+265)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Malaysia (+60)&lt;/td&gt;&lt;td&gt;$0.04&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Maldives (+960)&lt;/td&gt;&lt;td&gt;$2.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Mali (+223)&lt;/td&gt;&lt;td&gt;$1.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Malta (+356)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Marshall Islands (+692)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Martinique (+596)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Mauritania (+222)&lt;/td&gt;&lt;td&gt;$1.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Mauritius (+230)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Mexico (+52)&lt;/td&gt;&lt;td&gt;$0.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Micronesia (+691)&lt;/td&gt;&lt;td&gt;$1.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Moldova (+373)&lt;/td&gt;&lt;td&gt;$0.90&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Monaco (+377)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Mongolia (+976)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Montenegro (+382)&lt;/td&gt;&lt;td&gt;$0.85&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Montserrat (+1-664)&lt;/td&gt;&lt;td&gt;$1.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Morocco (+212)&lt;/td&gt;&lt;td&gt;$0.90&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Mozambique (+258)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Myanmar (+95)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Namibia (+264)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Nauru&amp;nbsp;(+674)&lt;/td&gt;&lt;td&gt;$2.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Nepal&amp;nbsp;(+977)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Netherlands&amp;nbsp;(+31)&lt;/td&gt;&lt;td&gt;$0.10&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;New Caledonia&amp;nbsp;(+687)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;New Zealand&amp;nbsp;(+64)&lt;/td&gt;&lt;td&gt;$0.09&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Nicaragua&amp;nbsp;(+505)&lt;/td&gt;&lt;td&gt;$3.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Niger&amp;nbsp;(+227)&lt;/td&gt;&lt;td&gt;$1.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Nigeria&amp;nbsp;(+234)&lt;/td&gt;&lt;td&gt;$0.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Niue&amp;nbsp;(+683)&lt;/td&gt;&lt;td&gt;$3.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Norfolk Island&amp;nbsp;(+672)&lt;/td&gt;&lt;td&gt;$2.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Northern Mariana Islands&amp;nbsp;(+1-670)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Norway&amp;nbsp;(+47)&lt;/td&gt;&lt;td&gt;$0.10&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Oman&amp;nbsp;(+968)&lt;/td&gt;&lt;td&gt;$0.60&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Pakistan&amp;nbsp;(+92)&lt;/td&gt;&lt;td&gt;$0.09&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Palau&amp;nbsp;(+680)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Palestinian Territory&amp;nbsp;(+970)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Panama&amp;nbsp;(+507)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Papua New Guinea&amp;nbsp;(+675)&lt;/td&gt;&lt;td&gt;$1.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Paraguay&amp;nbsp;(+595)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Peru&amp;nbsp;(+51)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Philippines&amp;nbsp;(+63)&lt;/td&gt;&lt;td&gt;$0.21&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Poland&amp;nbsp;(+48)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Portugal&amp;nbsp;(+351)&lt;/td&gt;&lt;td&gt;$0.10&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Puerto Rico&amp;nbsp;(+1-787, +1-939)&lt;/td&gt;&lt;td&gt;$0.15&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Qatar&amp;nbsp;(+974)&lt;/td&gt;&lt;td&gt;$0.45&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Reunion&amp;nbsp;(+262)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Romania&amp;nbsp;(+40)&lt;/td&gt;&lt;td&gt;$0.09&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Russia&amp;nbsp;(+7)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Rwanda&amp;nbsp;(+250)&lt;/td&gt;&lt;td&gt;$0.70&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Saint Helena&amp;nbsp;(+290)&lt;/td&gt;&lt;td&gt;$1.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Saint Kitts and Nevis&amp;nbsp;(+1-869)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Saint Lucia&amp;nbsp;(+1-758)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Saint Pierre &amp;amp; Miquelon&amp;nbsp;(+508)&lt;/td&gt;&lt;td&gt;$0.02&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Saint Vincent &amp;amp; The Grenadines&amp;nbsp;(+1-784)&lt;/td&gt;&lt;td&gt;$3.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Samoa&amp;nbsp;(+685)&lt;/td&gt;&lt;td&gt;$1.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;San Marino&amp;nbsp;(+378)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Sao Tome and Principe&amp;nbsp;(+239)&lt;/td&gt;&lt;td&gt;$3.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Saudi Arabia&amp;nbsp;(+966)&lt;/td&gt;&lt;td&gt;$0.18&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Senegal&amp;nbsp;(+221)&lt;/td&gt;&lt;td&gt;$0.90&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Serbia&amp;nbsp;(+381)&lt;/td&gt;&lt;td&gt;$0.70&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Seychelles&amp;nbsp;(+248)&lt;/td&gt;&lt;td&gt;$1.60&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Sierra Leone&amp;nbsp;(+232)&lt;/td&gt;&lt;td&gt;$1.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Singapore&amp;nbsp;(+65)&lt;/td&gt;&lt;td&gt;$0.02&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Slovak Republic&amp;nbsp;(+421)&lt;/td&gt;&lt;td&gt;$0.45&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Slovenia&amp;nbsp;(+386)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Solomon Islands&amp;nbsp;(+677)&lt;/td&gt;&lt;td&gt;$1.90&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Somalia&amp;nbsp;(+252)&lt;/td&gt;&lt;td&gt;$1.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;South Africa&amp;nbsp;(+27)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;South Sudan&amp;nbsp;(+211)&lt;/td&gt;&lt;td&gt;$0.35&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Spain&amp;nbsp;(+34)&lt;/td&gt;&lt;td&gt;$0.10&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Sri Lanka&amp;nbsp;(+94)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Sudan&amp;nbsp;(+249)&lt;/td&gt;&lt;td&gt;$0.35&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Suriname&amp;nbsp;(+597)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Swaziland&amp;nbsp;(+268)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Sweden&amp;nbsp;(+46)&lt;/td&gt;&lt;td&gt;$0.09&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Switzerland&amp;nbsp;(+41)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Syria&amp;nbsp;(+963)&lt;/td&gt;&lt;td&gt;$0.45&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Taiwan&amp;nbsp;(+886)&lt;/td&gt;&lt;td&gt;$1.40&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Tajikistan&amp;nbsp;(+992)&lt;/td&gt;&lt;td&gt;$1.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Tanzania&amp;nbsp;(+255)&lt;/td&gt;&lt;td&gt;$0.90&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Thailand&amp;nbsp;(+66)&lt;/td&gt;&lt;td&gt;$0.04&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;The Democratic Republic of Congo&amp;nbsp;(+243)&lt;/td&gt;&lt;td&gt;$1.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Togo&amp;nbsp;(+228)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Tokelau&amp;nbsp;(+690)&lt;/td&gt;&lt;td&gt;$3.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Tonga&amp;nbsp;(+676)&lt;/td&gt;&lt;td&gt;$1.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Trinidad and Tobago&amp;nbsp;(+1-868)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Tunisia&amp;nbsp;(+216)&lt;/td&gt;&lt;td&gt;$1.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Turkey&amp;nbsp;(+90)&lt;/td&gt;&lt;td&gt;$0.25&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Turkmenistan&amp;nbsp;(+993)&lt;/td&gt;&lt;td&gt;$0.40&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Turks &amp;amp; Caicos Islands&amp;nbsp;(+1-649)&lt;/td&gt;&lt;td&gt;$2.10&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Tuvalu&amp;nbsp;(+688)&lt;/td&gt;&lt;td&gt;$2.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;U.K&amp;nbsp;(+44)&lt;/td&gt;&lt;td&gt;$0.09&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;U.S.A.&amp;nbsp;(+1)&lt;/td&gt;&lt;td&gt;$0.03&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;UAE&amp;nbsp;(+971)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Uganda&amp;nbsp;(+256)&lt;/td&gt;&lt;td&gt;$0.75&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Ukraine&amp;nbsp;(+380)&lt;/td&gt;&lt;td&gt;$0.60&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Uruguay&amp;nbsp;(+598)&lt;/td&gt;&lt;td&gt;$0.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Uzbekistan&amp;nbsp;(+998)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Vanuatu&amp;nbsp;(+678)&lt;/td&gt;&lt;td&gt;$1.80&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Vatican City (Holy See)&amp;nbsp;(+379)&lt;/td&gt;&lt;td&gt;$0.20&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Venezuela&amp;nbsp;(+58)&lt;/td&gt;&lt;td&gt;$0.10&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Vietnam&amp;nbsp;(+84)&lt;/td&gt;&lt;td&gt;$0.18&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Virgin Islands (UK)&amp;nbsp;(+1)&lt;/td&gt;&lt;td&gt;$3.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Virgin Islands(USA)&amp;nbsp;(+1)&lt;/td&gt;&lt;td&gt;$0.50&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Wallis &amp;amp; Futuna Islands&amp;nbsp;(+681)&lt;/td&gt;&lt;td&gt;$3.00&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Yemen&amp;nbsp;(+967)&lt;/td&gt;&lt;td&gt;$0.30&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Zambia&amp;nbsp;(+260)&lt;/td&gt;&lt;td&gt;$0.60&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Zimbabwe&amp;nbsp;(+263)&lt;/td&gt;&lt;td&gt;$0.65&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;&lt;/div&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'payandgorechargeoptions',
    title: 'Pay and Go recharges',
    content:
      '&lt;p&gt;Here are the Pay and Go recharge options.&lt;/p&gt;&lt;table cellpadding=&quot;1&quot; cellspacing=&quot;0&quot; border=&quot;1&quot;&gt;&lt;tbody&gt;&lt;tr&gt;&lt;th style=&quot;text-align: center;&quot;&gt;&amp;nbsp;&lt;/th&gt;&lt;th style=&quot;text-align: center;&quot;&gt;$10&lt;/th&gt;&lt;th style=&quot;text-align: center;&quot;&gt;$20&lt;/th&gt;&lt;th style=&quot;text-align: center;&quot;&gt;$30&lt;/th&gt;&lt;th style=&quot;text-align: center;&quot;&gt;$40&lt;/th&gt;&lt;th style=&quot;text-align: center;&quot;&gt;$50&lt;/th&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Expiry&lt;/td&gt;&lt;td&gt;60 days&lt;/td&gt;&lt;td&gt;60 days&lt;/td&gt;&lt;td&gt;180 days&lt;/td&gt;&lt;td&gt;365 days&lt;/td&gt;&lt;td&gt;365 days&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Data&lt;/td&gt;&lt;td colspan=&quot;5&quot;&gt;4c per MB&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard national calls&lt;/td&gt;&lt;td colspan=&quot;5&quot;&gt;20c per minute&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard national SMS&lt;/td&gt;&lt;td colspan=&quot;5&quot;&gt;20c per SMS&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;National and international MMS&lt;/td&gt;&lt;td colspan=&quot;5&quot;&gt;50c per MMS&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td colspan=&quot;6&quot;&gt;View the Critical Information Summary for Pay and Go recharges&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;',
  },
  {
    cancelCtaLabel: '',
    confirmCtaLabel: '',
    id: 'payandgorates',
    title: 'Pay and Go rates and charges',
    content:
      '&lt;table cellpadding=&quot;1&quot; cellspacing=&quot;0&quot; border=&quot;1&quot;&gt;&lt;tbody&gt;&lt;tr&gt;&lt;td&gt;Data&lt;/td&gt;&lt;td&gt;4c per MB in 512KB increments&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard national voice calls&lt;/td&gt;&lt;td&gt;20c per minute&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard national SMS&lt;/td&gt;&lt;td&gt;20c per SMS&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard national MMS&lt;/td&gt;&lt;td&gt;50c per MMS&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard national video MMS&lt;/td&gt;&lt;td&gt;75c per video MMS&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;13 numbers&lt;/td&gt;&lt;td&gt;20c per minute&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;15 numbers&amp;nbsp;&lt;/td&gt;&lt;td&gt;Rates dependent on service&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;18 numbers&amp;nbsp;&lt;/td&gt;&lt;td&gt;20c per minute&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;1800 numbers&lt;/td&gt;&lt;td&gt;Unlimited&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard international calls&lt;/td&gt;&lt;td&gt;Check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.auhttps://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/prepaid/international-call-rates.html&quot;&gt;support page for international call rates&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard international SMS&lt;/td&gt;&lt;td&gt;20c per SMS&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard international MMS&lt;/td&gt;&lt;td&gt;50c per MMS&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard international video MMS&lt;/td&gt;&lt;td&gt;75c per video MMS&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Standard international video calls&lt;/td&gt;&lt;td&gt;Check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.auhttps://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/prepaid/international-call-rates.html&quot;&gt;support page for international call rates&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Internatoinal romaing&lt;/td&gt;&lt;td&gt;Check out our &lt;a href=&quot;https://aem-content-publisher.test.devops.services.vodafone.com.au/content/vha/support/prepaid/roaming-rates.html&quot;&gt;support page for international roaming rates&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Premium SMS&lt;/td&gt;&lt;td&gt;Rates dependent on service&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;123 (0414100123 &amp;amp; 0414123123) Ask Anything&lt;/td&gt;&lt;td&gt;$1.30/minute and $3.10 connection fee&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;1223 &amp;amp; 1225 Directory assistance&lt;/td&gt;&lt;td&gt;$0.95/minute and $1.50 connection fee&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;Voicemail&lt;/td&gt;&lt;td&gt;20c per minute&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;',
  },
];

export const mockAdditionalServiceBundleDetails: AdditionalServiceBundleDetails = {
  title: 'Welcome',
  sectionTitle: 'Your services',
  sectionInformation: {
    description:
      "&lt;p&gt;If you have more than one &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;bundleandsave&quot; style=&quot;color: black;&quot;&gt;eligible plan&lt;/vha-modal-trigger&gt; under your account, you&rsquo;re getting a Bundle &amp;amp; Save discount.&nbsp;Prepaid plans aren't eligible for Bundle &amp;amp; Save.&lt;/p&gt;",
    href: '',
    title: 'Bundle &amp;amp; Save eligible plans',
  },
  termsAndConditions: {
    description: '',
    label: '',
  },
  iconUrl:
    'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/0778-additional-services-hub-bundle-save-logo.png',
  phoneIconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/mobile.svg',
  planIconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/plans.svg',
  nbnIconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/nbn.svg',
  tabletIconUrl: 'https://www-prod.prod.cms.df.services.vodafone.com.au/images/icons/tablet.svg',
  savingsTitle: 'Your Savings',
  savingsImageUrl:
    'https://www-prod.prod.cms.df.services.vodafone.com.au/images/generic/0778-additional-services-hub-bundle-save-infographic.png',
};

export const mockUpgradesPageHeaderData: UpgradesPageHeaderContent = {
  ctaHomeLabel: 'Go to Home',
  altText: 'Welcome to upgrades',
  seoData: [],
  confirmCtaLabel: '',
  title: 'Welcome to upgrades',
  seoTitle: 'Upgrades Hub | Vodafone Australia',
  otherServicesLabel: 'View your other services',
  onlineUpgradeError:
    '&lt;p&gt;&lt;b&gt;Unfortunately, you can&rsquo;t upgrade online.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;If you&rsquo;d like to upgrade, give us a call to discuss your options on:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;1555 from your Vodafone mobile&lt;/li&gt;&lt;li&gt;1300 650 410&lt;/li&gt;&lt;/ul&gt;',
  alerts: [
    {
      alertType: 'error',
      alertId: 'enterprise-customer',
      alertText:
        '&lt;p&gt;&lt;b&gt;Unfortunately, you can&rsquo;t upgrade &lt;a&gt;online.&lt;/a&gt;&lt;/b&gt;&lt;/p&gt;&lt;p&gt;As you&rsquo;re an enterprise business customer, you can&rsquo;t upgrade online. If you&rsquo;d like to upgrade, give us a call on 1300 111 111.&lt;/p&gt;',
    },
    {
      alertType: 'error',
      alertId: 'barred-number',
      alertText:
        "&lt;p&gt;&lt;b&gt;Unfortunately, you can't upgrade online.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;If you&rsquo;d like to upgrade, give us a call on:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;1555 from your Vodafone mobile&lt;/li&gt;&lt;li&gt;1300 650 410 from any phone&lt;/li&gt;&lt;/ul&gt;",
    },
    {
      alertType: 'error',
      alertId: 'prepaid-no-account',
      alertText:
        "&lt;p&gt;&lt;b&gt;Unfortunately, you can't upgrade online.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;If you have any questions, give us a call on:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;1555 from your Vodafone mobile&nbsp;&lt;/li&gt;&lt;li&gt;1300 650 410 from any phone&lt;/li&gt;&lt;/ul&gt;",
    },
    {
      alertType: 'error',
      alertId: 'assured-cap',
      alertText:
        "&lt;p&gt;&lt;b&gt;Unfortunately, you can't upgrade online.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;If you have any questions, give us a call on:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;1555 from your Vodafone mobile&nbsp;&lt;/li&gt;&lt;li&gt;1300 650 410 from any phone&lt;/li&gt;&lt;/ul&gt;",
    },
    {
      alertType: 'error',
      alertId: 'no-upgrade-items',
      alertText:
        '&lt;p&gt;&lt;b&gt;You can&rsquo;t upgrade online yet&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Unfortunately, you can&rsquo;t upgrade online yet with the items in your cart.&lt;/p&gt;&lt;p&gt;Give us a call to discuss your options on:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;1555 from your Vodafone mobile&lt;/li&gt;&lt;li&gt;1300 650 410&lt;/li&gt;&lt;/ul&gt;',
    },
    {
      alertType: 'error',
      alertId: 'no-upgrade-online',
      alertText:
        '&lt;p&gt;&lt;b&gt;Unfortunately, you can&rsquo;t upgrade online.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;If you&rsquo;d like to upgrade, give us a call to discuss your options on:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;1555 from your Vodafone mobile&lt;/li&gt;&lt;li&gt;1300 650 410&lt;/li&gt;&lt;/ul&gt;',
    },
    {
      alertType: 'error',
      alertId: 'plan-not-added',
      alertText:
        '&lt;p&gt;&lt;b&gt;This plan hasn&rsquo;t been added to your cart&lt;/b&gt;&lt;/p&gt;&lt;p&gt;As you already have a plan in your cart, we haven&rsquo;t added this second plan to your cart.&lt;/p&gt;',
    },
    {
      alertType: 'error',
      alertId: 'mbb',
      alertText:
        '&lt;p&gt;Unfortunately, you can&rsquo;t upgrade your mobile broadband service online. To upgrade your mobile broadband service, please give us a call on 1300 650 410.&lt;/p&gt;',
    },
  ],
  serviceCardMessageSIMO:
    '&lt;p&gt;To get a new SIM Only Plan over phone or in store, you&rsquo;ll need to pay an Early Upgrade Fee of {UPGRADE_COST} on your next bill. This fee will be waived if you get a new phone and plan.&lt;/p&gt;',
  cancelCtaLabel: '',
  homepageUrl: '/content/vha/personal',
  subtitle: 'It’s great to see you.',
  metaTags:
    '&lt;meta name=&quot;title&quot; content=&quot;Upgrades Hub | Vodafone Australia&quot; /&gt;&lt;title&gt;Upgrades Hub | Vodafone Australia&lt;/title&gt;&lt;meta name=&quot;robots&quot; content=&quot;noindex,nofollow&quot; /&gt;',
  serviceCardMessage:
    'To get a new phone today, you&rsquo;ll need to pay&nbsp;{UPGRADE_COST} on your next bill. This is the &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;remainingbalance&quot; style=&quot;color: black;&quot;&gt;remaining balance&lt;/vha-modal-trigger&gt; for your current phone. However, you may have &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;remainingbalance&quot; style=&quot;color: black;&quot;&gt;other repayment options.&lt;/vha-modal-trigger&gt;',
  imageUrl:
    'https://aem-content-publisher.test.devops.services.vodafone.com.au/content/dam/vha/images/generic/0761-upgrade-hero-desktop.jpg',
  imageTablet: '',
  imageMobile: '',
  journeyTitle: '',
  theme: '',
  phoneIconUrl:
    'https://aem-content-publisher.test.devops.services.vodafone.com.au/content/dam/vha/images/icons/mobile-mid.svg',
  planIconUrl:
    'https://aem-content-publisher.test.devops.services.vodafone.com.au/content/dam/vha/images/icons/sim-mid.svg',
  tabletIcon: 'https://www.vodafone.com.au/images/icons/tablet-mid.svg',
  twoWaySmsIconUrl: 'https://www-sit.test.cms.df.services.vodafone.com.au/images/icons/tick-or-solved-green.svg',
  twoWaySmsMessage:
    "For security, we may send an SMS to 04*****553  to confirm the order. If 04*****553 isn't the best number to receive this SMS, please update your number through My Vodafone.",
  twoWaySmsInvalidMessage:
    'For security, we may send you an SMS to confirm the order. Please update your details with an Australian mobile number through My Vodafone',
};

export const mockCurrentServiceData: CurrentServiceData = {
  msisdn: '61430114436',
  formattedMSISDN: '0430 114 436',
  formattedTotalCost: '65',
  totalCost: 65,
  serviceCardMessageSIMO:
    '&lt;p&gt;To get a new SIM Only Plan over phone or in store, you&rsquo;ll need to pay an Early Upgrade Fee of 0 on your next bill. This fee will be waived if you get a new phone and plan.&lt;/p&gt;',
  serviceCardMessage:
    'To get a new phone today, you&rsquo;ll need to pay&nbsp;0 on your next bill. This is the &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;remainingbalance&quot; style=&quot;color: black;&quot;&gt;remaining balance&lt;/vha-modal-trigger&gt; for your current phone. However, you may have &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;remainingbalance&quot; style=&quot;color: black;&quot;&gt;other repayment options.&lt;/vha-modal-trigger&gt;',
  phoneIconUrl:
    'https://www-preprod.preprod.cms.df.services.vodafone.com.au/content/dam/vha/images/icons/mobile-mid.svg',
  planIconUrl: 'https://www-preprod.preprod.cms.df.services.vodafone.com.au/content/dam/vha/images/icons/sim-mid.svg',
  tabletIcon: 'https://www-preprod.preprod.cms.df.services.vodafone.com.au/content/dam/vha/images/icons/tablet-mid.svg',
  plan: {
    balanceAmount: 0,
    displayProductType: 'Plan',
    displayName: '$50 RED Plan',
    monthlyCharge: 50,
    monthlyRemaining: 0,
    contractAmount: 0,
    contractTerm: 0,
    formattedContractTerm: 'Month to month',
    formattedMonthlyCharge: '$50',
    paid: false,
  },
  phone: {
    balanceAmount: 0,
    displayProductType: 'Phone',
    displayName: 'iPhone X 64GB (Space Grey)',
    monthlyCharge: 0,
    monthlyRemaining: 0,
    contractAmount: 0,
    contractTerm: 0,
    itemName: 'IPHONE X 64GB SPACE GREY',
    formattedContractTerm: 'Month to month',
    formattedMonthlyCharge: '$0',
    paid: true,
  },
  extras: [
    {
      displayProductType: 'AddOn',
      displayName: 'Extra IDD 120min - 20 countries',
      balanceAmount: 0,
      monthlyCharge: 0,
      monthlyRemaining: 0,
      contractAmount: 0,
      contractTerm: 0,
      paid: true,
      formattedContractTerm: 'Month to month',
      formattedMonthlyCharge: '$0',
    },
    {
      displayProductType: 'Insurance',
      displayName: 'Phone Insurance',
      balanceAmount: 0,
      monthlyCharge: 15,
      monthlyRemaining: 0,
      contractAmount: 0,
      contractTerm: 0,
      paid: true,
      formattedContractTerm: 'Month to month',
      formattedMonthlyCharge: '$15',
    },
  ],
};

export const mockCustomerDetails: CustomerDetails = {
  customerAccountId: '3-123456789',
  approvedConnections: '4',
  liveConnections: '2',
  maximumConnections: '6',
  equipmentLimitRemaining: '6000',
  equipmentLimitUsed: '0',
  services: [
    {
      msisdn: '61430114436',
      serviceType: ProductServiceType.VOICE,
      customerID: 'encrypted-61430114436',
      eligibilityIndicator: true,
      additionalServiceEligibility: true,
      permitPlanChangeIndicator: true,
      eligibility: {
        type: 'None',
      },
      forceLogoutForUpgrade: false,
      forceLogoutForAdditionalService: false,
      bundleAndSaveEligible: true,
      bundleAndSaveEligibleText: 'Eligible',
      serviceCta: '',
    },
    {
      msisdn: '61430114532',
      serviceType: ProductServiceType.MBB,
      customerID: 'encrypted-61430114532',
      eligibilityIndicator: true,
      additionalServiceEligibility: true,
      permitPlanChangeIndicator: true,
      eligibility: {
        type: 'None',
      },
      forceLogoutForUpgrade: false,
      forceLogoutForAdditionalService: false,
      bundleAndSaveEligible: true,
      bundleAndSaveEligibleText: 'Eligible',
      serviceCta: '',
    },
  ],
};

export const mockCustomerProductsEligibility: CustomerProductsEligibility = {
  monthsRemaining: '8',
  monthsIntoContract: '16',
  planProductName: '$50 RED Plan',
  propositionIdentifier: 'AUP12345',
  internationalPassport: false,
  overdueAccount: false,
  upgradeEligibilityIndicator: true,
  upgradeEligiblePlans: [],
};

const mockUser: User = {
  name: 'John',
  nickname: 'John',
  picture: 'picture string',
  'https://auth.vodafone.com.au/msisdn': '61430114436',
  'https://auth.vodafone.com.au/servicetype': ProductServiceType.MBB,
  'https://auth.vodafone.com.au/accounttype': AccountType.POSTPAY,
  sub: 'sub',
  updated_at: '2021-02-25T12:59:59.999Z',
};

export const mockAuthenticationStateAuthed: AuthenticationState = {
  isAuthenticated: true,
  loading: false,
  user: mockUser,
};

export const mockAuthenticationStateUnAuthed: AuthenticationState = {
  isAuthenticated: false,
  loading: false,
  user: undefined,
};

export const mockAuthenticationStateLoading: AuthenticationState = {
  isAuthenticated: false,
  loading: true,
  user: undefined,
};

export const mockCustomerDataDefault = {
  activeService: { serviceType: ProductServiceType.MBB },
  customerDetails: [{ isLoading: false }],
  upgradePlanEligibility: [{ isLoading: false }],
};

export const mockCustomerDataLoading = {
  activeService: {},
  customerDetails: [{ isLoading: true }],
  upgradePlanEligibility: [{ isLoading: true, error: false }],
};

export const mockCustomerDataNBN = {
  activeService: { serviceType: ProductServiceType.NBN_ONLY },
  customerDetails: [{ isLoading: false }],
  upgradePlanEligibility: [{ isLoading: false }],
};

export const mockDefaultDataFetchState = {
  data: null,
  error: null,
  isInitialised: false,
  isLoading: false,
  isSuccess: false,
  params: null,
};

export const mockCustomerData = {
  activeService: {},
  customerDetails: [{ isLoading: false }],
  upgradePlanEligibility: [{ isLoading: false }],
  currentServiceData: [mockDefaultDataFetchState],
};

export const nbnPlanListingMock: NbnPlan[] = [
  {
    planId: 'AU12312',
    order: 1,
    planName: 'Essential nbn™ plan',
    customPlanName: 'nbn™ 25',
    planDescription:
      '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
    planTenure: '',
    planTitle: '',
    subHeadingPrimary: 'Typical Evening Speed 25Mbps (7pm-11pm)',
    subHeadingSecondary: '$60/mth when you already have a phone plan with us',
    ctaLabel: 'Select this plan',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Critical Information Summary',
    cisUrl:
      'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-plans/au12312-au12314-au12295-au12296-oct2021.pdf',
    planExtraInfo: 'Standard Evening Speed',
    planImage: {
      imageUrl: 'https://www.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-2-0-black-front.jpg',
      altText: 'Essential nbn™ plan with modem',
    },
    planData: 'Unlimited',
    planProductName: 'Essential nbn™ plan',
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
    planSubType: 'NBN Modem M2M',
    ctaDisabledLabel: 'This plan is unavailable at your address',
    ctaSelectedLabel: 'Plan selected',
    expandPlanByDefault: false,
    contractTerm: 1,
    recurringCharge: 75,
    discountedRecurringCharge: 75,
    factSheetLabel: 'Key Fact Sheet',
    factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
    connectionSpeed: '25',
    withModem: true,
    promotions: [
      {
        title: 'Save $15/mth on plan fees',
        description:
          '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$15_NBN_ASD_DISPLAY_01',
        iconUrl: 'https://www.vodafone.com.au/images/icons/all-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    inclusions: [
      {
        description: 'Good for browsing online, streaming movies and using social media.',
        planId: 'AU12312',
        title: 'Great for 1-2 users',
        iconUrl: 'https://www.vodafone.com.au/images/icons/my-vodafone-mid.svg',
      },
      {
        description:
          '&lt;p&gt;Included when&amp;nbsp;you stay connected for 24 months. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;nbn-modem-info&quot;&gt;Find out more&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
        planId: 'AU12312',
        title: '$0 upfront modem',
        iconUrl: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',
      },
      {
        description:
          '&lt;p&gt;With heaps of Max Speed data from $50/month when you already have a phone plan with us and your first month free, our 4G Home Wireless Plans are a great alternative. T&amp;amp;C apply.&amp;nbsp;&lt;br&gt;&lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;whynot4g&quot;&gt;Find out more&lt;/vha-modal-trigger&gt;&lt;/p&gt;',
        planId: 'AU12312',
        title: 'Why not choose 4G Home Wireless?',
        iconUrl: 'https://www.vodafone.com.au/images/icons/home-broadband.svg',
      },
    ],
    footnote: '',
    hideWasLabel: false,
  },
  {
    planId: 'AU12313',
    order: 2,
    planName: 'Essential+ nbn™ plan',
    customPlanName: 'nbn™ 50',
    planDescription:
      '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
    planTenure: '',
    planTitle: '',
    subHeadingPrimary: 'Typical Evening Speed 50Mbps (7pm-11pm)',
    subHeadingSecondary: '$65/mth when you already have a phone plan with us',
    ctaLabel: 'Select this plan',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Critical Infomation Summary',
    cisUrl:
      'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-plans/au12312-au12314-au12295-au12296-oct2021.pdf',
    planExtraInfo: 'Standard+ Evening Speed',
    planImage: {
      imageUrl: 'https://www.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-2-0-black-front.jpg',
      altText: 'Essential+ nbn™ plan with modem',
    },
    planData: 'Unlimited',
    planProductName: 'Essential+ nbn™ plan',
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
    planSubType: 'NBN Modem M2M',
    ctaDisabledLabel: 'This plan is unavailable at your address',
    ctaSelectedLabel: 'Plan selected',
    expandPlanByDefault: true,
    contractTerm: 1,
    recurringCharge: 80,
    discountedRecurringCharge: 80,
    factSheetLabel: 'Key Fact Sheet',
    factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
    connectionSpeed: '50',
    withModem: true,
    promotions: [
      {
        title: 'Save $15/mth on plan fees',
        description:
          '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$15_NBN_ASD_DISPLAY_01',
        iconUrl: 'https://www.vodafone.com.au/images/icons/all-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    inclusions: [
      {
        description: '&lt;p&gt;Good for browsing online, streaming movies in 4K and online gaming.&lt;/p&gt;',
        planId: 'AU12313',
        title: 'Great for 2-4 users',
        iconUrl: 'https://www.vodafone.com.au/images/icons/my-vodafone-mid.svg',
      },
      {
        description:
          '&lt;p&gt;Included when&amp;nbsp;you stay connected for 24 months. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;nbn-modem-info&quot;&gt;Find out more&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
        planId: 'AU12313',
        title: '$0 upfront modem',
        iconUrl: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',
      },
    ],
    footnote: '',
    hideWasLabel: false,
  },
  {
    planId: 'AU12314',
    order: 3,
    planName: 'nbn™ Home Fast plan',
    customPlanName: 'nbn™ Home Fast',
    planDescription:
      '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
    planTenure: '',
    planTitle: '',
    subHeadingPrimary: 'Typical Evening Speed 90Mbps (7pm-11pm)',
    subHeadingSecondary: '$80/mth when you already have a phone plan with us',
    ctaLabel: 'Select this plan',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Critical Infomation Summary',
    cisUrl:
      'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-plans/au12312-au12314-au12295-au12296-oct2021.pdf',
    planExtraInfo: 'Premium Evening Speed',
    planImage: {
      imageUrl: 'https://www.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-2-0-black-front.jpg',
      altText: 'Home Fast nbn™ plan with modem',
    },
    planData: 'Unlimited',
    planProductName: 'Home Fast nbn™ plan',
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
    planSubType: 'NBN Modem M2M',
    ctaDisabledLabel: 'This plan is unavailable at your address',
    ctaSelectedLabel: 'Plan selected',
    expandPlanByDefault: false,
    contractTerm: 1,
    recurringCharge: 95,
    discountedRecurringCharge: 95,
    factSheetLabel: 'Key Fact Sheet',
    factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
    connectionSpeed: '100',
    withModem: true,
    promotions: [
      {
        title: 'Save $15/mth on plan fees',
        description:
          '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$15_NBN_ASD_DISPLAY_01',
        iconUrl: 'https://www.vodafone.com.au/images/icons/all-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    inclusions: [
      {
        description: '&lt;p&gt;Good for 4K video streaming on several devices and responsive online gaming.&lt;/p&gt;',
        planId: 'AU12314',
        title: 'Great for 5+ users',
        iconUrl: 'https://www.vodafone.com.au/images/icons/my-vodafone-mid.svg',
      },
      {
        description:
          '&lt;p&gt;Included when you stay connected for 24 months. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;nbn-modem-info&quot;&gt;Find out more&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
        planId: 'AU12314',
        title: '$0 upfront modem',
        iconUrl: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',
      },
    ],
    footnote: '',
    hideWasLabel: false,
  },
  {
    planId: 'AU12295',
    order: 4,
    planName: 'nbn™ Home Superfast plan',
    customPlanName: 'nbn™ Home Superfast',
    planDescription:
      '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
    planTenure: '',
    planTitle: '',
    subHeadingPrimary: 'Estimated Typical Evening Speed 200Mbps (7pm-11pm)',
    subHeadingSecondary: '$115/mth when you already have a phone plan with us',
    ctaLabel: 'Select this plan',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Critical Infomation Summary',
    cisUrl:
      'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-plans/au12312-au12314-au12295-au12296-oct2021.pdf',
    planExtraInfo: 'Premium Evening Speed',
    planImage: {
      imageUrl: 'https://www.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-2-0-black-front.jpg',
      altText: 'Home Superfast plan with modem',
    },
    planData: 'Unlimited',
    planProductName: 'Home Superfast plan',
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
    planSubType: 'NBN Modem M2M',
    ctaDisabledLabel: 'This plan is unavailable at your address',
    ctaSelectedLabel: 'Plan selected',
    expandPlanByDefault: false,
    contractTerm: 1,
    recurringCharge: 120,
    discountedRecurringCharge: 120,
    factSheetLabel: 'Key Fact Sheet',
    factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
    connectionSpeed: '250',
    withModem: true,
    promotions: [
      {
        title: 'Save $15/mth on plan fees',
        description:
          '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$15_NBN_ASD_DISPLAY_01',
        iconUrl: 'https://www.vodafone.com.au/images/icons/all-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    inclusions: [
      {
        description:
          '&lt;p&gt;Good for 4K video streaming on several devices and downloading and uploading large files.&lt;/p&gt;',
        planId: 'AU12295',
        title: 'Great for 5+ users',
        iconUrl: 'https://www.vodafone.com.au/images/icons/my-vodafone-mid.svg',
      },
      {
        description:
          '&lt;p&gt;Included when you stay connected for 24 months. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;nbn-modem-info&quot;&gt;Find out more&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
        planId: 'AU12295',
        title: '$0 upfront modem',
        iconUrl: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',
      },
    ],
    footnote: '&lt;p&gt;This plan is only available for FTTP and selected HFC connections.&lt;/p&gt;',
    hideWasLabel: false,
  },
  {
    planId: 'AU12296',
    order: 5,
    planName: 'nbn™ Home Ultrafast plan',
    customPlanName: 'nbn™ Home Ultrafast',
    planDescription:
      '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
    planTenure: '',
    planTitle: '',
    subHeadingPrimary: 'Estimated Typical Evening Speed 250Mbps (7pm-11pm)',
    subHeadingSecondary: '$135/mth when you already have a phone plan with us',
    ctaLabel: 'Select this plan',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Critical Infomation Summary',
    cisUrl:
      'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-plans/au12312-au12314-au12295-au12296-oct2021.pdf',
    planExtraInfo: 'Premium Evening Speed',
    planImage: {
      imageUrl: 'https://www.vodafone.com.au/images/devices/vodafone/img-800x586-vodafone-wifi-hub-2-0-black-front.jpg',
      altText: 'Home Ultrafast plan with modem',
    },
    planData: 'Unlimited',
    planProductName: 'Home Ultrafast plan',
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
    planSubType: 'NBN Modem M2M',
    ctaDisabledLabel: 'This plan is unavailable at your address',
    ctaSelectedLabel: 'Plan selected',
    expandPlanByDefault: false,
    contractTerm: 1,
    recurringCharge: 110,
    discountedRecurringCharge: 110,
    factSheetLabel: 'Key Fact Sheet',
    factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
    connectionSpeed: '1000',
    withModem: true,
    promotions: [
      {
        title: 'Save $15/mth on plan fees',
        description:
          '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$15_NBN_ASD_DISPLAY_01',
        iconUrl: 'https://www.vodafone.com.au/images/icons/all-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    inclusions: [
      {
        description:
          '&lt;p&gt;Best for 4K video streaming on several devices and downloading and uploading large files.&lt;/p&gt;',
        planId: 'AU12296',
        title: 'Great for 5+ users',
        iconUrl: 'https://www.vodafone.com.au/images/icons/my-vodafone-mid.svg',
      },
      {
        description:
          '&lt;p&gt;Included when&amp;nbsp;you stay connected for 24 months. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;nbn-modem-info&quot;&gt;Find out more&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
        planId: 'AU12296',
        title: '$0 upfront modem',
        iconUrl: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',
      },
    ],
    footnote: '&lt;p&gt;This plan is only available for FTTP and selected HFC connections.&lt;/p&gt;',
    hideWasLabel: false,
  },
  {
    planId: 'AU12315',
    order: 6,
    planName: 'Essential nbn™ BYO plan',
    customPlanName: 'nbn™ 25',
    planDescription:
      '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
    planTenure: '',
    planTitle: '',
    subHeadingPrimary: 'Typical Evening Speed 25Mbps (7pm-11pm)',
    subHeadingSecondary: '$60/mth when you already have a phone plan with us',
    ctaLabel: 'Select this plan',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Critical Information Summary',
    cisUrl:
      'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-byo-plans/au12315-au12317-au12297-au12298-oct2021.pdf',
    planExtraInfo: 'Standard Evening Speed',
    planImage: {
      imageUrl: 'https://www.vodafone.com.au/images/icons/router-hifi-hi.svg',
      altText: 'Essential nbn™ BYO plan',
    },
    planData: 'Unlimited',
    planProductName: 'Essential nbn™ BYO Plan',
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
    planSubType: 'NBN BYO M2M',
    ctaDisabledLabel: 'This plan is unavailable at your address',
    ctaSelectedLabel: 'Plan selected',
    expandPlanByDefault: false,
    contractTerm: 1,
    recurringCharge: 75,
    discountedRecurringCharge: 75,
    factSheetLabel: 'Key Fact Sheet',
    factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
    connectionSpeed: '25',
    withModem: false,
    promotions: [
      {
        title: 'Save $15/mth on plan fees',
        description:
          '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$15_NBN_ASD_DISPLAY_01',
        iconUrl: 'https://www.vodafone.com.au/images/icons/all-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    inclusions: [
      {
        description: '&lt;p&gt;Good for browsing online, streaming movies and using social media.&lt;/p&gt;',
        planId: 'AU12315',
        title: 'Great for 1-2 users',
        iconUrl: 'https://www.vodafone.com.au/images/icons/my-vodafone-mid.svg',
      },
      {
        description:
          '&lt;p&gt;We can help you check that your current nbn&trade; modem is compatible. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;modemcapability&quot;&gt;Check modem capability&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
        planId: 'AU12315',
        title: 'Bring your own modem',
        iconUrl: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',
      },
    ],
    footnote: '',
    hideWasLabel: false,
  },
  {
    planId: 'AU12316',
    order: 7,
    planName: 'Essential+ nbn™ BYO plan',
    customPlanName: 'nbn™ 50',
    planDescription:
      '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
    planTenure: '',
    planTitle: '',
    subHeadingPrimary: 'Typical Evening Speed 50Mbps (7pm-11pm)',
    subHeadingSecondary: '$65/mth when you already have a phone plan with us',
    ctaLabel: 'Select this plan',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Critical Information Summary',
    cisUrl:
      'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-byo-plans/au12315-au12317-au12297-au12298-oct2021.pdf',
    planExtraInfo: 'Standard Evening Speed',
    planImage: {
      imageUrl: 'https://www.vodafone.com.au/images/icons/router-hifi-hi.svg',
      altText: 'Essential+ nbn™ BYO plan',
    },
    planData: 'Unlimited',
    planProductName: 'Essential+ nbn™ BYO Plan',
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
    planSubType: 'NBN BYO M2M',
    ctaDisabledLabel: 'This plan is unavailable at your address',
    ctaSelectedLabel: 'Plan selected',
    expandPlanByDefault: false,
    contractTerm: 1,
    recurringCharge: 80,
    discountedRecurringCharge: 80,
    factSheetLabel: 'Key Fact Sheet',
    factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
    connectionSpeed: '50',
    withModem: false,
    promotions: [
      {
        title: 'Save $15/mth on plan fees',
        description:
          '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$15_NBN_ASD_DISPLAY_01',
        iconUrl: 'https://www.vodafone.com.au/images/icons/all-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    inclusions: [
      {
        description: '&lt;p&gt;Good for browsing online, streaming movies in 4K and online gaming.&lt;/p&gt;',
        planId: 'AU12316',
        title: 'Great for 2-4 users',
        iconUrl: 'https://www.vodafone.com.au/images/icons/my-vodafone-mid.svg',
      },
      {
        description:
          '&lt;p&gt;We can help you check that your current nbn&trade; modem is compatible. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;modemcapability&quot;&gt;Check modem capability&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
        planId: 'AU12316',
        title: 'Bring your own modem',
        iconUrl: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',
      },
    ],
    footnote: '',
    hideWasLabel: false,
  },
  {
    planId: 'AU12317',
    order: 8,
    planName: 'nbn™ Home Fast BYO plan',
    customPlanName: 'nbn™ Home Fast',
    planDescription:
      '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
    planTenure: '',
    planTitle: '',
    subHeadingPrimary: 'Typical Evening Speed 90Mbps (7pm-11pm)',
    subHeadingSecondary: '$80/mth when you already have a phone plan with us',
    ctaLabel: 'Select this plan',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Critical Information Summary',
    cisUrl:
      'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-byo-plans/au12315-au12317-au12297-au12298-oct2021.pdf',
    planExtraInfo: 'Premium Evening Speed',
    planImage: {
      imageUrl: 'https://www.vodafone.com.au/images/icons/router-hifi-hi.svg',
      altText: 'Home Fast nbn™ BYO plan',
    },
    planData: 'Unlimited',
    planProductName: 'Home Fast nbn™ BYO Plan',
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
    planSubType: 'NBN BYO M2M',
    ctaDisabledLabel: 'This plan is unavailable at your address',
    ctaSelectedLabel: 'Plan selected',
    expandPlanByDefault: false,
    contractTerm: 1,
    recurringCharge: 95,
    discountedRecurringCharge: 95,
    factSheetLabel: 'Key Fact Sheet',
    factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
    connectionSpeed: '100',
    withModem: false,
    promotions: [
      {
        title: 'Save $15/mth on plan fees',
        description:
          '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$15_NBN_ASD_DISPLAY_01',
        iconUrl: 'https://www.vodafone.com.au/images/icons/all-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    inclusions: [
      {
        description: '&lt;p&gt;Good for 4K video streaming on several devices and responsive online gaming.&lt;/p&gt;',
        planId: 'AU12317',
        title: 'Great for 5+ users',
        iconUrl: 'https://www.vodafone.com.au/images/icons/my-vodafone-mid.svg',
      },
      {
        description:
          '&lt;p&gt;We can help you check that your current nbn&trade; modem is compatible. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;modemcapability&quot;&gt;Check modem capability&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
        planId: 'AU12317',
        title: 'Bring your own modem',
        iconUrl: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',
      },
    ],
    footnote: '',
    hideWasLabel: false,
  },
  {
    planId: 'AU12297',
    order: 9,
    planName: 'nbn™ Home Superfast BYO plan',
    customPlanName: 'nbn™ Home Superfast',
    planDescription:
      '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
    planTenure: '',
    planTitle: '',
    subHeadingPrimary: 'Estimated Typical Evening Speed 200Mbps (7pm-11pm)',
    subHeadingSecondary: '$115/mth when you already have a phone plan with us',
    ctaLabel: 'Select this plan',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Critical Infomation Summary',
    cisUrl:
      'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-byo-plans/au12315-au12317-au12297-au12298-oct2021.pdf',
    planExtraInfo: 'Premium Evening Speed',
    planImage: {
      imageUrl: 'https://www.vodafone.com.au/images/icons/router-hifi-hi.svg',
      altText: 'nbn™ Home Superfast BYO',
    },
    planData: 'Unlimited',
    planProductName: 'Home Superfast BYO plan',
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
    planSubType: 'NBN BYO M2M',
    ctaDisabledLabel: 'This plan is unavailable at your address',
    ctaSelectedLabel: '',
    expandPlanByDefault: false,
    contractTerm: 1,
    recurringCharge: 130,
    discountedRecurringCharge: 130,
    factSheetLabel: 'Key Fact Sheet',
    factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
    connectionSpeed: '250',
    withModem: false,
    promotions: [
      {
        title: 'Save $15/mth on plan fees',
        description:
          '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$15_NBN_ASD_DISPLAY_01',
        iconUrl: 'https://www.vodafone.com.au/images/icons/all-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    inclusions: [
      {
        description:
          '&lt;p&gt;Good for 4K video streaming on several devices and downloading and uploading large files.&lt;/p&gt;',
        planId: 'AU12297',
        title: 'Great for 5+ users',
        iconUrl: 'https://www.vodafone.com.au/images/icons/my-vodafone-mid.svg',
      },
      {
        description:
          '&lt;p&gt;We can help you check that your current nbn&trade; modem is compatible. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;modemcapability&quot;&gt;Check modem capability&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
        planId: 'AU12297',
        title: 'Bring your own modem',
        iconUrl: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',
      },
    ],
    footnote: '&lt;p&gt;This plan is only available for FTTP and selected HFC connections.&lt;/p&gt;',
    hideWasLabel: false,
  },
  {
    planId: 'AU12298',
    order: 10,
    planName: 'nbn™ Home Ultrafast BYO plan',
    customPlanName: 'nbn™ Home Ultrafast',
    planDescription:
      '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us.&lt;/p&gt;',
    planTenure: '',
    planTitle: '',
    subHeadingPrimary: 'Estimated Typical Evening Speed 250Mbps (7pm-11pm)',
    subHeadingSecondary: '$135/mth when you already have a phone plan with us',
    ctaLabel: 'Select this plan',
    heroLabel: '',
    heroOfferId: '',
    cisLabel: 'Critical Infomation Summary',
    cisUrl:
      'https://www.vodafone.com.au/cis/nbn-plans/month-to-month-byo-plans/au12315-au12317-au12297-au12298-oct2021.pdf',
    planExtraInfo: 'Premium Evening Speed',
    planImage: {
      imageUrl: 'https://www.vodafone.com.au/images/icons/router-hifi-hi.svg',
      altText: 'nbn™ Home Ultrafast BYO',
    },
    planData: 'Unlimited',
    planProductName: 'Home Ultrafast BYO plan',
    isBundleAndSaveEligible: false,
    isTrialPlan: false,
    planSubType: 'NBN BYO M2M',
    ctaDisabledLabel: 'This plan is unavailable at your address',
    ctaSelectedLabel: 'Plan selected',
    expandPlanByDefault: false,
    contractTerm: 1,
    recurringCharge: 150,
    discountedRecurringCharge: 150,
    factSheetLabel: 'Key Fact Sheet',
    factSheetUrl: 'https://www.vodafone.com.au/documents/others/kfs-con-may2021.pdf',
    connectionSpeed: '1000',
    withModem: false,
    promotions: [
      {
        title: 'Save $15/mth on plan fees',
        description:
          '&lt;p&gt;Save $15 per month on this nbn&trade; plan when you already have a phone plan with us. Discount won&rsquo;t appear in cart or checkout but will be on your bill. T&amp;amp;C apply.&lt;/p&gt;',
        promotionCode: '$15_NBN_ASD_DISPLAY_01',
        iconUrl: 'https://www.vodafone.com.au/images/icons/all-rewards.svg',
        endDate: '2200-05-30T14:00:00.000Z',
      },
    ],
    inclusions: [
      {
        description:
          '&lt;p&gt;Best for 4K video streaming on several devices and downloading and uploading large files.&lt;/p&gt;',
        planId: 'AU12298',
        title: 'Great for 5+ users',
        iconUrl: 'https://www.vodafone.com.au/images/icons/my-vodafone-mid.svg',
      },
      {
        description:
          '&lt;p&gt;We can help you check that your current nbn&trade; modem is compatible. &lt;vha-modal-trigger type=&quot;plain&quot; id=&quot;modemcapability&quot;&gt;Check modem capability&lt;/vha-modal-trigger&gt;.&lt;/p&gt;',
        planId: 'AU12298',
        title: 'Bring your own modem',
        iconUrl: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',
      },
    ],
    footnote: '&lt;p&gt;This plan is only available for FTTP and selected HFC connections.&lt;/p&gt;',
    hideWasLabel: false,
  },
];

export const mockCartSplitterContentList: CheckoutSplitterContent[] = [
  {
    secondaryCtaStyle: 'primary',
    secondaryCtaLabel: '',
    primaryCtaStyle: 'primary',
    secondaryCtaRole: 'new',
    primaryCtaLabel: "Yes, I'm new",
    title: 'New to Vodafone?',
    body: '',
    primaryCtaRole: 'new',
  },
  {
    secondaryCtaStyle: 'secondary',
    secondaryCtaLabel: 'Add another device or plan',
    primaryCtaStyle: 'secondary',
    secondaryCtaRole: 'additional-service',
    primaryCtaLabel: 'Change your plan',
    title: 'Already with Vodafone?',
    body: '',
    primaryCtaRole: 'change-plan',
  },
];

export const mockCartSplitterContentListForSimo: CheckoutSplitterContent[] = [
  {
    secondaryCtaStyle: 'primary',
    secondaryCtaLabel: '',
    primaryCtaStyle: 'primary',
    secondaryCtaRole: 'new',
    primaryCtaLabel: "Yes, I'm new",
    title: 'New to Vodafone?',
    body: '',
    primaryCtaRole: 'new',
  },
  {
    secondaryCtaStyle: 'secondary',
    secondaryCtaLabel: 'Add another plan',
    primaryCtaStyle: 'secondary',
    secondaryCtaRole: 'additional-service',
    primaryCtaLabel: 'Change your plan',
    title: 'Already with Vodafone?',
    body: '',
    primaryCtaRole: 'change-plan',
  },
];

export const mockCartSplitterContentListForHandset: CheckoutSplitterContent[] = [
  {
    secondaryCtaStyle: 'primary',
    secondaryCtaLabel: '',
    primaryCtaStyle: 'primary',
    secondaryCtaRole: 'new',
    primaryCtaLabel: "Yes, I'm new",
    title: 'New to Vodafone?',
    body: '',
    primaryCtaRole: 'new',
  },
  {
    secondaryCtaStyle: 'tertiary',
    secondaryCtaLabel: 'Add another device or plan',
    primaryCtaStyle: 'secondary',
    secondaryCtaRole: 'additional-service',
    primaryCtaLabel: 'Upgrade your device',
    title: 'Already with Vodafone?',
    body: '',
    primaryCtaRole: 'upgrade',
  },
];

export const mockCartSplitterContentListHomeInternet: CheckoutSplitterContent[] = [
  {
    secondaryCtaStyle: 'primary',
    secondaryCtaLabel: '',
    primaryCtaStyle: 'primary',
    secondaryCtaRole: 'new',
    primaryCtaLabel: 'Add this plan',
    title: 'Already with Vodafone?',
    body: '&lt;p&gt;What would you like to do with the plan in your shopping cart?&lt;/p&gt;',
    primaryCtaRole: 'additional-service',
  },
  {
    secondaryCtaStyle: 'primary',
    secondaryCtaLabel: '',
    primaryCtaStyle: 'secondary',
    secondaryCtaRole: 'new',
    primaryCtaLabel: "Yes, I'm new",
    title: 'New to Vodafone?',
    body: '',
    primaryCtaRole: 'new',
  },
];

export const mockCartSplitterContentWatchOnly: CheckoutSplitterContent[] = [
  {
    secondaryCtaStyle: 'primary',
    secondaryCtaLabel: '',
    primaryCtaStyle: 'primary',
    secondaryCtaRole: 'new',
    primaryCtaLabel: 'Add this device',
    title: 'Already with Vodafone?',
    body: '',
    primaryCtaRole: 'additional-service',
  },
  {
    secondaryCtaStyle: 'secondary',
    secondaryCtaLabel: 'Plans with a Phone',
    primaryCtaStyle: 'primary',
    secondaryCtaRole: 'new-plan-handset',
    primaryCtaLabel: 'SIM Only Plan',
    title: 'New to Vodafone?',
    body: '&lt;p&gt;To continue to checkout, please add a mobile plan to your cart.&lt;/p&gt;',
    primaryCtaRole: 'new-simo',
  },
];

export const mockCartSplitterContentWatchSimo: CheckoutSplitterContent[] = [
  {
    secondaryCtaStyle: 'primary',
    secondaryCtaLabel: '',
    primaryCtaStyle: 'primary',
    secondaryCtaRole: 'new',
    primaryCtaLabel: "Yes, I'm new",
    title: 'New to Vodafone?',
    body: '',
    primaryCtaRole: 'new',
  },
  {
    secondaryCtaStyle: 'secondary',
    secondaryCtaLabel: '',
    primaryCtaStyle: 'primary',
    secondaryCtaRole: 'additional-service',
    primaryCtaLabel: 'Add another device or plan',
    title: 'Already with Vodafone?',
    body: '',
    primaryCtaRole: 'additional-service',
  },
];

export const mockCartSplitterContentWatchHandset: CheckoutSplitterContent[] = [
  {
    secondaryCtaStyle: 'primary',
    secondaryCtaLabel: '',
    primaryCtaStyle: 'primary',
    secondaryCtaRole: 'new',
    primaryCtaLabel: 'Yes, I’m new',
    title: 'New to Vodafone?',
    body: '',
    primaryCtaRole: 'new',
  },
  {
    secondaryCtaStyle: 'secondary',
    secondaryCtaLabel: 'Add another device or plan',
    primaryCtaStyle: 'primary',
    secondaryCtaRole: 'additional-service',
    primaryCtaLabel: 'Upgrade your device',
    title: 'Already with Vodafone?',
    body: '',
    primaryCtaRole: 'one-service-upgrade',
  },
];

export const mockCheckoutSplitterGroups: CheckoutSplitterGroup[] = [
  {
    id: 'simo',
    content: mockCartSplitterContentListForSimo,
  },
  {
    id: 'home-internet',
    content: mockCartSplitterContentListHomeInternet,
  },
  {
    id: 'handset',
    content: mockCartSplitterContentListForHandset,
  },
  {
    id: 'watch-only',
    content: mockCartSplitterContentWatchOnly,
  },
  {
    id: 'watch-simo',
    content: mockCartSplitterContentWatchSimo,
  },
  {
    id: 'watch-handset',
    content: mockCartSplitterContentWatchHandset,
  },
];

export const mockCartWatch: Basket = {
  basketId:
    '4Dr3319dLndaG8Ds0z4wUEFzDcG3uChxusVEelluUTg.ZVgXaHEnHOnAN28dKfRi5tzh3cqzTYDGqyUu_5oau2qOHS7bMLEnWtQ_-U0V0tlx',
  bundleAndSaveApplied: false,
  packages: [
    {
      packageId: '1',
      items: mockNbnPlanAndDeviceBasketItems,
    },
  ],
  totalPrice: {
    recurringCharge: 70,
    oneTimeCharge: 0,
  },
};

export const devicePageData: DevicePageResponse = {} as DevicePageResponse;
