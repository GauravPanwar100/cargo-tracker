const primary = {
  red: '#E60000',
  redDark: '#990000',
  greyLight: '#D8D8D8',
  grey: '#4A4D4E',
  greyDark: '#333333',
  white: '#FFFFFF',
} as const;

const secondary = {
  turquoise: '#007C92',
  aquaBlue: '#00B0CA',
  aubergine: '#5E2750',
  redViolet: '#9C2AA0',
  springGreen: '#A8B400',
  lightGreen: '#009900',
  freshOrange: '#EB9700',
  lemonYellow: '#FECB00',
  transparent: 'transparent',
  persianBlue: '#005EA5',
} as const;

const digital = {
  uiGreen: '#008A00',
  maroon: '#990000',
  darkRed: '#BD0000',
} as const;

const monochrome = {
  black: '#000000',
  darkGrey: '#333333',
  anthracite: '#666666',
  midGrey: '#999999',
  platinum: '#AFAFAF',
  silver: '#CCCCCC',
  aluminium: '#EBEBEB',
  lightGrey: '#F4F4F4',
  turquoise: '#007C92',
} as const;

const globals = {
  mainColor: monochrome.darkGrey,
  linkColor: monochrome.darkGrey,
  focusColor: secondary.aquaBlue,
};

export const breakpoints = {
  xs: 340,
  s: 640,
  m: 768,
  l: 1024,
  xl: 1440,
  xxl: 1920,
} as const;

const fonts = {
  regular: "'VodafoneRegular', Arial, sans-serif",
  light: "'VodafoneLight', Arial, sans-serif",
  bold: "'VodafoneRegularBold', Arial, sans-serif",
} as const;

const fontSizes = {
  heading1: 64,
  heading1Tablet: 56,
  heading1Mobile: 32,
  heading2: 56,
  heading2Tablet: 40,
  heading2Mobile: 28,
  heading3: 40,
  heading3Tablet: 34,
  heading3Mobile: 24,
  heading4: 28,
  heading4Tablet: 24,
  heading4Mobile: 20,
  heading5: 20,
  heading5Tablet: 20,
  heading5Mobile: 18,
  heading6: 18,
  heading6Tablet: 18,
  heading6Mobile: 18,
  heading7: 27,
  button: 20,
  buttonMobile: 18,
  price: 40,
  priceLarge: 48,
  priceRegular: 36,
  priceMedium: 22,
  priceSmall: 20,
  priceXSmall: 15,
  base: 16,
  baseSmall: 14,
  baseLarge: 18,
  baseXSmall: 13,
  footnote: 14,
  footnoteMobile: 12,
  priceContainer: 16,
  priceStrikeThroughTitle: 20,
  amountSmall: 20,
  priceSmallText: 14,
} as const;

const lineHeights = {
  heading1: 72,
  heading1Tablet: 62,
  heading1Mobile: 40,
  heading2: 62,
  heading2Tablet: 48,
  heading2Mobile: 36,
  heading3: 48,
  heading3Tablet: 40,
  heading3Mobile: 30,
  heading3MobileUplifted: 38,
  heading4: 34,
  heading4Tablet: 30,
  heading4Mobile: 28,
  heading5: 28,
  heading5Tablet: 28,
  heading5Mobile: 24,
  heading6: 20,
  heading6Tablet: 20,
  heading6Mobile: 20,
  heading7: 32,
  button: 28,
  buttonMobile: 24,
  price: 48,
  priceLarge: 40,
  priceSmall: 28,
  priceXSmall: 24,
  priceMedium: 22,
  priceRegular: 30,
  base: 22,
  baseSmall: 20,
  baseLarge: 24,
  baseXSmall: 18,
  footnote: 18,
  footnoteMobile: 16,
  priceContainer: 28,
  priceStrikeThroughTitle: 26,
  amountSmall: 24,
  priceSmallText: 15,
} as const;

export const sizes = {
  modulePaddingSmallest: 4,
  modulePaddingSmallSmall: 8,
  modulePaddingSemiSmall: 12,
  modulePaddingSmall: 16,
  modulePaddingPromoTiles: 20,
  modulePaddingSmallMedium: 24,
  modulePadding: 32,
  modulePaddingLarge: 48,
  textMaxWidth: 780,
  textMaxWidthTablet: 476,
  containerMaxWidth: 1180,
  videoHeight: 450,
  borderRadius: 6,
} as const;

export const spacing = {
  none: 0,
  xxxs: 8,
  xxs: 16,
  xs: 24,
  s: 32,
  m: 40,
  l: 48,
  xl: 52,
  ml: 55,
  xxl: 60,
  xxxl: 64,
} as const;

const boxShadows = {
  brand: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
  card: '0 3px 10px rgb(0 0 0 / 0.2)',
} as const;

const zIndex = {
  liveChat: 999_998,
  grecaptcha: 999_000,
} as const;

const baseTheme = {
  breakpoints,
  colors: {
    ...primary,
    ...secondary,
    ...digital,
    ...monochrome,
    ...globals,
  },
  fonts,
  fontSizes,
  lineHeights,
  durations: {
    transition: '250ms' as const,
  },
  sizes,
  spacing,
  boxShadows,
  zIndex,
};

export type Theme = BaseTheme & VariantTheme;

export type BreakpointKey = keyof Theme['breakpoints'];
export type ColorKey = keyof Theme['colors'];
export type FontKey = keyof Theme['fonts'];
export type FontSizeKey = keyof Theme['fontSizes'];
export type LineHeightKey = keyof Theme['lineHeights'];
export type SizeKey = keyof Theme['sizes'];
export type SpacingKey = keyof Theme['spacing'];

type BaseTheme = typeof baseTheme;

type VariantTheme = {
  variants: {
    mainColor: string;
    linkColor: string;
    hoverColor: string;
    focusColor: string;
    backgroundColor: string;
    greyBorderColor: string;
    tableHeaderBackgroundColor: string;
    tableCellBackgroundColor: string;
    featuredLinkColor: string;

    accordionColor: string;
    accordionBackgroundColor: string;
    accordionSecondBackgroundColor?: string;
    accordionFooterBackgroundColor?: string;
    accordionBoxShadow: string;
    accordionIndicatorColor: string;
    accordionSeparatorColor: string;
    accordionTitleFontFamily: string;
    accordionTitleFontSize?: number;
  };
};

const makeTheme = (variantTheme: VariantTheme): Theme => {
  const theme: Theme = {
    ...baseTheme,
    ...variantTheme,
  };
  return theme;
};

export const lightTheme = makeTheme({
  variants: {
    mainColor: primary.greyDark,
    linkColor: primary.greyDark,
    hoverColor: primary.red,
    focusColor: monochrome.turquoise,
    backgroundColor: primary.white,
    // Note: This is intentionally not the --brand-grey-border-theme-light variable from aem-fed
    // That variable is only used in one place (video component) and everywhere else uses aluminium
    // for grey borders in the default (light) theme in accordance with --brand-grey-border
    greyBorderColor: monochrome.aluminium,
    tableHeaderBackgroundColor: monochrome.lightGrey,
    tableCellBackgroundColor: primary.white,
    featuredLinkColor: primary.red,

    accordionBackgroundColor: primary.white,
    accordionBoxShadow: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    accordionColor: monochrome.darkGrey,
    accordionIndicatorColor: primary.red,
    accordionSeparatorColor: monochrome.silver,
    accordionTitleFontFamily: fonts.bold,
  },
});

export const lightGreyTheme = makeTheme({
  variants: {
    mainColor: primary.greyDark,
    linkColor: primary.greyDark,
    hoverColor: primary.red,
    focusColor: monochrome.turquoise,
    backgroundColor: monochrome.lightGrey,
    greyBorderColor: monochrome.lightGrey,
    tableHeaderBackgroundColor: monochrome.lightGrey,
    tableCellBackgroundColor: primary.white,
    featuredLinkColor: primary.red,

    accordionBackgroundColor: primary.white,
    accordionBoxShadow: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    accordionColor: monochrome.darkGrey,
    accordionIndicatorColor: primary.red,
    accordionSeparatorColor: monochrome.silver,
    accordionTitleFontFamily: fonts.bold,
  },
});

export const midTheme = makeTheme({
  variants: {
    mainColor: primary.greyDark,
    linkColor: primary.greyDark,
    hoverColor: primary.red,
    focusColor: monochrome.turquoise,
    backgroundColor: monochrome.aluminium,
    greyBorderColor: monochrome.aluminium,
    tableHeaderBackgroundColor: monochrome.lightGrey,
    tableCellBackgroundColor: primary.white,
    featuredLinkColor: primary.red,

    accordionBackgroundColor: primary.white,
    accordionBoxShadow: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    accordionColor: monochrome.darkGrey,
    accordionIndicatorColor: primary.red,
    accordionSeparatorColor: monochrome.silver,
    accordionTitleFontFamily: fonts.bold,
  },
});

export const violetTheme = makeTheme({
  variants: {
    mainColor: primary.greyDark,
    linkColor: primary.white,
    hoverColor: monochrome.silver,
    focusColor: monochrome.turquoise,
    backgroundColor: secondary.aubergine,
    greyBorderColor: monochrome.aluminium,
    tableHeaderBackgroundColor: monochrome.lightGrey,
    tableCellBackgroundColor: primary.white,
    featuredLinkColor: primary.red,

    accordionBackgroundColor: primary.white,
    accordionBoxShadow: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    accordionColor: monochrome.darkGrey,
    accordionIndicatorColor: primary.red,
    accordionSeparatorColor: monochrome.silver,
    accordionTitleFontFamily: fonts.bold,
  },
});

export const upliftDarkTheme = makeTheme({
  variants: {
    mainColor: primary.greyDark,
    linkColor: primary.white,
    hoverColor: primary.white,
    focusColor: monochrome.turquoise,
    backgroundColor: primary.grey,
    greyBorderColor: monochrome.aluminium,
    tableHeaderBackgroundColor: monochrome.lightGrey,
    tableCellBackgroundColor: primary.white,
    featuredLinkColor: primary.red,

    accordionBackgroundColor: primary.white,
    accordionBoxShadow: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    accordionColor: monochrome.darkGrey,
    accordionIndicatorColor: primary.red,
    accordionSeparatorColor: monochrome.silver,
    accordionTitleFontFamily: fonts.bold,
  },
});

export const upliftLightTheme = makeTheme({
  variants: {
    mainColor: primary.greyDark,
    linkColor: primary.greyDark,
    hoverColor: primary.greyDark,
    focusColor: monochrome.turquoise,
    backgroundColor: monochrome.aluminium,
    greyBorderColor: monochrome.aluminium,
    tableHeaderBackgroundColor: monochrome.lightGrey,
    tableCellBackgroundColor: primary.white,
    featuredLinkColor: primary.red,

    accordionBackgroundColor: primary.white,
    accordionBoxShadow: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    accordionColor: monochrome.darkGrey,
    accordionIndicatorColor: primary.red,
    accordionSeparatorColor: monochrome.silver,
    accordionTitleFontFamily: fonts.bold,
  },
});

export const darkTheme = makeTheme({
  variants: {
    mainColor: primary.white,
    linkColor: primary.white,
    hoverColor: monochrome.silver,
    focusColor: monochrome.turquoise,
    backgroundColor: primary.grey,
    greyBorderColor: monochrome.anthracite,
    tableHeaderBackgroundColor: monochrome.darkGrey,
    tableCellBackgroundColor: monochrome.anthracite,
    featuredLinkColor: primary.white,

    accordionBackgroundColor: primary.grey,
    accordionBoxShadow: '0 2px 8px 0 rgba(255, 255, 255, 0.16)',
    accordionColor: primary.white,
    accordionIndicatorColor: primary.white,
    accordionSeparatorColor: monochrome.anthracite,
    accordionTitleFontFamily: fonts.light,
  },
});

/**
 * Same as the darkTheme, except this one has greyDark instead of grey as its background color.
 * Currently only used for the Footer and CheckoutFooter component, extend and rename if necessary
 */
export const footerTheme = makeTheme({
  variants: {
    mainColor: primary.white,
    linkColor: primary.white,
    hoverColor: monochrome.silver,
    focusColor: monochrome.turquoise,
    backgroundColor: primary.greyDark,
    greyBorderColor: monochrome.anthracite,
    tableHeaderBackgroundColor: monochrome.darkGrey,
    tableCellBackgroundColor: monochrome.anthracite,
    featuredLinkColor: primary.white,

    accordionBackgroundColor: primary.greyDark,
    accordionBoxShadow: '0 2px 8px 0 rgba(255, 255, 255, 0.16)',
    accordionColor: primary.white,
    accordionIndicatorColor: primary.white,
    accordionSeparatorColor: monochrome.anthracite,
    accordionTitleFontFamily: fonts.light,
  },
});

export const EULandingTheme = makeTheme({
  variants: {
    mainColor: primary.greyDark,
    linkColor: primary.greyDark,
    hoverColor: primary.red,
    focusColor: monochrome.turquoise,
    backgroundColor: monochrome.aluminium,
    greyBorderColor: monochrome.aluminium,
    tableHeaderBackgroundColor: monochrome.lightGrey,
    tableCellBackgroundColor: primary.white,
    featuredLinkColor: primary.red,

    accordionBackgroundColor: primary.white,
    accordionSecondBackgroundColor: monochrome.lightGrey,
    accordionFooterBackgroundColor: primary.white,
    accordionBoxShadow: '0 2px 8px 0 rgba(0, 0, 0, 0.16)',
    accordionColor: monochrome.lightGrey,
    accordionIndicatorColor: primary.red,
    accordionSeparatorColor: monochrome.silver,
    accordionTitleFontFamily: fonts.bold,
    accordionTitleFontSize: fontSizes.heading5,
  },
});
