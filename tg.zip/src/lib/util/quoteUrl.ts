/**
 * Adds double quotes surrounding the provided `url` so that URLs containing single quotes can be
 * included in `styled-components` components. This is necessary because `prettier` will
 * automatically convert to single quotes even though the URL itself may contain single quotes as a
 * UTF-8 encoded data URI.
 *
 * @example
 * ```ts
 * import styled from 'styled-components';
 * import img from '@src/assets/svg/icon.svg';
 * import quoteUrl from '@src/lib/util/quoteUrl';
 *
 * export const Background = styled.div`
 *   background-image: url(${quoteUrl(img)});
 * `;
 * ```
 *
 * @param url
 */
export default function quoteUrl(url: string): string {
  return `"${url}"`;
}
