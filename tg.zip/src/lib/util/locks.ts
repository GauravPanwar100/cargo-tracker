interface Lock {
  readonly clientId: string;
  readonly mode: 'exclusive' | 'shared';
  readonly name: string;
}

interface LockRequestOptions {
  ifAvailable?: boolean;
  mode?: Lock['mode'];
  signal?: AbortSignal;
  // steal?: boolean;
}

/**
 * Same tab only lock implementation that has a similar API to the upcoming Web Locks API
 * @see https://developer.mozilla.org/en-US/docs/Web/API/Web_Locks_API
 */
class LocksManager {
  private static ID = 1;

  private held: readonly Lock[] = [];

  private pending: readonly Lock[] = [];

  private queue: { lock: Lock; onAvailable: () => void }[] = [];

  private advanceQueue(): void {
    const index = this.queue.findIndex((item) => this.isLockAvailable(item.lock));
    if (index !== -1) {
      this.queue.splice(index, 1)[0].onAvailable();
    }
  }

  private addPending(lock: Lock): void {
    this.pending = [...this.pending, lock];
  }

  private acquireLock(lock: Lock): void {
    this.pending = this.pending.filter((l) => l !== lock);
    this.held = [...this.held, lock];
    this.advanceQueue();
  }

  private isLockAvailable(lock: Lock): boolean {
    return !this.held.some(
      (l) => l !== lock && l.name === lock.name && (l.mode === 'exclusive' || lock.mode === 'exclusive'),
    );
  }

  private releaseLock(lock: Lock): void {
    this.pending = this.pending.filter((l) => l !== lock);
    this.held = this.held.filter((l) => l !== lock);
    this.advanceQueue();
  }

  private waitToAcquire(lock: Lock, signal: AbortSignal | undefined): Promise<void> {
    return new Promise<void>((resolve) => {
      if (this.isLockAvailable(lock)) {
        this.acquireLock(lock);
        resolve();
        return;
      }

      if (signal?.aborted) {
        resolve();
        return;
      }

      signal?.addEventListener('abort', () => {
        const index = this.queue.findIndex((item) => item.lock === lock);
        if (index !== -1) this.queue.splice(index, 1);
        resolve();
      });

      this.queue.push({
        lock,
        onAvailable: () => {
          this.acquireLock(lock);
          resolve();
        },
      });
    });
  }

  public request<T>(name: string, callback: (lock: Lock | null) => Promise<T>): Promise<T>;

  public request<T>(name: string, options: LockRequestOptions, callback: (lock: Lock | null) => Promise<T>): Promise<T>;

  public async request<T>(
    name: string,
    ...args: [(lock: Lock | null) => Promise<T>] | [LockRequestOptions, (lock: Lock | null) => Promise<T>]
  ): Promise<T> {
    const options = args.length === 2 ? args[0] : {};
    const callback = args.length === 2 ? args[1] : args[0];

    const { ifAvailable = false, mode = 'exclusive', signal } = options;
    // eslint-disable-next-line no-plusplus
    const clientId = `${LocksManager.ID++}`;
    const lock: Lock = Object.freeze({ clientId, mode, name });

    this.addPending(lock);

    if (ifAvailable) {
      if (!this.isLockAvailable(lock) && !signal?.aborted) {
        this.releaseLock(lock);
        return callback(null);
      }
    } else {
      await this.waitToAcquire(lock, signal);
    }

    if (signal?.aborted) {
      this.releaseLock(lock);
      throw new DOMException('Lock acquisition was aborted', 'AbortError');
    }

    return callback(lock).finally(() => this.releaseLock(lock));
  }

  public async query() {
    return { held: [...this.held], pending: [...this.pending] };
  }
}

const locks = new LocksManager();
export default locks;
