import { LocalStorageClient } from '@src/lib/storage';
import { GAValueProps, RETURNING_USER_DAYS, isReturningUser, setGASessionValue } from './upgradeHub';

const MockGASessionValue: GAValueProps = {
  GAClientId: '474212465',
  lastVisitedDate: new Date(),
};
const MockNegetiveGASessionValue: GAValueProps = {
  GAClientId: 'test',
  lastVisitedDate: new Date(),
};
const GAValue = jest.fn().mockReturnValue(MockGASessionValue);

const mockGetGASessionValue = jest.fn();

Object.defineProperty(window, 'localStorage', {
  value: {
    getItem: () => {
      return mockGetGASessionValue();
    },
    clearLocalStorage: () => {
      return mockGetGASessionValue();
    },
  },
});

Object.defineProperty(window.document, 'cookie', {
  writable: true,
  value: 'GA1.3.474212465.1677127189',
});

describe('isReturningUser', () => {
  beforeEach(() => {
    window.localStorage.clearLocalStorage();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return false, if user visited for first time this website', async () => {
    // GA session value
    mockGetGASessionValue.mockReturnValueOnce(null);
    const GAStorageValue = window.localStorage.getItem('_ga');

    await isReturningUser();
    expect(GAStorageValue).toBeNull();
  });

  it('should return false, if session GAClientID is different from GACookieValue', async () => {
    // GA session value
    mockGetGASessionValue.mockReturnValueOnce(JSON.stringify(MockNegetiveGASessionValue));
    const GACookieValue = window.document.cookie;
    const GACookeiValueSplitted = GACookieValue.split('.');

    await isReturningUser();
    // session GAClientID and GACookieValue clientID are different
    expect(MockNegetiveGASessionValue.GAClientId).not.toEqual(GACookeiValueSplitted[2]);
  });

  it('should return true, if session GAClientID and GACookieValue clientID are same', async () => {
    // GA session value
    mockGetGASessionValue.mockReturnValueOnce(JSON.stringify(MockGASessionValue));
    const GAStorageValue = window.localStorage.getItem('_ga');
    // GA cookie value
    const GACookieValue = window.document.cookie;
    const GACookeiValueSplitted = GACookieValue.split('.');

    // calculate last visited in days
    const LastVisitedInDays = Math.floor(
      (new Date().getTime() - new Date(MockGASessionValue.lastVisitedDate).getTime()) / (24 * 60 * 60 * 1000),
    );

    await isReturningUser();
    // _ga session set value
    expect(GAStorageValue).toEqual(JSON.stringify(MockGASessionValue));
    // session GAClientID and GACookieValue clientID are same
    expect(MockGASessionValue.GAClientId).toEqual(GACookeiValueSplitted[2]);
    // Last visited in days not more than RETURNING_USER_DAYS
    expect(RETURNING_USER_DAYS).toBeGreaterThan(LastVisitedInDays);
  });
});

describe('setGASessionValue', () => {
  it('should set _ga session value in localstorage', async () => {
    // GA session value
    const spyToSetGAValue = jest.spyOn(LocalStorageClient, 'setGAValue');
    spyToSetGAValue.mockImplementation(() => GAValue);

    await setGASessionValue();

    expect(spyToSetGAValue).toHaveBeenCalled();
    expect(spyToSetGAValue).toHaveBeenCalledTimes(1);
  });
});
