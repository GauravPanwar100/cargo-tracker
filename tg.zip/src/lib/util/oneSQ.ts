import {
  HomeWirelessPageResponse,
  HomeWirelessPlan,
  HomeWirelessPlansResponse,
  NbnPageResponse,
  NbnPlan,
  NbnPlansResponse,
} from '@src/lib/api/types';
import { HomeInternetType } from '@src/templates/HomeWireless/HomeWireless.constants';

export interface ModemDetailsProps {
  modemTitle: string;
  thumbnailUrl: string;
  altText: string;
  textBlock: string;
  usp: {
    image: string;
    description: string;
  }[];
  homeInternetType: HomeInternetType | string;
  byoInfo: string;
}

export const homeInternetTypesArray = [
  { title: '4G', homeInternetType: HomeInternetType.FHW_4G, disabled: false },
  { title: '5G', homeInternetType: HomeInternetType.FHW_5G, disabled: false },
  { title: 'nbn™', homeInternetType: HomeInternetType.NBN, disabled: false },
];

export const getModemDetails = (
  selectedPlanId: string,
  selectedPlan: NbnPlan | HomeWirelessPlan | undefined,
  pageData4g: HomeWirelessPageResponse,
  pageData5g: HomeWirelessPageResponse,
  pageDataNbn: NbnPageResponse,
) => {
  let modemDetails: ModemDetailsProps = {
    modemTitle: '',
    thumbnailUrl: '',
    altText: '',
    textBlock: '',
    usp: [],
    homeInternetType: '',
    byoInfo: '',
  };
  const usp = [{ image: '', description: '' }];
  if (selectedPlanId !== '') {
    if (selectedPlan?.homeInternetType === HomeInternetType.FHW_4G) {
      modemDetails = {
        modemTitle: pageData4g.fhwModemsContent.modemPlans[0].productDisplayName,
        thumbnailUrl: pageData4g.fhwModemsContent.modemPlans[0].thumbnailUrl,
        altText: pageData4g.fhwModemsContent.modemPlans[0].altText,
        textBlock: pageData4g.fhwModemsContent.modemPlans[0].textBlock,
        usp: pageData4g.fhwModemsContent.modemPlans[0].inclusions || usp,
        homeInternetType: HomeInternetType.FHW_4G,
        byoInfo: '',
      };
    } else if (selectedPlan?.homeInternetType === HomeInternetType.FHW_5G) {
      modemDetails = {
        modemTitle: pageData5g.fhwModemsContent.modemPlans[0].productDisplayName,
        thumbnailUrl: pageData5g.fhwModemsContent.modemPlans[0].thumbnailUrl,
        altText: pageData5g.fhwModemsContent.modemPlans[0].altText,
        textBlock: pageData5g.fhwModemsContent.modemPlans[0].textBlock,
        usp: pageData5g.fhwModemsContent.modemPlans[0].inclusions || usp,
        homeInternetType: HomeInternetType.FHW_5G,
        byoInfo: '',
      };
    } else {
      modemDetails = {
        modemTitle: pageDataNbn.nbnModemsContent.modemPlans[0].productDisplayName,
        thumbnailUrl: pageDataNbn.nbnModemsContent.modemPlans[0].thumbnailUrl,
        altText: pageDataNbn.nbnModemsContent.modemPlans[0].altText,
        textBlock: pageDataNbn.nbnModemsContent.modemPlans[0].textBlock,
        usp: pageDataNbn.nbnModemsContent.modemPlans[0].inclusions || usp,
        homeInternetType: HomeInternetType.NBN,
        byoInfo: pageDataNbn.nbnModemsContent.modemPlans[1].textBlock,
      };
    }
  }
  return modemDetails;
};

export const getFilteredPlans = (
  plansResponse4g: HomeWirelessPlansResponse,
  plansResponse5g: HomeWirelessPlansResponse,
  plansResponseNbn: NbnPlansResponse,
  chips: { title: string; homeInternetType: string; disabled: boolean }[],
  chipValue: string[],
) => {
  const plans4g =
    plansResponse4g && plansResponse4g?.planListing.plans.length > 0
      ? plansResponse4g?.planListing.plans.map((singlePlan) => ({
          ...singlePlan,
          homeInternetType: HomeInternetType.FHW_4G,
        }))
      : [];

  const plans5g =
    plansResponse5g && plansResponse5g?.planListing.plans.length > 0
      ? plansResponse5g?.planListing.plans.map((singlePlan) => ({
          ...singlePlan,
          homeInternetType: HomeInternetType.FHW_5G,
        }))
      : [];

  const plansNbn =
    plansResponseNbn && plansResponseNbn?.planListing.plans.length > 0
      ? plansResponseNbn?.planListing.plans
          .map((singlePlan) => ({
            ...singlePlan,
            homeInternetType: HomeInternetType.NBN,
          }))
          .filter(({ withModem }) => !!withModem)
      : [];

  const allPlans = [
    ...(!chips[0].disabled ? plans4g : []),
    ...(!chips[1].disabled ? plans5g : []),
    ...(!chips[2].disabled ? plansNbn : []),
  ];

  const filteredPlans =
    chipValue.length > 0
      ? allPlans.filter((singlePlan) => chipValue.includes(singlePlan?.homeInternetType || ''))
      : [...allPlans];

  return filteredPlans;
};
