/**
 * Will throw if called
 * @param value
 */
export function assertNever(value: never): never {
  throw new Error(`Expected never but got ${value}`);
}
