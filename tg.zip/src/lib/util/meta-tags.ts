import { NextSeoProps } from 'next-seo';
import he from 'he';
import sanitize from 'sanitize-html';

interface BaseMetaTag {
  content: string;
}
interface HTML5MetaTag extends BaseMetaTag {
  name: string;
}
interface RDFaMetaTag extends BaseMetaTag {
  property: string;
}
type MetaTag = HTML5MetaTag | RDFaMetaTag;

const generateAdditionalMetaTags = (aemMetaTags: string, title: string): NextSeoProps => {
  let nofollow = false;
  let noindex = false;
  const metaTags: MetaTag[] = [];
  if (title) {
    metaTags.push({
      name: 'title',
      content: title,
    });
  }
  const tags = aemMetaTags.split('>');
  tags.forEach((tag: string) => {
    if (!tag) {
      return;
    }
    const property: string[] | null = tag.match(/<meta.*property="(.*)".*content="(.*)".*/);
    if (property && property.length > 2 && property[1] && property[2]) {
      metaTags.push({
        property: property[1],
        content: property[2],
      });
      return;
    }
    const name: string[] | null = tag.match(/<meta.*name="(.*)".*content="(.*)".*/);
    if (name && name.length > 2 && name[1] && name[2]) {
      if (name[1] === 'robots') {
        if (name[2].indexOf('nofollow') > -1) {
          nofollow = true;
        }
        if (name[2].indexOf('noindex') > -1) {
          noindex = true;
        }
      } else {
        metaTags.push({
          name: name[1],
          content: name[2],
        });
      }
    }
  });
  return {
    additionalMetaTags: metaTags,
    nofollow,
    noindex,
  };
};

const generateCanonicalString = (aemMetaTags: string): string | undefined => {
  const canonical: string[] | null = aemMetaTags.match(/.*rel="canonical".*href="(.*?)".*>/);
  if (canonical && canonical.length > 1) {
    return canonical[1];
  }
  return undefined;
};

export const generateMetaTags = (aemMetaTags: string | undefined, title: string | undefined): NextSeoProps => {
  const unescaped = he.unescape(aemMetaTags || '');
  const sanitized = sanitize(unescaped, {
    allowedTags: sanitize.defaults.allowedTags.concat(['meta', 'link']),
    allowedAttributes: {
      meta: ['property', 'content', 'name'],
      link: ['*'],
    },
  });
  const additional: NextSeoProps = generateAdditionalMetaTags(sanitized, title || '');
  const canonical: string | undefined = generateCanonicalString(sanitized);
  return {
    ...additional,
    canonical,
  };
};
