import { enrichTextWithAttributes } from './formatUtils';

export const getTwoWaySmsMessage = (
  contact: string | undefined,
  {
    twoWaySmsMessage,
    twoWaySmsInvalidMessage,
    twoWaySmsIconUrl,
  }: {
    twoWaySmsMessage: string | undefined;
    twoWaySmsInvalidMessage: string | undefined;
    twoWaySmsIconUrl: string | undefined;
  },
): string | null => {
  if (contact === undefined) return null;
  let finalMessage = twoWaySmsMessage || '';
  if (!contact.startsWith('614') && !contact.startsWith('04')) {
    finalMessage = twoWaySmsInvalidMessage || '';
  }
  if (!(twoWaySmsIconUrl && finalMessage)) return null;

  return enrichTextWithAttributes(finalMessage, { MSISDN_CONTACT: contact });
};
