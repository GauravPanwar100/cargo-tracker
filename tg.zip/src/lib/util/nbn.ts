import {
  BasePlan,
  BasketRequestItem,
  BasketRequestItemPriceInfo,
  CartItemType,
  CartProductSubType,
  CartProductType,
  CatalogCode,
  HomeInternetModemItem,
  ModemChildBasketRequestItem,
  NbnPlan,
} from '@src/lib/api/types';
import { compact } from 'lodash';

const uniquePropertyKeys = ['id', 'planImage', 'planSubType', 'cisUrl', 'withModem'];

type CommonPlanProperties = Omit<NbnPlan, 'id' | 'planImage' | 'planSubType' | 'cisUrl' | 'withModem'>;

export interface ConsolidatedNbnPlan extends CommonPlanProperties {
  modemPlan?: UniquePlanContent;
  byoPlan?: UniquePlanContent;
}

export interface UniquePlanContent {
  planId: string;
  cisUrl: string;
  planImage: {
    imageUrl: string;
    altText: string;
  };
  planSubType: string;
}

export const consolidateNbnPlans = (plans: NbnPlan[]) => {
  const planMap = new Map<string, ConsolidatedNbnPlan>();
  plans.forEach((plan) => {
    let consolidatedPlan = planMap.get(plan.connectionSpeed) ?? ({} as ConsolidatedNbnPlan);

    if (plan.withModem) {
      const commonPlanProps: { [key: string]: unknown } = {};
      for (const [k, v] of Object.entries(plan)) {
        if (!uniquePropertyKeys.includes(k)) {
          commonPlanProps[k] = v;
        }
      }
      consolidatedPlan = { ...consolidatedPlan, ...commonPlanProps };
    }

    consolidatedPlan[plan.withModem ? 'modemPlan' : 'byoPlan'] = {
      planId: plan.planId,
      planImage: plan.planImage,
      cisUrl: plan.cisUrl,
      planSubType: plan.planSubType,
    };

    planMap.set(plan.connectionSpeed, consolidatedPlan);
  });

  return Array.from(planMap.values());
};

export const isConsolidatedNbnPlan = (plan: BasePlan | ConsolidatedNbnPlan): plan is ConsolidatedNbnPlan => {
  return 'modemPlan' in plan || 'byoPlan' in plan;
};

export const nbnPlanHasPlanId = (plan: ConsolidatedNbnPlan, planId: string) => {
  return plan.modemPlan?.planId === planId || plan.byoPlan?.planId === planId;
};

export const constructNbnStickyCartItem = (
  plan: NbnPlan | ConsolidatedNbnPlan,
  withModem: boolean,
  discountedCost: number | null,
  modemPriceInfo: { recurringCharge: number; loyaltyMRCAmount: number; contractTerm: string },
  planId: string,
  modemContent?: HomeInternetModemItem,
  showSubHeadingSecondary = true,
  displayPrice?: number,
) => {
  const childProduct: ModemChildBasketRequestItem | undefined =
    modemContent && withModem
      ? {
          catalogCode: CatalogCode.NBN_MODEMS,
          itemType: CartItemType.MODEM,
          packageId: '',
          priceInfo: {
            recurringCharge: modemPriceInfo?.recurringCharge,
            adjustedMRCAmount: modemPriceInfo?.loyaltyMRCAmount,
          },
          productCode: modemContent.productId as string,
          productConfig: {
            contractTerm: modemPriceInfo.contractTerm,
          },
          productName: modemContent.productDisplayName,
          productType: CartProductType.DEVICE,
          productSubType: CartProductSubType.NBN_MODEM,
          relatedContent: {
            modemName: modemContent.productDisplayName,
          },
        }
      : undefined;

  const basketItems: BasketRequestItem[] = [
    {
      catalogCode: CatalogCode.NBN_PLANS,
      productCode: planId,
      childProducts: compact([childProduct]),
      itemType: CartItemType.PLAN,
      packageId: '',
      priceInfo: {
        recurringCharge: plan.recurringCharge,
        oneTimeCharge: plan.oneTimeCharge,
        adjustedMRCAmount: discountedCost ?? plan.discountedRecurringCharge,
        ...(!!displayPrice && { discountedCost: displayPrice }),
      } as BasketRequestItemPriceInfo,
      productConfig: {
        contractTerm: String(plan.contractTerm),
      },
      productName: plan.planName,
      productType: CartProductType.PLAN_FIXED,
      asdSubCopy: showSubHeadingSecondary ? plan.subHeadingSecondary : '',
    },
  ];

  return basketItems;
};

export const getPlanId = (plan: BasePlan | ConsolidatedNbnPlan) => {
  return isConsolidatedNbnPlan(plan) ? plan.modemPlan?.planId || '' : plan.planId;
};

export const getCisUrl = (plan: BasePlan | ConsolidatedNbnPlan) => {
  return isConsolidatedNbnPlan(plan) ? plan.modemPlan?.cisUrl : plan.cisUrl;
};

export const getPlanImage = (plan: BasePlan | ConsolidatedNbnPlan) => {
  return isConsolidatedNbnPlan(plan) ? plan.modemPlan?.planImage : plan.planImage;
};

export const planHasPlanId = (plan: BasePlan | ConsolidatedNbnPlan, planId: string) =>
  isConsolidatedNbnPlan(plan) ? nbnPlanHasPlanId(plan, planId) : plan.planId === planId;
