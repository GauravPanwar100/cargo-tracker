import { isEqual, isUndefined, omitBy } from 'lodash';
import Router, { useRouter } from 'next/router';
import queryString, { ParsedQuery } from 'query-string';
import React from 'react';
import useIsomorphicLayoutEffect from '@src/lib/hooks/use-isomorphic-layout-effect';
import { PROTOCOL_REGEX, stripQueryFromPath } from '@src/lib/util/url';

export type RouterMethod = 'push' | 'replace';

/**
 * Next.js does not scroll to the top of the page when you use Router.push, like it does when you
 * use Link component. This leads to weird behaviour where you redirect the user to a new page, but
 * it's scrolled down to wherever you were on the first page. Using this function instead of
 * Router[method] directly works by scrolling to the top (unless we're already there) if the route
 * transition was a success.
 */
function safeRouterMethod<M extends RouterMethod>(method: M): typeof Router[M] {
  return (...params) =>
    Router[method](...params).then((success) => {
      if (success && window.scrollY !== 0) {
        window.scrollTo(0, 0);
      }
      return success;
    });
}

export const safeRouterPush = safeRouterMethod('push');

export const safeRouterReplace = safeRouterMethod('replace');

export function safeWindowLocationReplace(url: string) {
  window.location.replace(window.location.origin + url);
}

/**
 * Returns the page query, or null if the page is not yet hydrated.
 * NOTE: This will include next.js query params that come from the path.
 * e.g. /pages/mobile/mobile-phones/[manufacturer]/[device].tsx -- this hook will return a { device: X } query
 */
export const useNextQuery = () => {
  const router = useRouter();

  const hasQueryParams = /\[.+\]/.test(router.route) || /\?./.test(router.asPath);
  const ready = !hasQueryParams || Object.keys(router.query).length > 0;

  if (!ready) return null;

  return router.query;
};

/**
 * Returns the page query, or null if the page is not yet hydrated.
 * NOTE: This will only include window.location.search, not any of the next.js "query" params that are
 * actually path params
 */
export const useClientQuery = () => {
  const [query, setQuery] = React.useState<ParsedQuery | null>(null);

  useIsomorphicLayoutEffect(() => {
    const update = () => {
      setQuery((previous) => {
        const newQuery = queryString.parse(window.location.search);
        return isEqual(previous, newQuery) ? previous : newQuery;
      });
    };
    Router.events.on('routeChangeComplete', update);
    update();
    return () => Router.events.off('routeChangeComplete', update);
  }, []);

  return query;
};

export const useUpdateQuery = () => {
  const router = useRouter();
  const routerRef = React.useRef(router);
  routerRef.current = router;

  const updateQuery = React.useCallback((newQuery: ParsedQuery, routerMethod: RouterMethod) => {
    const query = omitBy(
      {
        ...queryString.parse(window.location.search),
        ...newQuery,
      },
      isUndefined,
    );

    // URL needs to point to the router.pathname (name of the NextJS page): /pages/[device]
    const url = queryString.stringifyUrl({
      query,
      url: routerRef.current.pathname,
    });
    // Strip the query params from the asPath to get something like: /pages/IPH_XR
    const as = queryString.stringifyUrl({
      query,
      url: stripQueryFromPath(routerRef.current.asPath),
    });

    return routerRef.current[routerMethod](url, as, { shallow: true });
  }, []);

  return updateQuery;
};

/**
 * Returns whether a `href` is SPA-navigable (meaning it should be handled by the Next.js router). If not, it should
 * only be used with a regular anchor tag. In addition to handling non-relative URLs as not SPA-navigable, we also
 * have specific cases for `pathname`s where we want the AEM version in CloudFronted environments to override our SPA
 * routes.
 *
 * Partially relies on testing for a protocol.
 * @see https://stackoverflow.com/questions/10687099/how-to-test-if-a-url-string-is-absolute-or-relative
 *
 * @param href
 */
export function isSpaNavigable(href: string) {
  // If the URL includes a protocol, it is not SPA-navigable
  if (PROTOCOL_REGEX.test(href)) return false;

  // As we only care about `pathname`, the `base` URL here doesn't really matter
  const { pathname } = new URL(href, 'https://shop.vodafone.com.au');

  // Even though we have a `/` SPA route, we want the AEM page to override this.
  if (pathname === '/') return false;

  // Otherwise Default to true
  return true;
}

export function isHeadlessRoute(pathname: string): boolean {
  return pathname.startsWith('/iframe/');
}
