import Logger from '@src/lib/logger/logger';
import { Promotion, ShipmentAddress } from '@src/lib/api/types';
import { format } from 'date-fns';
import { lowerCase, startCase } from 'lodash';
import { GST_PERCENTAGE_MULTIPLY_FACTOR } from '@src/lib/util/express-upgrades';

/**
 * Non-breaking space character
 */
export const NBSP = '\u00a0';

/**
 * No, this module won't make you rich. "Enrichment" is the term used
 * within VFE for replacing template variables that are inside CMS content,
 * with actual values.
 */
const ENRICHMENT_SLOT_REGEX = /{([a-zA-Z0-9_-]+)}/g;
const ATTRIBUTE_PLUG_REGEX = /{(.[^}]*)}/g;
const MISSING_TEMPLATE_STRING = '{NOT_FOUND}';

export function enrichContent(id: string, content: string, enrichments: Enrichment[]): string {
  // Take the enrichments array-of-hashmaps, loop over it and return a map that contains
  // just the 'id' key. If several enrichment-hashmaps have the same key, the last one wins.
  const enrichmentsForId = Object.assign({}, ...enrichments.map((enrichment) => enrichment[id])) as Record<
    string,
    string | undefined
  >;
  // Replace any template-variables with the same enrichment-key-name with the enrichment-key-value
  return content.replace(ENRICHMENT_SLOT_REGEX, (slot, slotName: string) => {
    const replacement = enrichmentsForId[slotName];
    if (typeof replacement === 'undefined') {
      // No replacement found, just return the slot as-is
      return slot;
    }
    return replacement;
  });
}

// IMHO, this version (below) is more straightforward than the one above:
export function enrichTextWithAttributes(text: string, tagValueMap?: { [key: string]: string }): string {
  if (text === undefined) return '';
  if (!text.match(ENRICHMENT_SLOT_REGEX)) return text;

  const tagMap = { ...tagValueMap }; // Ensure that we have an object
  return text.replace(ENRICHMENT_SLOT_REGEX, (_: string, templateVariableName: string) => {
    const replacement = tagMap[templateVariableName];
    if (typeof replacement !== 'undefined') {
      return tagMap[templateVariableName];
    }
    return templateVariableName; // If no match, just return the templateVariable name
  });
}

// This version used in vfe-apis
export function replaceTemplateVariables(
  text: string,
  templateValues: { [key: string]: string } = {},
  itemIdentifier?: string,
): { value: string; valid: boolean } {
  if (text === undefined) return { value: '', valid: true };
  if (!text.match(ATTRIBUTE_PLUG_REGEX)) return { value: text, valid: true };

  const missingAttributes: string[] = [];
  const value = text.replace(ATTRIBUTE_PLUG_REGEX, (_: string, templateVarName: string) => {
    if (templateValues[templateVarName]) {
      return templateValues[templateVarName];
    }

    missingAttributes.push(templateVarName);
    return MISSING_TEMPLATE_STRING;
  });

  if (missingAttributes.length) {
    const err = `${missingAttributes.join(
      ', ',
    )} was not replaced for promotion code ${itemIdentifier} for text '${text}'`;
    Logger.error(err, templateValues);
  }

  return { value, valid: !missingAttributes.length };
}

export function enrichPromotion(promotion: Promotion, attributes: { [key: string]: string } = {}): Promotion | null {
  try {
    const { promotionCode } = promotion;

    const enrichTitle = replaceTemplateVariables(promotion.title, attributes, promotionCode);
    const enrichDescription = replaceTemplateVariables(promotion.description, attributes, promotionCode);

    return {
      ...promotion,
      title: enrichTitle.valid ? enrichTitle.value : '',
      description: enrichDescription.valid ? enrichDescription.value : '',
    };
  } catch (e) {
    Logger.error(e);
    return null;
  }
}

/**
 * parses date string for these formats:-
 * `04/Dec/22, 04/12/22, 04-Dec-22, 04-12-22`
 * and returns `MM/DD/YYYY`
 * @param preParsedString Sttring
 * @param defaultSeparator String
 * @returns String
 */
export function parseDateString(preParsedString: string, defaultSeparator = '/'): string {
  if (!preParsedString) return '';
  let separator = defaultSeparator; // no-param-reassign
  if (!preParsedString.includes(defaultSeparator)) {
    separator = '-';
  }
  const dateSplit = preParsedString.split(separator);
  if (dateSplit.length <= 1) return ''; // a third type of seperator?

  // check if month is a number or string
  // if the month is is not a number
  // get the month index from the month name
  const month = Number(dateSplit[1]);
  const objDate = {
    day: dateSplit[0],
    month: Number.isNaN(month) ? getMonthNumber(dateSplit[1]) : month,
    year: dateSplit[2],
  };

  const dateMillennium = objDate.year.length === 2 ? '20' : '';
  return `${objDate.month}/${objDate.day}/${dateMillennium}${objDate.year}`;
}

export function formatDate(date: string, targetFormat: string): string {
  const validatedDate = Number.isNaN(Date.parse(date)) ? date.replaceAll('-', '/') : date;
  return format(Date.parse(validatedDate), targetFormat);
}

export function formatDeliveryAddress(address: ShipmentAddress): string {
  if (address) {
    let deliveryAddress = '';
    if (address.floorType && address.floor) {
      deliveryAddress = deliveryAddress.concat(address.floorType).concat(' ').concat(address.floor).concat('/');
    }
    return deliveryAddress
      .concat(address.streetNumber)
      .concat(' ')
      .concat(startCase(lowerCase(address.streetName)))
      .concat(' ')
      .concat(startCase(lowerCase(address.streetType)))
      .concat('\n')
      .concat(startCase(lowerCase(address.city)))
      .concat(', ')
      .concat(address.state)
      .concat(' ')
      .concat(address.postalCode);
  }
  return '';
}

export function formatGSTInclusiveAmount(amount: string): number {
  const parsedPrice = parseFloat(amount);
  return Math.round(parsedPrice * GST_PERCENTAGE_MULTIPLY_FACTOR);
}

/**
 * formatEUPrice
 * 1234 => 1234
 * 30.52111111111111 => 30.52
 */
export const formatEUPrice = (amount: number): number => {
  return parseFloat(Number.isInteger(amount) ? amount.toFixed(0) : amount.toFixed(2));
};

// I think this is a hashmap. Not sure.
export type Enrichment = Record<string, Record<string, string | undefined> | undefined>;

/**
 * `td_dsp_offer_cd` has a format of `dd-MMM-yy`.
 * this func will retrun the month index for
 * the given `MMM`
 * @private
 * @param monthName String
 * @returns String
 */
function getMonthNumber(monthName: string): string {
  const monthObject: { [key: string]: string } = {
    jan: '01',
    feb: '02',
    mar: '03',
    apr: '04',
    may: '05',
    jun: '06',
    jul: '07',
    aug: '08',
    sep: '09',
    oct: '10',
    nov: '11',
    dec: '12',
  };
  const monthNumber = monthObject[monthName.toLocaleLowerCase()];
  return monthNumber || '';
}
