import { LocalStorageClient } from '@src/lib/storage';
import { Basket } from '@src/lib/api/types';

export const checkStudentOfferApplicable = (cart: Basket | null) => {
  const isStudentOfferEligibleProductAvailable = (productCode: string) => {
    const studentOfferProduct = cart?.packages.filter((packageItem) => {
      return packageItem.items.find((item) => item.productCode === productCode);
    });
    return studentOfferProduct && studentOfferProduct.length > 0;
  };
  const studentOfferPlanId = LocalStorageClient.getStudentOfferInfo().planId;
  if (studentOfferPlanId) {
    return isStudentOfferEligibleProductAvailable(studentOfferPlanId);
  }
  return false;
};
