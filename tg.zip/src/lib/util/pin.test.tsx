import { render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import React from 'react';
import { normalisePin, onKeyPressPreventNonNumericKey } from '@src/lib/util/pin';

describe('PIN lib', () => {
  describe('normalisePin', () => {
    it('should strip non-numeric characters', () => {
      expect(normalisePin('abc123')).toBe('123');
    });
  });

  describe('onKeyPressPreventNonNumericKey', () => {
    it.skip('should ignore all non numeric keys', () => {
      const Component = () => {
        const [value, setValue] = React.useState('');
        return (
          <input
            type="text"
            value={value}
            onChange={(e) => setValue(e.currentTarget.value)}
            onKeyPress={onKeyPressPreventNonNumericKey}
          />
        );
      };
      const result = render(<Component />);
      userEvent.type(result.getByRole('textbox'), 'abc123');
      // Looks like `keypress` event handlers are not triggered in JSDOM
      expect(result.getByRole('textbox')).toHaveValue('123');
    });

    // Fallback tests as above test doesn't seem to work in JSDOM
    it.each([
      { key: 'a', defaultPrevented: true },
      { key: '1', defaultPrevented: false },
      { key: 'ArrowLeft', defaultPrevented: false },
    ])('should set defaultPrevented: $defaultPrevented for key "$key"', ({ key, defaultPrevented }) => {
      const e = new KeyboardEvent('keypress', { key });
      e.preventDefault = jest.fn();
      onKeyPressPreventNonNumericKey(e as unknown as React.KeyboardEvent<HTMLInputElement>);
      expect(e.preventDefault).toBeCalledTimes(defaultPrevented ? 1 : 0);
    });
  });
});
