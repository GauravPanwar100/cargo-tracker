/*
 *  toTitleCase: capitalize the first letter in a string and lowercase all remaining characters.
 */
export const toTitleCase = (sentence: string): string => {
  if (sentence.length > 1) {
    return `${sentence[0].toUpperCase()}${sentence.substring(1).toLowerCase()}`;
  }
  return sentence.toUpperCase();
};
