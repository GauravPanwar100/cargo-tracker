import { AddressStatus, PickedMatchedAddress } from '@src/components/vfe/AddressChecker/AddressChecker.interfaces';
import {
  HighSpeedPlanTiers,
  convertStreetType,
  extractHighSpeedEligibility,
} from '@src/components/vfe/AddressChecker/utils';
import { ContinueJourney, HomeInternetType } from '@src/templates/HomeWireless/HomeWireless.constants';
import React, { useCallback } from 'react';
import {
  BasketItem,
  BasketPackage,
  BasketRequestItem,
  CatalogCode,
  HomeWirelessPlan,
  HomeWirelessPlansResponse,
  NbnPlan,
  NbnPlansResponse,
  ProductSubType,
} from '@src/lib/api/types';

import { ModemPriceInfo } from '@src/lib/context/modem-price-info';
import { MIN_COST_MODAL_IDS } from '@src/lib/constants/modals';
import { defaultTriggerLabel } from '@src/components/vfe/MinCostModal/MinCostModal.constants';
import { ConsolidatedNbnPlan } from '@src/lib/util/nbn';
import { SessionStorageClient } from '@src/lib/storage';
import { AddressDetails } from '../storage/types';
import { isFhw4gPlanBasketItem, isFhw5gPlanBasketItem, isNbnPlanBasketItem } from './cart';

export const useFhwDetailsFn = (
  setAddressDetails: React.Dispatch<React.SetStateAction<AddressDetails | null>>,
  setFhwEligible: React.Dispatch<React.SetStateAction<boolean | null>>,
  continueJourney: ContinueJourney,
  pathName: string,
) => {
  return useCallback(
    (pickedMatchedAddress: PickedMatchedAddress | null, homeWirelessStatus: AddressStatus | null) => {
      if (pickedMatchedAddress) {
        // set valid address details in session to use on reload
        SessionStorageClient.setValidAddressDetailsInSession(pickedMatchedAddress);
      }
      if (homeWirelessStatus) {
        // set valid internet details in session to use on reload
        SessionStorageClient.setValidInternetDetailsInSession(homeWirelessStatus);
      }
      if (homeWirelessStatus) setFhwEligible(homeWirelessStatus[continueJourney]);
      if (!pickedMatchedAddress || !homeWirelessStatus || !homeWirelessStatus[continueJourney]) {
        setAddressDetails(null);
      } else {
        setAddressDetails({
          address: {
            correlationId: pickedMatchedAddress.correlationId,
            matchedAddress: {
              nbnLocationId: pickedMatchedAddress.matchedAddress.nbnLocationId,
              geocode: pickedMatchedAddress.matchedAddress.geocode,
              address: {
                ...pickedMatchedAddress.matchedAddress.address,
                streetType:
                  convertStreetType(pickedMatchedAddress.matchedAddress.address.streetType) ||
                  pickedMatchedAddress.matchedAddress.address.streetType,
                complexStreetType: convertStreetType(pickedMatchedAddress.matchedAddress.address.complexStreetType),
              },
            },
          },
        });
        // set valid address details in session to use on reload
        SessionStorageClient.setValidAddressDetailsInSession(pickedMatchedAddress);
        // set current route in session if valid address search to reuse on page redirection data retrival
        SessionStorageClient.setRouteNameInSession(pathName);
        // set valid internet details in session to use on reload
        SessionStorageClient.setValidInternetDetailsInSession(homeWirelessStatus);
      }
    },
    [continueJourney, setAddressDetails, setFhwEligible, pathName],
  );
};

export const use1SQDetailsFn = (
  setAddressDetails: React.Dispatch<React.SetStateAction<AddressDetails | null>>,
  setEligibleSpeed: React.Dispatch<React.SetStateAction<HighSpeedPlanTiers[]>>,
  pathName: string,
) => {
  return useCallback(
    (pickedMatchedAddress: PickedMatchedAddress | null, homeWirelessStatus: AddressStatus | null) => {
      if (pickedMatchedAddress) {
        SessionStorageClient.setValidAddressDetailsInSession(pickedMatchedAddress);
      }
      if (homeWirelessStatus) {
        SessionStorageClient.setValidInternetDetailsInSession(homeWirelessStatus);
        setEligibleSpeed(extractHighSpeedEligibility(homeWirelessStatus));
      }
      if (!pickedMatchedAddress || !homeWirelessStatus) {
        setAddressDetails(null);
      } else {
        setAddressDetails({
          address: {
            correlationId: pickedMatchedAddress.correlationId,
            matchedAddress: {
              nbnLocationId: pickedMatchedAddress.matchedAddress.nbnLocationId,
              geocode: pickedMatchedAddress.matchedAddress.geocode,
              address: {
                ...pickedMatchedAddress.matchedAddress.address,
                streetType:
                  convertStreetType(pickedMatchedAddress.matchedAddress.address.streetType) ||
                  pickedMatchedAddress.matchedAddress.address.streetType,
                complexStreetType: convertStreetType(pickedMatchedAddress.matchedAddress.address.complexStreetType),
              },
            },
          },
        });
        SessionStorageClient.setRouteNameInSession(pathName);
      }
    },
    [setAddressDetails, setEligibleSpeed, pathName],
  );
};

export const getInternetType = (bundle: BasketPackage): HomeInternetType | undefined => {
  if (bundle.items.some(isNbnPlanBasketItem)) {
    return HomeInternetType.NBN;
  }
  if (bundle.items.some(isFhw4gPlanBasketItem)) {
    return HomeInternetType.FHW_4G;
  }
  if (bundle.items.some(isFhw5gPlanBasketItem)) {
    return HomeInternetType.FHW_5G;
  }
  return undefined;
};

export const isHomeInternetPlan = (catalogCode?: CatalogCode) => {
  if (!catalogCode) {
    return false;
  }
  return (
    catalogCode === CatalogCode.NBN_PLANS ||
    catalogCode === CatalogCode.FHW_4G_PLANS ||
    catalogCode === CatalogCode.FHW_5G_PLANS
  );
};

/**
 * getHomeInternetPlanPriceInfoFromCartItem returns productName, recurringCharge, nrcPriceAdjustment of cart item
 */
export const getHomeInternetPlanPriceInfoFromPlan = (plan: NbnPlan | HomeWirelessPlan | ConsolidatedNbnPlan) => ({
  planName: plan.planName,
  planRecurringCharge: plan.recurringCharge,
  planDiscountedRecurringCharge: plan.discountedRecurringCharge,
});

/**
 * getHomeInternetPlanPriceInfoFromCartItem returns productName, recurringCharge, nrcPriceAdjustment of cart item
 */
export const getHomeInternetPlanPriceInfoFromCartItem = (item: BasketItem | BasketRequestItem | undefined) => ({
  planName: item?.productName || '',
  planRecurringCharge: item?.priceInfo.recurringCharge || 0,
  planDiscountedRecurringCharge: item?.priceInfo.adjustedMRCAmount || 0,
});

/**
 * getHomeInternetModemPriceInfoFromCartItems returns modemPriceInfo from modem item in cart items of home internet bundle.
 */
export const getHomeInternetModemPriceInfoFromCartItems = (cartItems: BasketItem[]) => {
  const modemCartItem = cartItems?.find(
    (item) => item.productSubType === ProductSubType.NBN_MODEM && item.itemType === 'MODEM',
  );

  const modemPriceInfo: ModemPriceInfo = {
    recurringCharge: modemCartItem?.priceInfo?.recurringCharge || 0,
    oneTimeCharge: modemCartItem?.priceInfo?.oneTimeCharge || 0,
    loyaltyMRCAmount: modemCartItem?.priceInfo?.loyaltyMRCAmount || 0,
    contractTerm: modemCartItem?.productConfig?.contractTerm || '',
  };

  return modemPriceInfo;
};

export const getHomeInternetModemPriceInfo = (plansResponse: HomeWirelessPlansResponse | NbnPlansResponse) => {
  return plansResponse.modemPriceInfo;
};

export const getHomeInternetModemPriceInfoFromStickyCartItems = (items: BasketRequestItem[]) => {
  const modemItem = items.find((item) => isHomeInternetPlan(item.catalogCode) && item.childProducts.length !== 0);

  const modemPriceInfo: ModemPriceInfo = {
    recurringCharge: modemItem?.childProducts[0].priceInfo?.recurringCharge || 0,
    oneTimeCharge: modemItem?.childProducts[0].priceInfo?.oneTimeCharge || 0,
    loyaltyMRCAmount: modemItem?.childProducts[0].priceInfo?.loyaltyMRCAmount || 0,
    contractTerm: modemItem?.childProducts[0].productConfig?.contractTerm || '',
  };

  return modemPriceInfo;
};

export const getMinCostModalId = (basketItem: BasketRequestItem) => {
  if (basketItem.catalogCode === CatalogCode.FHW_4G_PLANS) {
    return MIN_COST_MODAL_IDS.MIN_COST_MODEM_MODAL_ID;
  }

  if (basketItem.catalogCode === CatalogCode.FHW_5G_PLANS) {
    return MIN_COST_MODAL_IDS.MIN_COST_5G_MODAL_ID;
  }

  if (basketItem.catalogCode === CatalogCode.NBN_PLANS && basketItem.childProducts.length !== 0) {
    return MIN_COST_MODAL_IDS.MIN_COST_MODEM_MODAL_ID;
  }

  if (basketItem.catalogCode === CatalogCode.NBN_PLANS && basketItem.childProducts.length === 0) {
    return MIN_COST_MODAL_IDS.MIN_COST_BYO_MODAL_ID;
  }

  return undefined;
};

export const getHomeInternetMinCostModalProps = (bundle: BasketItem | undefined) => {
  const planPriceInfo = getHomeInternetPlanPriceInfoFromCartItem(bundle);
  let minCostModalId;
  switch (bundle?.productSubType) {
    case ProductSubType.FHW_5G_M2M:
      minCostModalId = MIN_COST_MODAL_IDS.MIN_COST_5G_MODAL_ID;
      break;
    case ProductSubType.NBN_BYO_M2M:
      minCostModalId = MIN_COST_MODAL_IDS.MIN_COST_BYO_MODAL_ID;
      break;
    default:
      minCostModalId = MIN_COST_MODAL_IDS.MIN_COST_MODEM_MODAL_ID;
  }

  return {
    planPriceInfo,
    minCostModalId,
  };
};

export const getMinCostModalPropsFromPlan = (plan: HomeWirelessPlan) => {
  const planPriceInfo = {
    planName: plan.planProductName,
    planRecurringCharge: plan.recurringCharge || 0,
    planDiscountedRecurringCharge: plan.discountedRecurringCharge || plan.recurringCharge || 0,
  };

  let minCostModalId = MIN_COST_MODAL_IDS.MIN_COST_MODEM_MODAL_ID;

  if (plan.planSubType === ProductSubType.FHW_5G_M2M) {
    minCostModalId = MIN_COST_MODAL_IDS.MIN_COST_5G_MODAL_ID;
  }

  return {
    planPriceInfo,
    minCostLabel: defaultTriggerLabel,
    minCostModalId,
  };
};
