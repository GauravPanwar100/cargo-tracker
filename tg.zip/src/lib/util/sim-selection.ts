import { CartItemType, CartProductSubType, CartProductType, PlanBasketRequestItem } from '@src/lib/api/types';

export enum SimTypeCompatibility {
  PHYSICAL_SIM_ONLY = 'Physical SIM Only',
  ESIM_ONLY = 'e-SIM Only',
  PHYSICAL_AND_ESIM = 'Physical and e-SIM',
}

export enum SimProductCode {
  /**
   * NOTE: This is a _real_ productCode
   */
  ESIM = 'eSIM',
  /**
   * NOTE: This is a _fake_ productCode that is translated in `vfe-apis` to the real productCode applicable to the plan
   */
  PSIM = 'pSIM',
}

export const planWithSim = (plan: PlanBasketRequestItem, productCode: SimProductCode): PlanBasketRequestItem => ({
  ...plan,
  childProducts: [
    ...plan.childProducts.filter(
      (childProduct) => !([SimProductCode.ESIM, SimProductCode.PSIM] as string[]).includes(childProduct.productCode),
    ),
    {
      itemType: CartItemType.OFFER,
      productCode,
      catalogCode: plan.catalogCode,
      packageId: plan.packageId,
      priceInfo: {
        recurringCharge: 0,
      },
      productConfig: {},
      productName: {
        [SimProductCode.ESIM]: 'eSIM',
        [SimProductCode.PSIM]: 'SIM Card',
      }[productCode],
      productType: CartProductType.HARDWARE,
      productSubType: {
        [SimProductCode.ESIM]: CartProductSubType.ESIM,
        [SimProductCode.PSIM]: CartProductSubType.SIM,
      }[productCode],
    },
  ],
});
