// Util file for additional service discount

import { PostpaidMobilePhoneAndPlan } from '@src/lib/constants/journeys';
import {
  CART_PAGE,
  CHECKOUT_PAGE,
  FHW_4G_PAGE,
  FHW_5G_PAGE,
  MOBILE_LISTING_PAGE,
  NBN_PAGE,
  PLANS_PAGE,
  SIMO_PLANS_PAGE,
} from '@src/lib/constants/pages';

export const isInternetPage = (path: string) => [NBN_PAGE, FHW_4G_PAGE, FHW_5G_PAGE].includes(path);

export const isVoicePage = (path: string) => {
  let isPage = [PLANS_PAGE, SIMO_PLANS_PAGE].includes(path);
  if (path.startsWith(MOBILE_LISTING_PAGE) && path.includes(`step=${PostpaidMobilePhoneAndPlan.PLAN}`)) {
    isPage = true;
  }
  return isPage;
};

export const isCartPage = (path: string) => path === CART_PAGE;
export const isCheckoutPage = (path: string) => path === CHECKOUT_PAGE;
