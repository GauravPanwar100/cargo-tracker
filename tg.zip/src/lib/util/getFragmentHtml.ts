import { ExperienceFragment } from '@src/lib/api/types';

export const getFragmentHtml = (successArr: ExperienceFragment[][], id = '') => {
  if (!successArr || successArr.length === 0) return '';
  const [experienceFragments] = successArr;
  if (!experienceFragments || experienceFragments.length === 0) return '';
  const fragmentObj = id ? experienceFragments.find(({ fragmentId }) => fragmentId === id) : experienceFragments[0];
  const fragmentHtml = fragmentObj?.fragmentHtml;
  return fragmentHtml || '';
};
