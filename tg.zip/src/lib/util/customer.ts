import Router, { useRouter } from 'next/router';
import * as qs from 'query-string';
import React from 'react';
import {
  AccountType,
  BasketItem,
  BasketRequestItem,
  CartItemType,
  CustomerProductsEligibility,
  CustomerServiceDetails,
  ProductServiceType,
} from '@src/lib/api/types';
import { useCustomerData } from '@src/lib/context/customer-data';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { LocalStorageClient } from '@src/lib/storage';
import { User, useAuthentication } from '@src/lib/context/authentication';
import {
  flattenBasket,
  hasPlanBasketItem,
  isNbnPlanBasketItem,
  isPostpaidSimoPlanBasketItem,
  isTabletPlanBasketItem,
  isTabletSimoPlanBasketItem,
} from '@src/lib/util/cart';
import { useBasketState } from '@src/lib/context/basket';
import useServiceType from '@src/lib/hooks/use-service-type';
import { QueryKey } from '@src/lib/util/query';
import { useClientQuery } from '@src/lib/util/router';

export function isNbnService(service: CustomerServiceDetails) {
  return [ProductServiceType.NBN_ONLY, ProductServiceType.NBN_WITH_MBB].includes(service.serviceType!);
}

export function isPostpayMbbService(service: CustomerServiceDetails, user: User) {
  return isPostpayUser(user) && service.serviceType === ProductServiceType.MBB;
}

export function isPrepayMbbService(service: CustomerServiceDetails, user: User) {
  return isPrepayUser(user) && service.serviceType === ProductServiceType.MBB;
}

export function isPrepayVoiceService(service: CustomerServiceDetails, user: User) {
  return isPrepayUser(user) && service.serviceType === ProductServiceType.VOICE;
}

export function isPostpayVoiceService(service: CustomerServiceDetails, user: User) {
  return isPostpayUser(user) && service.serviceType === ProductServiceType.VOICE;
}

export function isPostpayUser(user: User) {
  return user['https://auth.vodafone.com.au/accounttype'] === AccountType.POSTPAY;
}

export function isPrepayUser(user: User) {
  return user['https://auth.vodafone.com.au/accounttype'] === AccountType.PREPAY;
}

export const customerUpgradingIsEligibleForProducts = (
  basketItems: readonly (BasketItem | BasketRequestItem)[],
  productsEligibility: CustomerProductsEligibility,
): boolean => {
  // no products in cart, so customer is still eligible
  if (!basketItems.length) return true;

  const { upgradeEligibilityIndicator, upgradeEligiblePlans } = productsEligibility;
  return (
    !!upgradeEligibilityIndicator &&
    !!upgradeEligiblePlans &&
    basketItems
      .filter((cartItem) => cartItem.itemType === CartItemType.PLAN)
      .every((cartItem) => upgradeEligiblePlans.includes(cartItem.productCode))
  );
};

export const continueShoppingRouteMap = {
  [ServiceTypeValue.AnotherService]: '/another-service',
  [ServiceTypeValue.Upgrade]: '/upgrade/mobile/mobile-phones',
} as const;

/**
 * Split out from `useCustomerEligibility` but excludes the basket state
 */
export const useCustomerEligibilityLoading = () => {
  const { isAuthenticated, loading: isAuthLoading, user } = useAuthentication();

  const {
    activeService,
    customerDetails: [customerDetailsState],
    upgradePlanEligibility: [upgradePlanEligibilityState],
  } = useCustomerData();

  const { pathname } = useRouter();

  const [serviceType] = useServiceType();
  if (isAuthLoading) {
    return true;
  }

  if (isAuthenticated && customerDetailsState.isLoading) {
    return true;
  }

  const isTryingToUpgrade = !!user && !!activeService && isServiceOfType(serviceType, ServiceTypeValue.Upgrade);
  const isNbnCustomerTryingToUpgrade = isTryingToUpgrade && isNbnService(activeService!);
  if (isNbnCustomerTryingToUpgrade) {
    return true;
  }

  const isPrepaidVoiceCustomerTryingToUpgrade = isTryingToUpgrade && isPrepayVoiceService(activeService!, user!);
  if (isPrepaidVoiceCustomerTryingToUpgrade) {
    return true;
  }

  const isPrepaidMbbCustomerTryingToUpgrade = isTryingToUpgrade && isPrepayMbbService(activeService!, user!);
  if (isPrepaidMbbCustomerTryingToUpgrade) {
    return true;
  }

  const isTryingToAddService =
    !!user && !!activeService && isServiceOfType(serviceType, ServiceTypeValue.AnotherService);
  const isPrepaidVoiceOrMbbCustomerTryingToAddService =
    isTryingToAddService && (isPrepayVoiceService(activeService!, user!) || isPrepayMbbService(activeService!, user!));
  if (isPrepaidVoiceOrMbbCustomerTryingToAddService) {
    return true;
  }

  const isPrepaidCustomerTryingToAddServiceOnCart =
    isPrepaidVoiceOrMbbCustomerTryingToAddService && pathname === '/cart';
  if (isPrepaidCustomerTryingToAddServiceOnCart) {
    return true;
  }

  const isPrepaidVoiceCustomerTryingToUpgradeOnCart = isPrepaidVoiceCustomerTryingToUpgrade && pathname === '/cart';
  if (isPrepaidVoiceCustomerTryingToUpgradeOnCart) {
    return true;
  }

  const isPostpayMbbCustomerTryingToUpgrade = isTryingToUpgrade && isPostpayMbbService(activeService!, user!);
  if (isPostpayMbbCustomerTryingToUpgrade && pathname !== '/upgrade') {
    return true;
  }

  // connect the transient state where customerDetailsState is success and upgradePlanEligibilityState has not yet initialised
  const upgradePlanEligibilityPending =
    upgradePlanEligibilityState.isLoading ||
    (customerDetailsState.isSuccess && !upgradePlanEligibilityState.isInitialised);
  if (isServiceOfType(serviceType, ServiceTypeValue.Upgrade) && upgradePlanEligibilityPending) {
    return true;
  }

  if (isServiceOfType(serviceType, ServiceTypeValue.Upgrade) && !!activeService?.forceLogoutForUpgrade) {
    return true;
  }

  if (
    isServiceOfType(serviceType, ServiceTypeValue.AnotherService) &&
    !!activeService?.forceLogoutForAdditionalService
  ) {
    return true;
  }

  return false;
};

/**
 * Using this so that the empty list is referentially stable
 */
const EMPTY_BASKET_ITEMS_LIST: readonly (BasketItem | BasketRequestItem)[] = [];

export const useCustomerEligibility = (
  basketItems: readonly (BasketItem | BasketRequestItem)[] = EMPTY_BASKET_ITEMS_LIST,
) => {
  const { logout, user } = useAuthentication();
  const {
    activeMsisdn,
    activeService,
    customerDetails: [customerDetailsState],
    upgradePlanEligibility: [upgradePlanEligibilityState],
  } = useCustomerData();
  const { pathname } = useRouter();
  const query = useClientQuery();
  const [serviceType] = useServiceType();
  // check the sticky cart, and the basket to ensure that all products are valid for customer to upgrade
  const { getBasketState, getBasket } = useBasketState();

  const fromNudge = (query?.[QueryKey.NUDGE_REFERRER] || '').toString();
  const isTryingToUpgrade = !!user && !!activeService && isServiceOfType(serviceType, ServiceTypeValue.Upgrade);
  const isTryingToAddService =
    !!user && !!activeService && isServiceOfType(serviceType, ServiceTypeValue.AnotherService);
  const isNbnCustomerTryingToUpgrade = isTryingToUpgrade && isNbnService(activeService!);
  const isPostpayMbbCustomerTryingToUpgrade = isTryingToUpgrade && isPostpayMbbService(activeService!, user!);
  const isPrepaidVoiceCustomerTryingToUpgrade = isTryingToUpgrade && isPrepayVoiceService(activeService!, user!);
  const isPrepaidMbbCustomerTryingToUpgrade = isTryingToUpgrade && isPrepayMbbService(activeService!, user!);
  const isPrepaidVoiceOrMbbCustomerTryingToAddService =
    isTryingToAddService && (isPrepayVoiceService(activeService!, user!) || isPrepayMbbService(activeService!, user!));
  const isPrepaidCustomerTryingToAddServiceOnCart =
    isPrepaidVoiceOrMbbCustomerTryingToAddService && pathname === '/cart';
  const isPrepaidVoiceCustomerTryingToUpgradeOnCart = isPrepaidVoiceCustomerTryingToUpgrade && pathname === '/cart';

  // SHOP-2573-006
  React.useEffect(() => {
    if (isPrepaidCustomerTryingToAddServiceOnCart) {
      logout({
        returnTo: `${window.location.origin}/cart?${qs.stringify({
          push: 'prepay-additional-service-splitter',
          returnTo: `${window.location.origin}/checkout`,
        })}`,
      });
    }
  }, [isPrepaidCustomerTryingToAddServiceOnCart, logout]);

  // SHOP-2573-001/003
  React.useEffect(() => {
    if (isPrepaidVoiceCustomerTryingToUpgrade) {
      logout({
        returnTo: `${window.location.origin}${fromNudge ? '/logout' : '/mobile/mobile-phones'}?${qs.stringify({
          push: fromNudge ? 'prepay-upgrade-nudge' : 'prepay-voice-upgrade',
          /**
           * Note: we cannot use the current pathname as the AUTH0 returnTo url because these need to be configured in IAM upfront.
           * Instead, we set our own proprietary `returnTo` queryString after the fact. This is used to direct the user to a specific
           * url when they close the push notification from the logout page.
           */
          returnTo: fromNudge ? `${window.location.origin}${fromNudge}` : undefined,
          nudgeReferrer: fromNudge || undefined,
        })}`,
      });
    }
  }, [fromNudge, isPrepaidVoiceCustomerTryingToUpgrade, logout]);

  // SHOP-2573-002/003
  React.useEffect(() => {
    if (isPrepaidMbbCustomerTryingToUpgrade) {
      logout({
        returnTo: `${window.location.origin}${fromNudge ? '/logout' : '/mobile/tablets'}?${qs.stringify({
          push: fromNudge ? 'prepay-upgrade-nudge' : 'prepay-mbb-tablet-upgrade',
          returnTo: fromNudge ? `${window.location.origin}${fromNudge}` : undefined,
          nudgeReferrer: fromNudge || undefined,
        })}`,
      });
    }
  }, [fromNudge, isPrepaidMbbCustomerTryingToUpgrade, logout]);

  // SHOP-2573-004/005
  React.useEffect(() => {
    if (isPrepaidVoiceOrMbbCustomerTryingToAddService) {
      logout({
        returnTo: `${window.location.origin}/logout?${qs.stringify({
          push: fromNudge ? 'prepay-additional-service-nudge' : 'prepay-additional-service',
          returnTo: fromNudge ? `${window.location.origin}${fromNudge}` : undefined,
          nudgeReferrer: fromNudge || undefined,
        })}`,
      });
    }
  }, [fromNudge, isPrepaidVoiceOrMbbCustomerTryingToAddService, logout]);

  React.useEffect(() => {
    if (isNbnCustomerTryingToUpgrade) {
      // This is an AEM page not handled by the Next router
      window.location.href = '/wait/nbn';
    }
  }, [isNbnCustomerTryingToUpgrade]);

  React.useEffect(() => {
    if (isPrepaidVoiceCustomerTryingToUpgradeOnCart) {
      logout({ returnTo: `${window.location.origin}/wait/prepaid` });
    }
  }, [isPrepaidVoiceCustomerTryingToUpgradeOnCart, logout]);

  const cleanupCart = React.useCallback(() => {
    LocalStorageClient.clearCheckoutCart();
    LocalStorageClient.clearDisplayedCartStorage();
    LocalStorageClient.removeBasketId();
  }, []);

  React.useEffect(() => {
    if (!isTryingToUpgrade || getBasketState.isLoading) {
      return;
    }

    if (!getBasketState.data && !getBasketState.error) {
      const basketId = LocalStorageClient.getBasketId();
      if (basketId) {
        getBasket({ basketId });
      }
      return;
    }

    if (
      getBasketState.error ||
      [...basketItems, ...flattenBasket(getBasketState.data?.packages ?? [])].some(
        (item: BasketItem | BasketRequestItem) =>
          isNbnPlanBasketItem(item) ||
          isTabletPlanBasketItem(item) ||
          isTabletSimoPlanBasketItem(item) ||
          isPostpaidSimoPlanBasketItem(item),
      )
    ) {
      cleanupCart();
      Router.replace('/upgrade?push=errorunabletosave');
    }
  }, [
    basketItems,
    cleanupCart,
    getBasket,
    getBasketState.data,
    getBasketState.error,
    getBasketState.isLoading,
    isTryingToUpgrade,
  ]);

  // when the customer eligibility response is received, verify the response and redirect if the user is ineligible
  React.useEffect(() => {
    if (
      customerDetailsState.isLoading ||
      !customerDetailsState.data ||
      !activeService ||
      isNbnCustomerTryingToUpgrade ||
      isPrepaidCustomerTryingToAddServiceOnCart ||
      isPrepaidVoiceCustomerTryingToUpgrade ||
      isPrepaidMbbCustomerTryingToUpgrade ||
      isPrepaidVoiceOrMbbCustomerTryingToAddService ||
      isPrepaidVoiceCustomerTryingToUpgradeOnCart
    ) {
      return;
    }

    const {
      additionalServiceEligibility,
      permitPlanChangeIndicator,
      eligibilityIndicator,
      forceLogoutForUpgrade,
      forceLogoutForAdditionalService,
    } = activeService;

    if (isServiceOfType(serviceType, ServiceTypeValue.Upgrade)) {
      if (forceLogoutForUpgrade) {
        cleanupCart();
        // redirect to /upgrade/call page after logout
        logout({ returnTo: `${window.location.origin}/upgrade/call` });
      } else if (
        !eligibilityIndicator ||
        (!permitPlanChangeIndicator && hasPlanBasketItem(basketItems)) ||
        isPostpayMbbCustomerTryingToUpgrade
      ) {
        cleanupCart();
        if (pathname !== '/upgrade') Router.replace('/upgrade?push=errorunabletosave');
      }
    } else if (isServiceOfType(serviceType, ServiceTypeValue.AnotherService)) {
      if (forceLogoutForAdditionalService) {
        cleanupCart();
        // redirect to /additional-service/call page after logout
        logout({ returnTo: `${window.location.origin}/another-service/call` });
      } else if (!additionalServiceEligibility) {
        cleanupCart();
        if (pathname !== '/another-service') Router.replace('/another-service?push=errorunabletosave');
      }
    }
  }, [
    activeMsisdn,
    activeService,
    basketItems,
    cleanupCart,
    customerDetailsState.data,
    customerDetailsState.isLoading,
    isNbnCustomerTryingToUpgrade,
    isPostpayMbbCustomerTryingToUpgrade,
    isPrepaidCustomerTryingToAddServiceOnCart,
    isPrepaidMbbCustomerTryingToUpgrade,
    isPrepaidVoiceCustomerTryingToUpgrade,
    isPrepaidVoiceCustomerTryingToUpgradeOnCart,
    isPrepaidVoiceOrMbbCustomerTryingToAddService,
    logout,
    pathname,
    serviceType,
  ]);

  // when the products eligibility response is received, verify the response and redirect if the user is ineligible
  React.useEffect(() => {
    if (
      upgradePlanEligibilityState.isLoading ||
      !upgradePlanEligibilityState.data ||
      // Product eligibility checks are only for upgrades
      !isServiceOfType(serviceType, ServiceTypeValue.Upgrade) ||
      isNbnCustomerTryingToUpgrade ||
      isPostpayMbbCustomerTryingToUpgrade ||
      isPrepaidCustomerTryingToAddServiceOnCart ||
      isPrepaidVoiceCustomerTryingToUpgrade ||
      isPrepaidMbbCustomerTryingToUpgrade ||
      isPrepaidVoiceOrMbbCustomerTryingToAddService ||
      isPrepaidVoiceCustomerTryingToUpgradeOnCart
    ) {
      return;
    }

    if (!customerUpgradingIsEligibleForProducts(basketItems, upgradePlanEligibilityState.data)) {
      cleanupCart();
      Router.replace('/upgrade?push=errorunabletosave');
    }
  }, [
    basketItems,
    cleanupCart,
    isNbnCustomerTryingToUpgrade,
    isPostpayMbbCustomerTryingToUpgrade,
    isPrepaidCustomerTryingToAddServiceOnCart,
    isPrepaidMbbCustomerTryingToUpgrade,
    isPrepaidVoiceCustomerTryingToUpgrade,
    isPrepaidVoiceCustomerTryingToUpgradeOnCart,
    isPrepaidVoiceOrMbbCustomerTryingToAddService,
    serviceType,
    upgradePlanEligibilityState.data,
    upgradePlanEligibilityState.isLoading,
  ]);

  return {
    error: customerDetailsState.error || upgradePlanEligibilityState.error,
    loading:
      useCustomerEligibilityLoading() ||
      !query ||
      (isServiceOfType(serviceType, ServiceTypeValue.Upgrade) && getBasketState.isLoading),
  };
};

export const isServiceOfType = (serviceType: string | undefined, type: ServiceTypeValue) => {
  return serviceType === type;
};

export const formatMSISDN = (msisdn: string, mask?: boolean, maskChar?: string): string => {
  let phoneNumber: string = msisdn.replace(/^(614)/, '04');
  if (mask) {
    phoneNumber = `${phoneNumber.slice(0, 2)}${(maskChar ?? 'X').repeat(5)}${phoneNumber.slice(7, 10)}`;
  }
  return `${phoneNumber.slice(0, 4)} ${phoneNumber.slice(4, 7)} ${phoneNumber.slice(7, 10)}`;
};

// getUpgradeEligibilityAlertId exists because no nested ternaries allowed
export const getUpgradeEligibilityAlertId = ({
  isMbb,
  ineligibleStatusForUpgrade,
  customerEligibilityError,
  currentServiceError,
}: {
  isMbb: boolean;
  ineligibleStatusForUpgrade?: string;
  customerEligibilityError?: boolean;
  currentServiceError?: boolean;
}) => {
  switch (true) {
    case customerEligibilityError:
      return 'upgrade-technical-error';
    case isMbb:
    case currentServiceError:
      return 'no-upgrade-online';
    default:
      return ineligibleStatusForUpgrade;
  }
};

export const getDefaultLoginParams = () => {
  const urlParams = new URLSearchParams(window.location.search);
  return {
    cmp: urlParams.get(QueryKey.CMP) ?? undefined,
    DealerCode: urlParams.get(QueryKey.DEALER_CODE) ?? undefined,
    AgentID: urlParams.get(QueryKey.AGENT_ID) ?? undefined,
    nudgeReferrer: urlParams.get(QueryKey.NUDGE_REFERRER) ?? undefined,
  };
};
