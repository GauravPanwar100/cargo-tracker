import { ParsedUrlQuery } from 'querystring';
import { preview } from './preview';
import { QueryKey } from './query';

export const stripQueryFromPath = (path: string) => {
  let strippedPath = path;

  if (preview) {
    const indexOfDate = path.indexOf('date=');
    if (indexOfDate >= 0) {
      strippedPath = path.substring(0, indexOfDate) + path.substring(indexOfDate + 34, path.length);
    }
  }

  const indexOfParams = strippedPath.indexOf('?');
  return strippedPath.substring(0, indexOfParams !== -1 ? indexOfParams : undefined);
};

export const stripLastSegmentFromPath = (path: string) => {
  const indexOfLastSegment = path.lastIndexOf('/');
  return path.substring(0, indexOfLastSegment !== -1 ? indexOfLastSegment : undefined);
};

// Source code from https://stackoverflow.com/questions/10687099/how-to-test-if-a-url-string-is-absolute-or-relative
export const PROTOCOL_REGEX = /^(?:[a-z]+:)?\/\//i; // Detects absolute URLs

/**
 * Returns whether a URL is relative.
 *
 * NOTE: You should probably use `isSpaNavigable` instead, which also handles routes that we want to be served by AEM
 * if available (e.g. in CloudFronted environments)
 *
 * @param url
 */
export function isRelativeUrl(url: string): boolean {
  return !PROTOCOL_REGEX.test(url); // "not" this regEx to return true for relative URLs
}

// https://vodafone.atlassian.net/wiki/spaces/DFS/pages/1447695152/Friendly+and+Vanity+URLs
export const convertDeviceNameToFriendlyUrl = (deviceName: string) => {
  return deviceName.replace(/\s/g, '-').replace('+', 'plus').replace(/\./g, ' ').toLowerCase();
};

export const getReferrerURL = () => {
  if (document.referrer === '') return null;
  const { origin, pathname, search } = new URL(document.referrer, window.location.origin);
  if (origin !== window.location.origin) return null;
  return `${pathname}${search}`;
};

export const decoratePathWithQueries = (path: string, queries: QueryKey[], query?: ParsedUrlQuery) => {
  if ((typeof window === 'undefined' && !query) || queries.length === 0) return path;
  const params = queries
    .map((q) => {
      const param = query ? (query[q] || '').toString() : new URLSearchParams(window.location.search)?.get(q);
      return param && !path.includes(`${q}=`) ? `${q}=${encodeURIComponent(param)}` : '';
    })
    .filter((q) => q);
  return params.length > 0 ? `${path}${path.includes('?') ? '&' : '?'}${params.join('&')}` : path;
};
