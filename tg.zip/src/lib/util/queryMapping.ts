import { HomeInternetType } from '@src/templates/HomeWireless/HomeWireless.constants';

export const fromQueriesToHomeInternetTypes = (typeQueries: string[]) => {
  const arr: string[] = [];
  if (!typeQueries) return arr;
  const [types] = typeQueries;
  if (!types) return arr;
  if (types.toLowerCase().indexOf('4g') >= 0) arr.push(HomeInternetType.FHW_4G);
  if (types.toLowerCase().indexOf('5g') >= 0) arr.push(HomeInternetType.FHW_5G);
  if (types.toLowerCase().indexOf('nbn') >= 0) arr.push(HomeInternetType.NBN);
  return arr;
};

export const fromHomeInternetTypesToQueries = (types: string[]) => {
  const arr: string[] = [];
  types.forEach((type: string) => {
    if (type === HomeInternetType.FHW_4G) arr.push('4G');
    if (type === HomeInternetType.FHW_5G) arr.push('5G');
    if (type === HomeInternetType.NBN) arr.push('nbn');
  });
  return arr.join('+');
};
