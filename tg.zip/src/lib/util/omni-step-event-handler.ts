interface stepMessage {
  name: string;
  type: string;
}

const BRAIN_TREE_EVENT_STRING = '/*framebus*/';

export const onpopstateOverride = (callback: () => void) => {
  return (e: PopStateEvent) => {
    if (e.state?.stepIndex != null) callback();
  };
};

export const stepUpdateMessageHandler = (stepPredicate: (data: stepMessage) => boolean, stepCallback: () => void) => {
  return (e: MessageEvent) => {
    // This is to resolve BrainTree excessive string at the beginning of the event data
    let sanitizedString;
    let data: stepMessage | undefined;
    if (typeof e.data === 'string') {
      sanitizedString = e.data.replace(BRAIN_TREE_EVENT_STRING, '') || '{}';
      data = JSON.parse(sanitizedString);
    } else {
      data = e.data;
    }
    if (data?.type === 'Step' && stepPredicate(data)) stepCallback();
  };
};
