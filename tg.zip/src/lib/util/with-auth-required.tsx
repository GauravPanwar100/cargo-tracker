import { NextPage } from 'next';
import { useRouter } from 'next/router';
import * as qs from 'query-string';
import React from 'react';
import getDisplayName from 'react-display-name';
import Cookies from 'universal-cookie';
import { useAuthentication } from '@src/lib/context/authentication';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { isUpgradesRoute } from '@src/lib/util/journey';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import { getDefaultLoginParams } from './customer';

const AuthRequired: React.FC = ({ children }) => {
  const { isAuthenticated, loading, login, user } = useAuthentication();
  const { pathname } = useRouter();

  React.useEffect(() => {
    if (!isAuthenticated && !loading) {
      login(
        isUpgradesRoute(pathname) ? ServiceTypeValue.Upgrade : ServiceTypeValue.AnotherService,
        getDefaultLoginParams(),
      );
    }
  }, [isAuthenticated, loading, login, pathname]);

  return <>{isAuthenticated && user ? children : <SpinnerSection />}</>;
};

/**
 * Wraps `WrappedComponent` with a client-only check that will force authentication for the route.
 *
 * This component may be used (not at the top level) when we still want SEO crawlers to index protected pages.
 * Importantly though, they will only see a spinner and hence any SEO content must be present 'above' this component
 * in the tree.
 *
 * @param WrappedComponent
 */
export function withAuthRequiredSeo<Props, InitialProps>(WrappedComponent: NextPage<Props, InitialProps>) {
  const WithAuthRequiredSeo: NextPage<Props, InitialProps> = (props) => (
    <AuthRequired>
      <WrappedComponent {...props} />
    </AuthRequired>
  );

  WithAuthRequiredSeo.getInitialProps = WrappedComponent.getInitialProps;

  return Object.assign(WithAuthRequiredSeo, {
    displayName: `WithAuthRequiredSeo(${getDisplayName(WrappedComponent)})`,
    getInitialProps: WrappedComponent.getInitialProps,
    WrappedComponent,
  });
}

/**
 * Wraps `WrappedComponent` with both a server-side redirect and a client check that will force authentication for the route.
 *
 * This uses the cookie `vfe.is.authenticated` as a server-side check for whether the user is not logged in to redirect
 * them immediately. As our pages are fronted by CloudFront, routes protected by this check need to have the cookie
 * whitelisted in the CloudFront configuration.
 *
 * Importantly, the client-side check will still occur even if the cookie indicates the user is logged in.
 *
 * @param WrappedComponent
 */
export function withAuthRequiredSsr<Props, InitialProps>(WrappedComponent: NextPage<Props, InitialProps>) {
  const WithAuthRequiredSsr: NextPage<Props, InitialProps> = (props) => (
    <AuthRequired>
      <WrappedComponent {...props} />
    </AuthRequired>
  );

  WithAuthRequiredSsr.getInitialProps = async (ctx) => {
    if (ctx.req && ctx.res) {
      const cookies = new Cookies(ctx.req.headers.cookie);
      if (cookies.get('vfe.is.authenticated') !== 'true') {
        ctx.res.writeHead(308, {
          Location: `/auth/login?${qs.stringify({
            route: ctx.req.url,
          })}`,
        });
        ctx.res.end();
      }
    }

    return {
      ...(await WrappedComponent.getInitialProps?.(ctx)),
    } as InitialProps;
  };

  return Object.assign(WithAuthRequiredSsr, {
    displayName: `WithAuthRequiredSsr(${getDisplayName(WrappedComponent)})`,
    WrappedComponent,
  });
}
