import { CatalogCode, PreviouslyViewedResponse } from '../api/types';
import LocalStorageClient from '../storage/local';
import { ProductItem } from '../storage/types';

export const storePreviouslyViewedProduct = (
  catalogCode: CatalogCode,
  fallback: ProductItem,
  previouslyViewedContent?: PreviouslyViewedResponse,
) => {
  if (!previouslyViewedContent) {
    LocalStorageClient.trackViewedProduct(fallback);
    return;
  }
  const item = previouslyViewedContent.products.find((product) => product.aemIdentifier === catalogCode);
  // if we are able to fetch content from AEM and find the content matching the catalog code we use
  // the content provided by AEM
  if (item) {
    const { iconPath: imageUrl, productDisplayName: productName } = item;
    LocalStorageClient.trackViewedProduct({
      productName,
      productImg: { imageUrl, altText: productName },
      productUrl: window.location.href,
      id: catalogCode,
    });
    return;
  }
  // if there are issues fetching data from AEM or we are not able to find the content for this catalog code
  // we use fallback product item instead
  LocalStorageClient.trackViewedProduct(fallback);
};
