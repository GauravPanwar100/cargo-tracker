import { BasePlan, BasketItemPriceInfo, BnsPlan, CatalogCode, PrepaidCatalogCodes } from '@src/lib/api/types';

type getDiscountedCostParams = {
  bnsPlans: BnsPlan[];
  plan: BasePlan;
  catalogCode: CatalogCode;
};

export const getDiscountedPriceInfo = ({
  bnsPlans,
  plan,
  catalogCode,
}: getDiscountedCostParams): BasketItemPriceInfo => {
  const bnsDiscount = bnsPlans.find((bnsPlan) => bnsPlan.planCode === plan.planId)?.bnsDiscount || 0;

  const isPrepaidPlan = PrepaidCatalogCodes.includes(catalogCode);
  const discountedCost = plan.discountedRecurringCharge ?? plan.discountedOneTimeCharge;
  const originalCost = plan.recurringCharge ?? plan.oneTimeCharge;
  const finalCost = discountedCost ?? originalCost;
  const discountedCostAfterBns = plan.isBundleAndSaveEligible && finalCost ? finalCost - bnsDiscount : finalCost;

  return {
    recurringCharge: plan.recurringCharge,
    oneTimeCharge: plan.oneTimeCharge,
    adjustedMRCAmount: isPrepaidPlan ? undefined : discountedCostAfterBns,
    adjustedNRCAmount: isPrepaidPlan ? discountedCostAfterBns : undefined,
  } as BasketItemPriceInfo;
};
