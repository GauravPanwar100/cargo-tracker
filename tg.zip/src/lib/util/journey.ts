import { BasketItem, BasketRequestItem } from '@src/lib/api/types';
import {
  isModemPlanBasketItem,
  isModemSimoPlanBasketItem,
  isPrepaidPlan,
  isTabletSimoPlanBasketItem,
} from '@src/lib/util/cart';

export const authenticatedRoutePrefixes = ['/upgrade', '/another-service'];

export function isUpgradesRoute(pathname: string) {
  return pathname.startsWith('/upgrade');
}

export function removeAuthenticatedRoutePrefix(pathname: string) {
  const found = authenticatedRoutePrefixes.find((prefix) => pathname.startsWith(prefix));
  return found ? pathname.slice(found.length) : pathname;
}

/**
 * shouldGoToExtrasPage is used to determine if we route the journey to the extras page under certain conditions. This function is necessary
 * because the APIs cannot tell us upfront which plans may or may not have extras, so we must hardcode the logic here for MVP.
 *
 * Current use cases:
 * - Prepaid journeys do not have extras, and do not need to select sim type, so goToExtrasPage = false.
 * - Tablet SIMO journeys, when simSelection feature is disabled, should also return false.
 *
 * @param item
 * @param simSelectionDisabled
 * @returns boolean
 */
export function shouldGoToExtrasPage(
  item: BasketItem | BasketRequestItem,
  simSelectionDisabled?: boolean | null,
): boolean {
  return (
    !isPrepaidPlan(item) &&
    !(simSelectionDisabled === true && isTabletSimoPlanBasketItem(item)) &&
    !isModemSimoPlanBasketItem(item) &&
    !isModemPlanBasketItem(item)
  );
}
