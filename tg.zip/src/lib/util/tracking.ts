import { AddressStatus } from '@src/components/vfe/AddressChecker/AddressChecker.interfaces';
import { HighSpeedPlanTiers, extractHighSpeedEligibility } from '@src/components/vfe/AddressChecker/utils';
import { trackEvent } from '@src/lib/tracking';

export const nbnAddressError = {
  pageEventAttributeOne: 'error',
  pageEventType: 'nbn-address-response',
  pageEventValue: 'click',
};

export const multipleMatchingAddresses = {
  pageEventAttributeOne: 'multiple-matching-addresses',
  pageEventType: 'nbn-address-response',
  pageEventValue: 'click',
};

export const noMatchingAddresses = {
  pageEventAttributeOne: 'no-matching-addresses',
  pageEventType: 'nbn-address-response',
  pageEventValue: 'click',
};

export const nbnUnavailable = {
  pageEventAttributeOne: 'nbn-unavailable',
  pageEventAttributeTwo: 'negative',
  pageEventType: 'nbn-address-response',
  pageEventValue: 'click',
};

export const nbnAllAvailable = {
  pageEventAttributeOne: 'nbn-available',
  pageEventAttributeTwo: 'all',
  pageEventType: 'nbn-address-response',
  pageEventValue: 'click',
};

export const nbn250Available = {
  pageEventAttributeOne: 'nbn-available',
  pageEventAttributeTwo: 'standard-plus-250',
  pageEventType: 'nbn-address-response',
  pageEventValue: 'click',
};

export const nbnStandardAvailable = {
  pageEventAttributeOne: 'nbn-available',
  pageEventAttributeTwo: 'standard',
  pageEventType: 'nbn-address-response',
  pageEventValue: 'click',
};

export const nbnAddressManual = {
  pageEventAttributeOne: 'search-nbn-address-manual-autocomplete-failed',
  pageEventType: 'button',
  pageEventValue: 'click',
};

export const nbnAddressManualDirect = {
  pageEventAttributeOne: 'search-nbn-address-manual-direct',
  pageEventType: 'button',
  pageEventValue: 'click',
};

export const selectNbnAddress = {
  pageEventAttributeOne: 'search-nbn-address',
  pageEventType: 'list-item',
  pageEventValue: 'select-positive',
};

export const selectNbnPlanWithModem = {
  pageEventAttributeOne: 'select-nbn-plans-with-modem',
  pageEventType: 'tab',
  pageEventValue: 'click',
};

export const selectNbnPlanWithoutModem = {
  pageEventAttributeOne: 'select-nbn-plans-without-modem',
  pageEventType: 'tab',
  pageEventValue: 'click',
};

export const removeBnsPackageCart = {
  pageEventAttributeOne: 'remove-bns-package-from-cart',
  pageEventType: 'button',
  pageEventValue: 'click',
};

export const keepBnsPackageCart = {
  pageEventAttributeOne: 'keep-bns-package-cart',
  pageEventType: 'button',
  pageEventValue: 'click',
};

export const dismissBnsPackageCart = {
  pageEventAttributeOne: 'dismiss-bns-package-cart',
  pageEventType: 'button',
  pageEventValue: 'click',
};

export const trackEventTabSelection = (withModem: boolean) => {
  if (withModem) {
    trackEvent(selectNbnPlanWithModem);
  } else {
    trackEvent(selectNbnPlanWithoutModem);
  }
};

export const trackNbnStatus = (nbnStatus: AddressStatus) => {
  if ((nbnStatus.status === '0' || nbnStatus.status === '') && !nbnStatus.continueNbnJourney) {
    trackEvent(nbnUnavailable);
    return;
  }
  const highSpeedPlanTiers = extractHighSpeedEligibility(nbnStatus);
  if (
    highSpeedPlanTiers.includes(HighSpeedPlanTiers.highspeed_1000) &&
    highSpeedPlanTiers.includes(HighSpeedPlanTiers.highspeed_250)
  ) {
    trackEvent(nbnAllAvailable);
    return;
  }
  if (highSpeedPlanTiers.includes(HighSpeedPlanTiers.highspeed_250)) {
    trackEvent(nbn250Available);
    return;
  }
  trackEvent(nbnStandardAvailable);
};

export const trackNbnManualSubmitEvent = (isAddressProvided: boolean) => {
  if (isAddressProvided) {
    // track when address is provided and user clicks on Enter address manually checkbox
    trackEvent(nbnAddressManual);
  } else {
    // track when user clicks on Enter address manually checkbox directly
    trackEvent(nbnAddressManualDirect);
  }
};

export const trackNbnAddressResponseError = (errorCode: string) => {
  trackEvent({ ...nbnAddressError, pageEventAttributeTwo: errorCode });
};
