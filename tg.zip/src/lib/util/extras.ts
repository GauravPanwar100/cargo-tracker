import { JourneyStepCompletionParams } from '@src/components/core/Journey/JourneyStep/JourneyStep';
import { getApiClient } from '@src/lib/api';
import { LocalStorageClient } from '@src/lib/storage';
import { canSelectESimOrPSim, getRafUpdateRequestParams } from '@src/lib/util/cart';
import { safeRouterPush } from '@src/lib/util/router';
import { shouldGoToExtrasPage } from '@src/lib/util/journey';

/** Decide if user should go to extras, or skip extras and go directly to cart
 * If no extras exist, commit selected plan to cart and push user to cart page
 * If extras do exist, push user to extras page
 */
export const onBeforeGoToExtrasStep = async (
  { hasExtras, isSimSelectionDisabledWithFeatureFlag, items, basketState }: JourneyStepCompletionParams,
  customerBundleAndSaveCount?: number,
): Promise<boolean> => {
  // As eSIM/pSIM selection now lives on the extras page,
  // it might seem we need to navigate to extras page regardless of whether there are extras.
  // However, the eSIM/pSIM selection can be disabled by a feature flag.
  // In case of no extras and no eSIM/pSIM selection, we will skip the extras page.
  if (canSelectESimOrPSim(items, isSimSelectionDisabledWithFeatureFlag)) return true;

  const cartHasExtras =
    hasExtras ?? items.some((item) => shouldGoToExtrasPage(item, isSimSelectionDisabledWithFeatureFlag?.data));

  if (cartHasExtras) return true;

  const response = await getApiClient().addToBasket({
    items,
    additionalBnsCount: customerBundleAndSaveCount || 0,
    raf: basketState ? getRafUpdateRequestParams(items, basketState) : undefined,
  });

  if (!response) return false;

  LocalStorageClient.setBasketId(response.basketId);
  await safeRouterPush('/cart');
  return false;
};
