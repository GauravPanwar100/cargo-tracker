import { LocalStorageClient } from '@src/lib/storage';

export interface GAValueProps {
  GAClientId: string | null;
  lastVisitedDate: Date;
}

// GA value from cookie
const GACookieValue = () => {
  const GaFromCookie = LocalStorageClient.getCookie(LocalStorageClient.GACookieKey);
  return GaFromCookie ? GaFromCookie.split('.') : null;
};

// GA value from local storage
const GALocalStorageValue = LocalStorageClient.getGAValue();

export const RETURNING_USER_DAYS = 60;

const SESSION_TIME_MINUTES = 30;

/**
 * It will return true/false based on user last visited on this website
 */
export const isReturningUser = (): boolean => {
  if (GALocalStorageValue) {
    // If user visited website more than 60 days past

    const GACookeiValueSplitted = GACookieValue();

    if (GACookeiValueSplitted && GACookeiValueSplitted.length > 3) {
      const LastVisitedInDays = Math.floor(
        (new Date(GALocalStorageValue.lastVisitedDate).getTime() - GACookeiValueSplitted[3] * 1000) /
          (24 * 60 * 60 * 1000),
      );

      const LastVisitedInMinutes = GACookeiValueSplitted
        ? Math.floor(
            (new Date(GALocalStorageValue.lastVisitedDate).getTime() - GACookeiValueSplitted[3] * 1000) / (60 * 1000),
          )
        : 0;

      // If GACookie & GASession value same and user visited within 60 days, the user is a valid return user
      return !!(
        GACookeiValueSplitted &&
        GALocalStorageValue.GAClientId === GACookeiValueSplitted[2] &&
        RETURNING_USER_DAYS >= LastVisitedInDays &&
        LastVisitedInMinutes > SESSION_TIME_MINUTES
      );
    }
  }
  return false;
};

export const setGASessionValue = () => {
  const GACookeiValueSplitted = GACookieValue();
  const GAValue: GAValueProps = {
    GAClientId: GACookeiValueSplitted ? GACookeiValueSplitted[2] : null,
    lastVisitedDate: new Date(),
  };
  LocalStorageClient.setGAValue(GAValue);
};
