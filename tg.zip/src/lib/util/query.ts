import { ParsedQuery } from 'query-string';
import { getApiClient } from '@src/lib/api';
import {
  BasePlan,
  BnsPlan,
  CartItemType,
  CartProductSubType,
  CartProductType,
  CatalogCode,
  DeepLinkableDeviceStockStatuses,
  DeviceBasketRequestItem,
  DeviceConfigPricingMatrix,
  DeviceDetails,
  ModemBasketRequestItem,
  ModemConfigPricingMatrix,
  PlanBasketRequestItem,
  PlanEndpoint,
  PrepaidCatalogCodes,
  ProductSubType,
  Promotion,
  StrippedBasketRequestItem,
  WatchConfigPricingMatrix,
  WatchDeviceDetails,
  WearableDeviceBasketRequestItem,
} from '@src/lib/api/types';
import { SimProductCode, planWithSim } from '@src/lib/util/sim-selection';
import { getTotalAdjustedValueFromPromotions } from '@src/templates/Plans/utils';
import { getDiscountedPriceInfo } from '@src/lib/util/bns';

export enum QueryKey {
  ACCORDION = 'accordion',
  AGENT_ID = 'AgentID',
  CMP = 'cmp',
  CONTINUE = 'continue',
  DEALER_CODE = 'DealerCode',
  DEVICE = 'device',
  DEVICE_CAPACITY = 'capacity',
  DEVICE_COLOR = 'color',
  DEVICE_CONTRACT_TERM = 'contractTerm',
  HERO_LABEL = 'heroLabel',
  HERO = 'hero',
  JOURNEY_STEP = 'step',
  MODEM = 'modem',
  NUDGE_REFERRER = 'nudgeReferrer',
  PLAN = 'plan',
  PLAN_TYPE = 'planType',
  TAB = 'tab',
  DATE = 'date',
  AUTH = 'auth',
  EXTRA = 'extra',
  PREPAID_DEVICE = 'prepaidDevice',
  WATCH = 'watch',
  BRAND = 'brand',
  SORT = 'sort',
  // Following query keys are added as part of Samsung Initiative
  PARTNER_CODE = 'partnerCode',
  PLAN_ID = 'planId',
  DEVICE_SKU = 'deviceSKU',
  CALLBACK_URL = 'callbackURL',
  RESUME_URL = 'resumeURL',
  CART_UID = 'cartUID',
  DEVICE_CASE_SIZE = 'caseSize',
  DEVICE_BAND_NAME = 'bandName',
  DEVICE_BAND_SIZE = 'bandSize',
  DEVICE_BAND_COLOR = 'bandColor',
  PLANID = 'planId',
  SLUG = 'slug',
  CLEARCART = 'clearCart',
}

interface BuildCartItemFromQueryParams {
  catalogCode: CatalogCode;
  query: ParsedQuery;
  defaultChildProduct?: null | string;
  promotions?: Promotion[];
  productSubType?: CartProductSubType;
}

interface BuildDeviceCartItemFromQueryParams extends BuildCartItemFromQueryParams {
  deviceConfig: DeviceConfigPricingMatrix;
  deviceDetails: DeviceDetails;
}
interface BuildWearableCartItemFromQueryParams extends BuildCartItemFromQueryParams {
  deviceConfig: WatchConfigPricingMatrix;
  deviceDetails: WatchDeviceDetails;
}

interface BuildModemCartItemFromQueryParams extends BuildCartItemFromQueryParams {
  deviceConfig: ModemConfigPricingMatrix;
  deviceDetails: DeviceDetails;
}

interface BuildPlanCartItemFromQueryParams extends BuildCartItemFromQueryParams {
  plans: BasePlan[];
}

export const buildDeviceFromQuery = async ({
  catalogCode,
  deviceConfig,
  deviceDetails,
  promotions,
  productSubType,
  query,
}: BuildDeviceCartItemFromQueryParams): Promise<DeviceBasketRequestItem> => {
  if (deviceDetails.announcementPhase) {
    throw new Error('Device in announcement phase');
  }

  const isPrepaid = PrepaidCatalogCodes.includes(catalogCode);
  const capacity = (query[QueryKey.DEVICE_CAPACITY] as string) ?? deviceDetails.defaultCapacity;
  const color = (query[QueryKey.DEVICE_COLOR] as string) ?? deviceDetails.defaultColor;
  const contractTerm = (query[QueryKey.DEVICE_CONTRACT_TERM] as string) ?? deviceDetails.defaultContractTerm;
  const config = deviceConfig[color]?.[capacity]?.find(
    (entry) =>
      entry.ContractTerm.toLowerCase() === `${contractTerm} Months`.toLowerCase() && entry.OrderType === 'Connect',
  );

  const totalAdjustedValue = getTotalAdjustedValueFromPromotions(promotions);

  if (!config) {
    throw new Error('Device config not found');
  }

  const discountedPrice = totalAdjustedValue ? config.MRC - totalAdjustedValue : undefined;

  const stockStatusResponse = await getApiClient().fetchDeviceStockStatus({ deviceSku: config.SKU });
  if (!DeepLinkableDeviceStockStatuses.includes(stockStatusResponse.stockStatus)) {
    throw new Error('Device is non-orderable');
  }

  return {
    catalogCode,
    childProducts: [],
    itemType: CartItemType.DEVICE,
    matrixRowKey: config.MatrixRowKey,
    productName: config.ProductName,
    packageId: '',
    priceInfo: {
      recurringCharge: config.FinalMRC ?? config.MRC,
      originalRecurringCharge: config.MRC,
      discount: config.Discount ?? 0,
      adjustedMRCAmount: isPrepaid ? undefined : discountedPrice,
      adjustedNRCAmount: isPrepaid ? discountedPrice : undefined,
    },
    productSubType: productSubType || CartProductSubType.HANDSET,
    productType: CartProductType.DEVICE,
    productCode: deviceDetails.id,
    productConfig: {
      capacity: query[QueryKey.DEVICE_CAPACITY] as string,
      color: query[QueryKey.DEVICE_COLOR] as string,
      contractTerm: query[QueryKey.DEVICE_CONTRACT_TERM] as string,
      deviceSku: config.SKU,
      orderType: 'Connect',
    },
    simTypeCompatibility: deviceDetails.simTypeCompatibility,
    manufacturer: deviceDetails.manufacturer,
  };
};
export const buildWearableFromQuery = async ({
  catalogCode,
  deviceConfig,
  deviceDetails,
  promotions,
  productSubType,
  query,
}: BuildWearableCartItemFromQueryParams): Promise<WearableDeviceBasketRequestItem> => {
  if (deviceDetails.announcementPhase) {
    throw new Error('Smart Watch in announcement phase');
  }
  const color = (query[QueryKey.DEVICE_COLOR] as string) ?? deviceDetails.defaultColor;
  const contractTerm = (query[QueryKey.DEVICE_CONTRACT_TERM] as string) ?? deviceDetails.defaultContractTerm;
  const caseSize = (query[QueryKey.DEVICE_CASE_SIZE] as string) ?? deviceDetails.defaultCaseSize;
  const bandName = (query[QueryKey.DEVICE_BAND_NAME] as string) ?? deviceDetails.defaultBandName;
  const bandColor = (query[QueryKey.DEVICE_BAND_COLOR] as string) ?? deviceDetails.defaultBandColor;
  const bandSize = (query[QueryKey.DEVICE_BAND_SIZE] as string) ?? deviceDetails.defaultBandSize;
  const config = deviceConfig[color]?.[caseSize]?.[bandName]?.[bandColor]?.[bandSize].find(
    (entry) =>
      entry.ContractTerm.toLowerCase() === `${contractTerm} Months`.toLowerCase() &&
      entry.OrderType.toLowerCase() === 'connect',
  );
  const totalAdjustedValue = getTotalAdjustedValueFromPromotions(promotions);

  if (!config) {
    throw new Error('Device config not found');
  }

  const discountedPrice = totalAdjustedValue ? config.MRC - totalAdjustedValue : undefined;

  const stockStatusResponse = await getApiClient().fetchDeviceStockStatus({ deviceSku: config.SKU });
  if (!DeepLinkableDeviceStockStatuses.includes(stockStatusResponse.stockStatus)) {
    throw new Error('Device is non-orderable');
  }

  return {
    catalogCode,
    childProducts: [],
    itemType: CartItemType.SMARTWATCH,
    matrixRowKey: config.MatrixRowKey,
    productName: config.ProductName,
    packageId: '',
    priceInfo: {
      recurringCharge: config.FinalMRC ?? config.MRC,
      originalRecurringCharge: config.MRC,
      discount: config.Discount ?? 0,
      adjustedMRCAmount: discountedPrice,
      adjustedNRCAmount: discountedPrice,
    },
    productSubType: productSubType || CartProductSubType.WEARABLES,
    productType: CartProductType.DEVICE,
    productCode: deviceDetails.id,
    productConfig: {
      caseSize: query[QueryKey.DEVICE_CASE_SIZE] as string,
      bandSize: query[QueryKey.DEVICE_BAND_SIZE] as string,
      bandColor: query[QueryKey.DEVICE_BAND_COLOR] as string,
      bandName: query[QueryKey.DEVICE_BAND_NAME] as string,
      color: query[QueryKey.DEVICE_COLOR] as string,
      contractTerm: query[QueryKey.DEVICE_CONTRACT_TERM] as string,
      deviceSku: config.SKU,
      orderType: 'Connect',
    },
    simTypeCompatibility: deviceDetails.simTypeCompatibility,
    manufacturer: deviceDetails.manufacturer,
  };
};
export const buildModemFromQuery = async ({
  catalogCode,
  deviceConfig,
  deviceDetails,
  promotions,
  productSubType,
  query,
}: BuildModemCartItemFromQueryParams): Promise<ModemBasketRequestItem> => {
  if (deviceDetails.announcementPhase) {
    throw new Error('Modem in announcement phase');
  }

  const isPrepaid = PrepaidCatalogCodes.includes(catalogCode);
  const color = (query[QueryKey.DEVICE_COLOR] as string) ?? deviceDetails.defaultColor;
  const contractTerm = (query[QueryKey.DEVICE_CONTRACT_TERM] as string) ?? deviceDetails.defaultContractTerm;
  const config = deviceConfig[color]?.find(
    (entry) =>
      entry.ContractTerm.toLowerCase() === `${contractTerm} Months`.toLowerCase() && entry.OrderType === 'Connect',
  );

  const totalAdjustedValue = getTotalAdjustedValueFromPromotions(promotions);

  if (!config) {
    throw new Error('Device config not found');
  }

  const discountedPrice = totalAdjustedValue ? config.MRC - totalAdjustedValue : undefined;

  const stockStatusResponse = await getApiClient().fetchDeviceStockStatus({ deviceSku: config.SKU });
  if (!DeepLinkableDeviceStockStatuses.includes(stockStatusResponse.stockStatus)) {
    throw new Error('Device is non-orderable');
  }

  return {
    catalogCode,
    childProducts: [],
    itemType: CartItemType.MODEM,
    matrixRowKey: config.MatrixRowKey,
    productName: config.ProductName,
    packageId: '',
    priceInfo: {
      recurringCharge: config.FinalMRC ?? config.MRC,
      originalRecurringCharge: config.MRC,
      discount: config.Discount ?? 0,
      adjustedMRCAmount: isPrepaid ? undefined : discountedPrice,
      adjustedNRCAmount: isPrepaid ? discountedPrice : undefined,
    },
    productSubType: productSubType || CartProductSubType.HANDSET,
    productType: CartProductType.DEVICE,
    productCode: deviceDetails.id,
    productConfig: {
      color: query[QueryKey.DEVICE_COLOR] as string,
      contractTerm: query[QueryKey.DEVICE_CONTRACT_TERM] as string,
      deviceSku: config.SKU,
      orderType: 'Connect',
    },
    simTypeCompatibility: deviceDetails.simTypeCompatibility,
    manufacturer: deviceDetails.manufacturer,
  };
};
export const buildStrippedPlanFromQuery = ({
  catalogCode,
  query,
  defaultChildProduct = null,
}: BuildCartItemFromQueryParams): StrippedBasketRequestItem => {
  const productCode = query[QueryKey.PLAN] as string;

  return {
    catalogCode,
    childProducts: defaultChildProduct ? [defaultChildProduct] : [],
    packageId: '',
    productCode,
  };
};

export const buildPlanFromQuery = (
  { catalogCode, plans, query }: BuildPlanCartItemFromQueryParams,
  bnsPlans?: BnsPlan[],
): PlanBasketRequestItem => {
  const productCode = query[QueryKey.PLAN] as string;
  const plan = plans.find(({ planId }) => planId === productCode);

  if (!plan) {
    throw new Error('Plan not found');
  }

  const planRequestItem: PlanBasketRequestItem = {
    catalogCode,
    childProducts: [],
    itemType: CartItemType.PLAN,
    packageId: '',
    hideWasLabel: plan.hideWasLabel ?? false,
    priceInfo: {
      recurringCharge: plan.recurringCharge,
      adjustedMRCAmount: plan.discountedOneTimeCharge ?? plan.discountedRecurringCharge,
    },
    productCode,
    productConfig: {
      contractTerm: String(plan.contractTerm ?? '1'),
    },
    productName: plan.planName,
    productType: CartProductType.PLAN_VOICE,
    relatedContent: {
      planData: plan.includePromotionPlanData ?? plan.planData,
    },
  };

  if (bnsPlans) {
    const priceInfo = getDiscountedPriceInfo({ bnsPlans, plan, catalogCode });
    return planWithSim({ ...planRequestItem, priceInfo }, SimProductCode.PSIM);
  }

  return planWithSim(
    planRequestItem,
    // Default to pSIM
    SimProductCode.PSIM,
  );
};

export const mapPlanTypeToCatalogCode = (planType: PlanEndpoint): CatalogCode | undefined => {
  switch (planType) {
    case PlanEndpoint.POSTPAID:
      return CatalogCode.POSTPAID_HANDSET_PLANS;
    case PlanEndpoint.POSTPAID_SIMO:
      return CatalogCode.POSTPAID_SIMO_PLANS;
    case PlanEndpoint.PREPAID_COMBO_PLUS:
      return CatalogCode.PREPAID_COMBO_PLUS_PLANS;
    case PlanEndpoint.PREPAID_PAY_AND_GO:
      return CatalogCode.PREPAID_PAY_AND_GO_PLANS;
    case PlanEndpoint.TABLET:
      return CatalogCode.POSTPAID_TABLET_PLANS;
    case PlanEndpoint.TABLET_SIMO:
      return CatalogCode.POSTPAID_TABLET_SIMO_PLANS;
    case PlanEndpoint.POSTPAID_MBB_MODEM:
      return CatalogCode.POSTPAID_MBB_MODEM_PLANS;
    case PlanEndpoint.POSTPAID_MBB_MODEM_SIMO:
      return CatalogCode.POSTPAID_MBB_MODEM_SIMO_PLANS;
    default:
      return undefined;
  }
};

export const encodeQueryStringId = (source: string) =>
  encodeURIComponent(
    source
      .replace(/[^a-z0-9\s-]/gi, '')
      .trim()
      .replace(/\s+/g, '-')
      .toLowerCase(),
  );

export const isQueryFirstStep = (query: ParsedQuery) => {
  const stepString = (query[QueryKey.JOURNEY_STEP] ?? '0') as string;
  const stepNumber = Number(stepString);
  return Number.isNaN(stepNumber) || stepNumber === 0;
};

export const getProductSubTypeFromPath = (pathname: string) => {
  switch (pathname) {
    case '/mobile/mobile-phones':
    case '/plans':
      return ProductSubType.HANDSET;
    case '/mobile/tablets':
      return ProductSubType.TABLET;
    case '/smart-watches':
      return ProductSubType.WEARABLES;
    default:
      return undefined;
  }
};
