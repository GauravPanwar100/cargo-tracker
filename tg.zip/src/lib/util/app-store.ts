import Cookie from 'universal-cookie';
import cuid from 'cuid';

class AppStore {
  public E2E_SESSION_ID = 'e2eSessionId';

  private e2eSessionId = '';

  private xInitialSystem = '';

  private xInitialComponent = '';

  getE2eSessionId() {
    if (typeof window !== 'undefined' && !this.e2eSessionId) {
      const cookies = new Cookie();
      // client side there should always be a cookie - this default is a just in case
      this.e2eSessionId = cookies.get(this.E2E_SESSION_ID) || cuid();
    }
    return this.e2eSessionId;
  }

  setE2eSessionId(e2eSessionId: string) {
    this.e2eSessionId = e2eSessionId;
  }

  getXInitialSystem() {
    return this.xInitialSystem;
  }

  setXInitialSystem(id: string) {
    this.xInitialSystem = id;
  }

  getXInitialComponent() {
    return this.xInitialComponent;
  }

  setXInitialComponent(id: string) {
    this.xInitialComponent = id;
  }
}

export default new AppStore();
