/**
 * formatAmount
 * 1234 => 1,234
 * 1234.5 => 1,234.50
 * 1234.55 => 1,234.55
 * (48.58 * 36) = 1748.8799999999999.toFixed(2) = 1,748.88
 */
export const formatPrice = (amount: string | number): string => {
  if (typeof amount === 'string') {
    return amount;
  }
  if (!amount) return '0';
  const formattedNumber = Number.isInteger(amount) ? amount.toFixed(0) : amount.toFixed(2);
  return formattedNumber.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
};

/**
 * formatEUDeviceRRPPrice
 * 1234 => 1234
 * 1234.5 => 1234.50
 * 1234.55 => 1234.55
 * (48.58 * 36) = 1748.8799999999999.toFixed(2) = 1748.88
 */
export const formatEUDeviceRRPPrice = (amount: string | number): string => {
  if (typeof amount === 'string') {
    return amount;
  }
  return Number.isInteger(amount) ? amount.toFixed(0) : amount.toFixed(2);
};

/**
 * formatAmount
 * 1234 => 1,234
 * 1234.5 => 1,234.50
 * 1234.55 => 1,234.55
 * (48.58 * 36) = 1748.8799999999999.toFixed(2) = 1,748.88
 */
export const formatStringPrice = (amount: string | number): string => {
  let rawPrice = amount;
  if (typeof amount === 'string') {
    const parsedPrice = parseFloat(amount ?? '');
    if (!Number.isNaN(parsedPrice)) {
      rawPrice = parsedPrice;
    }
  }
  return formatPrice(rawPrice);
};

/**
 * formatCurrency
 * 1234 => 1,234.00
 * 1234.5 => 1,234.50
 * 1234.55 => 1,234.55
 * (48.58 * 36) = 1748.8799999999999.toFixed(2) = 1,748.88
 */
export const formatCurrency = (amount: string | number): string => {
  if (typeof amount === 'string') {
    return amount;
  }
  const formattedNumber = (amount || 0).toFixed(2);
  return formattedNumber.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
};

export const formatCurrencyAbsolute = (amt: number): number => {
  return Math.abs(amt);
};
