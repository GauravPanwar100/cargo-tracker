import { FieldValidator } from 'final-form';

const VALID_CODE_REGEX = /^\d{6}$/;

export const validateOtp: FieldValidator<string> = (value) => {
  if (!VALID_CODE_REGEX.test(value)) {
    return 'The one-time code must be six digits. Please try again or get a new code.';
  }
  return undefined;
};

const NON_DIGIT_REGEX = /\D/g;
/**
 * Strips out all non-digit characters
 * @param value
 */
export const normaliseOtp = (value: string) => value.replaceAll(NON_DIGIT_REGEX, '');

/**
 * Prevents non-digit characters being typed, preserving cursor position as if the key had never
 * been pressed.
 * @param e
 */
export const onKeyPressPreventNonNumericKey: React.KeyboardEventHandler<HTMLInputElement> = (e) => {
  if (e.key.length === 1 && e.key.match(NON_DIGIT_REGEX)) {
    e.preventDefault();
  }
};
