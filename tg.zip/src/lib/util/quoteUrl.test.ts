import quoteUrl from '@src/lib/util/quoteUrl';

describe('quoteUrl', () => {
  it('should surround the provided URL in double quotes', () => {
    expect(
      quoteUrl(
        `data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' version='1.1' viewBox='0 0 24 24'%3e%3c/svg%3e`,
      ),
    ).toBe(
      `"data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' version='1.1' viewBox='0 0 24 24'%3e%3c/svg%3e"`,
    );
  });
});
