import { OmniCreditCheckCode, OmniEventMessage, OmniJourney, OmniServiceType } from '@src/lib/api/types';

export function showCheckoutSurvey(omniEvent: OmniEventMessage) {
  const allowedDecisionCodes: (OmniCreditCheckCode | undefined)[] = [
    OmniCreditCheckCode.APPROVED,
    OmniCreditCheckCode.CONDITIONALLY_APPROVED,
    OmniCreditCheckCode.REFER,
    OmniCreditCheckCode.WITHDRAWN,
    OmniCreditCheckCode.RTCC_OFF,
    OmniCreditCheckCode.RTCC_DOWNTIME,
  ];
  if (omniEvent['OmniScript-Messaging']?.orderId) {
    const { serviceType, journey, creditCheckDecisionCode } = omniEvent['OmniScript-Messaging'];
    switch (serviceType) {
      case OmniServiceType.UPGRADE:
        return true;
      case OmniServiceType.NEW:
        if (journey === OmniJourney.PREPAID) {
          return true;
        }
        if (allowedDecisionCodes.includes(creditCheckDecisionCode)) {
          return true;
        }
        break;
      case OmniServiceType.ADDITIONAL_SERVICES:
        if (allowedDecisionCodes.includes(creditCheckDecisionCode)) {
          return true;
        }
        break;
      default:
        return false;
    }
  }
  return false;
}
