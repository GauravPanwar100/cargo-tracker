import { BasketPackage } from '@src/lib/api/types';

export const filterFixedBundle = (packages: BasketPackage[] | undefined) => {
  if (!packages) return false;
  const homeFixed = packages.filter(({ items }) => {
    const arr = items.filter(({ productType }) => {
      return productType === 'Plan - Fixed' || productType === 'Plan - Voice';
    });
    return arr.length >= 1;
  });

  return homeFixed.length >= 2;
};
