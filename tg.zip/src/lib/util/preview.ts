import { ParsedUrlQuery } from 'querystring';

/**
 * Preview mode allows the user to pass in a custom date, in order to view devices, pages, plans and other products
 * that have been configured to start selling at a future time.
 */

export const preview = process.env.PREVIEW === 'true';

export function previewGetOptionalDate(query: ParsedUrlQuery): string | undefined {
  // function scope reading of environment variable is required for testing
  if (process.env.PREVIEW === 'true') {
    return query?.date?.toString();
  }
  return undefined;
}
