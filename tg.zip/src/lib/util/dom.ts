/**
 * Enum containing `KeyboardEvent#key` values
 * @see https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key/Key_Values
 */
export enum KeyboardEventKeyValue {
  ARROW_DOWN = 'ArrowDown',
  ARROW_LEFT = 'ArrowLeft',
  ARROW_RIGHT = 'ArrowRight',
  ARROW_UP = 'ArrowUp',
  BACKSPACE = 'Backspace',
  DELETE = 'Delete',
  END = 'End',
  ENTER = 'Enter',
  ESCAPE = 'Escape',
  HOME = 'Home',
  SPACE = ' ',
  TAB = 'Tab',
}

export const isElementInViewport = (element: HTMLElement) => {
  const rect = element.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
};

export const scrollElementIntoView = (element: HTMLElement | null, offsetTop = 0) => {
  if (!element) return;

  window.scrollTo({
    behavior: 'smooth',
    left: 0,
    top: element.getBoundingClientRect().top + window.pageYOffset + offsetTop,
  });
};

export const scrollElementIntoViewThenFocusInput = (
  element: HTMLElement | null,
  inputElement: HTMLInputElement | null,
) => {
  if (!element) return;

  setTimeout(() => scrollElementIntoView(element), 100);

  const focusInputWhenInView = () => {
    if (inputElement && isElementInViewport(element)) {
      inputElement.focus();
      window.removeEventListener('scroll', focusInputWhenInView);
    }
  };

  // Attach the listener, when it runs the focus it will remove itself from the window
  window.addEventListener('scroll', focusInputWhenInView);
};

/**
 * Returns whether a click event was a "normal" click.
 * Certain keys and buttons trigger links to open in a new tab/window
 * @param e
 */
export const isNormalClick = (e: React.MouseEvent | MouseEvent) =>
  !(e.ctrlKey || e.shiftKey || e.metaKey || e.button === 1);

export const isAnchorSameTarget = (el: HTMLAnchorElement) => el.target !== '_blank';
