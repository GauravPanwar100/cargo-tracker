const NON_DIGIT_REGEX = /\D/g;
/**
 * Strips out all non-digit characters
 * @param value
 */
export const normalisePin = (value: string) => value.replaceAll(NON_DIGIT_REGEX, '');

/**
 * Prevents non-digit characters being typed, preserving cursor position as if the key had never
 * been pressed.
 * @param e
 */
export const onKeyPressPreventNonNumericKey: React.KeyboardEventHandler<HTMLInputElement> = (e) => {
  if (e.key.length === 1 && e.key.match(NON_DIGIT_REGEX)) {
    e.preventDefault();
  }
};

/**
 * Prevents any copy or paste action.
 * @param e
 */
export const preventCopyPaste = (e: { preventDefault: () => void }) => {
  e.preventDefault();
  return false;
};
