import { formatCurrency, formatCurrencyAbsolute } from '@src/lib/util/number-formatter';
import { BasketItem, HomeWirelessPlan, PostpaidPlan, PromoSubtype, Promotion } from '@src/lib/api/types';
import { ConsolidatedNbnPlan } from '@src/lib/util/nbn';

export function filterAndReorderOffers({
  planHeroOfferId,
  deviceHeroOfferId,
  promotions,
}: {
  planHeroOfferId?: string;
  deviceHeroOfferId?: string;
  promotions: Promotion[];
}) {
  promotions.splice(0, promotions.length, ...promotions.filter((promo) => !isPromoExpired(promo.endDate)));
  const bnsPromotionId = findBundleAndSavePromotionId(promotions);

  // Order of below matters
  if (planHeroOfferId) {
    // Plan hero offer is third
    rearrangeOfferToFirst({ offerId: planHeroOfferId, promotions });
  }
  if (deviceHeroOfferId) {
    // Device hero offer is second
    rearrangeOfferToFirst({ offerId: deviceHeroOfferId, promotions });
  }
  if (bnsPromotionId) {
    // Bundle and save offer is first
    rearrangeOfferToFirst({ offerId: bnsPromotionId, promotions });
  }
}

function findBundleAndSavePromotionId(promotions: Promotion[]): undefined | string {
  const bnsPromo = promotions.find(
    (promotion) => promotion.promotionCode.includes('BUNDLE_AND_SAVE'), // TODO remove once https://vodafoneaus.atlassian.net/browse/VFE-2111 is implemented post-MVP.
  );
  return bnsPromo?.promotionCode;
}

function rearrangeOfferToFirst({ offerId, promotions }: { offerId?: string; promotions: Promotion[] }) {
  let index = 0;
  if (offerId) {
    index = promotions.findIndex((promotion) => promotion.promotionCode === offerId);
  }

  if (index > 0) {
    const heroOffer = promotions[index];
    promotions.splice(index, 1);
    promotions.unshift(heroOffer);
  }
}

function isPromoExpired(endDate: string | undefined): boolean {
  return endDate ? new Date() > new Date(endDate) : false;
}
export const checkOnlineBtlPromoInBasketItem = (basketItem: BasketItem) => {
  const { promotions } = basketItem;
  if (!promotions) return false;
  return promotions.some((promo) => promo.subType === PromoSubtype.OnlineBTL);
};

export const getNrcPriceAdjustment = (basketItem: BasketItem) => {
  const { priceInfo } = basketItem;
  return formatCurrencyAbsolute(priceInfo.nrcPriceAdjustment);
};
export const getNrcPercentAdjustment = (basketItem: BasketItem) => {
  const { priceInfo } = basketItem;
  return (formatCurrencyAbsolute(priceInfo.nrcPercentDiscount) / 100) * priceInfo.recurringCharge;
};
export const getDeviceDiscount = (basketItem: BasketItem) => {
  const { priceInfo } = basketItem;
  return priceInfo.Discount ? formatCurrency(priceInfo.Discount) : 0;
};

export const getPromoSubheading = (basketItem: BasketItem) => {
  const { relatedContent } = basketItem;
  return relatedContent?.subHeadingSecondary;
};

// check if there's a promotion with a subtype == OnlineBTL
export const checkOnlineBtlPromotion = (promotions: Promotion[]) => {
  if (!Array.isArray(promotions)) return false;
  return promotions.some((promo) => promo.subType === PromoSubtype.OnlineBTL);
};

export const hasAnyOnlineBtlPromotion = (
  plans: PostpaidPlan[] | ConsolidatedNbnPlan[] | HomeWirelessPlan[],
): boolean => {
  // Filter all plans having subType OnlineBTL promotion and return boolean
  return plans.some((plan) => checkOnlineBtlPromotion(plan.promotions));
};
// Sort promotions by subType. If subType available, it will be the first element.
export const reOrderPromotionsBasedOnSubType = (promotions: Promotion[]): Promotion[] => {
  return promotions.sort((promo) => {
    return promo?.subType ? -1 : 0;
  });
};
// Get OnlineBTL Promo Adjustment value
export const getOnlinePromotionAdjustmentValue = (basketItem: BasketItem): number => {
  // find promotion having subType as OnlineBTL
  const onlinePromotion =
    basketItem && basketItem.promotions
      ? basketItem.promotions.find((promo) => promo.subType === PromoSubtype.OnlineBTL)
      : undefined;
  return onlinePromotion && onlinePromotion?.adjustmentValue ? onlinePromotion?.adjustmentValue : 0;
};
