import { StyledProps, css, keyframes } from 'styled-components';
import { BreakpointKey, ColorKey, FontKey, FontSizeKey, LineHeightKey, breakpoints, sizes } from '@src/lib/theme';

export const fontLineHeightSize = (key: FontSizeKey) => css`
  font-size: ${(p) => p.theme.fontSizes[key]}px;
  line-height: ${(p) => p.theme.lineHeights[key]}px;
`;

export const variantThemeColors = css`
  color: ${(p) => p.theme.variants.mainColor};
  background-color: ${(p) => p.theme.variants.backgroundColor};
`;

export const variantThemeFeaturedLinkColors = css`
  a {
    color: ${(p) => p.theme.variants.featuredLinkColor};
  }
`;

export const focusOutline = (withOffset = true) => css`
  outline: 3px solid ${(p) => p.theme.colors.focusColor};
  ${withOffset &&
  css`
    outline-offset: -3px;
  `}
`;

export const focusBoxShadow = css`
  outline: none;
  box-shadow: 0px 0px 0px 3px ${(p) => p.theme.colors.focusColor};
`;

export const focusPseudoElement = css`
  outline: none;

  &:before {
    content: '';
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border: 3px solid ${(p) => p.theme.colors.focusColor};
    border-radius: ${(p) => p.theme.sizes.borderRadius}px;
    transition: border-radius ${(p) => p.theme.durations.transition} ease-out;
  }
`;

export const variantThemeLinkColorsBare = css`
  &,
  &:visited,
  &:focus {
    color: ${(p) => p.theme.variants.linkColor};
    transition: color 200ms;
  }

  &:hover,
  &:active {
    color: ${(p) => p.theme.variants.hoverColor};
  }

  &:focus {
    ${focusOutline(false)}
  }
`;

export const variantThemeLinkColors = css`
  a {
    ${variantThemeLinkColorsBare}
  }
`;

interface AccordionTitleFocusProps {
  disableFocusBorderRadius?: boolean;
  isFirstItem?: boolean;
  isLastItem?: boolean;
  isOpen?: boolean;
}
export const accordionTitleFocus = css<AccordionTitleFocusProps>`
  ${focusPseudoElement}

  &:before {
    border-radius: 0;

    ${(p) =>
      !p.disableFocusBorderRadius &&
      p.isFirstItem &&
      css`
        border-top-left-radius: ${p.theme.sizes.borderRadius}px;
        border-top-right-radius: ${p.theme.sizes.borderRadius}px;
      `}

    ${(p) =>
      !p.disableFocusBorderRadius &&
      p.isLastItem &&
      !p.isOpen &&
      css`
        border-bottom-left-radius: ${p.theme.sizes.borderRadius}px;
        border-bottom-right-radius: ${p.theme.sizes.borderRadius}px;
      `}
  }
`;

export const accordionFooterFocus = css`
  ${focusPseudoElement}

  &:before {
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
`;

export const rotate = keyframes`
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
`;

/**
 * Includes styles for listing cards
 *
 * @returns {CSSResult}
 */
export const cardFoundation = css`
  position: relative;
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  width: 100%;
  color: ${(p) => p.theme.colors.mainColor};
  background: ${(p) => p.theme.colors.white};
  box-shadow: ${(p) => p.theme.boxShadows.brand};
  border-radius: ${sizes.borderRadius}px;
  ${fontLineHeightSize('base')};
  font-family: ${(p) => p.theme.fonts.regular};
  text-decoration: none;
`;

export const listingCardFoundation = css`
  ${cardFoundation}
  cursor: pointer;

  &:focus {
    ${focusBoxShadow};
  }
`;

export const buttonReset = css`
  border: none;
  margin: 0;
  padding: 0;
  width: auto;
  background: transparent;
  color: inherit;
  font: inherit;
  line-height: normal;
  appearance: none;

  &:focus {
    ${focusOutline(false)}
  }
`;

export const listReset = css`
  list-style: none;
  margin: 0;
  padding: 0;
`;

/**
 * Exports an object who's keys match the keys of the breakpoints theme object
 * The value is a CSS function that wraps whatever CSS you pass inside a media
 * query matching the key.
 *
 * e.g. inside a styled component definition:
 * ${media.m`
 *    font-size: 12px;
 * `}
 */
type CSSParams = Parameters<typeof css>;
type CSSResult = ReturnType<typeof css>;

const breakpointKeys = Object.keys(breakpoints) as BreakpointKey[];

const from = Object.fromEntries(
  Object.entries(breakpoints).map(([key, breakpoint]) => [
    key,
    ((...params: CSSParams) => css`
      @media (min-width: ${breakpoint}px) {
        ${css(...params)}
      }
    `) as typeof css,
  ]),
) as Record<BreakpointKey, typeof css>;

const upTo = Object.fromEntries(
  Object.entries(breakpoints).map(([key, breakpoint]) => [
    key,
    ((...params: CSSParams) => css`
      @media (max-width: ${breakpoint - 0.01}px) {
        ${css(...params)}
      }
    `) as typeof css,
  ]),
) as Record<BreakpointKey, typeof css>;

export const media = {
  ...from,
  from,
  upTo,
  prefersReducedMotion: ((...params: CSSParams) => css`
    @media (prefers-reduced-motion: reduce) {
      ${css(...params)}
    }
  `) as typeof css,
};

export const maxMedia = breakpointKeys.reduce((acc, breakpoint) => {
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  acc[breakpoint] = (...params: CSSParams) => css`
    @media (max-width: ${breakpoints[breakpoint]}px) {
      ${css(...params)}
    }
  `;
  return acc;
}, {} as Record<BreakpointKey, typeof css>);

export interface AccordionIndicatorProps {
  isOpen?: boolean;
  hideIndicator?: boolean;
  upliftEnabled?: boolean;
}
export const accordionIndicator = (p: StyledProps<AccordionIndicatorProps>) => css`
  position: relative;

  &:after {
    display: block;
    content: '';
    width: 24px;
    height: 24px;
    position: absolute;
    right: 20px;
    top: 50%;
    transform: translateY(-50%);
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 16 16' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath fill='none' d='M0 0h16v16H0z'/%3E%3Cpath stroke='${encodeURIComponent(
      p.theme.variants.accordionIndicatorColor,
    )}' stroke-linecap='round' stroke-linejoin='round' d='M13.667 5.667L8 11.333 2.333 5.667'/%3E%3C/g%3E%3C/svg%3E%0A");
    background-repeat: no-repeat;
    background-position: right center;
    background-size: contain;

    ${media.m`
      width: 32px;
      height: 32px;
      background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath fill='none' d='M0 0h24v24H0z'/%3E%3Cpath stroke='${encodeURIComponent(
        p.theme.variants.accordionIndicatorColor,
      )}' stroke-linecap='round' stroke-linejoin='round' d='M20.5 8.5L12 17 3.5 8.5'/%3E%3C/g%3E%3C/svg%3E%0A");
    `}

    > * {
      pointer-events: none;
    }

    ${p.isOpen &&
    css`
      transform: translateY(-50%) rotate(180deg);
    `}

    ${p.hideIndicator &&
    css`
      display: none;
    `}
  }
`;

export function unitlessToPx(value?: string | number): string | undefined {
  return typeof value === 'number' ? `${value}px` : value;
}

/**
 * Types and functions below are for the Responsive Mixin function
 */

// Your average CSS property value i.e. 'block', '2px', 2
export type CSSProperty = string | number | Array<string | number> | null | undefined;
// MixinProperty can be the property itself, or an object keyed by BreakpointKey with property
// values
export type MixinProperty<P = CSSProperty> = P | ResponsiveProperty<P> | null;

// Object with keys that match the keys of the Breakpoint theme object, and values that match
// a particular type
type ResponsiveProperty<P> = {
  [key in BreakpointKey]?: P | null;
};

type CSSFormatter<P> = (propValue: P) => CSSResult;

/**
 * Creates a mixin that allows you to pass a CSS value as a plain value, or as an object with
 * keys matching the different media breakpoints. This allows you to control a component across
 * screen sizes with a simple prop. See @src/components/Grid/GridCol.tsx for an example
 *
 * @param formatter A formatter for the rendered value, should return a CSSResult
 */
export const createResponsiveMixin = <P = CSSProperty>(formatter: CSSFormatter<P>) =>
  function renderStyle(propValue?: MixinProperty<P>): null | CSSResult {
    // If nothing is provided for this property, return nothing
    if (typeof propValue === 'undefined' || propValue === null) {
      return null;
    }

    // If the property value is a primitive value like a string or a number, then use the provided
    // formatter to actually render the CSS/style.
    if (typeof propValue !== 'object' || propValue instanceof Array) {
      return formatter(propValue as P);
    }

    // In this case, the property provided is an object keyed with breakpoints. We loop through
    // each breakpoint, and render it inside a media query. If the breakpoint key is the smallest
    // value -- xs -- then don't render it inside a media query so that all possible small screen
    // sizes will also receive the styles (xs is defined as 340px, we still want the styles to
    // take effect for anything by chance smaller than that).
    const responsivePropValue = propValue as ResponsiveProperty<P>;
    const keys = Object.keys(responsivePropValue) as BreakpointKey[];

    return keys.reduce((acc: CSSResult, breakpoint: BreakpointKey) => {
      const valueForBreakpoint = responsivePropValue[breakpoint];
      return css`
        ${acc}
        ${breakpoint === 'xs'
          ? renderStyle(valueForBreakpoint)
          : media[breakpoint]`
          ${renderStyle(valueForBreakpoint)}
        `}
      `;
    }, css``);
  };

export const createIdentityPropertyResponsiveMixin = (propName: string) =>
  createResponsiveMixin<CSSProperty>(
    (propValue) => css`
      ${propName}: ${propValue};
    `,
  );

export const colorMixin = createResponsiveMixin<ColorKey>(
  (propValue) =>
    css`
      ${(p) => `color: ${p.theme.colors[propValue]};`}
    `,
);
export const fontSizeMixin = createResponsiveMixin<FontSizeKey>(
  (propValue) =>
    css`
      ${(p) => `font-size: ${p.theme.fontSizes[propValue]}px;`}
    `,
);
export const lineHeightMixin = createResponsiveMixin<LineHeightKey>(
  (propValue) =>
    css`
      ${(p) => `line-height: ${p.theme.lineHeights[propValue]}px;`}
    `,
);
export const fontFamilyMixin = createResponsiveMixin<FontKey>(
  (propValue) =>
    css`
      ${(p) => `font-family: ${p.theme.fonts[propValue]};`}
    `,
);
export const backgroundColorMixin = createResponsiveMixin<ColorKey>(
  (colourCode) =>
    css`
      ${(p) => `background-color: ${p.theme.colors[colourCode]};`}
    `,
);
export const fontSizeLineHeightMixin = createResponsiveMixin<FontSizeKey | [FontSizeKey, FontSizeKey]>((propValue) => {
  const [fontKey, heightKey] = propValue instanceof Array ? propValue : [propValue, propValue];
  return css`
    ${(p) => `font-size: ${p.theme.fontSizes[fontKey]}px;`}
    ${(p) => `line-height: ${p.theme.lineHeights[heightKey]}px;`}
  `;
});
export const marginTopMixin = createIdentityPropertyResponsiveMixin('margin-top');
export const marginBottomMixin = createIdentityPropertyResponsiveMixin('margin-bottom');
export const marginLeftMixin = createIdentityPropertyResponsiveMixin('margin-left');
export const marginRightMixin = createIdentityPropertyResponsiveMixin('margin-right');
export const heightMixin = createIdentityPropertyResponsiveMixin('height');
export const widthMixin = createIdentityPropertyResponsiveMixin('width');
export const maxWidthMixin = createIdentityPropertyResponsiveMixin('max-width');
export const borderRadiusMixin = createIdentityPropertyResponsiveMixin('border-radius');
export const displayMixin = createIdentityPropertyResponsiveMixin('display');
export const textAlignMixin = createIdentityPropertyResponsiveMixin('text-align');
export const rowGapMixin = createIdentityPropertyResponsiveMixin('row-gap');
export const columnGapMixin = createIdentityPropertyResponsiveMixin('column-gap');
export const topMixin = createIdentityPropertyResponsiveMixin('top');
export const leftMixin = createIdentityPropertyResponsiveMixin('left');
export const bottomMixin = createIdentityPropertyResponsiveMixin('bottom');
export const rightMixin = createIdentityPropertyResponsiveMixin('right');
export const objectFitMixin = createIdentityPropertyResponsiveMixin('object-fit');
export const objectPositionMixin = createIdentityPropertyResponsiveMixin('object-position');
export const backgroundPositionMixin = createIdentityPropertyResponsiveMixin('background-position');
export const boxShadowMixin = createIdentityPropertyResponsiveMixin('box-shadow');
export const paddingTopMixin = createIdentityPropertyResponsiveMixin('padding-top');
export const paddingLeftMixin = createIdentityPropertyResponsiveMixin('padding-left');
export const paddingRightMixin = createIdentityPropertyResponsiveMixin('padding-right');
export const paddingBottomMixin = createIdentityPropertyResponsiveMixin('padding-bottom');
export const justifyContentMixin = createIdentityPropertyResponsiveMixin('justify-content');
export const alignItemsMixin = createIdentityPropertyResponsiveMixin('align-items');
export const flexDirectionMixin = createIdentityPropertyResponsiveMixin('flex-direction');
export const positionMixin = createIdentityPropertyResponsiveMixin('position');
export const paddingMixin = createIdentityPropertyResponsiveMixin('padding');
export const marginMixin = createIdentityPropertyResponsiveMixin('margin');

export interface DisplayMixinProps {
  display: MixinProperty;
}
