// Util file for price related utilities

import {
  CatalogCode,
  ContentReOrderingPosition,
  HomeWirelessPlan,
  NbnPlan,
  PageContentSections,
} from '@src/lib/api/types';

export const getHomeInternetPlanPriceInfo = (plan: NbnPlan | HomeWirelessPlan) => ({
  planName: plan.planName,
  planRecurringCharge: plan.recurringCharge,
  planDiscountedRecurringCharge: plan?.discountedRecurringCharge,
});

export const isReOrderingContent = (catalogCode: CatalogCode, applyOn: PageContentSections) => {
  const approvedPageCatalogCodesForReordering = [
    CatalogCode.POSTPAID_SIMO_PLANS,
    CatalogCode.POSTPAID_SIMO_TPG_SM,
    CatalogCode.POSTPAID_HANDSET_PLANS,
  ];
  const applyOnPositionRespectToCatalogCodes: ContentReOrderingPosition[] = [
    {
      catalogCode: CatalogCode.POSTPAID_SIMO_PLANS,
      approvedPositions: [
        PageContentSections.DEFAULT_DESC,
        PageContentSections.PLAN,
        PageContentSections.TITLE_DESC,
        PageContentSections.USPS,
      ],
    },
    {
      catalogCode: CatalogCode.POSTPAID_SIMO_TPG_SM,
      approvedPositions: [
        PageContentSections.DEFAULT_DESC,
        PageContentSections.PLAN,
        PageContentSections.TITLE_DESC,
        PageContentSections.USPS,
      ],
    },
    {
      catalogCode: CatalogCode.POSTPAID_HANDSET_PLANS,
      approvedPositions: [
        PageContentSections.DEFAULT_DESC,
        PageContentSections.PLAN,
        PageContentSections.TITLE_DESC,
        PageContentSections.USPS,
        PageContentSections.BREADCRUMB,
      ],
    },
  ];

  if (approvedPageCatalogCodesForReordering.includes(catalogCode)) {
    const approvedPositionObj = applyOnPositionRespectToCatalogCodes.find(
      (applyOnPosiotionRespectToCatalogCode) => applyOnPosiotionRespectToCatalogCode.catalogCode === catalogCode,
    );
    return approvedPositionObj?.approvedPositions.includes(applyOn);
  }
  return false;
};
