import {
  CatalogCode,
  OptimizeContentKey,
  PromoSubtype,
  PromotionalCampaignsBaseContent,
  PromotionalCampaignsContentResponse,
} from '@src/lib/api/types';
import { SessionStorageClient } from '@src/lib/storage';

export const getPromotionalCampaignByIdentifier = (
  identifier: string,
  promoCampaignsContents: PromotionalCampaignsBaseContent[],
): PromotionalCampaignsBaseContent | undefined => {
  return promoCampaignsContents?.find((promoCampaignsContent) => promoCampaignsContent.identifier === identifier);
};
export const getPromoHeroLabelByIdentifier = ({
  catalogCode,
  promoCampaignsContent,
}: {
  catalogCode: CatalogCode;
  promoCampaignsContent: PromotionalCampaignsContentResponse;
}) => {
  const promoCampaignContent = getPromotionalCampaignByIdentifier(
    catalogCode,
    promoCampaignsContent?.promotionalCampaigns,
  );
  return promoCampaignContent?.heroLabel;
};
export const storeOptimizeContent = ({
  catalogCode,
  promoCampaignsContent,
  promoAvailability,
  optimizeContentKey,
}: {
  catalogCode: CatalogCode;
  promoCampaignsContent: PromotionalCampaignsContentResponse;
  promoAvailability: boolean;
  optimizeContentKey: OptimizeContentKey;
}) => {
  const promoCampaignContent = getPromotionalCampaignByIdentifier(
    catalogCode,
    promoCampaignsContent?.promotionalCampaigns,
  );
  if (
    catalogCode === CatalogCode.POSTPAID_HANDSET_PLANS &&
    promoCampaignContent &&
    window.location.href.includes('step=1')
  ) {
    let newUrl = window.location.href;
    if (!newUrl.includes('extra=OnlineBTL')) {
      newUrl = `${newUrl}&extra=${PromoSubtype.OnlineBTL}`;
    }
    promoCampaignContent.ctaUrl = newUrl;
  }
  const optimizedContent = {
    ...promoCampaignContent,
    availability: promoAvailability,
  };
  SessionStorageClient.setOptimizeContent(optimizeContentKey, optimizedContent);
};

export const getOnlinePromoCartHeroLabel = (promoCampaignsContentResponse: PromotionalCampaignsContentResponse) => {
  const cartPromoCampaignContent = getPromotionalCampaignByIdentifier(
    CatalogCode.CART_PROMO_OFFER,
    promoCampaignsContentResponse?.promotionalCampaigns,
  );
  return cartPromoCampaignContent?.heroLabel ?? '';
};
