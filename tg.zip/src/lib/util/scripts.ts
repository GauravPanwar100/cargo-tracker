class ScriptsManager {
  /**
   * Map of script src -> Promise
   */
  private promises = new Map<string, Promise<Event>>();

  /**
   * Injects script `src` if not already injected and returns a Promise that resolves or rejects after the script loads.
   * Will retry if a previous load failed
   * @param src
   */
  public inject = async (src: string): Promise<void> => {
    const existing = this.promises.get(src);

    // If we've already injected a script
    if (existing) {
      try {
        // Try waiting for it to load and return when successful
        await existing;
        return;
      } catch (err) {
        // If the previous loading failed, delete the promise and continue as if the script was not already injected
        this.promises.delete(src);
      }
    }

    const promise = new Promise<Event>((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.async = true;
      script.defer = true;
      script.addEventListener('load', resolve);
      script.addEventListener('error', reject);

      document.head.appendChild(script);
    });
    this.promises.set(src, promise);

    // Wait for script to load
    await promise;
  };
}

const scripts = new ScriptsManager();
export default scripts;
