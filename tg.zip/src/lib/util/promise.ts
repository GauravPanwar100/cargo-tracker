import { SECOND, timeout } from '@kablamo/kerosene';
import { ExtendableError } from '@src/lib/util/error';

export class TimeoutError extends ExtendableError {}

/**
 * Returns a new Promise that resolves/rejects with the earlier of the result of `createPromise({ signal })` or a
 * rejection after a timeout for `duration` milliseconds
 *
 * @param createPromise Function that takes an AbortSignal and returns a Promise
 * @param [options]
 * @param [options.duration] Defaults to 10 seconds
 */
export async function promiseRaceTimeout<T>(
  createPromise: ({ signal }: { signal: AbortSignal }) => Promise<T>,
  { duration = 10 * SECOND }: { duration?: number } = {},
): Promise<T> {
  const controller = new AbortController();

  try {
    const result = await Promise.race([
      createPromise({ signal: controller.signal }),
      timeout(duration, { signal: controller.signal }).then(() => {
        throw new TimeoutError(`Promise timed out after ${duration}ms`);
      }),
    ]);

    return result;
  } finally {
    controller.abort();
  }
}
