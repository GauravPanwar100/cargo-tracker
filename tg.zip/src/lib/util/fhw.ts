import {
  BasketRequestItem,
  BasketRequestItemPriceInfo,
  CartItemType,
  CartProductSubType,
  CartProductType,
  CatalogCode,
  HomeInternetModemItem,
  HomeWirelessPlan,
  ModemChildBasketRequestItem,
} from '@src/lib/api/types';
import { HomeInternetDataMap, HomeInternetType } from '@src/templates/HomeWireless/HomeWireless.constants';
import { compact } from 'lodash';

export const constructFhwStickyCartItem = (
  plan: HomeWirelessPlan,
  withModem: boolean,
  discountedCost: number | null,
  displayPrice: number | null,
  planId: string,
  modemPriceInfo?: { recurringCharge: number; loyaltyMRCAmount: number; contractTerm: string },
  modemContent?: HomeInternetModemItem,
) => {
  const { catalogCode } =
    HomeInternetDataMap[
      plan?.homeInternetType || (plan.planName.indexOf('5G') >= 0 ? HomeInternetType.FHW_5G : HomeInternetType.FHW_4G)
    ];

  const childProduct: ModemChildBasketRequestItem | undefined =
    modemPriceInfo && modemContent && withModem
      ? {
          catalogCode: CatalogCode.NBN_MODEMS,
          itemType: CartItemType.MODEM,
          packageId: '',
          priceInfo: {
            recurringCharge: modemPriceInfo?.recurringCharge,
            adjustedMRCAmount: modemPriceInfo?.loyaltyMRCAmount,
          },
          productCode: modemContent.productId as string,
          productConfig: {
            contractTerm: modemPriceInfo.contractTerm,
          },
          productName: modemContent.productDisplayName,
          productType: CartProductType.DEVICE,
          productSubType: CartProductSubType.NBN_MODEM,
          relatedContent: {
            modemName: modemContent.productDisplayName,
          },
        }
      : undefined;
  const basketItems: BasketRequestItem[] = [
    {
      catalogCode,
      productCode: planId,
      childProducts: compact([childProduct]),
      itemType: CartItemType.PLAN,
      packageId: '',
      priceInfo: {
        recurringCharge: plan.recurringCharge,
        oneTimeCharge: plan.oneTimeCharge,
        adjustedMRCAmount: displayPrice,
        discountedCost,
      } as BasketRequestItemPriceInfo,
      productConfig: {
        contractTerm: String(plan.contractTerm),
      },
      productName: plan.planName,
      productType: CartProductType.PLAN_FIXED,
    },
  ];

  return basketItems;
};
