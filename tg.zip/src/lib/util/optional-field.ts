export const isNonEmptyOptional = (field: string | null | undefined): boolean => {
  if (!field) return false;
  return field.trim().length > 0;
};
