import { compact, includes, isEmpty, sumBy } from 'lodash';
import { getApiClient } from '@src/lib/api';

import {
  AddOnExtra,
  AddOnsContent,
  AddToBasketParams,
  AddonCartItem,
  Alert,
  BaseCartItem,
  Basket,
  BasketItem,
  BasketItemPriceInfo,
  BasketItemProductConfig,
  BasketPackage,
  BasketParams,
  BasketRequestItem,
  BasketResponse,
  CartItem,
  CartItemType,
  CartProductSubType,
  CartProductType,
  CatalogCode,
  CheckoutSplitterContent,
  CheckoutSplitterCtaStyle,
  ChildBasketRequestItem,
  CustomerServiceDetails,
  DataLimit,
  DeviceBasketItem,
  DeviceBasketRequestItem,
  Extra,
  ExtraCartItem,
  ExtraType,
  ExtrasContent,
  GetContentParams,
  ModemBasketItem,
  ModemBasketRequestItem,
  ModemChildBasketRequestItem,
  NbnPlanBasketItem,
  NbnPlanBasketRequestItem,
  OfferItem,
  PlanBasketItem,
  PlanBasketRequestItem,
  PostpaidCatalogCodes,
  PostpaidMobileSIMOCatalogCodes,
  PostpaidSimoCatalogCodes,
  PostpaidSimoPlanBasketItem,
  PostpaidSimoPlanBasketRequestItem,
  PrepaidCatalogCodes,
  PrepaidComboPlusPlanBasketItem,
  PrepaidComboPlusPlanBasketRequestItem,
  PrepaidPayAndGoPlanBasketItem,
  PrepaidPayAndGoPlanBasketRequestItem,
  Promotion,
  RafAction,
  RafEligibleCatalogCodes,
  RafRequestParams,
  ServiceItem,
  StrippedBasketRequestItem,
  SwapAndGoContent,
  WearableDeviceBasketRequestItem,
} from '@src/lib/api/types';
import { LocalStorageClient } from '@src/lib/storage';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { safeRouterPush } from '@src/lib/util/router';
import { formatCurrency } from '@src/lib/util/number-formatter';
import { SimTypeCompatibility } from '@src/lib/util/sim-selection';
import { Image } from '@src/lib/types';
import { Flag } from '@src/lib/context/feature-flags';
import { DataFetchState } from '@src/lib/hooks/data-fetch-reducer';
import { Address } from '@src/components/vfe/AddressChecker/AddressChecker.interfaces';
import { HomeInternetType } from '@src/templates/HomeWireless/HomeWireless.constants';
import { ButtonVariant } from '@src/components/core/Button/Button.styles';
import { CheckoutSplitterGroupId } from '@src/components/vfe/CartSplitter/constants';
import { getOnlinePromotionAdjustmentValue } from '@src/lib/util/promotions';
import { PlansRefreshCatalogs } from '@src/lib/constants/plans';
import { isPrepayMbbService, isPrepayVoiceService, isServiceOfType } from '@src/lib/util/customer';
import { User } from '@src/lib/context/authentication';
import { decoratePathWithQueries } from './url';
import { QueryKey } from './query';

export const isOfferPopulated = (offer: OfferItem) => !!offer.title && !!offer.description && !!offer.code; // This should happen on the BE

interface CalculateMinCostParams {
  contractTerm?: string;
  recurringCharge: number;
}

/**
 * accumulateRecurringCharge is used to calculate total recurringCharge for an array of basketItems
 */
export const accumulateRecurringCharge = (
  cartItems: (BasketItem | BasketRequestItem)[] | undefined,
  showASDPricing = false,
): number =>
  sumBy(cartItems, (item) => {
    const { loyaltyMRCAmount, adjustedMRCAmount, recurringCharge } = item.priceInfo as BasketItemPriceInfo;
    // Home internet can have ASD discounts which affects total
    if (isHomeInternetCartItem(item)) {
      // if home internet having extra param OnlineBTL promotion in subtype, apply adjustmentValue irrespective to any condition
      const onlinePromotionAdjustedValue = getOnlinePromotionAdjustmentValue(item as BasketItem);

      return showASDPricing
        ? loyaltyMRCAmount ?? adjustedMRCAmount // total discounted price when ASD applied
        : loyaltyMRCAmount ?? recurringCharge - onlinePromotionAdjustedValue; // calculate total without ASD discounts
    }
    // recurring or not discounted total charges
    return loyaltyMRCAmount ?? adjustedMRCAmount ?? recurringCharge;
  });

export const getDiscountedValue = (basketItems: BasketItem[] | []): number => {
  let totalAdjustmentvalue = 0;
  let discountedValue = 0;
  // eslint-disable-next-line no-unused-expressions
  !isEmpty(basketItems) &&
    // eslint-disable-next-line array-callback-return
    basketItems.map((basketItem) => {
      // eslint-disable-next-line no-unused-expressions
      !isEmpty(basketItem.promotions) &&
        // eslint-disable-next-line array-callback-return, @typescript-eslint/no-explicit-any
        basketItem.promotions?.map((promotion: any) => {
          if (promotion.isASD) {
            totalAdjustmentvalue += promotion.adjustmentValue;
          }
        });
      if (!isEmpty(basketItem.promotions)) {
        discountedValue = basketItem.priceInfo?.recurringCharge - totalAdjustmentvalue;
      }
    });
  return discountedValue;
};

export const getDetailedDiscountedValue = (basketItem: BasketItem): number => {
  let totalAdjustmentvalue = 0;
  let detailedDiscountedValue = 0;
  // eslint-disable-next-line array-callback-return, @typescript-eslint/no-explicit-any
  basketItem.promotions?.map((promotion: any) => {
    if (promotion.isASD) {
      totalAdjustmentvalue += promotion.adjustmentValue;
    }
  });
  if (!isEmpty(basketItem.promotions)) {
    detailedDiscountedValue = basketItem.priceInfo?.recurringCharge - totalAdjustmentvalue;
  }
  return detailedDiscountedValue;
};

export const accumulateOriginalRecurringCharge = (cartItems: (BasketItem | BasketRequestItem)[] | undefined): number =>
  sumBy(
    cartItems,
    (item) => (item as BasketRequestItem).priceInfo?.originalRecurringCharge ?? item.priceInfo.recurringCharge,
  );
// Calculate total cart amount (no ASD) + any modem discounts Prepaid
export const accumulateNoAsdOneTimeCharge = (cartItems: (BasketItem | BasketRequestItem)[] | undefined): number =>
  sumBy(cartItems, (item) => (item.priceInfo && item.priceInfo.oneTimeCharge ? item.priceInfo?.oneTimeCharge : 0));

// Calculate total cart amount (no ASD) + any modem discounts
export const accumulateNoAsdRecurringCharge = (cartItems: (BasketItem | BasketRequestItem)[] | undefined): number =>
  sumBy(cartItems, (item) => item.priceInfo.loyaltyMRCAmount ?? item.priceInfo?.recurringCharge);

// Calculates discounted cart items (includes ASD and other discounts) + any modem discounts
export const accumulateAdjustedRecurringCharge = (cartItems: BasketItem[]): number =>
  sumBy(cartItems, (item) => item.priceInfo.loyaltyMRCAmount ?? item.priceInfo.adjustedMRCAmount);

// Calculates discounted cart items (includes ASD and other discounts) + any modem discounts prepaid
export const accumulateAdjustedOneTimeCharge = (cartItems: BasketItem[]): number =>
  sumBy(cartItems, (item) => item.priceInfo.adjustedNRCAmount);

export const accumulateRecurringChargeForBasketRequestItems = (
  items: (BasketRequestItem | ChildBasketRequestItem)[],
): number =>
  sumBy<BasketRequestItem | ChildBasketRequestItem>(
    items,
    (item) =>
      (item.priceInfo.adjustedMRCAmount ?? item.priceInfo.recurringCharge ?? 0) +
      ('childProducts' in item ? accumulateRecurringChargeForBasketRequestItems(item.childProducts) : 0),
  );

export const calculateMinCost = ({ recurringCharge, contractTerm }: CalculateMinCostParams) => {
  let numberContractTerm = parseInt(contractTerm ?? '', 10);

  if (Number.isNaN(numberContractTerm)) {
    numberContractTerm = 1;
  }

  return numberContractTerm * recurringCharge;
};

export const isDeviceSddPromotion = (item: BasketItem | BasketRequestItem | CartItem): boolean => {
  if (item.productType !== CartProductType.DEVICE) return false;
  const { promotions } = item as BasketItem;
  if (!promotions) return false;

  return promotions.some((promotion) => promotion.promotionCode.includes('PROMO_SDD'));
};

export const accumulateMinCost = (items: (BasketItem | BasketRequestItem | CartItem)[], useASDPricing = false) =>
  sumBy<BasketItem | BasketRequestItem | CartItem>(items, (item) => {
    let minCost;
    let minCostDiscount = 0;
    const contractTerm = item.productConfig?.contractTerm ?? '1';
    let recurringCharge: number;

    if (isDeviceSddPromotion(item)) {
      recurringCharge =
        (item.priceInfo as BasketItemPriceInfo).MRC ?? (item.priceInfo as BasketItemPriceInfo).adjustedMRCAmount;
      const { Discount } = item.priceInfo as BasketItemPriceInfo;
      if (Discount) {
        minCostDiscount = Discount;
      }
    } else if (isHomeInternetCartItem(item)) {
      recurringCharge = useASDPricing
        ? (item.priceInfo as BasketItemPriceInfo).adjustedMRCAmount
        : item.priceInfo.recurringCharge;
    } else {
      recurringCharge = (item.priceInfo as BasketItemPriceInfo).adjustedMRCAmount ?? item.priceInfo.recurringCharge;
    }

    minCost =
      calculateMinCost({
        contractTerm,
        recurringCharge,
      }) - minCostDiscount;

    if ('childProducts' in item) {
      minCost += sumBy<ExtraCartItem | ChildBasketRequestItem>(
        item.childProducts,
        (childProduct: ExtraCartItem | ChildBasketRequestItem) =>
          calculateMinCost({
            contractTerm: childProduct.productConfig?.contractTerm ?? '1',
            recurringCharge: childProduct.priceInfo.recurringCharge,
          }),
      );
    }

    return minCost;
  });

export const accumulateMinCostForStickyCart = (items: (BasketItem | BasketRequestItem | CartItem)[]) =>
  sumBy<BasketItem | BasketRequestItem | CartItem>(items, (item) => {
    const { recurringCharge, adjustedMRCAmount } = item.priceInfo as BasketItemPriceInfo;
    const { originalRecurringCharge, discount } = (item as BasketRequestItem).priceInfo;

    let minCost = calculateMinCost({
      contractTerm: item.productConfig?.contractTerm ?? '1',
      recurringCharge: originalRecurringCharge ?? adjustedMRCAmount ?? recurringCharge,
    });

    if (discount) {
      minCost -= discount;
    }

    if ('childProducts' in item) {
      minCost += sumBy<ExtraCartItem | ChildBasketRequestItem>(
        item.childProducts,
        (childProduct: ExtraCartItem | ChildBasketRequestItem) =>
          calculateMinCost({
            contractTerm: childProduct.productConfig?.contractTerm ?? '1',
            recurringCharge: childProduct.priceInfo.recurringCharge,
          }),
      );
    }

    return minCost;
  });

export const retrieveHeroIds = (basketItems: BasketItem[]): { planHeroOfferId: string; deviceHeroOfferId: string } => {
  // This method assumes we can have more than one plan/device in the cart. We use the first encountered hero id of each type
  let planHeroOfferId = '';
  let deviceHeroOfferId = '';
  let index = 0;
  while ((!planHeroOfferId || !deviceHeroOfferId) && index < basketItems.length) {
    if (basketItems[index].itemType === CartItemType.PLAN || basketItems[index].itemType === CartItemType.TABLET) {
      planHeroOfferId = basketItems[index].relatedContent?.heroOfferId || '';
    } else if (basketItems[index].itemType === CartItemType.DEVICE) {
      deviceHeroOfferId = basketItems[index].relatedContent?.heroOfferId || '';
    }
    index += 1;
  }
  return { planHeroOfferId, deviceHeroOfferId };
};
export const accumulatePromotions = (basketItems: BasketItem[]): Promotion[] =>
  basketItems.reduce((acc: Promotion[], basketItem) => {
    if (basketItem.promotions) {
      return [...acc, ...basketItem.promotions];
    }
    return acc;
  }, []);

export function isDeviceBasketItem(basketRequestItem: BasketRequestItem): basketRequestItem is DeviceBasketRequestItem;
export function isDeviceBasketItem(basketItem: BasketItem): basketItem is DeviceBasketItem;
export function isDeviceBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is DeviceBasketRequestItem | DeviceBasketItem;
export function isDeviceBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is DeviceBasketRequestItem | DeviceBasketItem {
  return basketItem.itemType === CartItemType.DEVICE;
}
export function isWearableDeviceBasketItem(
  basketRequestItem: BasketRequestItem,
): basketRequestItem is WearableDeviceBasketRequestItem;
export function isWearableDeviceBasketItem(basketItem: BasketItem): basketItem is DeviceBasketItem;
export function isWearableDeviceBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is WearableDeviceBasketRequestItem | DeviceBasketItem;
export function isWearableDeviceBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is WearableDeviceBasketRequestItem | DeviceBasketItem {
  return basketItem.catalogCode === CatalogCode.POSTPAID_WEARABLES;
}

export function isModemDeviceBasketItem(
  basketRequestItem: BasketRequestItem,
): basketRequestItem is ModemBasketRequestItem;
export function isModemDeviceBasketItem(basketItem: BasketItem): basketItem is DeviceBasketItem;
export function isModemDeviceBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is ModemBasketRequestItem | DeviceBasketItem;
export function isModemDeviceBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is ModemBasketRequestItem | DeviceBasketItem {
  return basketItem.catalogCode === CatalogCode.POSTPAID_MBB_MODEMS;
}

export const isESimBasketItem = (basketItem: BasketRequestItem | BasketItem) =>
  basketItem.productType === CartProductType.HARDWARE && basketItem.productSubType === CartProductSubType.ESIM;

export const hasDeviceBasketItem = (basketItems: BasketItem[] | undefined): boolean => {
  return !!basketItems && basketItems.some((cartItem: BasketItem) => isDeviceBasketItem(cartItem));
};

export const hasESimBasketItem = (basketItems: BasketItem[] | undefined): boolean => {
  return !!basketItems && basketItems.some((cartItem: BasketItem) => isESimBasketItem(cartItem));
};

export function isPlanBasketItem(basketRequestItem: BasketRequestItem): basketRequestItem is PlanBasketRequestItem;
export function isPlanBasketItem(basketItem: BasketItem): basketItem is PlanBasketItem;
export function isPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is PlanBasketRequestItem | PlanBasketItem;
export function isPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is PlanBasketRequestItem | PlanBasketItem {
  return basketItem.itemType === CartItemType.PLAN;
}

export const hasPlanBasketItem = (basketItems: readonly (BasketItem | BasketRequestItem)[] | undefined): boolean => {
  return !!basketItems && basketItems.some((cartItem) => isPlanBasketItem(cartItem));
};

export const hasSamsungPlanBasketItem = (
  basketItems: readonly (BasketItem | BasketRequestItem)[] | undefined,
): boolean => {
  return !!basketItems && basketItems.some(isSamsungPlanCartItem);
};

export const hasFhwPlanBasketItem = (basketItems: readonly (BasketItem | BasketRequestItem)[] | undefined): boolean => {
  return !!basketItems && basketItems.some((cartItem) => isFhwPlanBasketItem(cartItem));
};

export function isPostpaidSimoPlanBasketItem(
  basketRequestItem: BasketRequestItem,
): basketRequestItem is PostpaidSimoPlanBasketRequestItem;
export function isPostpaidSimoPlanBasketItem(basketItem: BasketItem): basketItem is PostpaidSimoPlanBasketItem;
export function isPostpaidSimoPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is PostpaidSimoPlanBasketRequestItem | PostpaidSimoPlanBasketItem;
export function isPostpaidSimoPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is PostpaidSimoPlanBasketRequestItem | PostpaidSimoPlanBasketItem {
  return PostpaidSimoCatalogCodes.includes(basketItem.catalogCode);
}

export function isPrepaidComboPlusPlanBasketItem(
  basketRequestItem: BasketRequestItem,
): basketRequestItem is PrepaidComboPlusPlanBasketRequestItem;
export function isPrepaidComboPlusPlanBasketItem(basketItem: BasketItem): basketItem is PrepaidComboPlusPlanBasketItem;
export function isPrepaidComboPlusPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is PrepaidComboPlusPlanBasketRequestItem | PrepaidComboPlusPlanBasketItem;
export function isPrepaidComboPlusPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is PrepaidComboPlusPlanBasketRequestItem | PrepaidComboPlusPlanBasketItem {
  return basketItem.catalogCode === CatalogCode.PREPAID_COMBO_PLUS_PLANS;
}

export function isPrepaidPayAndGoPlanBasketItem(
  basketRequestItem: BasketRequestItem,
): basketRequestItem is PrepaidPayAndGoPlanBasketRequestItem;
export function isPrepaidPayAndGoPlanBasketItem(basketItem: BasketItem): basketItem is PrepaidPayAndGoPlanBasketItem;
export function isPrepaidPayAndGoPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is PrepaidPayAndGoPlanBasketRequestItem | PrepaidPayAndGoPlanBasketItem;
export function isPrepaidPayAndGoPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is PrepaidPayAndGoPlanBasketRequestItem | PrepaidPayAndGoPlanBasketItem {
  return basketItem.catalogCode === CatalogCode.PREPAID_PAY_AND_GO_PLANS;
}

export const getPrepaidCartItem = (basketItems: BasketItem[]): BasketItem | undefined =>
  basketItems.find(
    (basketItem) => isPrepaidPayAndGoPlanBasketItem(basketItem) || isPrepaidComboPlusPlanBasketItem(basketItem),
  );

export const isTabletSimoPlanBasketItem = (basketItem: BasketRequestItem | BasketItem) =>
  basketItem.catalogCode === CatalogCode.POSTPAID_TABLET_SIMO_PLANS;

export const isTabletPlanBasketItem = (basketItem: BasketRequestItem | BasketItem) =>
  basketItem.catalogCode === CatalogCode.POSTPAID_TABLET_PLANS;

export const isModemSimoPlanBasketItem = (basketItem: BasketRequestItem | BasketItem) =>
  basketItem.catalogCode === CatalogCode.POSTPAID_MBB_MODEM_SIMO_PLANS;

export const isModemPlanBasketItem = (basketItem: BasketRequestItem | BasketItem) =>
  basketItem.catalogCode === CatalogCode.POSTPAID_MBB_MODEM_PLANS;

export const isHardwareBasketItem = (basketItem: BasketItem): boolean => basketItem.itemType === CartItemType.HARDWARE;

export function isNbnPlanBasketItem(
  basketRequestItem: BasketRequestItem,
): basketRequestItem is NbnPlanBasketRequestItem;
export function isNbnPlanBasketItem(basketItem: BasketItem): basketItem is NbnPlanBasketItem;
export function isNbnPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is DeviceBasketRequestItem | DeviceBasketItem;
export function isNbnPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is DeviceBasketRequestItem | DeviceBasketItem {
  return basketItem.catalogCode === CatalogCode.NBN_PLANS;
}

export function isFhw4gPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is DeviceBasketRequestItem | DeviceBasketItem {
  return basketItem.catalogCode === CatalogCode.FHW_4G_PLANS;
}

export function isFhw5gPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is DeviceBasketRequestItem | DeviceBasketItem {
  return basketItem.catalogCode === CatalogCode.FHW_5G_PLANS;
}

export function isFhwPlanBasketItem(
  basketItem: BasketRequestItem | BasketItem,
): basketItem is DeviceBasketRequestItem | DeviceBasketItem {
  return isFhw4gPlanBasketItem(basketItem) || isFhw5gPlanBasketItem(basketItem);
}

export const getNbnPlanWithModemCartItem = (basketItems: BasketItem[]): BasketItem | undefined =>
  basketItems.find((basketItem) => isNbnPlanBasketItem(basketItem));

export const isHomeInternetCartItem = (basketItem: BasketItem | BasketRequestItem | CartItem) => {
  return (
    basketItem.catalogCode === CatalogCode.FHW_4G_PLANS ||
    basketItem.catalogCode === CatalogCode.FHW_5G_PLANS ||
    basketItem.catalogCode === CatalogCode.NBN_PLANS
  );
};

export const isSamsungPlanCartItem = (basketItem: BasketItem | BasketRequestItem | CartItem) => {
  return basketItem.catalogCode === CatalogCode.POSTPAID_SIMO_TPG_SM;
};

// Whereas this works for anything that has a catalogCode, such as CartParams
export const isNbnPlan = (cartItem: { catalogCode: CatalogCode }) => cartItem.catalogCode === CatalogCode.NBN_PLANS;

export function isModemBasketItem(
  childBasketItem: ChildBasketRequestItem,
): childBasketItem is ModemChildBasketRequestItem;
export function isModemBasketItem(basketItem: BasketItem): basketItem is ModemBasketItem;
export function isModemBasketItem(basketItem: BasketRequestItem | BasketItem): basketItem is ModemBasketItem;
export function isModemBasketItem(
  basketItem: BasketRequestItem | BasketItem | ChildBasketRequestItem,
): basketItem is ModemBasketItem {
  return basketItem.itemType === CartItemType.MODEM;
}

export const isAddonCartItem = (cartItem: CartItem | BaseCartItem): cartItem is AddonCartItem =>
  cartItem.itemType === CartItemType.ADDON;

export const isExtraBasketItem = (basketItem: BasketItem): boolean =>
  basketItem.itemType === CartItemType.EXTRA || basketItem.itemType === CartItemType.ADDON;

export const isPrepaidPlanCartItem = (cartItem: { catalogCode: CatalogCode }) =>
  PrepaidCatalogCodes.includes(cartItem.catalogCode);

export const isPostpaidCartItem = (cartItem: { catalogCode: CatalogCode }) =>
  PostpaidCatalogCodes.includes(cartItem.catalogCode);

export const isSwapAndGoContent = (extrasContent: ExtrasContent): extrasContent is SwapAndGoContent =>
  extrasContent?.extraType === 'swapAndGo';

export const isAddOnsContent = (extrasContent: ExtrasContent): extrasContent is AddOnsContent =>
  'cisLabel' in extrasContent;

export const isAddOnExtra = (extra: Extra): extra is AddOnExtra => extra.productType === ExtraType.ADDON;

export const isAddonSwapAndGO = (extras: Extra) => extras.productCode === 'AUV0467' || 'AUV0468';

export const wrapNbnPlanName = (cartItem: BasketItem): string => `${cartItem.productName}`;

export const wrapPostpaidSimoPlanName = (cartItem: PostpaidSimoPlanBasketItem): string => {
  // SHOP-7216 - Plan Refresh | Remove Plan price shown as part of plan name for Postpaid Voice plans
  // Added the below check to return recurringCharge + planName only when catalogcodes are not SIMO and handset plans
  return includes(PlansRefreshCatalogs, cartItem.catalogCode)
    ? `${cartItem.relatedContent?.planName}`
    : `$${cartItem.priceInfo.recurringCharge} ${cartItem.relatedContent?.planName}`;
};

export const wrapPrepaidPlanName = (cartItem: PrepaidComboPlusPlanBasketItem | PrepaidPayAndGoPlanBasketItem): string =>
  `${cartItem.relatedContent?.planName}`;

/**
 * Filters out basket items which are not meant for inclusion when displaying to customers, e.g. SIM card
 * @param items
 */
export const filterNonVisibleItems = (items: readonly BasketItem[]) =>
  items.filter(
    (item) =>
      !(
        item.productType === CartProductType.HARDWARE &&
        ([CartProductSubType.ESIM, CartProductSubType.SIM] as Array<string | undefined>).includes(item.productSubType)
      ),
  );

interface OrderedItem {
  order: string;
}
export const sortOrderedItems = (itemA: OrderedItem, itemB: OrderedItem) => {
  const orderA = parseInt(itemA.order, 10);
  const orderB = parseInt(itemB.order, 10);
  return orderA - orderB;
};

const CartItemSortOrder: CartItemType[] = [
  CartItemType.DEVICE,
  CartItemType.HARDWARE,
  CartItemType.MODEM,
  CartItemType.PLAN,
  CartItemType.EXTRA,
  CartItemType.ADDON,
];

const sortCartItem = (order: CartItemType[]) => (a: BasketItem, b: BasketItem) =>
  order.indexOf(a.itemType) - order.indexOf(b.itemType);

export const sortCartItems = (cartItems: BasketItem[]): BasketItem[] => {
  const copy = [...cartItems];

  // TODO: Make fake cart items for child products somehow
  // Prepaid Plan displays childProduct(sim card) as another cart item
  // const prepaid = getPrepaidCartItem(copy);
  // if (prepaid && prepaid.childProducts) {
  //   copy.push({
  //     catalogCode: prepaid.catalogCode,
  //     itemType: CartItemType.HARDWARE,
  //     productName: ' ',
  //     priceInfo: prepaid.childProducts[0].priceInfo,
  //     productCode: prepaid.childProducts[0].productCode,
  //     productConfig: prepaid.childProducts[0].productConfig,
  //     productSubType: prepaid.childProducts[0].productSubType,
  //     productType: prepaid.childProducts[0].productType,
  //     quantity: prepaid.childProducts[0].quantity,
  //     relatedContent: {},
  //   });
  // }

  // // Nbn Plan With Modem displays childProduct(modem) as another cart item
  // const nbnPlanWithModem = getNbnPlanWithModemCartItem(copy);
  // if (nbnPlanWithModem && nbnPlanWithModem.childProducts) {
  //   copy.push({
  //     actions: {
  //       delete: { lineItemKey: 'na', bundleContextKey: 'na' },
  //       update: { lineItemKey: 'na', bundleContextKey: 'na' },
  //     },
  //     catalogCode: CatalogCode.NBN_MODEMS,
  //     itemType: CartItemType.MODEM,
  //     name: nbnPlanWithModem.childProducts[0].name,
  //     priceInfo: nbnPlanWithModem.childProducts[0].priceInfo,
  //     productCode: nbnPlanWithModem.childProducts[0].productCode,
  //     productConfig: nbnPlanWithModem.childProducts[0].productConfig,
  //     productSubType: nbnPlanWithModem.childProducts[0].productSubType,
  //     productType: nbnPlanWithModem.childProducts[0].productType,
  //     quantity: nbnPlanWithModem.childProducts[0].quantity,
  //     relatedContent: {},
  //   });
  // }

  return copy.sort(sortCartItem(CartItemSortOrder));
};

export const formatCartItemDetails = (
  cartItem: BasketItem,
  disableMaxSpeed: boolean,
  hideVoiceMBBTabletsPlanDetails?: boolean,
) => {
  let details = '';
  if (isDeviceBasketItem(cartItem)) {
    const { color, capacity, bandName, bandColor } = cartItem.productConfig as BasketItemProductConfig;
    details =
      cartItem.catalogCode === CatalogCode.POSTPAID_WEARABLES
        ? compact([color, `${bandColor} ${bandName}`]).join(' | ')
        : compact([color, capacity]).join(' | ');
  } else if (isPlanBasketItem(cartItem) && !isPrepaidPayAndGoPlanBasketItem(cartItem)) {
    const { productConfig, productSubType, relatedContent } = cartItem;
    const { planTenure, planData, hasDataOverride, subHeadingPrimary, planSpeedLabel } = relatedContent ?? {};
    const { dataLimit } = productConfig ?? {};
    const maxSpeedData = dataLimit === DataLimit.UNLIMITED ? 'Max Speed data' : 'data';
    const planDataLabel =
      productSubType === CartProductSubType.HANDSET_M2M
        ? ' data'
        : ` ${hasDataOverride ? 'total ' : ''}${disableMaxSpeed ? maxSpeedData : 'data'}`;
    details = compact([planTenure, planData ? `${planData}${planDataLabel} in Oz` : '']).join(' | ');

    if (
      hideVoiceMBBTabletsPlanDetails &&
      (cartItem.catalogCode === CatalogCode.POSTPAID_HANDSET_PLANS ||
        cartItem.catalogCode === CatalogCode.POSTPAID_SIMO_PLANS ||
        cartItem.catalogCode === CatalogCode.POSTPAID_TABLET_PLANS ||
        cartItem.catalogCode === CatalogCode.POSTPAID_TABLET_SIMO_PLANS ||
        cartItem.catalogCode === CatalogCode.POSTPAID_MBB_MODEM_PLANS ||
        cartItem.catalogCode === CatalogCode.POSTPAID_MBB_MODEM_SIMO_PLANS)
    ) {
      details = ''; // Hides details line for voice, MBB and tablets plans
    }

    if (isNbnPlanBasketItem(cartItem)) {
      details = compact([planTenure, planSpeedLabel]).join(' | ');
    }

    if (isFhwPlanBasketItem(cartItem)) {
      details = compact([planTenure, planSpeedLabel]).join(' | ');
    }

    if (isPrepaidComboPlusPlanBasketItem(cartItem) && planTenure) {
      const expiry = planTenure;
      const extraDetails = compact([planData, subHeadingPrimary]).join(' ');
      details = extraDetails ? `${expiry} | ${extraDetails}` : expiry;
    }
  } else if (isWearableDeviceBasketItem(cartItem)) {
    const { color, capacity } = cartItem.productConfig as BasketItemProductConfig;
    details = compact([color, capacity]).join(' | ');
  }

  if (isExtraBasketItem(cartItem) && shouldShowMonthToMonth(cartItem)) {
    details = 'Month to month';
  }

  return details;
};

export const wrapContractTerm = (
  contractTerm: CartItem['productConfig']['contractTerm'],
  itemType?: CartItemType,
  catalogCode?: CatalogCode,
) => {
  if (catalogCode === CatalogCode.PREPAID_HANDSETS || !contractTerm || contractTerm === '1') {
    return '';
  }
  if (itemType === CartItemType.MODEM || catalogCode === CatalogCode.POSTPAID_SIMO_TPG_SM) {
    return `when you stay connected for ${contractTerm} months`;
  }
  return `When you stay connected with us for ${contractTerm}`;
};

export const formatCartItemMinCost = (cartItem: BasketItem) => {
  if (isModemBasketItem(cartItem)) return undefined;

  const {
    priceInfo: { adjustedMRCAmount },
    productConfig,
  } = cartItem;

  const minCost = calculateMinCost({
    contractTerm: productConfig?.contractTerm || '1',
    recurringCharge: adjustedMRCAmount,
  });

  if (minCost === adjustedMRCAmount) {
    return '';
  }

  return `Min. cost $${formatCurrency(minCost)}`;
};

export const accumulateExtrasFromCartItems = (
  basketItems: BasketRequestItem[] | undefined,
): ChildBasketRequestItem[] => {
  return (
    basketItems?.reduce((acc: ChildBasketRequestItem[], basketItem: BasketRequestItem) => {
      if (basketItem.childProducts?.length) {
        return [
          ...acc,
          ...basketItem.childProducts.filter((item: ChildBasketRequestItem) => item.itemType !== CartItemType.OFFER),
        ];
      }
      return acc;
    }, []) || []
  );
};

/**
 * extraToChildBasketRequestItem: convert an Extra object to a ChildBasketRequestItem
 */
export const extraToChildBasketRequestItem = (extra: Extra): ChildBasketRequestItem => {
  const { contractTerm, name, oneTimeCharge, productCode, productType, productSubType, recurringCharge } = extra;
  return {
    catalogCode: CatalogCode.EXTRAS,
    itemType: CartItemType.EXTRA,
    packageId: '',
    productName: name,
    productCode,
    productType,
    productSubType,
    priceInfo: { recurringCharge, oneTimeCharge: oneTimeCharge || 0 },
    productConfig: { contractTerm: contractTerm || '1' },
  };
};

export const extractPriceFromBasketItem = (basketItem: BasketItem) => {
  if (isPrepaidPlan(basketItem)) {
    return formatCurrency(basketItem.priceInfo.oneTimeCharge);
  }

  if (isDeviceSddPromotion(basketItem)) {
    return formatCurrency(basketItem.priceInfo.MRC ?? basketItem.priceInfo.recurringCharge);
  }
  return formatCurrency(basketItem.priceInfo.recurringCharge);
};

export const extractAdjustedPriceFromBasketItem = (basketItem: BasketItem) => {
  if (isPrepaidPlan(basketItem)) {
    return formatCurrency(basketItem.priceInfo.adjustedNRCAmount);
  }
  if (isModemBasketItem(basketItem)) {
    return formatCurrency(basketItem.priceInfo.loyaltyMRCAmount as number);
  }

  return formatCurrency(basketItem.priceInfo.adjustedMRCAmount);
};

export const isPrepaidPlan = (plan: BasketItem | BasketRequestItem): boolean => {
  return PrepaidCatalogCodes.includes(plan.catalogCode);
};

export const getMaximumNumberOfCartBundles = (serviceType: ServiceTypeValue | undefined): number => {
  switch (serviceType) {
    case ServiceTypeValue.Upgrade:
      return Number(process.env.CART_MAX_UPGRADE_BUNDLES) || 1;
    case ServiceTypeValue.NewAcquisition:
    case ServiceTypeValue.AnotherService:
    default:
      return Number(process.env.CART_MAX_BUNDLES) || 5;
  }
};

export const getImageFromRelatedContent = (item?: BasketItem): Image | undefined => {
  if (item?.relatedContent?.image) {
    const { altText, imageUrl } = item.relatedContent.image;
    return { alt: altText, src: imageUrl };
  }
  return undefined;
};

export const basketResponseToBasket = (basketResponse: BasketResponse): Basket => {
  const packages: BasketPackage[] = Object.entries(basketResponse.packages).map(([packageId, bundle]) => ({
    items: Object.values(bundle).map((item) => ({
      ...item,
      packageId,
    })),
    packageId,
  }));

  // Modify an item to make it expired (TEST CODE)
  // packages[0].items[0].productExpired = true;

  // Check whether we have expired products, expired promotions, OR changed product config (VFE-1208)
  // If we do, clear the LocalStorageClient's basket.
  // Don't clear the bundle data here as the UI needs it to determine what message to show.
  if (isBasketWithExpiredItems(packages)) {
    LocalStorageClient.removeBasketId();
  }

  return {
    ...basketResponse,
    packages,
  };
};

export const flattenBasket = (packages: BasketPackage[]): BasketItem[] =>
  packages.reduce<BasketItem[]>((acc, bundle) => {
    return [...acc, ...bundle.items];
  }, []);

export const addToBasketAndNavigateToCartPage = async (
  items: BasketRequestItem[],
  additionalBnsCount: number,
  extraOffer?: string,
  basketState?: Basket | null,
): Promise<boolean> => {
  const response = await getApiClient().addToBasket({
    items,
    additionalBnsCount,
    raf: basketState ? getRafUpdateRequestParams(items, basketState) : undefined,
    extraOffer,
  });

  if (!response) {
    throw new Error('Unable to add bundle to basket');
  }

  LocalStorageClient.setBasketId(response.basketId);

  // If raf has been applied to the item thats just being added, notify the cart page to show the RAF MSO Alert
  if (response.raf?.appliedCatalogCode && basketState?.raf?.appliedCatalogCode && response.raf?.isValid === true) {
    setRafItemUpdated(response.raf?.appliedCatalogCode, basketState.raf?.appliedCatalogCode);
  }

  return safeRouterPush(decoratePathWithQueries('/cart', [QueryKey.NUDGE_REFERRER]));
};

export const shouldShowMonthToMonth = (extra: BasketItem): boolean =>
  extra.productConfig?.contractTerm === '1' ||
  (extra.productType === CartProductType.SWAP_AND_GO && !!extra.priceInfo.recurringCharge);

export const canSelectESimOrPSim = (
  basketItems: readonly (BasketItem | BasketRequestItem)[] = [],
  isSimSelectionDisabledWithFeatureFlag?: DataFetchState<Flag, boolean>,
): boolean => {
  // Don't show if SIM selection has been disabled with feature flag
  if (isSimSelectionDisabledWithFeatureFlag?.data) return false;

  const device = basketItems.find((item) => isDeviceBasketItem(item)) as
    | DeviceBasketItem
    | DeviceBasketRequestItem
    | undefined;
  return (
    (basketItems.some(isPostpaidSimoPlanBasketItem) && !basketItems.some(isModemSimoPlanBasketItem)) ||
    device?.simTypeCompatibility === SimTypeCompatibility.PHYSICAL_AND_ESIM ||
    device?.simTypeCompatibility === SimTypeCompatibility.ESIM_ONLY
  );
};

export const hasESimOnlyDeviceBasketItem = (basketItems: readonly (BasketItem | BasketRequestItem)[] = []): boolean => {
  const device = basketItems.find((item) => isDeviceBasketItem(item)) as
    | DeviceBasketItem
    | DeviceBasketRequestItem
    | undefined;
  return device?.simTypeCompatibility === SimTypeCompatibility.ESIM_ONLY;
};

export const hasESimCapableDeviceBasketItem = (
  basketItems: readonly (BasketItem | BasketRequestItem)[] = [],
): boolean => {
  const device = basketItems.find((item) => isDeviceBasketItem(item)) as
    | DeviceBasketItem
    | DeviceBasketRequestItem
    | undefined;
  return (
    device?.simTypeCompatibility === SimTypeCompatibility.PHYSICAL_AND_ESIM ||
    device?.simTypeCompatibility === SimTypeCompatibility.ESIM_ONLY
  );
};

export const hasPostpaidSimoPlanBasketItem = (
  basketItems: readonly (BasketItem | BasketRequestItem)[] = [],
): boolean => {
  return basketItems.some((item) => isPostpaidSimoPlanBasketItem(item));
};

export const isBasketLoadingOrEmpty = (
  cartState: DataFetchState<BasketParams, Basket>,
  addToCartState: DataFetchState<AddToBasketParams, Basket>,
): boolean => {
  const bundles = cartState?.data?.packages || []; // Bundles is an array of array-of-products

  return cartState.isLoading || addToCartState.isLoading || !bundles.length;
};

export const getInstallationAddress = (internetType: HomeInternetType): Address => {
  const installationAddress = JSON.parse(LocalStorageClient.getInstallationAddress(internetType));
  return {
    streetNumber: installationAddress.streetNumber ? installationAddress.streetNumber.toLowerCase() : '',
    street: installationAddress.street ? installationAddress.street.toLowerCase() : '',
    streetType: installationAddress.streetType ? installationAddress.streetType.toLowerCase() : '',
    suburb: installationAddress.suburb ? installationAddress.suburb.toLowerCase() : '',
    state: installationAddress.state || '',
    postcode: installationAddress.postcode || '',
    unitType: installationAddress.unitType ? installationAddress.unitType.toLowerCase() : '',
    unitNumber: installationAddress.unitNumber || 0,
    level: installationAddress.level ? installationAddress.level.toLowerCase() : '',
    complexStreetNumber: installationAddress.complexStreetNumber
      ? installationAddress.complexStreetNumber.toLowerCase()
      : '',
    complexOrSiteName: installationAddress.complexOrSiteName ? installationAddress.complexOrSiteName.toLowerCase() : '',
    buildingName: installationAddress.buildingName ? installationAddress.buildingName.toLowerCase() : '',
    complexStreet: installationAddress.complexStreet ? installationAddress.complexStreet.toLowerCase() : '',
    complexStreetType: installationAddress.complexStreetType ? installationAddress.complexStreetType.toLowerCase() : '',
  } as Address;
};

export const getNbnInstallationAddress = (): Address => {
  return getInstallationAddress(HomeInternetType.NBN);
};

export const getFhw4gInstallationAddress = (): Address => {
  return getInstallationAddress(HomeInternetType.FHW_4G);
};

export const getFhw5gInstallationAddress = (): Address => {
  return getInstallationAddress(HomeInternetType.FHW_5G);
};

export const isBasketWithExpiredItems = (bundles: BasketPackage[] = []): boolean => {
  // Check if the products have changed or expired, by looking for ANY product with productExpire=true or productConfigChanged=true
  // Also, look at the promotions of the product. If any promotions have expired, we should show
  // an empty basket.
  return bundles.some(
    (bundle) =>
      Array.isArray(bundle.items) &&
      bundle.items.some(
        (product) =>
          product.productConfigChanged ||
          product.productExpired ||
          (product?.promotions || []).some((promo: Promotion) => promo.promotionExpired),
      ),
  );
};

/**
 * isChangingDataSharingGroup compares the current service with the plan selected in the customer basket.
 * Currently, the only case we want to check for is when a customer is changing from ALPHA to OMEGA. But
 * there could be others in the future.
 *
 * Note: it's important we convert to uppercase as the dataSharingGroup is all caps in some systems and
 * title case in other systems.
 *
 * @param currentService
 * @param plan
 */
export const isChangingDataSharingGroup = (
  currentService: ServiceItem | undefined,
  plan: BasketItem | undefined,
): boolean => {
  return (
    !!plan &&
    plan.productConfig?.dataSharing?.toUpperCase() === 'OMEGA' &&
    currentService?.sharingCompatibility?.toUpperCase() === 'ALPHA'
  );
};

export const getCheckoutSplitterContentList = ({
  cart,
  checkoutSplitterGroups,
}: GetContentParams): CheckoutSplitterContent[] => {
  const defaultContentList: CheckoutSplitterContent[] = [
    {
      secondaryCtaStyle: 'primary',
      secondaryCtaLabel: '',
      primaryCtaStyle: 'primary',
      secondaryCtaRole: 'new',
      primaryCtaLabel: "Yes, I'm new",
      title: 'New to Vodafone?',
      body: '',
      primaryCtaRole: 'new',
    },
    {
      secondaryCtaStyle: 'secondary',
      secondaryCtaLabel: 'Add another plan',
      primaryCtaStyle: 'secondary',
      secondaryCtaRole: 'additional-service',
      primaryCtaLabel: 'Change your plan',
      title: 'Already with Vodafone?',
      body: '',
      primaryCtaRole: 'change-plan',
    },
  ];

  if (!checkoutSplitterGroups) {
    return defaultContentList;
  }

  const cartHasSmartWatch =
    cart && cart.packages?.some((cartItem) => cartItem.items.find((item) => isWearableDeviceBasketItem(item)));

  if (cartHasSmartWatch) {
    const cartItemLength = cart.packages.length;
    if (isCartWithSmartWatchOnly(cart.packages)) {
      // check whether cart have only smart watch
      return (
        checkoutSplitterGroups.find((e) => e.id === CheckoutSplitterGroupId.WATCH_ONLY)?.content || defaultContentList
      );
    }
    if (
      cartItemLength &&
      cartItemLength > 1 &&
      cart.packages?.some((cartItem) =>
        cartItem.items.find(
          (item) =>
            (!isWearableDeviceBasketItem(item) && isDeviceBasketItem(item)) ||
            (!isWearableDeviceBasketItem(item) && isTabletSimoPlanBasketItem(item)),
        ),
      )
    ) {
      // check whether items have atleast one plan
      return (
        checkoutSplitterGroups.find((e) => e.id === CheckoutSplitterGroupId.WATCH_HANDSET)?.content ||
        defaultContentList
      );
    }
    if (
      cartItemLength &&
      cartItemLength > 1 &&
      cart.packages?.some((cartItem) =>
        cartItem.items.find(
          (item) =>
            (!isWearableDeviceBasketItem(item) && isPostpaidSimoPlanBasketItem(item)) ||
            (!isWearableDeviceBasketItem(item) && isTabletSimoPlanBasketItem(item)),
        ),
      )
    ) {
      // check whether items have atleast one plan
      return (
        checkoutSplitterGroups.find((e) => e.id === CheckoutSplitterGroupId.WATCH_SIMO)?.content || defaultContentList
      );
    }
  }

  const isCartHasHomeInternetPlanOnly =
    cart?.packages.length === 1 &&
    cart.packages[0].items.some((item) => isNbnPlanBasketItem(item) || isFhwPlanBasketItem(item));

  if (isCartHasHomeInternetPlanOnly) {
    return (
      checkoutSplitterGroups.find((e) => e.id === CheckoutSplitterGroupId.HOME_INTERNET)?.content || defaultContentList
    );
  }

  const isCartHasSIMOPlanOnly =
    cart?.packages.length === 1 &&
    cart.packages[0].items.some((item) => isPostpaidSimoPlanBasketItem(item) || isTabletSimoPlanBasketItem(item));

  if (isCartHasSIMOPlanOnly) {
    return checkoutSplitterGroups.find((e) => e.id === CheckoutSplitterGroupId.SIMO)?.content || defaultContentList;
  }

  const items = flattenBasket(cart?.packages ?? []);
  if (items.some((item) => isDeviceBasketItem(item) || isTabletPlanBasketItem(item))) {
    return checkoutSplitterGroups.find((e) => e.id === CheckoutSplitterGroupId.HANDSET)?.content || defaultContentList;
  }
  return defaultContentList;
};

export const getCtaVariant = (style: CheckoutSplitterCtaStyle): ButtonVariant => {
  switch (style) {
    case 'primary':
      return 'primary';
    case 'secondary':
      return 'tertiary';
    default:
      return 'primary';
  }
};

export const getOnlineBtlEligiblePlanItem = (cartItems: BasketItem[]): BasketItem | undefined => {
  return cartItems.find(
    (cartItem) =>
      cartItem.catalogCode === CatalogCode.POSTPAID_SIMO_PLANS ||
      cartItem.catalogCode === CatalogCode.NBN_PLANS ||
      cartItem.catalogCode === CatalogCode.FHW_4G_PLANS ||
      cartItem.catalogCode === CatalogCode.POSTPAID_HANDSET_PLANS ||
      cartItem.catalogCode === CatalogCode.FHW_5G_PLANS,
  );
};

export const isPostpaidMobileSIMOPlan = (plan: BasketItem | BasketRequestItem): boolean => {
  return PostpaidMobileSIMOCatalogCodes.includes(plan.catalogCode);
};

export const isPostpaidPhonePlanCartItem = (cartItem: BasketItem): boolean => {
  return !!cartItem && cartItem.catalogCode === CatalogCode.POSTPAID_HANDSET_PLANS;
};

export const isSmartWatchWithHomeInternet = (cartItems: BasketPackage[]): boolean => {
  return (
    cartItems.some((cartItem) => cartItem.items.find((item) => isWearableDeviceBasketItem(item))) &&
    cartItems.some((cartItem) => cartItem.items.find((item) => isHomeInternetCartItem(item)))
  );
};

export const isCartWithSmartWatchOnly = (cartItems: BasketPackage[]): boolean => {
  return cartItems?.every((obj) => obj.items.find((item) => isWearableDeviceBasketItem(item)));
};

export const isCartWithSmartWatch = (cartItems: BasketPackage[]): boolean => {
  return cartItems?.some((obj) => obj.items.find((item) => isWearableDeviceBasketItem(item)));
};

/**
 * An eligible cart containing a smart watch should:
 *  - not have home internet
 *  - not have a prepaid product
 *  - if on a New Customer journey should also have a SIMO or Handset Plans
 *  - if on Add Services journey it should not be a prepaid customer
 */
export const isCartEligibleWithSmartWatch = (
  serviceType: ServiceTypeValue | undefined,
  basketPackage: BasketPackage[],
  user: User | undefined,
  activeService: CustomerServiceDetails | undefined,
): boolean => {
  return (
    basketPackage &&
    // No Internet
    !isSmartWatchWithHomeInternet(basketPackage) &&
    (isValidNewAcqSmartWatchCart(serviceType, basketPackage) ||
      isValidAddServicesSmartWatchCart(serviceType, basketPackage, user, activeService))
  );
};

export const isValidNewAcqSmartWatchCart = (
  serviceType: ServiceTypeValue | undefined,
  basketPackage: BasketPackage[],
) => {
  return (
    // new Acq
    isServiceOfType(serviceType, ServiceTypeValue.NewAcquisition) &&
    // wearable
    basketPackage.some((pack) => pack.items.find((cartItem) => isWearableDeviceBasketItem(cartItem))) &&
    // Simo or Handset Plan
    (basketPackage.some((pack) => pack.items.find((cartItem) => isPostpaidMobileSIMOPlan(cartItem))) ||
      basketPackage.some((pack) => pack.items.find((cartItem) => isPostpaidPhonePlanCartItem(cartItem))))
  );
};

export const isValidAddServicesSmartWatchCart = (
  serviceType: ServiceTypeValue | undefined,
  basketPackage: BasketPackage[],
  user: User | undefined,
  activeService: CustomerServiceDetails | undefined,
) => {
  return (
    // additional service
    isServiceOfType(serviceType, ServiceTypeValue.AnotherService) &&
    // wearable
    basketPackage.some((pack) => pack.items.find((cartItem) => isWearableDeviceBasketItem(cartItem))) &&
    !!user &&
    !!activeService &&
    // Prepay user with (Simo,Handset)
    ((isPrepayUser(user, activeService) &&
      // Simo or Handset Plan
      (basketPackage.some((pack) => pack.items.find((cartItem) => isPostpaidMobileSIMOPlan(cartItem))) ||
        basketPackage.some((pack) => pack.items.find((cartItem) => isPostpaidPhonePlanCartItem(cartItem))))) ||
      // OR normal postpaid user
      !isPrepayUser(user, activeService))
  );
};

const isPrepayUser = (user: User, activeService: CustomerServiceDetails) => {
  return isPrepayVoiceService(activeService, user) || isPrepayMbbService(activeService, user);
};

// All RAF utility functions on Cart page
export const getPackageCatalogCodesFromBundle = (bundles: BasketPackage[]) => {
  const rafPackagesInBasket: { [packageId: string]: CatalogCode } = {};
  bundles.forEach((bundle) => {
    bundle.items.forEach((item) => {
      if (
        item.catalogCode !== undefined &&
        item.itemType === 'PLAN' &&
        RafEligibleCatalogCodes.includes(item.catalogCode)
      ) {
        const { packageId } = item;
        const catCode = item.catalogCode;
        rafPackagesInBasket[packageId] = catCode;
      }
    });
  });
  return rafPackagesInBasket;
};

export const getMatchingPackage = (catCodePackagesList: Array<[string, CatalogCode]>, catalogCode: CatalogCode) => {
  if (catCodePackagesList.length > 0) {
    const rafItem = catCodePackagesList.find((item) => item[1] === catalogCode);
    if (rafItem) {
      const [packageId] = rafItem;
      return packageId;
    }
  }
  return null;
};

export const getUniqueCatalogCodes = (catalogCodes: Array<CatalogCode>) => {
  return [...Array.from(new Set(catalogCodes))];
};

export const isAlphanumeric = (code: string) => {
  return /^[A-Z]+[a-z]*[0-9]+$/.test(code);
};

export const getRafEligiblePackagesInBasketList = (rafEligiblePackagesInBasket?: {
  [packageId: string]: CatalogCode;
}) => {
  // get in form [[packageId, catalogCode], ...]
  return rafEligiblePackagesInBasket ? Object.entries(rafEligiblePackagesInBasket) : [];
};

export const checkIfIsRafApplicableProduct = (rafAppliedPackageId: string, cartItem: BasketItem) => {
  return !!(rafAppliedPackageId === cartItem.packageId && cartItem.itemType === 'PLAN');
};

// RAF utility Functions for Upsert on Product pages
// Check if item being added has a different catalog code to whats already RAF-applied.
export const checkIfRafRequiresUpdate = (catalogCodesInBasket?: Array<CatalogCode>, catalogCode?: CatalogCode) => {
  if (!catalogCodesInBasket || !catalogCode) return undefined;

  return !catalogCodesInBasket.includes(catalogCode);
};

// get RAF-eligible Catalog Codes from Basket
export const getRafCatalogCodesFromBasket = (bundles?: BasketPackage[]) => {
  const rafCatalogCodesInBasket: Array<CatalogCode> = [];
  if (bundles) {
    bundles.forEach((bundle) => {
      bundle.items.forEach((item) => {
        if (
          item.catalogCode !== undefined &&
          item.itemType === 'PLAN' &&
          RafEligibleCatalogCodes.includes(item.catalogCode)
        ) {
          rafCatalogCodesInBasket.push(item.catalogCode);
        }
      });
    });
  }
  return rafCatalogCodesInBasket;
};

export const createRafUpsertRequest = (rafCode?: string, catalogCode?: CatalogCode) => {
  let raf;
  if (rafCode && catalogCode) {
    raf = {
      action: 'Upsert' as RafAction,
      rafCode,
      rafCatalogCodes: [catalogCode],
      toBeValidated: true,
    };
  }
  return raf;
};

export const setRafItemUpdated = (updatedCatalogCode: CatalogCode, appliedCatalogCode: CatalogCode) => {
  if (updatedCatalogCode !== appliedCatalogCode) {
    LocalStorageClient.setRafItemUpdated(true);
  }
};

export const getRafUpdateRequestParams = (stickyCart: BasketRequestItem[], basket: Basket | null) => {
  if (!basket || !basket.raf) return undefined;

  const planItem = stickyCart.find((item) => item.itemType === 'PLAN');

  let raf: RafRequestParams | undefined;
  if (planItem) {
    const catalogCodesInBasket = getRafCatalogCodesFromBasket(basket.packages);

    // construct RAF request only if the catalogCode of item being added does not already exist in the Basket
    raf = checkIfRafRequiresUpdate(catalogCodesInBasket, planItem.catalogCode)
      ? createRafUpsertRequest(basket.raf.rafCode, planItem.catalogCode)
      : undefined;
  }

  return raf;
};

export const getRafUpdateParamsForDeepLinkedPlans = (planItem: StrippedBasketRequestItem, basket: Basket | null) => {
  if (!basket || !basket.raf) return undefined;

  let raf: RafRequestParams | undefined;
  if (planItem) {
    const catalogCodesInBasket = getRafCatalogCodesFromBasket(basket.packages);

    // construct RAF request only if the catalogCode of item being added does not already exist in the Basket
    raf = checkIfRafRequiresUpdate(catalogCodesInBasket, planItem.catalogCode)
      ? createRafUpsertRequest(basket.raf.rafCode, planItem.catalogCode)
      : undefined;
  }

  return raf;
};

export const getRemainingCatalogCodes = (
  packageId: string,
  rafEligiblePackagesInBasket?: { [packageId: string]: CatalogCode },
) => {
  return rafEligiblePackagesInBasket
    ? Object.entries(rafEligiblePackagesInBasket)
        .filter(([pkgId]) => pkgId !== packageId)
        .map(([, catalogCode]) => catalogCode as CatalogCode)
    : [];
};

export const getAlertData = (alerts: Alert[], id: string) => {
  return alerts.find((alert) => alert.alertId === id);
};
