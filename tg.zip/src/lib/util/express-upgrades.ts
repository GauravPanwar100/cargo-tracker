import { DeviceImage, MorePlanInfo, Offers, OffersList, TermsAndConditionsContent } from '@src/lib/api/types';
import { Flag } from '@src/lib/context/feature-flags';
import {
  enrichTextWithAttributes,
  formatDate,
  formatGSTInclusiveAmount,
  parseDateString,
} from '@src/lib/util/formatUtils';
import { AEMSasPromotionCodeMap, SchemaCategory } from '@src/lib/ci360/schema';
import { EXPRESS_JOURNEY_SLUGS, ExpressJourneySlug, MorePlanInfoIdentifier } from '@src/lib/constants/express';
import { formatEUDeviceRRPPrice } from '@src/lib/util/number-formatter';
import { CI360SpotAttributes } from '@src/lib/ci360/ci360';

interface DisplayOffer {
  offer_code: string;
  expiry_date: string;
}

export function isExpressJourneySlug(journey: unknown): journey is ExpressJourneySlug {
  return (EXPRESS_JOURNEY_SLUGS as unknown[]).includes(journey);
}

export const EXPRESS_UPGRADES_JOURNEY_DISABLED_FLAG_MAP: { [Journey in ExpressJourneySlug]: Flag | undefined } = {
  [ExpressJourneySlug.RPC]: Flag.DISABLE_EXPRESS_UPGRADES_REQUEST_PLAN_CHANGE,
  [ExpressJourneySlug.PHONE_AND_PLAN]: Flag.DISABLE_EXPRESS_UPGRADES_PHONE_PLAN,
  [ExpressJourneySlug.SIMO]: Flag.DISABLE_EXPRESS_UPGRADES_SIM_ONLY,
};

export const DEFAULT_INTERNATIONAL_TEXT_PLACEHOLDER = ' unlimited standard international texts.';
export const STANDARD_MINS_PLACEHODER = ' standard mins from Australia to ';
export const PLAN_TITLE_FOR_CALLS_AND_TEXTS = 'International calls and texts';
export const PLAN_TITLE_FOR_TEXTS = 'International texts';
export const FCID_MATCHER = /FCID=-4/;
export const HREF_MATCHER = /href="([^"]*)/;
export const SPOT_ID_MATCHER = /(spot_id=[\d\D]+?)\//;
export const EU_SPOT_NAMES = 'EU-1,EU-2,EU-3,EU-4';

// The below identifier is used to assign the Data attribute value in plan inclusions for express upgrade journey
export const EU_INCLUDED_DATA_ATTRIBUTE = 'AT_PLAN_DATA';

// The below is used as a constant value for 'Unlimited' value for target plans
export const UNLIMITED = 'Unlimited';

/**
 * This value with state that we are receiving an unlimited plan as offer
 * The actual value is residing in RTDM and in Siebel
 */
export const UNLIMITED_PLAN_DATA = '99999GB';

// When we get 99999 as tp_idd_zone1_min or tp_idd_zone2_min we treat that as Unlimited
export const UNLIMITED_MINS = '99999';

// GST Percentage is 10, so we multiply the price amount with 1.1 to get GST Inclusive amount
export const GST_PERCENTAGE_MULTIPLY_FACTOR = 1.1;

// Plan Data value which will be shown if cp_data value is 99999GB
export const CURRENT_PLAN_UNLIMITED_TEXT = 'Unlimited';

export const CURRENT_PLAN_DATA = 'cp_data';

export const MEGA_BYTE_IDENTIFIER = 'MB';

/**
 * It transforms an array of image urls into an array of DeviceImage object.
 * It defines the image's alt text property, removes any small image element.
 * If deviceId parameter is present it will be used to set the id property of the image tag for analytics purpose.
 *
 * @param deviceId
 * @param imageUrls
 * @returns { DeviceImage[] | undefined }
 */
export function buildCarouselImages(
  deviceId: string | undefined,
  imageUrls: string[] | undefined,
): DeviceImage[] | undefined {
  return imageUrls
    ?.filter((url) => !url.endsWith('s.png'))
    .map((largeImage, index) => {
      return {
        id: deviceId ? `eu-${deviceId}-${index}` : undefined, // For analytics purpose
        imageUrl: largeImage,
        altText: extractAltText(largeImage),
      };
    });
}

export function buildSpotJourneyAttribute(journey: string): CI360SpotAttributes {
  return EU_SPOT_NAMES.split(',').reduce((o, spotName) => {
    return {
      ...o,
      [spotName]: {
        url_path: journey,
      },
    };
  }, {});
}

// Don't try this at home :D
/**
 * It uses part of the image url to define the alt text to be used.
 * It gets the last part of it, it removes the hyphens and the file extension with the size info of the image
 * e.g.:
 * from: https://www-sit.test.cms.df.services.vodafone.com.au/images/devices/samsung/samsung-galaxy-s21/samsung-galaxy-s21-ultra-black-back-l.jpg
 * extracts: samsung galaxy s21 ultra black back
 * @param imageUrl
 * @returns { string }
 */
function extractAltText(imageUrl: string) {
  const tokens = imageUrl.split('/');
  const imgDetails = tokens[tokens.length - 1];
  const dotIndex = imgDetails.lastIndexOf('.');
  // replace hyphens and remove last bit "l.jpg"
  const altText = imgDetails
    .replaceAll('-', ' ')
    .slice(0, dotIndex - 1)
    .trim();
  return altText;
}

export function enrichHeroChinOffer(
  contents: SchemaCategory | undefined,
  offers: readonly OffersList[] | undefined,
): Array<OffersList> | null {
  let selectedOffers: OffersList | undefined;
  const heroChinOffer = [];

  if (contents?.target_device?.td_sdd_flag?.value === 'Y') {
    selectedOffers = offers?.find((item) => item.code === AEMSasPromotionCodeMap.td_sdd_flag);

    heroChinOffer.push({
      ...selectedOffers!,
      title: enrichTextWithAttributes(selectedOffers?.title || '', {
        TOTAL_DEVICE_DISCOUNT: contents?.target_device?.td_price_sdd_ttl?.template || '',
      }),
      description: enrichTextWithAttributes(selectedOffers?.description || '', {
        MONTHLY_DEVICE_DISCOUNT: contents?.target_device?.td_price_sdd_mth?.template || '',
        DEVICE_RRP: contents?.target_device?.td_rrp_ttl?.value
          ? formatEUDeviceRRPPrice(parseFloat(contents?.target_device?.td_rrp_ttl?.value))
          : '',
        AT_CONTRACT_TERM: contents?.target_device?.td_term?.template || '',
      }),
    });
  }
  if (contents?.target_plan?.tp_btl_disc_flag?.value === 'Y') {
    selectedOffers = offers?.find((item) => item.code === AEMSasPromotionCodeMap.tp_btl_disc_flag);
    const nowPrice = contents?.target_plan?.tp_price_disc_mth?.value || '0';

    const wasPrice = contents?.target_plan?.tp_price_mth?.value || '0';

    const adjustNowPrice = () => {
      const discountPrice = wasPrice && wasPrice !== '0' ? parseFloat(wasPrice) - parseFloat(nowPrice) : 0;
      return wasPrice && wasPrice !== '0'
        ? formatGSTInclusiveAmount(wasPrice) - Math.round(discountPrice)
        : formatGSTInclusiveAmount(nowPrice);
    };

    heroChinOffer.push({
      ...selectedOffers!,
      title: enrichTextWithAttributes(selectedOffers?.title || '', {
        tp_name: contents?.target_plan?.tp_name?.template || '',
        tp_price_disc_mth: adjustNowPrice().toString() || '',
      }),
      description: enrichTextWithAttributes(selectedOffers?.description || '', {
        tp_name: contents?.target_plan?.tp_name?.template || '',
        tp_price_disc_mth: adjustNowPrice().toString() || '',
        promotionEndDate: contents?.target_plan?.tp_btl_disc_exp_dt?.template || '',
      }),
    });
  }
  if (contents?.target_plan?.tp_data_bon_flag?.value === 'Y') {
    selectedOffers = offers?.find((item) => item.code === AEMSasPromotionCodeMap.tp_data_bon_flag);

    heroChinOffer.push({
      ...selectedOffers!,
      title: enrichTextWithAttributes(selectedOffers?.title || '', {
        tp_data_bon: contents?.target_plan?.tp_data_bon?.template || '',
      }),
      description: enrichTextWithAttributes(selectedOffers?.description || '', {
        tp_data_bon: contents?.target_plan?.tp_data_bon?.template || '',
        promotionEndDate: contents?.target_plan?.tp_data_bon_exp_dt?.template || '',
      }),
    });
  }
  return heroChinOffer.length > 0 ? heroChinOffer : null;
}

function enrichTradeInOffers(offerArray: readonly DisplayOffer[], offers: readonly OffersList[] | undefined) {
  const tradeInOffer: OffersList[] = [];

  offerArray?.forEach((offer) => {
    const selectedOffers = offers?.filter((item) => item.code === offer.offer_code)[0];

    if (selectedOffers && selectedOffers?.description) {
      const enrichedDescription = enrichTextWithAttributes(selectedOffers?.description || '', {
        promotionEndDate: offer.expiry_date || '',
      });
      selectedOffers.description = enrichedDescription;
    }

    if (selectedOffers?.code) {
      tradeInOffer.push(selectedOffers);
    }
  });
  return tradeInOffer;
}

// this is a combination of HeroChin and TradeInOffers
export function enrichMoreAboutYourPlan(
  contents: SchemaCategory | undefined,
  offers: readonly OffersList[] | undefined,
) {
  const enrichedOffers = [];
  const offersAttributes: DisplayOffer[] = [];
  const displayOffersWithExpiryDates = contents?.target_device?.td_dsp_offer_cd?.value?.split('|');

  displayOffersWithExpiryDates?.forEach((item: string) => {
    const offerArray = item.split('~');
    if (offerArray.length > 1) {
      const offerTitle = offerArray[0];
      const offerCode = offerTitle.includes('#') ? offerTitle.split('#')[0] : offerTitle;

      const offerDate = parseDateString(offerArray[1]);
      // [SHOP-7259] We are checking whether the offer is expired and pushing into offersAttributes only if it is not expired
      const isOfferExpired = new Date(offerDate) < new Date();

      // do we need to do the formatting again here?
      // should we handle the formatting in `parseDateString`
      if (!isOfferExpired) {
        offersAttributes.push({
          offer_code: offerCode,
          expiry_date: offerArray[1] ? formatDate(offerDate, 'dd/MM/yy') : '',
        });
      }
    }
  });
  const heroChinOffer = enrichHeroChinOffer(contents, offers);
  if (heroChinOffer) enrichedOffers.push(...heroChinOffer);
  enrichedOffers.push(...enrichTradeInOffers(offersAttributes, offers));
  return enrichedOffers.filter((eachOffer) => eachOffer.title && eachOffer.description);
}

export enum LandingPageCtaType {
  BAU = 'BAU',
  Care = 'CARE',
}

export function getUpgradeDeviceLandingPageCtaLabel(ctaType: string | undefined) {
  if (ctaType && ctaType === LandingPageCtaType.BAU) {
    return 'Continue to order';
  }

  if (ctaType && ctaType === LandingPageCtaType.Care) {
    return 'Call 1300 301 464';
  }
  return '';
}

export function callCare() {
  window.location.href = 'tel:1300301464';
}

export function getSimoRpcLandingPageCtaLabel(ctaType: string | undefined) {
  if (ctaType && ctaType === LandingPageCtaType.BAU) {
    return 'Order new plan';
  }

  if (ctaType && ctaType === LandingPageCtaType.Care) {
    return 'Call 1300 301 464';
  }
  return '';
}

export function buildExpiryDateMessage(
  morePlanInfoList: readonly MorePlanInfo[],
  ctaType: string | undefined,
  expiryDate: string | undefined,
) {
  if (ctaType && expiryDate) {
    const expiryPlanInfo = getMorePlanInfo(
      morePlanInfoList,
      ctaType === LandingPageCtaType.BAU
        ? MorePlanInfoIdentifier.CAMPAIGN_EXPIRY_BAU
        : MorePlanInfoIdentifier.CAMPAIGN_EXPIRY_CARE,
    );
    if (expiryPlanInfo && expiryPlanInfo.description) {
      return enrichTextWithAttributes(expiryPlanInfo.description, { promotionEndDate: expiryDate });
    }
  }
  return '';
}

export function buildTncMessage(morePlanInfoList: readonly MorePlanInfo[], identifier: MorePlanInfoIdentifier) {
  const morePlanInfo = getMorePlanInfo(morePlanInfoList, identifier);
  let tncMessage = '';
  if (morePlanInfo) {
    tncMessage = morePlanInfo.description
      ?.replace('terms and conditions', `<a class="tnc-link" href="#">terms and conditions</a>`)
      .replace('early termination fee', `<a class="early-fee-link" href="#">early termination fee</a>`);
  }
  return tncMessage;
}

export function getMorePlanInfo(morePlanInfoList: readonly MorePlanInfo[], identifier: MorePlanInfoIdentifier) {
  return morePlanInfoList.find((planInfo) => {
    return planInfo.identifier === identifier;
  });
}

export function buildCampaignTncMessage(
  genericTnc: TermsAndConditionsContent,
  campaignOffers: Offers,
  contents: SchemaCategory,
) {
  let tncCampaignMessage = genericTnc.termsConditionsDesc;
  const targetPlan = contents?.target_plan;
  const targetDevice = contents?.target_device;

  const offersEnabled = Object.keys(AEMSasPromotionCodeMap).filter((PromoCode) => {
    if (targetPlan?.[PromoCode] && targetPlan?.[PromoCode]?.value === 'Y') return PromoCode;
    if (targetDevice?.[PromoCode] && targetDevice?.[PromoCode]?.value === 'Y') return PromoCode;

    return '';
  });

  // eslint-disable-next-line array-callback-return
  const aemOfferPlans = campaignOffers?.offersList.filter((cOffer) => {
    // eslint-disable-next-line guard-for-in, consistent-return
    for (const key of offersEnabled) {
      if (cOffer.code === AEMSasPromotionCodeMap[key as keyof typeof AEMSasPromotionCodeMap]) {
        return true;
      }
    }
    return false;
  });

  for (const aemOffer of aemOfferPlans) {
    tncCampaignMessage += aemOffer.termsConditionsDesc;
  }
  /** Block to handle multiple offers listed in td_dsp_offer_cd */
  if (targetDevice?.td_dsp_flag?.value === 'Y') {
    const tdDispOfferCd = targetDevice!.td_dsp_offer_cd?.value;

    const dispOffersList = tdDispOfferCd!.split('|');

    const aemOfferDisp = campaignOffers?.offersList.filter((cOffer) => {
      for (const dispOffer of dispOffersList) {
        let offerCode = '';
        if (dispOffer.includes('#')) {
          [offerCode] = dispOffer.split('#');
        } else [offerCode] = dispOffer.split('~');
        if (cOffer.code === offerCode) {
          return true;
        }
      }
      return false;
    });

    for (const offer of aemOfferDisp) {
      tncCampaignMessage += offer.termsConditionsDesc;
    }
  }

  return tncCampaignMessage;
}
