import React, { useEffect } from 'react';
import { Auth0ClientOptions } from '@auth0/auth0-spa-js';
import Cookies from 'universal-cookie';
import cuid from 'cuid';
import Head from 'next/head';
import cookies from 'next-cookies';
import NextApp, {
  AppContext as NextAppContext,
  AppInitialProps as NextAppInitialProps,
  AppProps as NextAppProps,
} from 'next/app';
import { useRouter } from 'next/router';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import smoothscroll from 'smoothscroll-polyfill';
import styled, { ThemeProvider } from 'styled-components';
import { ModalProvider } from 'styled-react-modal';
import 'react-day-picker/lib/style.css'; // only used with Preview
import GlobalStyles from '@src/components/core/GlobalStyles';
import PreviewMode from '@src/components/core/PreviewMode';
import HeaderLayout from '@src/components/layouts/HeaderLayout';
import FooterLayout from '@src/components/layouts/FooterLayout';
import AcnBanner from '@src/components/vfe/AcnBanner';
import SamsungBanner from '@src/components/vfe/SamsungBanner';
import IdleModal from '@src/components/vfe/IdleModal';
import { ModalResponse, NavigationResponse } from '@src/lib/api/types';
import { AuthenticationProvider, ServiceTypeContext } from '@src/lib/context/authentication';
import { BasketProvider } from '@src/lib/context/basket';
import { FeatureFlagDisableAllJourneys, FeatureFlagsProvider } from '@src/lib/context/feature-flags';
import { GlobalModal, ModalDataProvider } from '@src/lib/context/modal';
import { RouteMetaProvider } from '@src/lib/context/route-meta';
import Logger from '@src/lib/logger/logger';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { lightTheme } from '@src/lib/theme';
import NewRelic from '@src/lib/tracking/newRelic';
import AppStore from '@src/lib/util/app-store';
import { ERROR_PAGE_URL } from '@src/lib/util/error';
import { preview } from '@src/lib/util/preview';
import { isServiceOfType } from '@src/lib/util/customer';
import { isUpgradesRoute } from '@src/lib/util/journey';
import { CustomerDataProvider } from '@src/lib/context/customer-data';
import { LocalStorageClient } from '@src/lib/storage';
import { getApiClient } from '@src/lib/api/api';
import { SasProvider } from '@src/lib/context/sas-provider';
import { HeaderDataProvider } from '@src/lib/context/header-data';
import { GlobalContentDataProvider } from '@src/lib/context/global-content';
import { isHeadlessRoute, safeRouterReplace } from '@src/lib/util/router';
import useAsyncLoadStyleSheet from '@src/lib/hooks/use-style';
import { QueryKey } from '@src/lib/util/query';
import { setGASessionValue } from '@src/lib/util/upgradeHub';

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  // Safari does not support ScrollToOptions or scroll behavior
  smoothscroll.polyfill();
}

interface AppProps {
  navigation?: NavigationResponse;
  modalResponse?: ModalResponse;
  ssrServiceType?: string;
}

const ModalBackgroundOverride = styled.div`
  display: flex;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 830;
  background-color: rgba(0, 0, 0, 0.5);
  align-items: center;
  justify-content: center;
`;

const App = ({ Component, pageProps, navigation, modalResponse, ssrServiceType }: AppProps & NextAppProps) => {
  const router = useRouter();
  const headless = isHeadlessRoute(router.asPath);
  const version = process.env.NEXT_PUBLIC_VERSION;

  useAsyncLoadStyleSheet('/webcomponent/css/global.css');
  useAsyncLoadStyleSheet('/webcomponent/css/webcomponent.bundle.css');

  const auth0Options: Auth0ClientOptions = {
    domain: process.env.AUTH0_CLIENT_DOMAIN || 'auth01.test.iam.services.vodafone.com.au',
    client_id: (() => {
      // For integration tests, we allow Cypress to set the auth0_client_id in localStorage
      if (typeof window !== 'undefined' && 'Cypress' in window) {
        const clientId = localStorage.getItem('auth0_client_id');
        if (clientId) return clientId;
      }
      return process.env.AUTH0_CLIENT_ID || 'Sr58zy4uUE9sMAn40MQK5K7rxuUXct25';
    })(),
    redirect_uri: process.env.AUTH0_REDIRECT_URI || 'http://localhost:3000/auth/callback',
    audience: process.env.AUTH0_AUDIENCE || 'https://dev01-integrationapi.test.cms.df.services.vodafone.com.au/',
    cacheLocation: 'localstorage',
    scope: 'openid profile email offline_access',
    useRefreshTokens: true,
  };

  // Check whether the cart is expired (and hence we clear the local
  // storage keys and notify the header component)
  useEffect(() => {
    LocalStorageClient.checkCartExpired();
  });
  useEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    if (queryParams.has(QueryKey.CLEARCART)) {
      queryParams.delete(QueryKey.CLEARCART);
      LocalStorageClient.clearCheckoutCart();
      LocalStorageClient.clearDisplayedCartStorage();
      LocalStorageClient.removeBasketId();
      safeRouterReplace({
        search: queryParams.toString(),
      });
    }

    // Set GA session key
    setGASessionValue();
  });

  return (
    <AuthenticationProvider options={auth0Options}>
      <CustomerDataProvider>
        <ThemeProvider theme={lightTheme}>
          <RouteMetaProvider router={router}>
            <FeatureFlagsProvider>
              <FeatureFlagDisableAllJourneys />
              <BasketProvider>
                <GlobalContentDataProvider>
                  <ModalProvider backgroundComponent={ModalBackgroundOverride}>
                    <ServiceTypeContext.Consumer>
                      {([serviceType]) => {
                        // Use ServiceTypeContext value if available, falling back on the SSR cookie value if
                        // present. This allows the upgrades header to render server side to prevent flashing
                        // between main/upgrade header on hydration
                        const headerKey =
                          isUpgradesRoute(router.pathname) ||
                          isServiceOfType(serviceType ?? ssrServiceType, ServiceTypeValue.Upgrade)
                            ? 'upgrades'
                            : 'main';
                        return (
                          <>
                            <Head>
                              <meta name="version-hash" content={version} />
                            </Head>
                            {!router.pathname.includes('iframe') && preview && <PreviewMode />}
                            <GlobalStyles />
                            <SasProvider path={router.pathname}>
                              {!headless && navigation && <HeaderLayout headerLinks={navigation[headerKey].header} />}
                              <HeaderDataProvider navigation={navigation}>
                                <AcnBanner />
                                <SamsungBanner />
                                <ModalDataProvider modals={modalResponse?.modals || []}>
                                  <Component {...pageProps} />
                                  {modalResponse && <GlobalModal />}
                                </ModalDataProvider>
                              </HeaderDataProvider>
                              {!headless && navigation && <FooterLayout footerLinks={navigation[headerKey].footer} />}
                            </SasProvider>
                            {!headless && <IdleModal idleLogoutMinutes={20} idleWarningMinutes={3} />}
                            {navigation &&
                              navigation[headerKey].includes.map((include) => {
                                if (include.type === 'text/javascript') {
                                  return <script key={include.name} src={include.source} type="text/javascript" />;
                                }
                                if (include.type === 'text/css') {
                                  return (
                                    <link href={include.source} key={include.name} rel="stylesheet" type="text/css" />
                                  );
                                }
                                return null;
                              })}
                          </>
                        );
                      }}
                    </ServiceTypeContext.Consumer>
                  </ModalProvider>
                </GlobalContentDataProvider>
              </BasketProvider>
            </FeatureFlagsProvider>
          </RouteMetaProvider>
        </ThemeProvider>
      </CustomerDataProvider>
    </AuthenticationProvider>
  );
};

App.getInitialProps = async (appContext: NextAppContext): Promise<NextAppInitialProps & AppProps> => {
  const ApiClient = getApiClient(appContext.ctx);
  appContext.ctx.res?.setHeader('Cache-Control', 'public');

  // It is possible for the cookie to not have been set
  // we cannot set a cookie server side as it would affect caching
  // so in this case we generate a dummy uuid.
  const e2eSessionId = cookies(appContext.ctx).e2eSessionId ?? cuid();
  AppStore.setE2eSessionId(e2eSessionId);
  AppStore.setXInitialSystem(process.env.X_INITIAL_SYSTEM ?? 'UNDEFINED');
  AppStore.setXInitialComponent(process.env.X_INITIAL_COMPONENT ?? 'UNDEFINED');
  Logger.info('Starting App getInitialProps', { ucode: '1f7b9a4' });

  // This may not be 100% accurate for SSR and we will know for certain client-side, but this allows
  // us to make a UX optimisation and avoid flashing between headers for the majority of renders.
  const ssrServiceType = new Cookies(appContext.ctx.req?.headers.cookie).get<string | undefined>('vfe.servicetype', {
    doNotParse: true,
  });

  // Parallelise requests
  const [navigation, modals, initialAppProps] = await Promise.all([
    // Navigation and Modals are nonessential - keep AEM fonts in VFE
    ApiClient.fetchNavigation().catch(() => undefined),
    ApiClient.fetchModals().catch(() => undefined),
    // page props are essential
    NextApp.getInitialProps(appContext),
  ]);

  // in all getInitialProps failures, errors are caught and an error returned to be captured here
  if (initialAppProps.pageProps && initialAppProps.pageProps.error) {
    if (typeof window === 'undefined') {
      // eslint-disable-next-line no-unused-expressions
      appContext.ctx?.res
        ?.writeHead(302, {
          Location: ERROR_PAGE_URL,
        })
        .end();
    }
    return {
      navigation,
      ssrServiceType,
      pageProps: { error: initialAppProps.pageProps.error },
    };
  }

  const appProps: NextAppInitialProps & AppProps = {
    navigation,
    modalResponse: modals,
    ssrServiceType,
    ...initialAppProps,
  };
  if (typeof window !== 'undefined') {
    setTimeout(() => {
      NewRelic.setCurrentRouteName(window.location.href);
    });
  }
  return appProps;
};

export default App;
