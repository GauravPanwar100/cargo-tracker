import React from 'react';
import { NextPage } from 'next';
import Section from '@src/components/core/Section';
import SeoHead from '@src/components/vfe/SeoHead';
import { Grid, GridCol } from '@src/components/core/Grid';
import Text from '@src/components/core/Text';

interface ErrorPageProps {
  statusCode: number;
}

const Error: NextPage<ErrorPageProps> = ({ statusCode }) => (
  <>
    <SeoHead title={`${statusCode}`} aemMetaTags='&lt;meta name="robots" content="noindex,nofollow" /&gt;' />
    <main>
      <Section>
        <Grid>
          <GridCol>
            <Text as="h1" textAlign="center">
              {statusCode}
            </Text>
          </GridCol>
        </Grid>
      </Section>
    </main>
  </>
);

Error.getInitialProps = ({ res, err }) => {
  let statusCode = 500;
  if (res) {
    statusCode = res.statusCode;
  } else if (err && err.statusCode) {
    statusCode = err.statusCode;
  }
  return { statusCode };
};

export default Error;
