import React from 'react';
import { NextPage, NextPageContext } from 'next';
import { useRouter } from 'next/router';
import { getApiClient } from '@src/lib/api';
import { stripQueryFromPath } from '@src/lib/util/url';
import { UpgradesPageResponse } from '@src/lib/api/types';
import useServiceType from '@src/lib/hooks/use-service-type';
import { ServiceTypeValue } from '@src/lib/storage/types';
import UpgradesTemplate from '@src/templates/Upgrades';
import RedirectTemplate from '@src/templates/common/RedirectTemplate';
import SeoHead from '@src/components/vfe/SeoHead';
import { redirectFlags } from '@src/lib/context/feature-flags';
import { useTrackPage } from '@src/lib/tracking';

interface UpgradesPageProps {
  error?: string;
  pageData?: UpgradesPageResponse;
  push?: string; // as in push notification
}

const UpgradesPage: NextPage<UpgradesPageProps> = ({ pageData, push }) => {
  useServiceType(ServiceTypeValue.Upgrade);

  const router = useRouter();
  const path = stripQueryFromPath(router.asPath);

  useTrackPage({
    pageTitle: pageData?.pageHeaderData.seoTitle || '',
    path,
    nudgeReferrer: path,
  });

  if (pageData) {
    return (
      <>
        <SeoHead
          title={pageData.pageHeaderData.seoTitle}
          aemMetaTags={pageData.pageHeaderData.metaTags}
          structuredData={pageData.pageHeaderData.seoData}
        />
        <UpgradesTemplate pageData={pageData} push={push} redirectFlag={redirectFlags.UPGRADE} />
      </>
    );
  }

  return <RedirectTemplate />;
};

UpgradesPage.getInitialProps = async (context: NextPageContext): Promise<UpgradesPageProps> => {
  const { query } = context;
  try {
    const pageData = await getApiClient(context).fetchUpgradesPageData();
    return { pageData, push: query?.push as string | undefined };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
  } catch (e: any) {
    return { error: e.message };
  }
};

export default UpgradesPage;
