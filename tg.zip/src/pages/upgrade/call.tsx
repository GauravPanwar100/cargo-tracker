import React from 'react';
import { NextPage, NextPageContext } from 'next';
import { getApiClient } from '@src/lib/api';
import { UpgradesPageResponse } from '@src/lib/api/types';
import RedirectTemplate from '@src/templates/common/RedirectTemplate';
import Ineligible from '@src/templates/common/Ineligible';

interface UpgradesErrorPageProps {
  error?: string;
  pageData?: UpgradesPageResponse;
}

const UpgradesErrorPage: NextPage<UpgradesErrorPageProps> = ({ pageData }) => {
  if (pageData?.pageHeaderData) {
    const { ctaHomeLabel, onlineUpgradeError } = pageData.pageHeaderData;
    return <Ineligible alertText={onlineUpgradeError} ctaLabel={ctaHomeLabel} type="upgrade" />;
  }

  return <RedirectTemplate />;
};

UpgradesErrorPage.getInitialProps = async (context: NextPageContext): Promise<UpgradesErrorPageProps> => {
  try {
    const pageData = await getApiClient(context).fetchUpgradesPageData();
    return { pageData };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
  } catch (e: any) {
    return { error: e.message };
  }
};

export default UpgradesErrorPage;
