import React, { useState } from 'react';
import { NextPage, NextPageContext } from 'next';
import { useRouter } from 'next/router';
import { Journey, JourneyStep } from '@src/components/core/Journey';
import StickyCart from '@src/components/vfe/StickyCart';
import { getApiClient } from '@src/lib/api';
import {
  BasketRequestItem,
  CartItemType,
  CatalogCode,
  OnlinePromoContentParams,
  OptimizeContentKey,
  PlanEndpoint,
  PlansPageResponse,
  PromoAvailibilityResponse,
  PromoSubtype,
} from '@src/lib/api/types';
import { PostpaidSIMOPlan } from '@src/lib/constants/journeys';
import { Flag, VFE_OMEGA_ENVIRONMENT, redirectFlags } from '@src/lib/context/feature-flags';
import { StickyCartProvider } from '@src/lib/context/sticky-cart';
import useServiceType from '@src/lib/hooks/use-service-type';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { useCustomerEligibility } from '@src/lib/util/customer';
import { onBeforeGoToExtrasStep } from '@src/lib/util/extras';
import { previewGetOptionalDate } from '@src/lib/util/preview';
import { QueryKey, buildPlanFromQuery } from '@src/lib/util/query';
import AdditionalServicesTitleSection from '@src/templates/AdditionalServices/AdditionalServicesTitleSection';
import RedirectTemplate from '@src/templates/common/RedirectTemplate';
import ExtrasTemplate from '@src/templates/Extras';
import PlansTemplate from '@src/templates/Plans';
import { updatePlanQueryOnNextStep } from '@src/templates/Plans/utils';
import FeatureClient from '@src/lib/omega-flagger/client-library';

interface ModemSimOPlansPageProps {
  plansPageData?: PlansPageResponse;
  extraOffer?: string;
  promoAvailability?: PromoAvailibilityResponse;
}

const ModemSimOPlansPage: NextPage<ModemSimOPlansPageProps> = ({ plansPageData, extraOffer, promoAvailability }) => {
  useServiceType(ServiceTypeValue.AnotherService);
  useCustomerEligibility();

  const { query } = useRouter();
  const [isStudentOfferValidated, setIsStudentOfferValidated] = useState(false);

  if (!plansPageData) {
    return <RedirectTemplate />;
  }

  const studentOfferValidationHandler = () => {
    setIsStudentOfferValidated(true);
  };
  const onlinePromoContentParams: OnlinePromoContentParams = {
    catalogCode: CatalogCode.POSTPAID_MBB_MODEM_SIMO_PLANS,
    promoAvailability: promoAvailability?.availability ?? false,
    optimizeContentKey: OptimizeContentKey.PLAN_ONLINE_OFFER,
  };

  return (
    <StickyCartProvider defaultState={{ itemTypes: [CartItemType.PLAN, CartItemType.EXTRA] }}>
      <AdditionalServicesTitleSection />
      <Journey>
        <JourneyStep
          initialProps={{ pageData: plansPageData }}
          onBeforeGoToNextStep={onBeforeGoToExtrasStep}
          render={({ goToNextStep, initialProps: { pageData }, isLoadingStep, step, bnsOffer }) => (
            <PlansTemplate
              bnsOffer={bnsOffer}
              goToNextStep={goToNextStep}
              isLoading={isLoadingStep}
              nudgeVariant="voiceSimO"
              pageData={pageData}
              redirectFlag={redirectFlags.POSTPAID_MBB_MODEM_SIMO}
              step={step}
              extraOffer={extraOffer}
              studentOfferValidationHandler={studentOfferValidationHandler}
              onlinePromoContentParams={onlinePromoContentParams}
            />
          )}
          step={PostpaidSIMOPlan.PLAN}
          updateQueryOnNextStep={updatePlanQueryOnNextStep}
        />
        <JourneyStep
          buildCartFromQuery={async (basketItems?: BasketRequestItem[]) => {
            const plan = buildPlanFromQuery({
              catalogCode: CatalogCode.POSTPAID_MBB_MODEM_SIMO_PLANS,
              plans: plansPageData.planListing.plans,
              query,
            });
            return [...(basketItems ?? []), plan];
          }}
          getInitialProps={async () => {
            const planProductCode = query[QueryKey.PLAN] as string;
            const pageData = await getApiClient().fetchExtrasPageData({
              params: [{ catalogCode: CatalogCode.POSTPAID_MBB_MODEM_SIMO_PLANS, productCode: planProductCode }],
            });
            return { pageData };
          }}
          queryKeysToClearOnPreviousStep={[QueryKey.PLAN]}
          render={({ goToPreviousStep, initialProps: { pageData }, step }) => (
            <ExtrasTemplate
              backLabel={`${pageData.pageHeaderData.breadcrumb} to Plans`}
              backOnClick={goToPreviousStep}
              pageData={pageData}
              redirectFlag={redirectFlags.POSTPAID_MBB_MODEM_SIMO}
              step={step}
              isStudentOfferValidated={isStudentOfferValidated}
            />
          )}
          step={PostpaidSIMOPlan.EXTRAS}
          validateQuery={[QueryKey.PLAN]}
        />
      </Journey>
      <StickyCart />
    </StickyCartProvider>
  );
};

ModemSimOPlansPage.getInitialProps = async (context: NextPageContext) => {
  const { query } = context;
  let extraOffer = query?.[QueryKey.EXTRA] as string;
  const ApiClient = getApiClient(context);

  // First we are checking whether the extra offer is student
  // If yes then we are checking the feature toggle value
  // If toggle returns true then we are setting the extraOffer as empty so that the same is not sent to plans API
  if (extraOffer === PromoSubtype.Student) {
    const featureClient = new FeatureClient();
    featureClient.setEnvironment(VFE_OMEGA_ENVIRONMENT);
    const isStudentJourneyDisabled = await featureClient.getFeatureToggle(
      `${VFE_OMEGA_ENVIRONMENT.env}-${VFE_OMEGA_ENVIRONMENT.appVersion}-${VFE_OMEGA_ENVIRONMENT.configVersion}-${Flag.STUDENT_OFFER}`,
    );
    if (isStudentJourneyDisabled) extraOffer = '';
  }
  try {
    const [pageData, promoAvailability] = await Promise.all([
      ApiClient.fetchPlansPageData({
        date: previewGetOptionalDate(query), // preview mode only, pass optional date parameter
        planEndpoint: PlanEndpoint.POSTPAID_MBB_MODEM_SIMO,
        delay: Number(query.delay),
        extraOffer,
      }),
      ApiClient.fetchPromoAvailability({
        subType: PromoSubtype.OnlineBTL,
        planEndpoint: PlanEndpoint.POSTPAID_MBB_MODEM_SIMO,
      }),
    ]);

    return { plansPageData: pageData, extraOffer, promoAvailability };
  } catch {
    return {};
  }
};

export default ModemSimOPlansPage;
