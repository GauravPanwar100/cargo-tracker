import { NextPage, NextPageContext } from 'next';
import React from 'react';
import { getApiClient } from '@src/lib/api';
import { AdditionalServicesPageResponse } from '@src/lib/api/types';
import RedirectTemplate from '@src/templates/common/RedirectTemplate';
import Ineligible from '@src/templates/common/Ineligible';

interface AdditionalServiceErrorPageProps {
  error?: string;
  pageData?: AdditionalServicesPageResponse;
}

const AdditionalServiceErrorPage: NextPage<AdditionalServiceErrorPageProps> = ({ pageData }) => {
  const alertText = pageData?.header.alerts.find(({ alertId }) => alertId === 'no-additionalservice-online')?.alertText;
  if (alertText) {
    return <Ineligible alertText={alertText} ctaLabel="Go to Home" type="additional-service" />;
  }

  return <RedirectTemplate />;
};

AdditionalServiceErrorPage.getInitialProps = async (
  context: NextPageContext,
): Promise<AdditionalServiceErrorPageProps> => {
  try {
    const pageData = await getApiClient(context).fetchAdditionalServicesPageData();
    return { pageData };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
  } catch (e: any) {
    return { error: e.message };
  }
};

export default AdditionalServiceErrorPage;
