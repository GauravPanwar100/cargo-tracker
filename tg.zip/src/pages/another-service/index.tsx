import React from 'react';
import { NextPage, NextPageContext } from 'next';
import { useRouter } from 'next/router';
import { getApiClient } from '@src/lib/api';
import { stripQueryFromPath } from '@src/lib/util/url';
import { AdditionalServicesPageResponse } from '@src/lib/api/types';
import AdditionalServicesPageTemplate from '@src/templates/AdditionalServices';
import RedirectTemplate from '@src/templates/common/RedirectTemplate';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import SeoHead from '@src/components/vfe/SeoHead';
import useServiceType from '@src/lib/hooks/use-service-type';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { useCustomerEligibility } from '@src/lib/util/customer';
import { redirectFlags } from '@src/lib/context/feature-flags';
import { useTrackPage } from '@src/lib/tracking';
import { QueryKey } from '@src/lib/util/query';

interface AdditionalServicesTemplateProps {
  error?: string;
  pageData?: AdditionalServicesPageResponse;
}

const AdditionalServicesPage: NextPage<AdditionalServicesTemplateProps> = ({ pageData }) => {
  useServiceType(ServiceTypeValue.AnotherService);

  const { asPath, query } = useRouter();
  const path = stripQueryFromPath(asPath);

  useTrackPage({
    pageTitle: pageData?.header.seoTitle || '',
    path,
    nudgeReferrer: (query[QueryKey.NUDGE_REFERRER] || '').toString(),
  });

  const { loading } = useCustomerEligibility();

  if (!pageData) return <RedirectTemplate />;

  return (
    <>
      <SeoHead
        title={pageData.header.seoTitle}
        aemMetaTags={pageData.header.metaTags}
        structuredData={pageData.header.seoData}
      />
      {loading ? (
        <SpinnerSection />
      ) : (
        <AdditionalServicesPageTemplate pageData={pageData} redirectFlag={redirectFlags.ANOTHER_SERVICE} />
      )}
    </>
  );
};

AdditionalServicesPage.getInitialProps = async (context: NextPageContext) => {
  try {
    // eslint-disable-next-line max-len
    const pageData: AdditionalServicesPageResponse = await getApiClient(context).fetchAdditionalServicesPageData();
    return {
      pageData,
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
  } catch (error: any) {
    return { error: error.message };
  }
};

export default AdditionalServicesPage;
