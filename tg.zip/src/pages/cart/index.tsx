/* eslint-disable no-console */
import { ElementType } from '@kablamo/kerosene';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { NextPage, NextPageContext } from 'next';
import SeoHead from '@src/components/vfe/SeoHead';
import { getApiClient } from '@src/lib/api';
import {
  AddToBasketParams,
  Basket,
  BasketItem,
  CartPageResponse,
  CatalogCode,
  OnlinePromoContentParams,
  OptimizeContentKey,
  PlanEndpoint,
  PrepaidCatalogCodes,
  RafAction,
  RafAppliedItem,
  RemovePackageFromBasketParams,
} from '@src/lib/api/types';
import { useSetModal } from '@src/lib/context/modal';
import { useBasketState } from '@src/lib/context/basket';
import { Flag, isPlanTypeDisabled, useFeatureFlag, useFeatureFlags } from '@src/lib/context/feature-flags';
import useImperativeData from '@src/lib/hooks/use-imperative-data';
import useServiceType from '@src/lib/hooks/use-service-type';
import useASDEligibility from '@src/lib/hooks/use-asd-eligibility';
import { LocalStorageClient, SessionStorageClient } from '@src/lib/storage';
import { trackEvent } from '@src/lib/tracking';
import {
  accumulateMinCost,
  flattenBasket,
  getPackageCatalogCodesFromBundle,
  getRafUpdateParamsForDeepLinkedPlans,
  isBasketWithExpiredItems,
  isNbnPlan,
  isPlanBasketItem,
} from '@src/lib/util/cart';
import { safeRouterPush, useClientQuery, useUpdateQuery } from '@src/lib/util/router';
import { QueryKey, buildStrippedPlanFromQuery, mapPlanTypeToCatalogCode } from '@src/lib/util/query';
import { isElementInViewport } from '@src/lib/util/dom';
import { useCustomerData } from '@src/lib/context/customer-data';
import { isServiceOfType, useCustomerEligibility } from '@src/lib/util/customer';
import CartTemplate from '@src/templates/Cart';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import { decoratePathWithQueries } from '@src/lib/util/url';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { dismissBnsPackageCart, keepBnsPackageCart, removeBnsPackageCart } from '@src/lib/util/tracking';
import { SimProductCode } from '@src/lib/util/sim-selection';
import { filterFixedBundle } from '@src/lib/util/filterFixedBundle';

interface CartPageProps {
  pageData: CartPageResponse;
  extraOffer?: string;
}

/**
 * As per VFE-1689, this includes postpaid SIMO and prepaid plans only
 */
const VALID_PLAN_ENDPOINTS_FOR_DEEPLINKING = [
  PlanEndpoint.POSTPAID_SIMO,
  PlanEndpoint.TABLET_SIMO,
  PlanEndpoint.PREPAID_COMBO_PLUS,
  PlanEndpoint.PREPAID_PAY_AND_GO,
] as const;

const isValidPlanTypeForDeepLinking = (
  planType: unknown,
): planType is ElementType<typeof VALID_PLAN_ENDPOINTS_FOR_DEEPLINKING> =>
  (VALID_PLAN_ENDPOINTS_FOR_DEEPLINKING as readonly unknown[]).includes(planType);

const CartPage: NextPage<CartPageProps> = ({ pageData, extraOffer }) => {
  const acnFeatureDisabled = useFeatureFlag(Flag.DISABLE_ACN);
  if (acnFeatureDisabled.data != null && !acnFeatureDisabled.data) {
    LocalStorageClient.setPartnerDetails();
  }
  const ApiClient = getApiClient();
  const { getBasket, getBasketState, setBasket } = useBasketState();
  const [packageIdToRemove, setPackageIdToRemove] = useState<string | null>(null);
  const [addToBasketState, addToBasket] = useImperativeData<AddToBasketParams, Basket>(ApiClient.addToBasket);
  const [removePackageFromBasketState, removePackageFromBasket] = useImperativeData<
    RemovePackageFromBasketParams,
    Basket
  >(ApiClient.removePackageFromBasket);

  const query = useClientQuery();
  const continueToCheckoutImmediately = query?.[QueryKey.CONTINUE] === 'true';
  const updateQuery = useUpdateQuery();
  const { customerBundleAndSaveCount, activeService } = useCustomerData();
  const [serviceType] = useServiceType();
  const { eligibilityIndicator } = activeService || {};
  const applyDiscount =
    LocalStorageClient.getIsExistingCustomerFrom1SQ() || filterFixedBundle(getBasketState.data?.packages);
  const isHomeInternetASDEligible = useASDEligibility();
  const disableAsdCopy = !!useFeatureFlag(Flag.DISABLE_ASD_PRESENTATION_UPLIFT).data;
  const onContinueToCheckout = useCallback(() => {
    if (!getBasketState.data) return;
    const items = flattenBasket(getBasketState.data.packages);
    trackEvent({
      pageEventType: 'button',
      pageEventValue: 'click',
      pageEventAttributeOne: 'checkout',
      pageEventAttributeThree: 'continued-to-checkout',
      basketSize: getBasketState.data?.packages.length,
      catalogueNames: items?.map((item) => item.productName),
      transactionAmount: accumulateMinCost(items),
    });
    LocalStorageClient.setCheckoutCart(getBasketState.data, pageData.cartSummary.disclaimer);
    if (!disableAsdCopy) {
      LocalStorageClient.setHomeInternetASDEligibility(isHomeInternetASDEligible);
    }
    safeRouterPush(decoratePathWithQueries('/checkout', [QueryKey.NUDGE_REFERRER]));
  }, [disableAsdCopy, getBasketState.data, isHomeInternetASDEligible, pageData.cartSummary.disclaimer]);

  // Cart RAF data
  const [rafAppliedItem, setRafAppliedItem] = useState<RafAppliedItem | null>(null);
  const [rafEligiblePackagesInBasket, setRafEligiblePackagesInBasket] = useState<{ [packageId: string]: CatalogCode }>(
    {},
  );
  const [showRafTransferredAlert, setShowRafTransferredAlert] = useState(false);

  const disableReferAFriend = useFeatureFlag(Flag.DISABLE_REFER_A_FRIEND).data;

  useEffect(() => {
    // Skip this step if RAF is toggled off.
    if (disableReferAFriend === null || disableReferAFriend) return;
    if (serviceType !== ServiceTypeValue.NewAcquisition) return;
    const bundles = getBasketState.data?.packages;
    if (bundles && bundles.length > 0) {
      const rafPackagesInBasket = getPackageCatalogCodesFromBundle(bundles);
      setRafEligiblePackagesInBasket(rafPackagesInBasket);
    }
  }, [disableReferAFriend, getBasketState.data?.packages, serviceType]);

  const updateRafAppliedItemInCart = useCallback((item: RafAppliedItem | null) => {
    setRafAppliedItem(item);
  }, []);

  const { loading, error: eligibilityError } = useCustomerEligibility(
    getBasketState.data?.packages ? flattenBasket(getBasketState.data.packages) : undefined,
  );

  // set loading state if the customer is not eligibile and is trying to upgrade
  const isLoading =
    loading || (isServiceOfType(serviceType, ServiceTypeValue.Upgrade) && eligibilityIndicator === false);

  // Load basket after eligibility check is ready
  // NOTE: It is important to wait for the eligibility check to complete as there is a potential race condition for the
  // scenario where a prepaid customer is trying to upgrade from the cart splitter, and is logged out shortly after the
  // basket starts rebuilding for the `Upgrade` service type, even though it should remain as `New` and the customer
  // attempts to proceed to checkout before the basket has rebuilt.
  const hasLoadedBasket = useRef(false);
  useEffect(() => {
    if (loading || hasLoadedBasket.current) return;
    hasLoadedBasket.current = true;

    const basketId = LocalStorageClient.getBasketId();

    if (!basketId) return;
    if (extraOffer) {
      getBasket({ basketId, extraOffer });
    } else {
      getBasket({ basketId });
    }
  }, [getBasket, loading, query, extraOffer]);

  useEffect(() => {
    if (continueToCheckoutImmediately && getBasketState.data) {
      onContinueToCheckout();
    }
  }, [continueToCheckoutImmediately, getBasketState.data, onContinueToCheckout]);

  // Only persist the cart data when it does not have expired items
  useEffect(() => {
    if (!isBasketWithExpiredItems(getBasketState?.data?.packages)) {
      LocalStorageClient.setDisplayedCartStorage(getBasketState.data);
    }

    // After addToCart/ GetBasket/ Remove item from cart, getBasketState?.data affected
  }, [getBasketState.data]);
  const onlinePromoContentParams: OnlinePromoContentParams = {
    catalogCode: CatalogCode.CART_PROMO_OFFER,
    promoAvailability: getBasketState?.data ? getBasketState?.data?.onlinePromotionAvailability ?? false : false,
    optimizeContentKey: OptimizeContentKey.CART,
  };
  // Add plan on deeplink to cart page
  const omega = useFeatureFlags();
  const [flags, getAllFlags] = useImperativeData(omega.getAllFlags);
  useEffect(() => {
    getAllFlags();
  }, [getAllFlags]);

  useEffect(() => {
    // TODO: VFE-2330 Show some sort of spinner whilst/while we are waiting to add these items to cart
    const addPlanToCart = async () => {
      const planId = query?.[QueryKey.PLAN];
      const planType = query?.[QueryKey.PLAN_TYPE];
      if (query && typeof planId === 'string' && isValidPlanTypeForDeepLinking(planType) && flags.data) {
        // ignore deeplink if the planType has a corresponding journey that is disabled by a feature flag
        if (isPlanTypeDisabled(planType, flags.data)) return;

        const { planListing, secondaryPlanListing } = await getApiClient().fetchPlansPageData({
          planEndpoint: planType,
        });

        // If there are no matching plans, do nothing
        if (![...planListing.plans, ...(secondaryPlanListing?.plans ?? [])].some((plan) => plan.planId === planId))
          return;

        const catalogCode = mapPlanTypeToCatalogCode(planType);
        if (catalogCode) {
          const defaultChildProduct = PrepaidCatalogCodes.includes(catalogCode) ? SimProductCode.PSIM : null;
          const plan = buildStrippedPlanFromQuery({
            catalogCode,
            query,
            defaultChildProduct,
          });
          const response: Basket | undefined = await addToBasket({
            items: [plan],
            additionalBnsCount: customerBundleAndSaveCount,
            raf: getBasketState.data ? getRafUpdateParamsForDeepLinkedPlans(plan, getBasketState.data) : undefined,
          });
          if (!response) return;

          LocalStorageClient.setBasketId(response.basketId);
          LocalStorageClient.setDisplayedCartStorage(response);
          setBasket(response);
        }

        // Remove query string
        const clearedQuery: Partial<Record<QueryKey, undefined>> = Object.fromEntries(
          [QueryKey.PLAN, QueryKey.PLAN_TYPE].map((key) => [key, undefined]),
        );
        updateQuery(clearedQuery, 'replace');
      }
    };

    addPlanToCart();
  }, [addToBasket, setBasket, query, updateQuery, flags.data, customerBundleAndSaveCount, getBasketState.data]);

  const titleRef = useRef<HTMLDivElement>(null);

  const clearCart = useCallback(() => {
    LocalStorageClient.removeBasketId();
    LocalStorageClient.clearDisplayedCartStorage();
    setBasket(null);
  }, [setBasket]);

  const removePackageFromBasketById = useCallback(
    async (packageId: string, raf?: { action: RafAction; rafCatalogCodes: Array<CatalogCode>; rafCode: string }) => {
      trackEvent({
        pageEventType: 'button',
        pageEventValue: 'click',
        pageEventAttributeOne: 'remove',
        pageEventAttributeThree: 'item-removed-from-cart',
      });

      setPackageIdToRemove(packageId);

      // Only remove NBN context when the package being removed is the sole NBN plan in basket.
      if (
        getBasketState.data!.packages.find((pkg) => pkg.packageId === packageId)?.items.some(isNbnPlan) &&
        getBasketState.data!.packages.filter((pkg) => pkg.items.some(isNbnPlan)).length === 1
      ) {
        LocalStorageClient.removeNbnContext();
      }

      // Remove the student offer validation information from localstorage when student offer validated item is removed from cart
      if (
        LocalStorageClient.getStudentOfferInfo().planId &&
        getBasketState
          .data!.packages.find((pkg) => pkg.packageId === packageId)
          ?.items.some((item) => item.productCode === LocalStorageClient.getStudentOfferInfo().planId)
      ) {
        LocalStorageClient.clearStudentOfferInfo();
      }

      if (getBasketState.data?.packages.length === 1) {
        clearCart();
        SessionStorageClient.cleanupRafAttemptCount();
        SessionStorageClient.cleanupRafOfferData();
      }

      const response = await removePackageFromBasket({
        basketId: getBasketState.data!.basketId,
        packageId,
        additionalBnsCount: customerBundleAndSaveCount,
        raf,
      });

      if (!response) {
        if (titleRef.current && !isElementInViewport(titleRef.current)) {
          window.scrollTo({
            behavior: 'smooth',
            left: 0,
            top: titleRef.current.offsetTop,
          });
        }

        return;
      }

      if (response.packages.length) {
        LocalStorageClient.setBasketId(response.basketId);
        LocalStorageClient.setDisplayedCartStorage(response);
        setBasket(response);

        // Apply RAF according to appliedCatCode in response.
        if (response.raf && response.raf.isValid === true) {
          if (response.raf.appliedCatalogCode && response.raf.discountAmount && response.raf.rafCode) {
            if (response.raf.appliedCatalogCode !== rafAppliedItem?.catalogCode) {
              setShowRafTransferredAlert(true);
            }
            // packageIds may have changed in the response, therefore the RAF applied item's packageId must be updaqted in the new state.
            setRafAppliedItem({
              packageId: '',
              catalogCode: response.raf.appliedCatalogCode,
              discountAmount: response.raf.discountAmount,
              rafCode: response.raf.rafCode,
            });
          }
        } else {
          // Handle invalid RAF code - removed RAF scenario.
          console.log('Existing RAF code was invalid, show Removed RAF alert.');
        }
      } else {
        clearCart();
        SessionStorageClient.cleanupRafAttemptCount();
        SessionStorageClient.cleanupRafOfferData();
      }
    },
    [
      clearCart,
      customerBundleAndSaveCount,
      getBasketState.data,
      rafAppliedItem?.catalogCode,
      removePackageFromBasket,
      setBasket,
    ],
  );

  const setGlobalModal = useSetModal();

  const onRemoveFromBasket = useCallback(
    async (packageId: string, raf?: { action: RafAction; rafCatalogCodes: Array<CatalogCode>; rafCode: string }) => {
      if (!getBasketState.data) return;

      const packageToRemove = getBasketState.data.packages.find((pkg) => pkg.packageId === packageId);
      const plan = packageToRemove?.items.find(isPlanBasketItem) as BasketItem;
      if (!!plan && plan.productType === 'Plan - Fixed') {
        LocalStorageClient.clearIsExistingCustomerFrom1SQ();
      }
      const totalBnSCount = getBasketState.data.packages.filter((pkg) =>
        pkg.items.some((item) => item.isBundleAndSaveEligible),
      ).length;
      if (
        isServiceOfType(serviceType, ServiceTypeValue.NewAcquisition) &&
        packageToRemove &&
        packageToRemove.items.some((item) => item.isBundleAndSaveEligible) &&
        totalBnSCount === 2
      ) {
        setGlobalModal({
          id: 'remove-cart-items',
          isOpen: true,
          onClose: () => {
            trackEvent(dismissBnsPackageCart);
            setGlobalModal('');
          },
          cancelCtaAction: () => {
            trackEvent(keepBnsPackageCart);
            setGlobalModal('');
          },
          confirmCtaAction: () => {
            trackEvent(removeBnsPackageCart);
            removePackageFromBasketById(packageId, raf);
            setGlobalModal('');
          },
        });
      } else {
        removePackageFromBasketById(packageId, raf);
      }
    },
    [getBasketState.data, removePackageFromBasketById, serviceType, setGlobalModal],
  );

  if (isLoading) {
    return <SpinnerSection />;
  }

  return (
    <>
      <SeoHead title={pageData.seoTitle} aemMetaTags={pageData.metaTags} structuredData={pageData.seoData} />
      {(!query || continueToCheckoutImmediately) && <SpinnerSection />}
      {!!query && !continueToCheckoutImmediately && (
        <CartTemplate
          getBasketState={getBasketState}
          eligibilityError={eligibilityError}
          addToBasketState={addToBasketState}
          removePackageFromBasketState={removePackageFromBasketState}
          onContinueToCheckout={onContinueToCheckout}
          onRemoveFromBasket={onRemoveFromBasket}
          packageIdToRemove={packageIdToRemove}
          pageData={pageData}
          titleRef={titleRef}
          isHomeInternetASDEligible={isHomeInternetASDEligible}
          applyDiscount={applyDiscount}
          disableAsdCopy={disableAsdCopy}
          checkoutSplitterGroups={pageData.checkoutSplitterGroups}
          checkoutSplitterLogo={pageData.checkoutSplitterLogo}
          onlinePromoContentParams={onlinePromoContentParams}
          rafEligiblePackagesInBasket={rafEligiblePackagesInBasket}
          updateRafAppliedItemInCart={updateRafAppliedItemInCart}
          rafAppliedItemInCart={rafAppliedItem}
          showRafTransferredAlert={showRafTransferredAlert}
          updateShowRafTransferredAlert={setShowRafTransferredAlert}
        />
      )}
    </>
  );
};

CartPage.getInitialProps = async (context: NextPageContext) => {
  const { query } = context;
  const extraOffer = query?.[QueryKey.EXTRA] as string;
  const pageData = await getApiClient(context).fetchCartPageData();
  return { pageData, extraOffer };
};

export default CartPage;
