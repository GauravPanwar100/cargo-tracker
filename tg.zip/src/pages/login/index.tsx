import React, { useEffect } from 'react';
import useAuthentication from '@src/lib/hooks/use-authentication';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { QueryKey } from '@src/lib/util/query';

const Login: React.FC = () => {
  const { isAuthenticated, loading, login } = useAuthentication();
  useEffect(() => {
    if (!isAuthenticated && !loading) {
      login(ServiceTypeValue.AnotherService, {
        cmp: new URLSearchParams(window.location.search).get(QueryKey.CMP) ?? undefined,
        DealerCode: new URLSearchParams(window.location.search).get(QueryKey.DEALER_CODE) ?? undefined,
        AgentID: new URLSearchParams(window.location.search).get(QueryKey.AGENT_ID) ?? undefined,
      });
    }
    // TODO: What happens when the user is logged in? Can we remove this file?
  }, [isAuthenticated, loading, login]);
  return null;
};

export default Login;
