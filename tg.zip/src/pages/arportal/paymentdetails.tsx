import { Grid, GridCol } from '@src/components/core/Grid';
import Text from '@src/components/core/Text';
import Section from '@src/components/core/Section';
import { SubmitHandler, useForm } from 'react-hook-form';
import Input from '@src/components/core/Input';

import { NextPage } from 'next';
import Head from 'next/head';
import React, { useState } from 'react';
import { Label } from '@src/components/core/Field/Field.styles';
import IconWrapper from '@src/components/core/IconWrapper';

import { ReactComponent as Logo } from '@src/assets/svg/logo.svg';
import Button from '@src/components/core/Button';
import Alert from '@src/components/core/Alert';
import PageSpinner from '@src/components/core/PageSpinner';

const ARCheckout: NextPage = () => {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormFields>();

  // alert is not showing now as the submit button will be disabled when input is empty
  // Do we need to keep the headers/navigation and footers on the page?
  // implement functionality of mastercard/visa payment (no other APM is required)
  // payment section should be in a separate div with margin top
  // for the payment section, MyVF portal is using https://github.com/VodafoneAustralia/myvf-widgets/pkgs/npm/myvf-widgets-payment
  // a loading overlay/modal appears after clicking submit for now set to 5 seconds but should be authenticating the invoice number via related api
  // payment form section at line 200 to be implemented

  const [invoiceNo, setInvoiceNo] = useState<string | undefined>(undefined);

  const onSubmit: SubmitHandler<FormFields> = (data) => {
    setInvoiceNo(data.InvoiceNumber);
    // eslint-disable-next-line no-console
    console.log(invoiceNo);
    // eslint-disable-next-line no-console
    console.log(data.InvoiceNumber);
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        resolve();
      }, 5000);
    });
  };
  type FormFields = {
    InvoiceNumber: string;
  };
  return (
    <Section backgroundColorValue="#ebebeb">
      <Head>
        <title>Payment | Vodafone Australia</title>
        <meta name="title" content="Payment | Vodafone Australia" />
        <meta name="robots" content="noindex, nofollow" />
      </Head>
      {isSubmitting ? (
        <Section
          displayValue="flex"
          backgroundColorValue="#ebebeb"
          zIndexValue="9999"
          positionValue="relative"
          fixedWidth="100%"
          fixedHeight="100%"
        >
          <Section
            displayValue="flex"
            flexDirectionValue="column"
            alignItemsValue="center"
            fixedWidth="100%"
            backgroundColorValue="#ebebeb"
          >
            <Section backgroundColorValue="transparent" spacingBottom="none">
              <Text
                fontFamily="light"
                fontSize={{ xs: 'heading2Mobile', m: 'heading2Tablet', l: 'heading2' }}
                lineHeight="heading2"
                marginBottom="10px"
              >
                Processing the request
              </Text>
            </Section>
            <Section backgroundColorValue="transparent">
              <PageSpinner active={isSubmitting} width={96} height={96} position="relative">
                <div />
              </PageSpinner>
              <Section alignItemsValue="center" backgroundColorValue="transparent">
                <Text
                  fontFamily="light"
                  fontSize={{ xs: 'heading4Mobile', m: 'heading4Tablet', l: 'heading4' }}
                  lineHeight="heading4"
                  marginTop="110px"
                >
                  Please don&apos;t leave this page
                </Text>
              </Section>
            </Section>
          </Section>
        </Section>
      ) : (
        <>
          <Section
            spacingLeft={{ xs: 'xs', l: 's' }}
            backgroundColorValue="#ffffff"
            spacingBottom={{ xs: 'xs', l: 's' }}
            spacingTop={{ xs: 'xs', l: 's' }}
            margin="auto"
            fixedWidth={{ l: '960px' }}
            boxShadowValue="3px 0px 3px rgba(0, 0, 0, 0.16)"
          >
            <Grid>
              <GridCol display="flex" gridColStart="2">
                <IconWrapper display="flex" svg={Logo} width="48px" height="48px" />
                <Text fontSize="heading4" marginLeft="10px" marginTop="10px">
                  Credit Card Payment
                </Text>
              </GridCol>
            </Grid>
          </Section>
          <Section
            margin="20px auto"
            fixedWidth={{ l: '960px' }}
            fixedHeight={{ l: 'content-fit' }}
            spacingTop={{ xs: 'xs', l: 'xs' }}
            spacingBottom={{ xs: 'xs', l: 'none' }}
            spacingLeft={{ xs: 'xs', l: 'l' }}
            boxShadowValue="3px 6px 3px rgba(0, 0, 0, 0.16)"
          >
            <Grid>
              <GridCol width="100%" display={{ xs: 'block', l: 'flex' }} gridColStart="2">
                <Section spacingLeft={{ xs: 'xs', m: 'l' }} spacingTop="none" spacingBottom={{ xs: 'xxs', m: 's' }}>
                  <form>
                    <Label size="medium" htmlFor="inputID">
                      <Text marginBottom="5px">Invoice No.</Text>
                      <Input
                        defaultValue=""
                        name="InvoiceNumber"
                        ref={register({ required: '* Invoice number is required' })}
                        id="inputID"
                        onChange={(event: React.ChangeEvent<HTMLInputElement>) => setInvoiceNo(event.target.value)}
                        size={60}
                        borderRadiusValue="3px"
                        value={invoiceNo}
                      />
                    </Label>
                    <p />
                    {errors?.InvoiceNumber ? (
                      <Alert size="m" variant="error" marginBottom="10px">
                        <p>{errors.InvoiceNumber.message}</p>
                      </Alert>
                    ) : null}
                  </form>
                </Section>
                <Section
                  spacingTop={{ xs: `none`, l: `s` }}
                  spacingRight={{ xs: `15px`, l: `l` }}
                  spacingLeft={{ xs: `none`, l: `30px` }}
                >
                  <Grid grid-auto-flow="row" gridCols={5}>
                    <GridCol
                      width="100%"
                      display="flex"
                      gridColStart={{ xs: 1, m: 5, l: 1 }}
                      gridColSpan={{ xs: 10, m: 1, l: 10 }}
                      columnGap={{ xs: `10px`, m: `16px` }}
                    >
                      <Button
                        type="submit"
                        variant="primary"
                        fixedHeight="48px"
                        fixedWidth={{ xs: '500px', m: '150px' }}
                        borderRadius="1px"
                        onClick={handleSubmit(onSubmit)}
                        size="l"
                        disabled={!invoiceNo || isSubmitting || undefined}
                      >
                        Submit
                      </Button>
                      <Button
                        type="reset"
                        value="Cancel"
                        variant="lightGrey"
                        fixedHeight="48px"
                        borderRadius="1px"
                        size="l"
                      >
                        Cancel
                      </Button>
                    </GridCol>
                  </Grid>
                </Section>
              </GridCol>
            </Grid>
          </Section>
        </>
      )}
      {/* 
        <Section
          margin="20px auto"
          fixedWidth={{ l: '960px' }}
          fixedHeight={{ l: 'content-fit' }}
          spacingTop={{ xs: 'xs', l: 'xs' }}
          spacingBottom={{ xs: 'xs', l: 'xs' }}
          spacingLeft={{ xs: 'xs', l: 'l' }}
          boxShadowValue="3px 6px 3px rgba(0, 0, 0, 0.16)"
        >
          <Grid>
            <GridCol width="100%" display={{ xs: 'block', l: 'flex' }} gridColStart="2">
              <p>payment form section</p>
            </GridCol>
          </Grid>
        </Section>
       */}
    </Section>
  );
};

export default ARCheckout;
