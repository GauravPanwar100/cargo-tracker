import React from 'react';
import Document, { DocumentContext, Head, Html, Main, NextScript } from 'next/document';
import { resetId } from 'react-id-generator';
import { ServerStyleSheet } from 'styled-components';
import sanitize from 'sanitize-html';

export default class MyDocument extends Document {
  public static path: string | undefined;

  static async getInitialProps(ctx: DocumentContext) {
    // This line resets the unique ID incrementer for react-id-generator
    resetId();
    this.path = ctx.asPath;
    /**
     * These lines are for styled-components server-side rendering
     */
    const sheet = new ServerStyleSheet();
    const originalRenderPage = ctx.renderPage;

    try {
      ctx.renderPage = () =>
        originalRenderPage({
          enhanceApp: (App) => (props) => sheet.collectStyles(<App {...props} />),
        });

      const initialProps = await Document.getInitialProps(ctx);
      return {
        ...initialProps,
        styles: (
          <>
            {initialProps.styles}
            {sheet.getStyleElement()}
          </>
        ),
      };
    } finally {
      sheet.seal();
    }
  }

  render() {
    // Google antiflicker snippet
    const antiflickerSnippet = `(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
    h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
    (a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
    })(window,document.documentElement,'async-hide','dataLayer',4000,
    {'GTM-PHDQDBW':true});`;
    const sanitized = sanitize(antiflickerSnippet, {
      allowedTags: false,
      allowedAttributes: false,
    });

    const gtmContainerScript = `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.vodafone.com.au/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-PHDQDBW');`;
    const sanitizedGtmContainerScript = sanitize(gtmContainerScript, {
      allowedTags: false,
      allowedAttributes: false,
    });

    // Optimizely snippet
    const optimizelySnippet = `(function() {
    var a = 24176680311
      , c = "https:" == document.location.protocol ? "https://" : "http://"
      , b = document.createElement("script");
    b.type = "text/javascript";
    b.async = !!0;
    b.src = c + "www.vodafone.com.au/js/" + a + ".js";
    a = document.getElementsByTagName("script")[0];
    a.parentNode.insertBefore(b, a)})();`;
    const sanitizedOptimizelyScript = sanitize(optimizelySnippet, {
      allowedTags: false,
      allowedAttributes: false,
    });

    return (
      <Html lang="en">
        <Head>
          <link rel="shortcut icon" href="/favicon.ico" />
          <link rel="apple-touch-icon" href="/images/icons/apple_touch.png" />

          <link rel="preconnect" href="https://www.googleoptimize.com" />

          <link rel="preconnect" href="https://assets.adobedtm.com" />
          <link rel="dns-prefetch" href="https://assets.adobedtm.com" />

          <link rel="preconnect" href="https://customer.cludo.com" />

          <link rel="preconnect" href="https://dfmvshcme4.execute-api.ap-southeast-2.amazonaws.com" />

          <style>{'.async-hide { opacity: 0 !important} '}</style>
          <script
            type="text/javascript"
            /* eslint-disable-next-line react/no-danger */
            dangerouslySetInnerHTML={{ __html: sanitizedOptimizelyScript }}
          />
          <script
            type="text/javascript"
            /* eslint-disable-next-line react/no-danger */
            dangerouslySetInnerHTML={{ __html: sanitized }}
            async={true}
          />

          <script
            type="text/javascript"
            /* eslint-disable-next-line react/no-danger */
            dangerouslySetInnerHTML={{ __html: sanitizedGtmContainerScript }}
            defer={true}
          />
          {!MyDocument.path?.includes('iframe') && (
            <script
              type="text/javascript"
              src="//assets.adobedtm.com/06d8ea8ef14f/9d165c2e431d/launch-43db4402be86.min.js"
              defer={true}
            />
          )}
        </Head>
        <body>
          <noscript>
            <iframe
              src="https://www.vodafone.com.au/ns.html?id=GTM-PHDQDBW"
              height="0"
              width="0"
              title="gtm-no-script"
              style={{ display: 'none', visibility: 'hidden' }}
            />
          </noscript>
          <Main />
          <NextScript />
          {this.props.styles}
          <script type="text/javascript" src="/common/js/common.bundle.js" />
        </body>
      </Html>
    );
  }
}
