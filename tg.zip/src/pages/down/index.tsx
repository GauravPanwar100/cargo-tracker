import React from 'react';
import { NextPage, NextPageContext } from 'next';
import ErrorTemplate from '@src/templates/common/Error';
import SeoHead from '@src/components/vfe/SeoHead';

interface DownPageProps {}

const DownPage: NextPage<DownPageProps> = () => {
  return (
    <>
      <SeoHead
        title="Something didn’t go as planned | Vodafone Australia"
        aemMetaTags='&lt;meta name="robots" content="noindex,nofollow" /&gt;'
      />
      <ErrorTemplate title="Something didn’t go as planned">
        Unfortunately we can’t show our plans or devices at the moment. Please try again later.
      </ErrorTemplate>
    </>
  );
};

export const getServerSideProps = async (context: NextPageContext) => {
  if (context.res) {
    context.res.statusCode = 500;
  }
  return {
    props: {},
  };
};

export default DownPage;
