import React from 'react';
import { NextPage, NextPageContext } from 'next';
import { useRouter } from 'next/router';
import { Journey, JourneyStep } from '@src/components/core/Journey';
import StickyCart from '@src/components/vfe/StickyCart';
import { getApiClient } from '@src/lib/api';
import {
  BasketRequestItem,
  CartItemType,
  CatalogCode,
  DeviceEndpoint,
  PlanEndpoint,
  PlansPageResponse,
} from '@src/lib/api/types';
import { PostpaidPlanAndMobilePhone } from '@src/lib/constants/journeys';
import { redirectFlags } from '@src/lib/context/feature-flags';
import { withStickyCartProvider } from '@src/lib/context/sticky-cart';
import useServiceType from '@src/lib/hooks/use-service-type';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { isDeviceBasketItem } from '@src/lib/util/cart';
import { useCustomerEligibility } from '@src/lib/util/customer';
import { onBeforeGoToExtrasStep } from '@src/lib/util/extras';
import { previewGetOptionalDate } from '@src/lib/util/preview';
import { QueryKey, buildDeviceFromQuery, buildPlanFromQuery } from '@src/lib/util/query';
import AdditionalServicesTitleSection from '@src/templates/AdditionalServices/AdditionalServicesTitleSection';
import RedirectTemplate from '@src/templates/common/RedirectTemplate';
import DeviceTemplate from '@src/templates/Device';
import DevicesTemplate from '@src/templates/Devices';
import ExtrasTemplate from '@src/templates/Extras';
import PlansTemplate from '@src/templates/Plans';
import { updatePlanQueryOnNextStep } from '@src/templates/Plans/utils';
import { useRouteMeta } from '@src/lib/context/route-meta';
import PageSpinner from '@src/components/core/PageSpinner';

interface PostpaidPlanAndPhonePageProps {
  plansPageData?: PlansPageResponse;
}

const PostpaidPlanAndPhonePage: NextPage<PostpaidPlanAndPhonePageProps> = ({ plansPageData }) => {
  useServiceType(ServiceTypeValue.AnotherService);
  useCustomerEligibility();

  const { query } = useRouter();

  const { isJourneyUpdating } = useRouteMeta();

  if (!plansPageData) {
    return <RedirectTemplate />;
  }

  return (
    <>
      <PageSpinner active={isJourneyUpdating}>
        <AdditionalServicesTitleSection />
        <Journey>
          <JourneyStep
            initialProps={{ pageData: plansPageData }}
            render={({ goToNextStep, initialProps: { pageData }, isLoadingStep, step, bnsOffer }) => (
              <PlansTemplate
                bnsOffer={bnsOffer}
                goToNextStep={goToNextStep}
                isLoading={isLoadingStep}
                nudgeVariant="phoneAndPlan"
                pageData={pageData}
                redirectFlag={redirectFlags.MOBILE_PHONES}
                step={step}
              />
            )}
            step={PostpaidPlanAndMobilePhone.PLAN}
            updateQueryOnNextStep={updatePlanQueryOnNextStep}
          />
          <JourneyStep
            buildCartFromQuery={async (baseCart, bnsOffers) => {
              const plan = buildPlanFromQuery(
                {
                  catalogCode: CatalogCode.POSTPAID_HANDSET_PLANS,
                  plans: plansPageData.planListing.plans,
                  query,
                },
                bnsOffers?.plans,
              );
              return [plan];
            }}
            getInitialProps={async () => {
              const pageData = await getApiClient().fetchDevicesPageData({
                deviceEndpoint: DeviceEndpoint.PHONE,
                delay: Number(query.delay),
              });
              return { pageData };
            }}
            isInterimStep={true}
            queryKeysToClearOnPreviousStep={[QueryKey.PLAN]}
            render={({ goToNextStep, goToPreviousStep, initialProps: { pageData }, step }) => (
              <DevicesTemplate
                backOnClick={goToPreviousStep}
                goToNextStep={goToNextStep}
                nudgeVariant="phoneAndPlan"
                pageData={pageData}
                redirectFlag={redirectFlags.MOBILE_PHONES}
                step={step}
              />
            )}
            step={PostpaidPlanAndMobilePhone.MOBILE_PHONES}
            validateQuery={[QueryKey.PLAN]}
          />
          <JourneyStep
            getInitialProps={async () => {
              const deviceId = query[QueryKey.DEVICE] as string;
              const pageData = await getApiClient().fetchDevicePageData({
                deviceEndpoint: DeviceEndpoint.PHONE,
                deviceId,
              });
              return { pageData };
            }}
            onBeforeGoToNextStep={onBeforeGoToExtrasStep}
            queryKeysToClearOnPreviousStep={[
              QueryKey.DEVICE,
              QueryKey.DEVICE_CAPACITY,
              QueryKey.DEVICE_COLOR,
              QueryKey.DEVICE_CONTRACT_TERM,
            ]}
            render={({ goToNextStep, goToPreviousStep, initialProps: { pageData }, step }) => (
              <DeviceTemplate
                backOnClick={goToPreviousStep}
                catalogCode={CatalogCode.POSTPAID_HANDSETS}
                ctaLabel={pageData.labels.altCtaLabel}
                goToNextStep={goToNextStep}
                nudgeVariant="phoneAndPlan"
                pageData={pageData}
                redirectFlag={redirectFlags.MOBILE_PHONES}
                step={step}
              />
            )}
            step={PostpaidPlanAndMobilePhone.MOBILE_PHONE}
            validateQuery={[QueryKey.DEVICE, QueryKey.PLAN]}
          />
          <JourneyStep
            buildCartFromQuery={async (basketItems?: BasketRequestItem[]) => {
              const deviceId = query[QueryKey.DEVICE] as string;
              const { deviceConfig, deviceDetails, promotions } = await getApiClient().fetchDevicePageData({
                deviceEndpoint: DeviceEndpoint.PHONE,
                deviceId,
              });

              const device = await buildDeviceFromQuery({
                catalogCode: CatalogCode.POSTPAID_HANDSETS,
                deviceConfig,
                deviceDetails,
                promotions,
                query,
              });

              return [...(basketItems ?? []), device];
            }}
            getInitialProps={async (basketItems?: BasketRequestItem[]) => {
              const mobilePhone = basketItems?.find(isDeviceBasketItem);

              // Use the product code instead of the device slug for all calls that aren't /device/postpaid
              const planProductCode = query[QueryKey.PLAN] as string;
              const mobilePhoneProductCode = mobilePhone!.productCode;
              const pageData = await getApiClient().fetchExtrasPageData({
                params: [
                  { catalogCode: CatalogCode.POSTPAID_HANDSET_PLANS, productCode: planProductCode },
                  { catalogCode: CatalogCode.POSTPAID_HANDSETS, productCode: mobilePhoneProductCode },
                ],
              });
              return { pageData };
            }}
            render={({ goToPreviousStep, initialProps: { pageData }, step, stickyCart }) => (
              <ExtrasTemplate
                backLabel={`Back to ${stickyCart?.find(isDeviceBasketItem)?.productName}`}
                backOnClick={goToPreviousStep}
                pageData={pageData}
                redirectFlag={redirectFlags.MOBILE_PHONES}
                step={step}
              />
            )}
            step={PostpaidPlanAndMobilePhone.EXTRAS}
            validateQuery={[QueryKey.DEVICE, QueryKey.PLAN]}
          />
        </Journey>
        <StickyCart />
      </PageSpinner>
    </>
  );
};

const WrappedPostpaidPlanAndPhonePage: NextPage<PostpaidPlanAndPhonePageProps> = withStickyCartProvider({
  itemTypes: [CartItemType.PLAN, CartItemType.DEVICE, CartItemType.EXTRA],
})(PostpaidPlanAndPhonePage);

WrappedPostpaidPlanAndPhonePage.getInitialProps = async (context: NextPageContext) => {
  const { query } = context;
  try {
    const pageData = await getApiClient(context).fetchPlansPageData({
      date: previewGetOptionalDate(query), // preview mode only, pass optional date parameter
      planEndpoint: PlanEndpoint.POSTPAID,
      delay: Number(query.delay),
    });
    return { plansPageData: pageData };
  } catch {
    return {};
  }
};

export default WrappedPostpaidPlanAndPhonePage;
