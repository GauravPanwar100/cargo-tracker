import { NextPage } from 'next';
import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import { ThemeProvider } from 'styled-components';
import { Section } from '@src/components/core/Section/Section.styles';
import { Grid, GridCol } from '@src/components/core/Grid';
import { IframeContainer } from '@src/components/core/IframeContainer';
import PersistentOrderSummary from '@src/components/vfe/PersistentOrderSummary';
import { OmniEventMessage } from '@src/lib/api/types';
import { useCustomerData } from '@src/lib/context/customer-data';
import useServiceType from '@src/lib/hooks/use-service-type';
import { LocalStorageClient } from '@src/lib/storage';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { midTheme } from '@src/lib/theme';
import { isServiceOfType } from '@src/lib/util/customer';
import Modal from '@src/components/core/Modal';
import IframeResizer from 'iframe-resizer-react';
import { showCheckoutSurvey } from '@src/lib/util/omni-event-parser';
import { useBasketState } from '@src/lib/context/basket';
import { onpopstateOverride, stepUpdateMessageHandler } from '@src/lib/util/omni-step-event-handler';
import { safeRouterPush } from '@src/lib/util/router';
import StudentOfferBanner from '@src/components/vfe/StudentOfferBanner/StudentOfferBanner';
import { checkStudentOfferApplicable } from '@src/lib/util/student';
import { Flag, useFeatureFlag } from '@src/lib/context/feature-flags';

const Checkout: NextPage = () => {
  const [serviceType] = useServiceType();
  const { getBasket, getBasketState } = useBasketState();
  const [showSurveyModalId, setShowSurveyModalId] = useState<string | undefined>(undefined);
  const omniWrapperRef = React.useRef<HTMLElement | null>(null);
  const [omniIframe, setOmniIframe] = useState<HTMLIFrameElement | null>(null);
  // TODO: Do we want to show a loading spinner if we're waiting for this data
  const {
    currentServiceData: [currentServiceData],
  } = useCustomerData();
  const upgradeCost = isServiceOfType(serviceType, ServiceTypeValue.Upgrade)
    ? currentServiceData.data?.phone?.balanceAmount
    : undefined;

  useEffect(() => {
    LocalStorageClient.setCheckoutUrls();
    return () => {
      LocalStorageClient.clearCheckoutUrls();
    };
  }, []);

  // We cant add our own ref to the iframe resizer so we have to find the iframe via a parent ref
  useEffect(() => {
    if (omniWrapperRef.current) {
      let iframe: HTMLIFrameElement | null = omniWrapperRef.current.querySelector('#iFrameResizer0');
      if (!iframe) {
        iframe = omniWrapperRef.current.querySelector('iframe');
      }
      setOmniIframe(iframe);
    }
  }, [omniWrapperRef]);

  useEffect(() => {
    const loadScript = () => {
      if (omniIframe?.contentWindow) {
        const obScriptEl = document.createElement('script');
        obScriptEl.src = 'https://www.vodafone.com.au/js/ot-all.min.js';
        obScriptEl.setAttribute('data-efname', 'ci360');
        obScriptEl.setAttribute('data-a', `${process.env.SAS_TENANT_ID}`);
        obScriptEl.setAttribute('id', 'ob-script-async');
        obScriptEl.setAttribute('async', 'true');
        omniIframe.contentWindow.document.body.appendChild(obScriptEl);

        const sasScriptEl = document.createElement('script');
        sasScriptEl.innerHTML = `(function(ci){ var ef=window[ci]=function(){ return ef.q.push(arguments);}; ef.q=[];ef.a={}; })('ci360')`;
        sasScriptEl.setAttribute('data-a', `${process.env.SAS_TENANT_ID}`);
        sasScriptEl.setAttribute('id', 'sas-inline-script');
        sasScriptEl.setAttribute('async', 'true');
        omniIframe.contentWindow.document.body.appendChild(sasScriptEl);
      }
    };
    omniIframe?.addEventListener('load', loadScript);
  }, [omniIframe]);

  // Create event listener to override the default Omni back button handler
  useEffect(() => {
    const handler = stepUpdateMessageHandler(
      ({ name }) => name === 'WaitingPage' || name.includes('OrderSummary'),
      () => {
        if (omniIframe?.contentWindow)
          omniIframe.contentWindow.onpopstate = onpopstateOverride(() => safeRouterPush('/cart'));
      },
    );
    window.addEventListener('message', handler);

    return () => window.removeEventListener('message', handler);
  }, [omniIframe?.contentWindow]);

  // Load cart on mount
  useEffect(() => {
    const basketId = LocalStorageClient.getBasketId();

    if (basketId) {
      getBasket({ basketId });
    }
  }, [getBasket]);

  useEffect(() => {
    const handler = (event: MessageEvent<OmniEventMessage>) => {
      const orderId: string = event.data['OmniScript-Messaging']?.orderId;
      if (orderId && showCheckoutSurvey(event.data)) {
        setTimeout(setShowSurveyModalId, 7000, orderId);
      }
    };

    window.addEventListener('message', handler);

    // clean up
    return () => window.removeEventListener('message', handler);
  }, []);

  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://assets.adobedtm.com/06d8ea8ef14f/9d165c2e431d/launch-43db4402be86.min.js';
    script.async = true;
    document.head.appendChild(script);
  }, []);

  useEffect(() => {
    LocalStorageClient.clearIsExistingCustomerFrom1SQ();
  }, []);

  const cart = getBasketState.data;

  const disableStudentOffer = !!useFeatureFlag(Flag.STUDENT_OFFER).data;

  const isStudentOfferApplicable = !disableStudentOffer && checkStudentOfferApplicable(cart);

  return (
    <>
      <Head>
        <title>Checkout | Vodafone Australia</title>
      </Head>
      <div id="omnioutWrapper" data-testid="omniout-wrapper">
        {isStudentOfferApplicable && <StudentOfferBanner />}
        <ThemeProvider theme={midTheme}>
          {getBasketState && getBasketState.data && (
            <Section
              spacingTop={{ xs: 's', m: 'l' }}
              spacingBottom={{ xs: 's', m: 'l' }}
              spacingHorizontal={true}
              spacingRight={{ xs: '16px' }}
              spacingLeft={{ xs: '16px' }}
              backgroundColor={true}
              data-testid="omniout-persistent-order-summary"
            >
              <Grid>
                <GridCol>
                  <PersistentOrderSummary cart={getBasketState.data} defaultIsOpen={false} upgradeCost={upgradeCost} />
                </GridCol>
              </Grid>
            </Section>
          )}
          <Section
            spacingBottom={{ m: 'l' }}
            spacingHorizontal={false}
            backgroundColor={true}
            data-testid="omniout-iframe-container"
            ref={omniWrapperRef}
          >
            <IframeContainer srcUrl="/omniout/index.html" isCentered={true} />
          </Section>
        </ThemeProvider>
      </div>
      <Modal id="checkout-survey" isOpen={!!showSurveyModalId} onClose={() => setShowSurveyModalId(undefined)}>
        <IframeResizer
          log={false}
          src={`${process.env.CHECKOUT_SURVEY_URL}&sessionCustomText1=${showSurveyModalId}`}
          scrolling={true}
          style={{
            width: '768px',
            maxWidth: '100%',
            minWidth: '100%',
            height: '610px',
            maxHeight: '100%',
            borderWidth: '0px',
          }}
        >
          Iframe Wrapper
        </IframeResizer>
      </Modal>
    </>
  );
};

Checkout.getInitialProps = async ({ res }) => {
  /*
   * res is only passed by next.js when rendering server side
   * This allows us to block all direct links to the checkout page, and send to /cart.
   * Client side links will pass through still as res will be undefined.
   */
  if (res) {
    res.writeHead(303, {
      Location: '/cart',
    });
    res.end();
    return {};
  }
  return {};
};

export default Checkout;
