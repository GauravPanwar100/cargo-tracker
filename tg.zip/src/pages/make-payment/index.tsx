import { NextPage } from 'next';
import React from 'react';
import MakePaymentTemplate from '@src/templates/MakePayment/MakePaymentTemplate';
import { redirectFlags } from '@src/lib/context/feature-flags';

const MakePaymentPage: NextPage = () => {
  return <MakePaymentTemplate redirectFlag={redirectFlags.MAKE_PAYMENT} />;
};

export default MakePaymentPage;
