import { compact } from 'lodash';
import { NextPage } from 'next';
import Link from 'next/link';
import React from 'react';
import { Accordion, AccordionItemDesktopOpen } from '@src/components/core/Accordion';
import ArticleContainer from '@src/components/core/ArticleContainer';
import DescriptionList from '@src/components/core/DescriptionList';
import { Grid, GridCol } from '@src/components/core/Grid';
import Section from '@src/components/core/Section';
import { WaiAccordion, WaiAccordionItem } from '@src/components/core/WaiAccordion';
import { UNLIMITED_PLAN_DATA } from '@src/lib/util/express-upgrades';

const Home: NextPage = () => (
  <main>
    <Section>
      <Grid>
        <GridCol>
          <ArticleContainer>
            <h2>VFE</h2>
          </ArticleContainer>
        </GridCol>
      </Grid>
      <Grid rowGap={0}>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen title="Postpaid">
              <DescriptionList>
                <dt>Device Led</dt>
                <dd>
                  <Link href="/mobile/mobile-phones" passHref={true}>
                    <a>/mobile/mobile-phones</a>
                  </Link>
                </dd>
                <dd>
                  <Link href="/mobile/mobile-phones?brand=samsung_apple&sort=priceLow" passHref={true}>
                    <a>/mobile/mobile-phones?brand=samsung_apple&sort=priceLow</a>
                  </Link>
                </dd>
                <dt>SIM Only</dt>
                <dd>
                  <Link href="/mobile/sim-only-phone-plans" passHref={true}>
                    <a>/mobile/sim-only-phone-plans</a>
                  </Link>
                </dd>
                <dd>
                  <Link href="/mobile/sim-only-phone-plans/small-plan" passHref={true}>
                    <a>
                      <b>Small plan: </b>/mobile/sim-only-phone-plans/small-plan
                    </a>
                  </Link>
                  <br />
                  <Link href="/mobile/sim-only-phone-plans/medium-plan" passHref={true}>
                    <a>
                      <b>Medium plan: </b>/mobile/sim-only-phone-plans/medium-plan
                    </a>
                  </Link>
                  <br />
                  <Link href="/mobile/sim-only-phone-plans/large-plan" passHref={true}>
                    <a>
                      <b>Large plan: </b>/mobile/sim-only-phone-plans/large-plan
                    </a>
                  </Link>
                </dd>
                <dt>Tablet</dt>
                <dd>
                  <Link href="/mobile/tablets" passHref={true}>
                    <a>/mobile/tablets</a>
                  </Link>
                </dd>
                <dt>Tablet SIM Only</dt>
                <dd>
                  <Link href="/mobile/sim-only-tablet-plans" passHref={true}>
                    <a>/mobile/sim-only-tablet-plans</a>
                  </Link>
                </dd>
                <dt>Modem</dt>
                <dd>
                  <Link href="/mobile/modems" passHref={true}>
                    <a>/mobile/modems</a>
                  </Link>
                </dd>
                <dt>Modem SIM Only</dt>
                <dd>
                  <Link href="/mobile/sim-only-modem-plans" passHref={true}>
                    <a>/mobile/sim-only-modem-plans</a>
                  </Link>
                </dd>
                <dt>Student Plans</dt>
                <dd>
                  <Link href="/mobile/sim-only-phone-plans?extra=student" passHref={true}>
                    <a>/mobile/sim-only-phone-plans?extra=student</a>
                  </Link>
                </dd>
                <dt>Smart Watches</dt>
                <dd>
                  <Link href="/smart-watches" passHref={true}>
                    <a>/smart-watches</a>
                  </Link>
                </dd>
                <dt>Smart Watch Details</dt>
                <dd>
                  <Link href="/smart-watches/apple-watch-series-7" passHref={true}>
                    <a>/smart-watches/apple-watch-series-7</a>
                  </Link>
                </dd>
                <dt>Samsung SIMO - AU12478</dt>
                <dd>
                  <Link
                    href="/mobile/sim-only-phone-plans/partner-offer/samsung?partnerCode=samsung&planId=AU12478&deviceSKU=devicesku&callbackURL=https://www.samsung.com/au/&resumeURL=resumeUrl&cartUID=cartUID"
                    passHref={true}
                  >
                    <a>
                      /mobile/sim-only-phone-plans/partner-offer/samsung?partnerCode=samsung&planId=AU12478&deviceSKU=devicesku&callbackURL=https://www.samsung.com/au/&resumeURL=resumeUrl&cartUID=cartUID
                    </a>
                  </Link>
                </dd>
                <dt>Samsung SIMO - AU12479</dt>
                <dd>
                  <Link
                    href="/mobile/sim-only-phone-plans/partner-offer/samsung?partnerCode=samsung&planId=AU12479&deviceSKU=devicesku&callbackURL=https://www.samsung.com/au/&resumeURL=resumeUrl&cartUID=cartUID"
                    passHref={true}
                  >
                    <a>
                      /mobile/sim-only-phone-plans/partner-offer/samsung?partnerCode=samsung&planId=AU12479&deviceSKU=devicesku&callbackURL=https://www.samsung.com/au/&resumeURL=resumeUrl&cartUID=cartUID
                    </a>
                  </Link>
                </dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen title="NBN & Home Internet">
              <DescriptionList>
                <dt>NBN</dt>
                <dd>
                  <Link href="/home-internet/nbn" passHref={true}>
                    <a>/home-internet/nbn</a>
                  </Link>
                </dd>
                <dt>4G Home Internet</dt>
                <dd>
                  <Link href="/home-internet/4g" passHref={true}>
                    <a>/home-internet/4g</a>
                  </Link>
                </dd>
                <dt>5G Home Internet</dt>
                <dd>
                  <Link href="/home-internet/5g" passHref={true}>
                    <a>/home-internet/5g</a>
                  </Link>
                </dd>
                <dt>home-internet/plans</dt>
                <dd>
                  <Link href="/home-internet/plans" passHref={true}>
                    <a>/home-internet/plans</a>
                  </Link>
                </dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen title="Upgrades">
              <DescriptionList>
                <dt>Upgrades Hub</dt>
                <dd>
                  <Link href="/upgrade" passHref={true}>
                    <a>/upgrade</a>
                  </Link>
                </dd>
                <dd>
                  <Link href="/upgrade/plans" passHref={true}>
                    <a>/upgrade/plans</a>
                  </Link>
                </dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen title="Cart">
              <DescriptionList>
                <dt>Cart Summary</dt>
                <dd>
                  <Link href="/cart" passHref={true}>
                    <a>/cart</a>
                  </Link>
                </dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen title="Additional Services">
              <DescriptionList>
                <dt>Additional Services Hub</dt>
                <dd>
                  <Link href="/another-service" passHref={true}>
                    <a>/another-service</a>
                  </Link>
                </dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen title="Prepaid">
              <DescriptionList>
                <dt>Combo plus</dt>
                <dd>
                  <Link href="/prepaid/plans" passHref={true}>
                    <a>/prepaid/plans</a>
                  </Link>
                </dd>
                <dt>Pay and Go</dt>
                <dd>
                  <Link href="/prepaid/plans/pay-and-go" passHref={true}>
                    <a>/prepaid/plans/pay-and-go</a>
                  </Link>
                </dd>
                <dt>Device List</dt>
                <dd>
                  <Link href="/prepaid/mobile-phones" passHref={true}>
                    <a>/prepaid/mobile-phones</a>
                  </Link>
                </dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen title="Express Upgrades">
              <DescriptionList>
                <dt>Upgrade Device (Phone and Plan)</dt>
                <dd>
                  <Link href="/express/upgrade-device?hid=12345678&utm_campaign=camp614340" passHref={true}>
                    <a>/express/upgrade-device (default)</a>
                  </Link>
                  <br />
                  <br />
                  <WaiAccordion>
                    <WaiAccordionItem header={<h6>See more</h6>}>
                      <p>Supported parameters:</p>
                      <ul>
                        <li>td_sdd_flag (Y/N)</li>
                        <li>tp_btl_disc_flag (Y/N)</li>
                        <li>tp_data_bon_flag (Y/N)</li>
                        <li>cd_num_offers (0, 1, 2, 3, 4, 5)</li>
                        <li>cta_btn (Care/BAU)</li>
                        <li>td_sku</li>
                      </ul>
                      {[
                        {
                          td_sdd_flag: 'Y',
                          tp_btl_disc_flag: 'Y',
                          tp_data_bon_flag: 'Y',
                          cd_num_offers: '5',
                          td_sku: 'MGJ63X/A',
                        },
                        {
                          td_sdd_flag: 'N',
                          tp_btl_disc_flag: 'N',
                          tp_data_bon_flag: 'N',
                          cd_num_offers: '',
                          td_sku: 'HSAMGS21U128S',
                        },
                        {
                          td_sdd_flag: 'N',
                          tp_btl_disc_flag: 'N',
                          tp_data_bon_flag: 'N',
                          cd_num_offers: '1',
                          td_sku: 'MGJ63X/A',
                        },
                        {
                          td_sdd_flag: 'N',
                          tp_btl_disc_flag: 'N',
                          tp_data_bon_flag: 'N',
                          cd_num_offers: '2',
                          td_sku: 'MGJ63X/A',
                        },
                        {
                          td_sdd_flag: 'N',
                          tp_btl_disc_flag: 'N',
                          tp_data_bon_flag: 'N',
                          cd_num_offers: '3',
                          td_sku: 'MGJ63X/A',
                        },
                        {
                          td_sdd_flag: 'N',
                          tp_btl_disc_flag: 'N',
                          tp_data_bon_flag: 'N',
                          cd_num_offers: '4',
                          td_sku: 'MGJ63X/A',
                        },
                        {
                          td_sdd_flag: 'N',
                          tp_btl_disc_flag: 'N',
                          tp_data_bon_flag: 'N',
                          cd_num_offers: '5',
                          td_sku: 'MGJ63X/A',
                        },
                        {
                          td_sdd_flag: 'Y',
                          tp_btl_disc_flag: 'N',
                          tp_data_bon_flag: 'N',
                          cd_num_offers: '2',
                          td_sku: 'MGJ63X/A',
                        },
                        {
                          td_sdd_flag: 'N',
                          tp_btl_disc_flag: 'Y',
                          tp_data_bon_flag: 'N',
                          cd_num_offers: '2',
                          td_sku: 'MGJ63X/A',
                        },
                        {
                          td_sdd_flag: 'N',
                          tp_btl_disc_flag: 'N',
                          tp_data_bon_flag: 'Y',
                          cd_num_offers: '2',
                          td_sku: 'MGJ63X/A',
                        },
                        {
                          td_sdd_flag: 'Y',
                          tp_btl_disc_flag: 'Y',
                          tp_data_bon_flag: 'Y',
                          cd_num_offers: '2',
                          cta_btn: 'Care',
                          td_sku: 'MGJ63X/A',
                        },
                        {
                          td_sdd_flag: 'Y',
                          tp_btl_disc_flag: 'Y',
                          tp_data_bon_flag: 'Y',
                          cd_num_offers: '2',
                          cta_btn: 'Care',
                          td_sku: 'MGJ63X/A',
                          tp_term: '12',
                        },
                        {
                          td_sdd_flag: 'Y',
                          tp_btl_disc_flag: 'Y',
                          tp_data_bon_flag: 'Y',
                          cd_num_offers: '2',
                          cta_btn: 'BAU',
                          td_sku: 'MGJ63X/A',
                          tp_term: '12',
                          tp_data: '99999',
                        },
                      ].map((params, index) => {
                        const search = `?${new URLSearchParams({
                          hid: '12345678',
                          ...params,
                        } as Record<string, string>).toString()}`;
                        return (
                          <React.Fragment key={search}>
                            {index !== 0 && <br />}
                            {index !== 0 && <br />}
                            <Link href={`/express/upgrade-device${search}`} passHref={true}>
                              <a>
                                /express/upgrade-device (
                                {compact([
                                  params.td_sdd_flag === 'Y' && 'device discount',
                                  params.tp_btl_disc_flag === 'Y' && 'plan discount',
                                  params.tp_data_bon_flag === 'Y' && 'data bonus',
                                  `${params.cd_num_offers || '0'} offer${params.cd_num_offers === '1' ? '' : 's'}`,
                                  params.cta_btn === 'Bau' && 'BAU',
                                  params.td_sku === 'HSAMGS21U128S' && 'Samsung Galaxy S21',
                                  params.tp_term === '12' && '12 month SIMO',
                                  params.tp_data === UNLIMITED_PLAN_DATA && 'Unlimited',
                                ]).join(', ')}
                                )
                              </a>
                            </Link>
                          </React.Fragment>
                        );
                      })}
                    </WaiAccordionItem>
                  </WaiAccordion>
                </dd>

                <dt>Upgrade Plan (SIMO)</dt>

                <dd>
                  <Link href="/express/upgrade-plan?hid=12345678" passHref={true}>
                    <a>/express/upgrade-plan</a>
                  </Link>
                  <br />
                  <Link href="/express/upgrade-plan?hid=12345678&cta_btn=Care" passHref={true}>
                    <a>/express/upgrade-plan (Care CTa)</a>
                  </Link>
                  <br />
                </dd>

                <dt>Change Plan (RPC)</dt>
                <dd>
                  <Link href="/express/change-plan?hid=12345678" passHref={true}>
                    <a>/express/change-plan</a>
                  </Link>
                  <br />
                  <Link href="/express/change-plan?hid=care_cta&cta_btn=Care" passHref={true}>
                    <a>/express/change-plan (Care CTA)</a>
                  </Link>
                </dd>
                <dt>Checkout (Phone and Plan)</dt>
                <dd>
                  <Link href="/express/checkout?journey=upgrade-device" passHref={true}>
                    <a>/express/checkout</a>
                  </Link>
                </dd>
                <dt>Confirmation (Phone and Plan)</dt>
                <dd>
                  <Link href="/express/confirm?journey=upgrade-device" passHref={true}>
                    <a>/express/confirm</a>
                  </Link>
                </dd>
                <dt>Confirmation (SIMO)</dt>
                <dd>
                  <Link href="/express/confirm?journey=upgrade-plan" passHref={true}>
                    <a>/express/confirm</a>
                  </Link>
                </dd>
                <dt>Confirmation (RPC)</dt>
                <dd>
                  <Link href="/express/confirm?journey=change-plan" passHref={true}>
                    <a>/express/confirm</a>
                  </Link>
                </dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen title="OTP">
              <DescriptionList>
                <dt>OTP page - Device and Plan</dt>
                <dd>
                  <Link href="/express/otp?journey=upgrade-device" passHref={true}>
                    <a>/express/otp?journey=upgrade-device</a>
                  </Link>
                </dd>
                <dt>OTP page - SIMO</dt>
                <dd>
                  <Link href="/express/otp?journey=upgrade-plan" passHref={true}>
                    <a>/express/otp?journey=upgrade-plan</a>
                  </Link>
                </dd>
                <dt>OTP page - RPC</dt>
                <dd>
                  <Link href="/express/otp?journey=change-plan" passHref={true}>
                    <a>/express/otp?journey=change-plan</a>
                  </Link>
                </dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen title="PTK">
              <DescriptionList>
                <dt>Postpaid simo with extra param</dt>
                <dd>
                  <Link href="/mobile/sim-only-phone-plans?extra=OnlineBTL" passHref={true}>
                    <a>/mobile/sim-only-phone-plans?extra=OnlineBTL</a>
                  </Link>
                </dd>
                <dt>Postpaid simo with extra param with hero param</dt>
                <dd>
                  <Link href="/mobile/sim-only-phone-plans?extra=OnlineBTL&hero=AU12274" passHref={true}>
                    <a>/mobile/sim-only-phone-plans?extra=OnlineBTL&hero=AU12274</a>
                  </Link>
                </dd>
                <dt>Cart with extra param</dt>
                <dd>
                  <Link href="/cart?extra=OnlineBTL" passHref={true}>
                    <a>/cart?extra=OnlineBTL</a>
                  </Link>
                </dd>
                <dt>Home Internet 4G with extra param</dt>
                <dd>
                  <Link href="/home-internet/4g?extra=OnlineBTL" passHref={true}>
                    <a>/home-internet/4g?extra=OnlineBTL</a>
                  </Link>
                </dd>
                <dt>Home Internet 5G with extra param</dt>
                <dd>
                  <Link href="/home-internet/5g?extra=OnlineBTL" passHref={true}>
                    <a>/home-internet/5g?extra=OnlineBTL</a>
                  </Link>
                </dd>
                <dt>NBN with extra param</dt>
                <dd>
                  <Link href="/home-internet/nbn?extra=OnlineBTL" passHref={true}>
                    <a>/home-internet/nbn?extra=OnlineBTL</a>
                  </Link>
                </dd>
                <dt>Postpaid Plan -iPhone 14 Pro- with extra param</dt>
                <dd>
                  <Link
                    href="/mobile/mobile-phones/apple/iphone-14-pro?capacity=128GB&color=Deep%20Purple&contractTerm=36&step=1&extra=OnlineBTL"
                    passHref={true}
                  >
                    <a>/mobile/mobile-phones/apple/iphone-14-pro?capacity=128GB...extra=OnlineBTL</a>
                  </Link>
                </dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
        <GridCol display="flex" gridColSpan={{ xs: 12, m: 4 }}>
          <Accordion hasSeparator={true} variant="flat">
            <AccordionItemDesktopOpen title="Always on Plan Pages">
              <DescriptionList>
                <dt>SIMO-small</dt>
                <dd>
                  <Link href="/mobile/sim-only-phone-plans/small-plan" passHref={true}>
                    <a>/mobile/sim-only-phone-plans/small-plan</a>
                  </Link>
                </dd>
                <dt>SIMO-medium</dt>
                <dd>
                  <Link href="/mobile/sim-only-phone-plans/medium-plan" passHref={true}>
                    <a>/mobile/sim-only-phone-plans/medium-plan</a>
                  </Link>
                </dd>
                <dt>SIMO-large</dt>
                <dd>
                  <Link href="/mobile/sim-only-phone-plans/large-plan" passHref={true}>
                    <a>/mobile/sim-only-phone-plans/large-plan</a>
                  </Link>
                </dd>
              </DescriptionList>
            </AccordionItemDesktopOpen>
          </Accordion>
        </GridCol>
      </Grid>
    </Section>
  </main>
);

export default Home;
