import * as qs from 'query-string';
import React from 'react';
import styled from 'styled-components';
import { LinkButton } from '@src/components/core/Button';
import Section from '@src/components/core/Section';
import Text from '@src/components/core/Text';
import useAuthentication from '@src/lib/hooks/use-authentication';
import { useClientQuery } from '@src/lib/util/router';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import { media, variantThemeLinkColorsBare } from '@src/lib/util/mixins';
import { Grid, GridCol } from '@src/components/core/Grid';
import SeoHead from '@src/components/vfe/SeoHead';
import useServiceType from '@src/lib/hooks/use-service-type';
import { isUpgradesRoute } from '@src/lib/util/journey';
import { ServiceTypeValue } from '@src/lib/storage/types';
import LogoutErrorModal from '@src/components/vfe/LogoutErrorModal/LogoutErrorModal';

const Backdrop = styled.div`
  flex: 1 0 auto;
  background-color: ${(p) => p.theme.colors.white};

  ${media.m`
    background-image: url(/content/dam/vha/images/generic/authentication-background.jpg);
    background-position: center top;
    background-size: cover;
  `}
`;

const Box = styled.div`
  display: grid;
  grid-template-areas:
    'heading'
    '.'
    'login'
    'home';
  gap: 16px;

  ${media.m`
    justify-content: center;
    gap: 24px;
    max-width: 480px;
    border-radius: ${(p) => p.theme.sizes.borderRadius}px;
    padding: 40px 60px 60px;
    background-color: ${(p) => p.theme.colors.white};
    box-shadow: ${(p) => p.theme.boxShadows.brand};
  `}
`;

const Heading = styled(Text)`
  grid-area: heading;
  justify-self: center;
`;

const LoginButton = styled(LinkButton)`
  grid-area: login;

  ${media.m`
    justify-self: center;
  `}
`;

const HomeLink = styled.a`
  grid-area: home;
  justify-self: center;
  ${variantThemeLinkColorsBare}
`;

const LogoutPage = () => {
  const { isAuthenticated, loading, logout } = useAuthentication();
  const [serviceType] = useServiceType();

  // Ensure that we only request to log out once
  const hasRun = React.useRef(false);
  React.useEffect(() => {
    if (!isAuthenticated || !serviceType || hasRun.current) return;
    hasRun.current = true;

    const route = (() => {
      const { route: routeFromQuery } = qs.parse(window.location.search);
      // If there is already a route param, use it
      if (typeof routeFromQuery === 'string') return routeFromQuery;

      // Otherwise, fall back to document.referrer, and failing that fall back to /another-service
      if (document.referrer === '') return '/another-service';
      const { origin, pathname, search } = new URL(document.referrer, window.location.origin);
      if (origin !== window.location.origin) return '/another-service';
      return `${pathname}${search}`;
    })();

    logout({
      returnTo: `${window.location.origin}${window.location.pathname}?${qs.stringify({
        route,
        serviceType,
      })}`,
    });
  }, [isAuthenticated, logout, serviceType]);

  const query = useClientQuery();
  const route = typeof query?.route === 'string' ? query.route : '/another-service';
  const push = typeof query?.push === 'string' ? query.push : undefined;
  const returnTo = typeof query?.returnTo === 'string' ? query.returnTo : undefined;

  const isUpgrades = isUpgradesRoute(route) || query?.serviceType === ServiceTypeValue.Upgrade;

  return (
    <>
      <SeoHead
        title="You've been logged out"
        aemMetaTags='&lt;link rel="canonical" href="https://www.vodafone.com.au/logout" /&gt;&lt;meta name="robots" content="noindex,nofollow" /&gt;&lt;meta name="description" content="Are you sure that you&apos;d like to logout of upgrades or additional service." /&gt;'
      />
      {(loading || isAuthenticated || !query) && <SpinnerSection />}
      {!loading && !isAuthenticated && query && (
        <Backdrop>
          <Section backgroundColor={false}>
            <Grid>
              <GridCol>
                <Box>
                  <Heading fontSize={{ xs: 'heading3Mobile', m: 'heading3' }} fontFamily="light" textAlign="center">
                    You&apos;ve been logged out
                  </Heading>
                  <LoginButton
                    href={`/auth/login?${qs.stringify({
                      route,
                      serviceType: isUpgrades ? ServiceTypeValue.Upgrade : ServiceTypeValue.AnotherService,
                    })}`}
                  >
                    Log me back in
                  </LoginButton>
                  <HomeLink href="/">Go to Vodafone home</HomeLink>
                </Box>
              </GridCol>
            </Grid>
          </Section>
          <LogoutErrorModal variant={push} path={route} returnTo={returnTo} />
        </Backdrop>
      )}
    </>
  );
};

export default LogoutPage;
