import React from 'react';
import { NextPage, NextPageContext } from 'next';
import { getApiClient } from '@src/lib/api';
import { DeviceEndpoint, DevicesPageResponse } from '@src/lib/api/types';
import WatchesTemplate from '@src/templates/Watches';
import RedirectTemplate from '@src/templates/common/RedirectTemplate';
import PageSpinner from '@src/components/core/PageSpinner';
import { useRouteMeta } from '@src/lib/context/route-meta';
import { previewGetOptionalDate } from '@src/lib/util/preview';
import { redirectFlags } from '@src/lib/context/feature-flags';

interface SmartWatchesPageProps {
  error?: string;
  pageData?: DevicesPageResponse;
}

const SmartWatchesPage: NextPage<SmartWatchesPageProps> = ({ pageData }) => {
  const { isLoading } = useRouteMeta();

  if (pageData) {
    return (
      <PageSpinner active={isLoading}>
        <WatchesTemplate pageData={pageData} redirectFlag={redirectFlags.SMARTWATCH} />
      </PageSpinner>
    );
  }

  return <RedirectTemplate />;
};

SmartWatchesPage.getInitialProps = async (context: NextPageContext) => {
  const { query } = context;
  try {
    const pageData = await getApiClient(context).fetchDevicesPageData({
      date: previewGetOptionalDate(query), // preview mode only, pass optional date parameter
      deviceEndpoint: DeviceEndpoint.WEARABLES,
    });
    return {
      pageData,
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
  } catch (error: any) {
    return { error: error.message };
  }
};

export default SmartWatchesPage;
