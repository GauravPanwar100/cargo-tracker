import React from 'react';
import { NextPage, NextPageContext } from 'next';
import { getApiClient } from '@src/lib/api';
import { QueryKey, buildWearableFromQuery, isQueryFirstStep } from '@src/lib/util/query';
import WatchTemplate from '@src/templates/Watch';
import { BasketRequestItem, CartItemType, CatalogCode, SmartWatchPageResponse } from '@src/lib/api/types';
import useServiceType from '@src/lib/hooks/use-service-type';
import { ServiceTypeValue } from '@src/lib/storage/types';
import { useCustomerEligibility } from '@src/lib/util/customer';
import { withStickyCartProvider } from '@src/lib/context/sticky-cart';
import RedirectTemplate from '@src/templates/common/RedirectTemplate';
import { Journey, JourneyStep } from '@src/components/core/Journey';
import { SmartWatchDetails } from '@src/lib/constants/journeys';
import { isWearableDeviceBasketItem } from '@src/lib/util/cart';
import ExtrasTemplate from '@src/templates/Extras';
import PageSpinner from '@src/components/core/PageSpinner';
import { useRouteMeta } from '@src/lib/context/route-meta';
import AdditionalServicesTitleSection from '@src/templates/AdditionalServices/AdditionalServicesTitleSection';
import { Flag, redirectFlags, useFeatureFlag } from '@src/lib/context/feature-flags';
import { previewGetOptionalDate } from '@src/lib/util/preview';
import { useRouter } from 'next/router';
import StickyCart from '@src/components/vfe/StickyCart';

interface SmartWatchPageProps {
  watchPageData?: SmartWatchPageResponse;
}

const SmartWatchPage: NextPage<SmartWatchPageProps> = ({ watchPageData }) => {
  useServiceType(ServiceTypeValue.AnotherService);
  useCustomerEligibility();
  const { isLoading } = useRouteMeta();
  const { query } = useRouter();
  const disableStickyCartFlag = useFeatureFlag(Flag.DISABLE_SMART_WATCH_JOURNEY_DEVICE_STEP_STICKY_CART);
  if (!watchPageData) {
    // Redirection to smart watch listing page
    const smartWatchListingUrl = '/smart-watches';
    return <RedirectTemplate url={smartWatchListingUrl} />;
  }

  const isFirstStep = isQueryFirstStep(query);
  const hideStickyCart = disableStickyCartFlag?.isLoading || (disableStickyCartFlag?.data && isFirstStep);
  return (
    <>
      <PageSpinner active={isLoading}>
        <AdditionalServicesTitleSection />
        <Journey>
          <JourneyStep
            initialProps={{ pageData: watchPageData }}
            render={({ goToNextStep, hasInitialised, initialProps: { pageData }, step }) => (
              <WatchTemplate
                backHref="/smart-watches"
                catalogCode={CatalogCode.POSTPAID_WEARABLES}
                ctaLabel={pageData.labels.ctaLabel}
                disableCartInteraction={!hasInitialised}
                goToNextStep={goToNextStep}
                nudgeVariant="smartWatch"
                pageData={watchPageData}
                redirectFlag={redirectFlags.SMARTWATCH}
                step={step}
              />
            )}
            step={SmartWatchDetails.WATCH}
          />
          <JourneyStep
            buildCartFromQuery={async (basketItems?: BasketRequestItem[]) => {
              const device = await buildWearableFromQuery({
                catalogCode: CatalogCode.POSTPAID_WEARABLES,
                deviceConfig: watchPageData.deviceConfig,
                deviceDetails: watchPageData.deviceDetails,
                promotions: watchPageData.promotions,
                query,
              });
              return [...(basketItems ?? []), device];
            }}
            getInitialProps={async (basketItems?: BasketRequestItem[]) => {
              const smartWatch = basketItems?.find(isWearableDeviceBasketItem);
              const smartWatchProductCode = smartWatch?.productCode as string;
              const pageData = await getApiClient().fetchExtrasPageData({
                params: [{ catalogCode: CatalogCode.POSTPAID_WEARABLES, productCode: smartWatchProductCode }],
              });
              return { pageData };
            }}
            queryKeysToClearOnPreviousStep={[QueryKey.WATCH]}
            render={({ goToPreviousStep, initialProps: { pageData }, step, stickyCart }) => {
              const productName = stickyCart?.find(isWearableDeviceBasketItem)?.productName;
              const backLabel = productName ? `Back to ${productName}` : `${pageData.pageHeaderData.breadcrumb}`;
              return (
                <ExtrasTemplate
                  backLabel={`${backLabel}`}
                  backOnClick={goToPreviousStep}
                  pageData={pageData}
                  redirectFlag={redirectFlags.SMARTWATCH}
                  step={step}
                />
              );
            }}
            step={SmartWatchDetails.EXTRAS}
            validateQuery={[QueryKey.WATCH]}
          />
        </Journey>
      </PageSpinner>
      {!hideStickyCart && <StickyCart />}
    </>
  );
};

const WrappedSmartWatchPage: NextPage<SmartWatchPageProps> = withStickyCartProvider({
  itemTypes: [CartItemType.SMARTWATCH, CartItemType.EXTRA],
})(SmartWatchPage);

WrappedSmartWatchPage.getInitialProps = async (context: NextPageContext) => {
  const { query } = context;
  const watchId = query[QueryKey.WATCH] as string;

  try {
    const pageData = await getApiClient(context).fetchSmartWatchPageData({
      date: previewGetOptionalDate(query), // preview mode only, pass optional date parameter
      watchId,
    });
    return { key: watchId, watchPageData: pageData };
  } catch {
    return {};
  }
};

export default WrappedSmartWatchPage;
