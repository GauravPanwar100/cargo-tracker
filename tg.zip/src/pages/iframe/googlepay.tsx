/* eslint-disable no-console */
import braintree from 'braintree-web';
import { NextPage } from 'next';
import React from 'react';
import ResizeIframeParentContainer from '@src/components/vfe/ResizeIframeParentContainer';
import Logger from '@src/lib/logger/logger';
import { usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import useLoadExternalScript, { LoadScriptState } from '@src/lib/hooks/use-load-external-script';
import GooglePayPayment from '@src/templates/Payment/GooglePay';
import useBraintreeClient from '@src/lib/hooks/use-braintree-client';
import usePaymentConfiguration from '@src/lib/hooks/use-payment-configuration';

const GOOGLE_PAY_API = 'https://pay.google.com/gp/p/js/pay.js';

const GooglePay: NextPage = () => {
  const { client, deviceData } = useBraintreeClient();
  const postMessage = usePaymentIframePostMessage();
  const loadExternalScriptStatus: LoadScriptState = useLoadExternalScript(GOOGLE_PAY_API);
  const { merchantId } = usePaymentConfiguration('googlePay').data ?? {};
  const [googlePayInstance, setGooglePayInstance] = React.useState<braintree.GooglePayment>();

  const isGooglePayApiLoaded = loadExternalScriptStatus.loaded && !loadExternalScriptStatus.error;

  React.useEffect(() => {
    if (loadExternalScriptStatus.loaded && loadExternalScriptStatus.error) {
      Logger.error('Failed to load Google Pay API', { ucode: 'f77a9fb' });
      postMessage({
        source: 'vfe',
        type: 'VFE_IFRAME_FAILED',
      });
    }
  }, [loadExternalScriptStatus.error, loadExternalScriptStatus.loaded, postMessage]);

  React.useEffect(() => {
    if (!client || !deviceData || !merchantId || !isGooglePayApiLoaded) return;

    braintree.googlePayment
      .create({
        client,
        googlePayVersion: 2,
        googleMerchantId: merchantId,
      })
      .then((gpInstance) => setGooglePayInstance(gpInstance))
      .catch((error) => {
        Logger.error('Failed to create GooglePay instance', { error, ucode: 'fd842f8' });
        postMessage({
          source: 'vfe',
          type: 'VFE_IFRAME_FAILED',
        });
      });
  }, [client, deviceData, isGooglePayApiLoaded, merchantId, postMessage]);

  return (
    <ResizeIframeParentContainer>
      {googlePayInstance && (
        <GooglePayPayment googleMerchantId={merchantId} deviceData={deviceData} googlePayInstance={googlePayInstance} />
      )}
    </ResizeIframeParentContainer>
  );
};

export default GooglePay;
