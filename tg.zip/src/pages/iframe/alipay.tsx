/* eslint-disable no-console */
import braintree from 'braintree-web';
import { NextPage } from 'next';
import React from 'react';
import ResizeIframeParentContainer from '@src/components/vfe/ResizeIframeParentContainer';
import Logger from '@src/lib/logger/logger';
import { usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import useBraintreeClient from '@src/lib/hooks/use-braintree-client';
import AliPayPayment from '@src/templates/Payment/AliPayPayment';
import usePaymentConfiguration from '@src/lib/hooks/use-payment-configuration';
import type { LocalPayment } from 'braintree-web/modules/local-payment';

const AliPay: NextPage = () => {
  const { client, deviceData } = useBraintreeClient();
  const [localPaymentInstance, setLocalPaymentInstance] = React.useState<LocalPayment>();
  const { merchantAccountId } = usePaymentConfiguration('aliPay').data ?? {};

  const postMessage = usePaymentIframePostMessage();

  const setInstance = React.useCallback(
    (paymentInstance) => {
      setLocalPaymentInstance(paymentInstance);
      postMessage({
        source: 'vfe',
        type: 'VFE_IFRAME_READY',
        iframe: 'ALIPAY',
      });
    },
    [postMessage],
  );

  React.useEffect(() => {
    if (!client || !merchantAccountId) return;

    braintree.localPayment
      .create({
        client,
        merchantAccountId,
      })
      .then(
        (paymentInstance) => setInstance(paymentInstance),
        // tokenize
        (error) => {
          Logger.error('Failed to set Braintree localPayment instance', { error, ucode: '2717a52' });
          postMessage({
            source: 'vfe',
            type: 'VFE_IFRAME_FAILED',
          });
        },
      );
  }, [client, merchantAccountId, postMessage, setInstance]);

  return (
    <ResizeIframeParentContainer>
      {client && deviceData && localPaymentInstance && (
        <AliPayPayment deviceData={deviceData} localPaymentInstance={localPaymentInstance} />
      )}
    </ResizeIframeParentContainer>
  );
};

export default AliPay;
