import braintree from 'braintree-web';
import { NextPage } from 'next';
import Head from 'next/head';
import React from 'react';
import { useTheme } from 'styled-components';
import ResizeIframeParentContainer from '@src/components/vfe/ResizeIframeParentContainer';
import Logger from '@src/lib/logger/logger';
import { usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import CardPayment from '@src/templates/Payment/CardPayment';
import { getPaymentIframeHashParams } from '@src/lib/payment/params';
import useBraintreeClient from '@src/lib/hooks/use-braintree-client';
import { Flag, useFeatureFlag } from '@src/lib/context/feature-flags';
import usePaymentConfiguration from '@src/lib/hooks/use-payment-configuration';
import { isThreeDSEnabled } from '@src/lib/payment/3ds';
import { AccountType } from '@src/lib/api/types';

const CCInput: NextPage = () => {
  const [pageTitle, setPageTitle] = React.useState('');
  const { client, deviceData } = useBraintreeClient();

  const [hostedFields, setHostedFields] = React.useState<braintree.HostedFields>();
  const [threeDSecure, setThreeDSecure] = React.useState<braintree.ThreeDSecure>();

  const threeDSPrepaidDisabled = useFeatureFlag(Flag.DISABLE_3DS_PREPAID);
  const threeDSPostpaidDisabled = useFeatureFlag(Flag.DISABLE_3DS_POSTPAID);
  const threeDSPaymentConfig = usePaymentConfiguration('threeDS');

  const postMessage = usePaymentIframePostMessage();

  const theme = useTheme();
  const themeRef = React.useRef(theme);

  React.useEffect(() => {
    if (!client) return;

    const placeholderStyles = {
      color: themeRef.current.colors.anthracite,
    };

    // Wait for all data to load before creating hosted fields
    if (
      threeDSPrepaidDisabled.isLoading ||
      typeof threeDSPrepaidDisabled.data !== 'boolean' ||
      threeDSPostpaidDisabled.isLoading ||
      typeof threeDSPostpaidDisabled.data !== 'boolean' ||
      threeDSPaymentConfig.isLoading
    )
      return;

    const accountType = getPaymentIframeHashParams().accounttype;
    const amount = +getPaymentIframeHashParams().AMOUNT;
    const { amountThresholdPrepaid, amountThresholdPostpaid } = threeDSPaymentConfig.data ?? {};
    const threeDSEnabled = isThreeDSEnabled(
      accountType === AccountType.PREPAY ? !threeDSPrepaidDisabled.data : !threeDSPostpaidDisabled.data,
      amount,
      accountType === AccountType.PREPAY ? amountThresholdPrepaid : amountThresholdPostpaid,
    );

    Promise.all([
      braintree.hostedFields.create({
        client,
        fields: {
          cardholderName: {
            container: '#cc-name',
          },
          number: {
            container: '#cc-number',
          },
          expirationDate: {
            container: '#cc-exp',
            placeholder: 'MM / YY',
          },
          cvv: {
            container: '#cc-csc',
          },
        },
        styles: {
          input: {
            color: themeRef.current.colors.mainColor,
            'font-family': 'Arial, sans-serif',
            'font-size': `${themeRef.current.fontSizes.base}px`,
            'font-weight': 'normal',
            'line-height': `${themeRef.current.lineHeights.base}px`,
          },
          '::placeholder': placeholderStyles,
          '::-webkit-input-placeholder': placeholderStyles,
          ':-moz-placeholder': placeholderStyles,
          '::-moz-placeholder': placeholderStyles,
          ':-ms-input-placeholder': placeholderStyles,
        },
      }),
      threeDSEnabled ? braintree.threeDSecure.create({ client, version: '2-inline-iframe' }) : null,
    ]).then(
      ([hf, threeDS]) => {
        setHostedFields(hf);
        if (threeDS) {
          setThreeDSecure(threeDS);
        }
        postMessage({
          source: 'vfe',
          type: 'VFE_IFRAME_READY',
          iframe: 'CC',
        });
      },
      (error) => {
        Logger.error('Failed to create Braintree HostedFields', { error, ucode: '29e4890' });
        postMessage({
          source: 'vfe',
          type: 'VFE_IFRAME_FAILED',
        });
      },
    );
  }, [
    client,
    postMessage,
    threeDSPaymentConfig.data,
    threeDSPaymentConfig.isLoading,
    threeDSPostpaidDisabled.data,
    threeDSPostpaidDisabled.isLoading,
    threeDSPrepaidDisabled.data,
    threeDSPrepaidDisabled.isLoading,
  ]);

  React.useEffect(() => {
    // if parent is from a different origin this will throw an error
    try {
      const parentDoc = window.parent.document;
      const parentTitle = parentDoc.title;
      setPageTitle(parentTitle);
    } catch (e) {
      setPageTitle('Checkout: Review | Vodafone Australia');
    }
  }, []);

  return (
    <ResizeIframeParentContainer role="form" aria-label="credit card">
      <>
        <Head>
          <title>{pageTitle}</title>
        </Head>
        {client && <CardPayment deviceData={deviceData} hostedFields={hostedFields} threeDSecure={threeDSecure} />}
      </>
    </ResizeIframeParentContainer>
  );
};

export default CCInput;
