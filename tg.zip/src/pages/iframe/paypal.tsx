import braintree from 'braintree-web';
import { NextPage } from 'next';
import React, { useCallback } from 'react';
import Head from 'next/head';
import ResizeIframeParentContainer from '@src/components/vfe/ResizeIframeParentContainer';
import Logger from '@src/lib/logger/logger';
import { ReceivedMessageType, usePaymentIframePostMessage } from '@src/lib/payment/postMessage';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import PayPalPayment from '@src/templates/Payment/PayPalPayment';
import useBraintreeClient from '@src/lib/hooks/use-braintree-client';
import { PaypalSTCRequest } from '@src/lib/api/types';
import { getApiClient } from '@src/lib/api';
import { getPaymentIframeHashParams } from '@src/lib/payment/params';

const PayPal: NextPage = () => {
  const [pageTitle, setPageTitle] = React.useState('');
  const [details, setDetails] = React.useState<Extract<ReceivedMessageType, { type: 'CUSTOMER_DETAILS' }>['payload']>();
  const [clientMetadataId, setClientMetadataId] = React.useState<string>('');

  // Get customer details to extract phone number for msisdn
  const postMessage = usePaymentIframePostMessage((data) => {
    switch (data.type) {
      case 'CUSTOMER_DETAILS':
        // User Phone number for STC ClientMetadataId request and Customer details to be sent for Paypal charge transaction
        setDetails(data.payload);
        break;

      default:
      // do nothing
    }
  });

  // API call to request the clientMetadataId
  const getClientMetadataId = useCallback(
    async (msisdn: string, orderId: string) => {
      const ApiClient = getApiClient();
      let id = '';
      const paypalStcRequest: PaypalSTCRequest = { msisdn, orderId };

      try {
        const response = await ApiClient.getPaypalSTCClientMetadataId(paypalStcRequest);
        id = response.clientMetadataId;
      } catch (error) {
        Logger.error('Failed to get Paypal clientMetadataId', { error, ucode: 'ec04bcb' });
        postMessage({
          source: 'vfe',
          type: 'VFE_IFRAME_FAILED',
        });
      }
      return id;
    },
    [postMessage],
  );

  // Get the clientMetadata ID
  React.useEffect(() => {
    const fetchClientMetadataId = async (msisdn: string, orderId: string) => {
      const id = await getClientMetadataId(msisdn, orderId);
      setClientMetadataId(id);
    };
    const { FLOW_TYPE, ORDER_ID } = getPaymentIframeHashParams();
    const isPrepaidTransaction = FLOW_TYPE === 'CHARGE';

    if (isPrepaidTransaction && details?.phone) {
      fetchClientMetadataId(details?.phone, ORDER_ID);
    }
  }, [details?.phone, getClientMetadataId]);

  const { client, deviceData } = useBraintreeClient(clientMetadataId, true);

  const [paypalCheckout, setPaypalCheckout] = React.useState<braintree.PayPalCheckout>();

  const setCheckout = useCallback(
    (paypalCheckoutInstance) => {
      setPaypalCheckout(paypalCheckoutInstance);
      postMessage({
        source: 'vfe',
        type: 'VFE_IFRAME_READY',
        iframe: 'PAYPAL',
      });
    },
    [postMessage],
  );

  React.useEffect(() => {
    if (!client) return;

    braintree.paypalCheckout
      .create({
        client,
      })
      .then(
        (paypalCheckoutInstance) => setCheckout(paypalCheckoutInstance),
        (error) => {
          Logger.error('Failed to create Braintree PayPal Checkout component', { error, ucode: '094b283' });
          postMessage({
            source: 'vfe',
            type: 'VFE_IFRAME_FAILED',
          });
        },
      );
  }, [client, postMessage, setCheckout]);

  React.useEffect(() => {
    // if parent is from a different origin this will throw an error
    try {
      const parentDoc = window.parent.document;
      const parentTitle = parentDoc.title;
      setPageTitle(parentTitle);
    } catch (e) {
      setPageTitle('Checkout: Review | Vodafone Australia');
    }
  }, []);

  return (
    <ResizeIframeParentContainer aria-label="paypal">
      {!client && <SpinnerSection />}
      <>
        <Head>
          <title>{pageTitle}</title>
        </Head>
        {client && deviceData && details && (
          <PayPalPayment
            customerDetails={details}
            deviceData={deviceData}
            paypalCheckout={paypalCheckout}
            clientMetadataId={clientMetadataId}
          />
        )}
      </>
    </ResizeIframeParentContainer>
  );
};

export default PayPal;
