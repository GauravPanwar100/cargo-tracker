import { NextPage } from 'next';
import braintree from 'braintree-web';
import React, { useCallback, useEffect, useState } from 'react';
import Logger from '@src/lib/logger/logger';
import ApplePayButton from '@src/templates/Payment/ApplePayButton';
import SpinnerSection from '@src/templates/common/SpinnerSection';
import ResizeIframeParentContainer from '@src/components/vfe/ResizeIframeParentContainer';
import useBraintreeClient from '@src/lib/hooks/use-braintree-client';
import { usePaymentIframePostMessage } from '@src/lib/payment/postMessage';

const ApplePay: NextPage = () => {
  const { client, deviceData } = useBraintreeClient();
  const [applePayInstance, setApplePayInstance] = useState<braintree.ApplePay>();
  const [isApplePaySupported, setApplePaySupported] = useState(false);

  const postMessage = usePaymentIframePostMessage();

  const initApplePay = useCallback(async () => {
    try {
      const instance = await braintree.applePay.create({ client: client! });

      setApplePayInstance(instance);
      postMessage({
        source: 'vfe',
        type: 'VFE_IFRAME_READY',
        iframe: 'APPLE_PAY',
      });
    } catch (error) {
      Logger.error('Failed to create Apple Pay iframe', { error, ucode: 'c06b703' });
      postMessage({
        source: 'vfe',
        type: 'VFE_IFRAME_FAILED',
      });
    }
  }, [client, postMessage]);

  useEffect(() => {
    if (!client) {
      return;
    }
    if (!window.ApplePaySession) {
      Logger.error('This device does not support Apple Pay');
      postMessage({
        source: 'vfe',
        type: 'VFE_IFRAME_FAILED',
      });
      return;
    }
    // @ts-ignore
    if (!window.ApplePaySession.canMakePayments()) {
      Logger.error('This device is not capable of making Apple Pay payments');
      postMessage({
        source: 'vfe',
        type: 'VFE_IFRAME_FAILED',
      });
      return;
    }

    setApplePaySupported(true);

    initApplePay();
  }, [client, initApplePay, postMessage]);

  return (
    <ResizeIframeParentContainer>
      {!client && <SpinnerSection />}
      {applePayInstance && isApplePaySupported && (
        <ApplePayButton deviceData={deviceData} applePayInstance={applePayInstance} />
      )}
    </ResizeIframeParentContainer>
  );
};

export default ApplePay;
