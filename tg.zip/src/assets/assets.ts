const AssetsLinks = {
  AEM_ASSET_BACKGROUND_IMG: 'https://www.vodafone.com.au/images/generic/authentication-background.jpg',
  AEM_ASSET_VODAFONE_LOGO: 'https://www.vodafone.com.au/images/icons/VF-logo-desktop.svg',
  AEM_ASSET_INFO_CIRCLE: 'https://www.vodafone.com.au/images/icons/info-circle.svg',
  AEM_ASSET_WARNING_LOGO: 'https://www.vodafone.com.au/images/icons/warning-filled-white.svg',
  AEM_ASSET_GREEN_TICK: 'https://www.vodafone.com.au/images/icons/tick-or-solved-green.svg',

  AEM_ASSET_VODAFONE_LIGHT_FONT:
    'https://www.vodafone.com.au/etc.clientlibs/vha/clientlibs/clientlib-base/css/resources/vodafone-light.woff',
  AEM_ASSET_VODAFONE_REGULAR_FONT:
    'https://www.vodafone.com.au/etc.clientlibs/vha/clientlibs/clientlib-base/css/resources/vodafone-regular.woff',
  AEM_ASSET_VODAFONE_REGULAR_BOLD_FONT:
    'https://www.vodafone.com.au/etc.clientlibs/vha/clientlibs/clientlib-base/css/resources/vodafone-bold.woff',

  AEM_ASSET_MOBILE_RED: 'https://www.vodafone.com.au/images/icons/mobile-red.svg',
  AEM_ASSET_LANDLINE_OR_CALL_RED: 'https://www.vodafone.com.au/images/icons/landline-or-call-red.svg',
  AEM_ASSET_STORE_RED: 'https://www.vodafone.com.au/images/icons/vodafone-store-red.svg',
};

export { AssetsLinks };
